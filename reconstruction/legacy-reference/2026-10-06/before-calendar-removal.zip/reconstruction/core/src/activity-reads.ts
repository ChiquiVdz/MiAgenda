import type { Prisma } from "../generated/client.ts";
import { activityInclude, activityView } from "./views.ts";

const readInclude = {
  schedule: true, mealStep: true,
  occurrence: activityInclude.occurrence, parent: activityInclude.parent,
  children: { ...activityInclude.children, include: { schedule: true, mealStep: true } },
} satisfies Prisma.ActivityInclude;

/** Load the common tree once and hydrate kitchen metadata only when present. */
export async function readActivities(tx: Prisma.TransactionClient, userId: string,
  options: Pick<Prisma.ActivityFindManyArgs, "where" | "orderBy" | "take">) {
  const rows = await tx.activity.findMany({ ...options,
    where: { AND: [options.where ?? {}, { userId }] }, include: readInclude });
  const recipeIds = [...new Set(rows.flatMap(row => [row, ...row.children])
    .flatMap(row => row.mealStep ? [row.mealStep.mealRecipeId] : []))];
  const recipes = recipeIds.length ? await tx.mealRecipe.findMany({ where: { userId, id: { in: recipeIds } },
    select: { id: true, blockId: true, cookedServings: true,
      recipeRevision: { select: { baseServings: true, steps: { select: { stepKey: true, quantityForBaseServings: true } } } } } }) : [];
  const recipeById = new Map(recipes.map(recipe => [recipe.id, recipe]));
  const mealIds = rows.filter(row => row.kind === "meal").map(row => row.id);
  const blocks = mealIds.length ? await tx.mealBlock.findMany({ where: { userId, activityId: { in: mealIds } },
    select: { activityId: true, completions: activityInclude.mealBlock.select.completions } }) : [];
  const blockById = new Map(blocks.map(block => [block.activityId, block]));
  function mealStep(step: typeof rows[number]["mealStep"]) {
    if (!step) return null;
    const recipe = recipeById.get(step.mealRecipeId);
    if (!recipe) throw new Error("La relación del paso de comida no está disponible.");
    return { ...step, mealRecipe: recipe };
  }
  return rows.map(row => activityView({ ...row, mealStep: mealStep(row.mealStep),
    mealBlock: blockById.get(row.id) ?? null,
    children: row.children.map(child => ({ ...child, mealStep: mealStep(child.mealStep) })) }));
}
