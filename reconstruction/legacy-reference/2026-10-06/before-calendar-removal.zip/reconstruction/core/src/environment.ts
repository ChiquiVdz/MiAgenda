import { readFileSync, existsSync } from "node:fs";
import { resolve, basename } from "node:path";
import { parse } from "dotenv";

function fileValues(relative: string): Record<string, string> {
  // Runtime paths: never let a bundler import credentials as a build asset.
  const cwd = process.cwd();
  const core = basename(cwd) === "core" && basename(resolve(cwd, "..")) === "reconstruction"
    ? cwd : resolve(cwd, "reconstruction/core");
  const path = resolve(core, "src", relative);
  return existsSync(path) ? parse(readFileSync(path)) : {};
}

/** Read only the isolated variable; never fall back to the application's DB. */
export function coreDatabaseUrl(): string {
  const raw = process.env.MIAGENDA_CORE_DATABASE_URL ??
    fileValues("../.env.local").MIAGENDA_CORE_DATABASE_URL;
  if (!raw) throw new Error("Falta MIAGENDA_CORE_DATABASE_URL en reconstruction/core/.env.local.");
  let target: URL;
  try { target = new URL(raw); } catch { throw new Error("La conexión del núcleo no es una URL válida."); }
  if (!["postgresql:", "postgres:"].includes(target.protocol) ||
    decodeURIComponent(target.pathname) !== "/miagenda_core") {
    throw new Error("El núcleo exige una base independiente llamada miagenda_core.");
  }
  const current = process.env.DATABASE_URL ?? fileValues("../../../.env.local").DATABASE_URL;
  if (current) {
    let old: URL;
    try { old = new URL(current); } catch { throw new Error("No se pudo comprobar el aislamiento de la base actual."); }
    // Refuse the same database even if hosts differ (pooled/direct/branch alias).
    if (decodeURIComponent(old.pathname) === decodeURIComponent(target.pathname)) {
      throw new Error("La base nueva debe tener un nombre diferente al de la aplicación actual.");
    }
  }
  target.searchParams.delete("uselibpqcompat");
  target.searchParams.set("sslmode", "verify-full");
  return target.toString();
}
