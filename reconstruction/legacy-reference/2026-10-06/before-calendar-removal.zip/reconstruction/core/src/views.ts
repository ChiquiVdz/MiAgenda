import type { Prisma } from "../generated/client.ts";

export const activityInclude = {
  schedule: true,
  mealStep: { select: { role: true, optional:true, ingredientNameSnapshot:true, unitSnapshot:true, quantityPerServing:true, equivalent:true, sourceStepKey:true, mealRecipe: { select: { blockId: true, cookedServings:true, recipeRevision:{select:{baseServings:true,steps:{select:{stepKey:true,quantityForBaseServings:true}}}} } } } },
  mealBlock: { select: { completions: { orderBy:[{createdAt:"desc" as const},{id:"desc" as const}],take:1,select:{optionalSteps:true} } } },
  occurrence: { include: { series: { select: { revision: true } } } },
  parent: { select: { occurrence: { include: { series: { select: { revision: true } } } } } },
  children: {
    where: { lifecycle: "active" as const },
    orderBy: [{ position: "asc" as const }, { id: "asc" as const }],
    include: { schedule: true, mealStep: { select: { role: true, optional:true, ingredientNameSnapshot:true, unitSnapshot:true, quantityPerServing:true, equivalent:true, sourceStepKey:true, mealRecipe: { select: { blockId: true, cookedServings:true, recipeRevision:{select:{baseServings:true,steps:{select:{stepKey:true,quantityForBaseServings:true}}}} } } } } },
  },
} satisfies Prisma.ActivityInclude;

type Row = Prisma.ActivityGetPayload<{ include: typeof activityInclude }>;
type ChildRow = Row["children"][number];
type ScheduleRow = NonNullable<Row["schedule"]>;

function scheduleView(schedule: ScheduleRow | null) {
  if (!schedule) return null;
  return {
    calendarId: schedule.calendarId,
    mode: schedule.mode,
    timeZone: schedule.timeZone,
    startsAt: schedule.startsAt?.toISOString() ?? null,
    endsAt: schedule.endsAt?.toISOString() ?? null,
    startDate: schedule.startDate?.toISOString().slice(0, 10) ?? null,
    endDate: schedule.endDate?.toISOString().slice(0, 10) ?? null,
  };
}
function itemView(activity: Row | ChildRow, inherited?: Row["occurrence"]) {
  const occurrence = ("occurrence" in activity ? activity.occurrence : null) ?? ("parent" in activity ? activity.parent?.occurrence : inherited);
  const ingredientStep = activity.mealStep?.mealRecipe.recipeRevision.steps.find(step => step.stepKey === activity.mealStep?.sourceStepKey);
  const baseServings = activity.mealStep?.mealRecipe.recipeRevision.baseServings;
  return {
    id: activity.id, kind: activity.kind, title: activity.title,
    ...(activity.mealStep ? { mealRole: activity.mealStep.role, mealOptional:activity.mealStep.optional, mealBlockId: activity.mealStep.mealRecipe.blockId, mealIngredient: activity.mealStep.ingredientNameSnapshot ? { name:activity.mealStep.ingredientNameSnapshot, unit:activity.mealStep.unitSnapshot, quantity:ingredientStep?.quantityForBaseServings && baseServings ? ingredientStep.quantityForBaseServings.mul(activity.mealStep.mealRecipe.cookedServings).div(baseServings).toDecimalPlaces(3, 0).toString() : null, equivalent:activity.mealStep.equivalent, cookedServings:activity.mealStep.mealRecipe.cookedServings.toString() } : null } : {}),
    ...("mealBlock" in activity && activity.mealBlock ? {lastMealOptionals:Array.isArray(activity.mealBlock.completions[0]?.optionalSteps)?(activity.mealBlock.completions[0].optionalSteps as unknown[]).filter((id):id is string=>typeof id==="string"):[]} : {}),
    description: activity.description, parentId: activity.parentId,
    position: activity.position, revision: activity.revision,
    stepKeyId: activity.stepKeyId,
    completedAt: activity.completedAt?.toISOString() ?? null,
    keep: activity.keep, highlighted: activity.highlighted,
    createdAt: activity.createdAt.toISOString(), updatedAt: activity.updatedAt.toISOString(),
    schedule: scheduleView(activity.schedule),
    recurrence: occurrence ? {
      seriesId: occurrence.seriesId, ordinal: Number(occurrence.ordinal), seriesRevision: occurrence.series.revision, virtual: false,
    } : null,
  };
}
export function activityView(activity: Row) {
  return { ...itemView(activity), children: activity.children.map(child => itemView(child, activity.occurrence ?? activity.parent?.occurrence)) };
}
export type ActivityView = ReturnType<typeof activityView>;
export type CommandResult = {
  activities: ActivityView[];
  removedIds: string[];
  calendars: { id: string; name: string; color: string; revision: number }[];
  dataRevision: string;
};
