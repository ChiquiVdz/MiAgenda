// Reentrant, additive preparation only. No Google writes or application cutover.
require('dotenv').config({ path: ['.env.local', '.env'], quiet: true });
const { Client } = require('pg');
const { randomUUID } = require('node:crypto');
const id = () => randomUUID().replaceAll('-', '');

async function main() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  const counts = { usersPrepared: 0, usersDeferred: 0, inboxMapped: 0, overlaysMapped: 0, receiptsDeferred: 0 };
  try {
    const users = (await client.query('SELECT id FROM users ORDER BY id')).rows;
    for (const user of users) {
      await client.query('BEGIN');
      try {
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [user.id]);
        const blockers = (await client.query(`SELECT
          EXISTS(SELECT 1 FROM inbox_items WHERE user_id=$1 AND transfer_payload IS NOT NULL)
          OR EXISTS(SELECT 1 FROM recurrence_changes WHERE user_id=$1 AND finished_at IS NULL)
          OR EXISTS(SELECT 1 FROM scheduled_subtasks WHERE user_id=$1 AND (NOT active OR pending_payload IS NOT NULL))
          OR EXISTS(SELECT 1 FROM scheduled_subtasks c JOIN scheduled_subtasks p ON c.user_id=p.user_id
            AND c.parent_calendar_id=p.google_calendar_id AND c.parent_event_id=p.google_event_id WHERE c.user_id=$1)
          AS blocked`, [user.id])).rows[0];
        if (blockers.blocked) {
          await client.query('ROLLBACK'); counts.usersDeferred++; continue;
        }
        async function source(source, sourceId, activityId) {
          const old = (await client.query(`SELECT activity_id FROM activity_legacy_sources
            WHERE user_id=$1 AND source=$2 AND source_id=$3`, [user.id, source, sourceId])).rows[0];
          if (old && old.activity_id !== activityId) throw new Error('IdentityConflict');
          if (!old) await client.query(`INSERT INTO activity_legacy_sources(id,activity_id,user_id,source,source_id)
            VALUES($1,$2,$3,$4,$5)`, [id(), activityId, user.id, source, sourceId]);
        }
        async function identity(preferred, sourceName, sourceId, calendarId, eventId) {
          const mapped = (await client.query(`SELECT activity_id FROM activity_legacy_sources
            WHERE user_id=$1 AND source=$2 AND source_id=$3`, [user.id, sourceName, sourceId])).rows[0];
          const linked = calendarId && eventId ? (await client.query(`SELECT activity_id FROM activity_calendar_links
            WHERE user_id=$1 AND google_calendar_id=$2 AND google_event_id=$3`, [user.id, calendarId, eventId])).rows[0] : null;
          if (mapped && linked && mapped.activity_id !== linked.activity_id) throw new Error('IdentityConflict');
          let activityId = mapped?.activity_id || linked?.activity_id;
          if (!activityId) {
            activityId = preferred;
            if ((await client.query('SELECT 1 FROM activities WHERE id=$1', [activityId])).rowCount) activityId = id();
            // Deliberately omit text/progress: legacy remains the sole authority.
            await client.query(`INSERT INTO activities(id,user_id,kind,lifecycle,updated_at)
              VALUES($1,$2,'task','staged',CURRENT_TIMESTAMP)`, [activityId, user.id]);
          }
          const activity = (await client.query('SELECT kind,lifecycle FROM activities WHERE id=$1 AND user_id=$2', [activityId, user.id])).rows[0];
          if (!activity || activity.kind !== 'task' || activity.lifecycle !== 'staged') throw new Error('GroupAlreadyActivated');
          await source(sourceName, sourceId, activityId);
          if (calendarId && eventId && !linked) {
            // Google existence and cache must be refreshed before activation.
            await client.query(`INSERT INTO activity_calendar_links(id,activity_id,user_id,google_calendar_id,google_event_id,state,updated_at)
              VALUES($1,$2,$3,$4,$5,'pending',CURRENT_TIMESTAMP)`, [id(), activityId, user.id, calendarId, eventId]);
          }
          return activityId;
        }
        const overlays = (await client.query(`SELECT e.id,e.google_calendar_id,e.google_event_id,
          (SELECT i.id FROM inbox_items i WHERE i.user_id=e.user_id AND i.transferred_at IS NOT NULL
            AND i.google_calendar_id=e.google_calendar_id AND i.google_event_id=e.google_event_id
            ORDER BY i.created_at,i.id LIMIT 1) AS inbox_id
          FROM event_overlays e WHERE e.user_id=$1 AND e.kind <> 'meal'
          AND NOT EXISTS(SELECT 1 FROM scheduled_subtasks s WHERE s.user_id=e.user_id
            AND s.google_calendar_id=e.google_calendar_id AND s.google_event_id=e.google_event_id)
          ORDER BY e.created_at,e.id`, [user.id])).rows;
        for (const overlay of overlays) {
          const activityId = await identity(overlay.inbox_id || overlay.id, 'event_overlay', overlay.id, overlay.google_calendar_id, overlay.google_event_id);
          if (overlay.inbox_id) await source('inbox_item', overlay.inbox_id, activityId);
          counts.overlaysMapped++;
        }
        const inbox = (await client.query('SELECT * FROM inbox_items WHERE user_id=$1 ORDER BY created_at,id', [user.id])).rows;
        for (const item of inbox) {
          if (item.transferred_at) {
            const link = (await client.query(`SELECT activity_id FROM activity_calendar_links WHERE user_id=$1
              AND google_calendar_id=$2 AND google_event_id=$3`, [user.id, item.google_calendar_id, item.google_event_id])).rows[0];
            if (link) { await source('inbox_item', item.id, link.activity_id); counts.inboxMapped++; }
            else counts.receiptsDeferred++; // Never invent an active event from an old receipt.
          } else {
            await identity(item.id, 'inbox_item', item.id, null, null); counts.inboxMapped++;
          }
        }
        await client.query('COMMIT'); counts.usersPrepared++;
      } catch (error) { await client.query('ROLLBACK'); throw error; }
    }
    console.log(JSON.stringify(counts, null, 2));
  } finally { await client.end(); }
}
main().catch((error) => {
  const safeReason = ['IdentityConflict', 'GroupAlreadyActivated'].includes(error.message) ? error.message : error.code || error.name;
  console.error('Preparación no completada:', safeReason);
  process.exitCode = 1;
});
