// Read-only inventory. Never print titles, credentials, tokens or user identities.
require('dotenv').config({ path: ['.env.local', '.env'], quiet: true });
const { Client } = require('pg');

async function main() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  try {
    await client.query('BEGIN READ ONLY');
    const { rows } = await client.query(`SELECT
      (SELECT count(*) FROM users)::int AS users,
      (SELECT count(*) FROM inbox_items WHERE transferred_at IS NULL)::int AS inbox_active,
      (SELECT count(*) FROM inbox_items WHERE transferred_at IS NOT NULL)::int AS inbox_receipts,
      (SELECT count(*) FROM inbox_items WHERE transfer_payload IS NOT NULL)::int AS inbox_pending,
      (SELECT count(*) FROM event_overlays WHERE kind <> 'meal')::int AS task_overlays,
      (SELECT count(*) FROM event_overlays WHERE kind = 'meal')::int AS meal_overlays,
      (SELECT count(*) FROM scheduled_subtasks)::int AS scheduled_children,
      (SELECT count(*) FROM scheduled_subtasks WHERE NOT active OR pending_payload IS NOT NULL)::int AS pending_children,
      (SELECT count(*) FROM recurrence_changes WHERE finished_at IS NULL)::int AS pending_series_changes,
      (SELECT count(*) FROM scheduled_subtasks child JOIN scheduled_subtasks parent
        ON child.user_id = parent.user_id AND child.parent_calendar_id = parent.google_calendar_id
        AND child.parent_event_id = parent.google_event_id)::int AS nested_children,
      (SELECT count(*) FROM inbox_items i JOIN event_overlays e
        ON i.user_id = e.user_id AND i.google_calendar_id = e.google_calendar_id
        AND i.google_event_id = e.google_event_id WHERE i.transferred_at IS NOT NULL)::int AS matching_receipts,
      (SELECT count(*) FROM (SELECT user_id, google_calendar_id, google_event_id FROM inbox_items
        WHERE google_calendar_id IS NOT NULL AND google_event_id IS NOT NULL
        GROUP BY user_id, google_calendar_id, google_event_id HAVING count(*) > 1) duplicates)::int AS duplicate_receipts`);
    console.log(JSON.stringify(rows[0], null, 2));
    await client.query('COMMIT');
  } finally { await client.end(); }
}
main().catch((error) => {
  console.error('Inventario no completado:', error.code || error.name);
  process.exitCode = 1;
});
