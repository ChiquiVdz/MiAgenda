ALTER TABLE "event_overlays" ADD COLUMN "checklist" JSONB;
CREATE TABLE "activity_templates" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "user_id" TEXT NOT NULL REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "name" VARCHAR(150) NOT NULL,
  "steps" JSONB NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL
);
CREATE INDEX "activity_templates_user_id_name_idx" ON "activity_templates"("user_id", "name");
CREATE TABLE "activity_checklists" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "user_id" TEXT NOT NULL REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "google_calendar_id" TEXT NOT NULL,
  "google_event_id" TEXT NOT NULL,
  "template_id" TEXT REFERENCES "activity_templates"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  "versions" JSONB NOT NULL
);
CREATE UNIQUE INDEX "activity_checklists_user_id_google_calendar_id_google_event_id_key" ON "activity_checklists"("user_id", "google_calendar_id", "google_event_id");
CREATE INDEX "activity_checklists_template_id_idx" ON "activity_checklists"("template_id");
