ALTER TABLE "meal_plans" ADD COLUMN "cooked_servings" INTEGER,
 ADD COLUMN "cooking_enabled" BOOLEAN NOT NULL DEFAULT true,
 ADD COLUMN "scheduled_at" TIMESTAMP(3),
 ADD COLUMN "event_missing" BOOLEAN NOT NULL DEFAULT false;
UPDATE "meal_plans" SET "cooked_servings" = "servings";
ALTER TABLE "meal_plans" ALTER COLUMN "cooked_servings" SET NOT NULL;
ALTER TABLE "meal_plan_ingredients" ADD COLUMN "quantity_per_serving" DECIMAL(12,3);
UPDATE "meal_plan_ingredients" AS i SET "quantity_per_serving" = i."required_quantity" / m."servings"
 FROM "meal_plans" AS m WHERE i."meal_plan_id" = m."id";
ALTER TABLE "meal_plan_ingredients" ALTER COLUMN "quantity_per_serving" SET NOT NULL;
CREATE TABLE "cooked_batches" (
 "id" TEXT PRIMARY KEY, "user_id" TEXT NOT NULL, "recipe_key" TEXT NOT NULL,
 "recipe_name" VARCHAR(150) NOT NULL, "origin_meal_plan_id" TEXT,
 "servings" INTEGER NOT NULL CHECK ("servings" > 0), "cooked_at" TIMESTAMP(3) NOT NULL,
 FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE,
 FOREIGN KEY ("origin_meal_plan_id") REFERENCES "meal_plans"("id") ON DELETE SET NULL
);
CREATE TABLE "portion_uses" (
 "id" TEXT PRIMARY KEY, "batch_id" TEXT NOT NULL, "meal_plan_id" TEXT,
 "servings" INTEGER NOT NULL CHECK ("servings" > 0),
 FOREIGN KEY ("batch_id") REFERENCES "cooked_batches"("id") ON DELETE RESTRICT,
 FOREIGN KEY ("meal_plan_id") REFERENCES "meal_plans"("id") ON DELETE SET NULL
);
CREATE INDEX "cooked_batches_user_id_recipe_key_cooked_at_idx" ON "cooked_batches"("user_id", "recipe_key", "cooked_at");
CREATE INDEX "cooked_batches_origin_meal_plan_id_idx" ON "cooked_batches"("origin_meal_plan_id");
CREATE INDEX "portion_uses_meal_plan_id_idx" ON "portion_uses"("meal_plan_id");
CREATE UNIQUE INDEX "portion_uses_batch_id_meal_plan_id_key" ON "portion_uses"("batch_id", "meal_plan_id");
