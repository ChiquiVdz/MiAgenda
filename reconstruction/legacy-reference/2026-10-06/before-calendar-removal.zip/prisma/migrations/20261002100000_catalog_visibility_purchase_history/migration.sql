ALTER TABLE "users" ADD COLUMN "hidden_ingredient_ids" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];
DROP INDEX "shopping_list_items_shopping_list_id_ingredient_id_key";
