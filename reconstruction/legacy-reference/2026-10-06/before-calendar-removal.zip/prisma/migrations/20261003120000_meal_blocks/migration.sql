ALTER TABLE "users" ADD COLUMN "meal_eating_minutes" INTEGER NOT NULL DEFAULT 20,
  ADD COLUMN "meal_washing_minutes" INTEGER NOT NULL DEFAULT 10;
ALTER TABLE "event_overlays"
  ADD COLUMN "meal_block_configured" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN "meal_cooking_enabled" BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN "meal_eating_enabled" BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN "meal_washing_enabled" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN "meal_eating_minutes" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "meal_washing_minutes" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "meal_duration_override" INTEGER;
ALTER TABLE "meal_plans" ADD COLUMN "preparation_minutes" INTEGER NOT NULL DEFAULT 45;
UPDATE "meal_plans" SET "preparation_minutes" = "duration_minutes";
DROP INDEX "meal_plans_overlay_id_key";
DROP INDEX "meal_plans_user_id_google_calendar_id_google_event_id_key";
CREATE INDEX "meal_plans_overlay_id_idx" ON "meal_plans"("overlay_id");
CREATE INDEX "meal_plans_user_id_google_calendar_id_google_event_id_idx" ON "meal_plans"("user_id", "google_calendar_id", "google_event_id");
