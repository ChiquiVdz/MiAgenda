ALTER TABLE "event_overlays" ADD COLUMN "highlighted" BOOLEAN NOT NULL DEFAULT false;
CREATE INDEX "event_overlays_user_id_highlighted_idx" ON "event_overlays"("user_id", "highlighted");
