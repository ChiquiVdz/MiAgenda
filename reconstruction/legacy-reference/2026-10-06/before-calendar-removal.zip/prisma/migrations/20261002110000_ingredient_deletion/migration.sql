ALTER TABLE "users" ADD COLUMN "deleted_ingredient_ids" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];
