-- CreateEnum
CREATE TYPE "activity_kind" AS ENUM ('task', 'meal');

-- CreateEnum
CREATE TYPE "activity_lifecycle" AS ENUM ('staged', 'visible', 'retired');

-- CreateEnum
CREATE TYPE "activity_link_state" AS ENUM ('pending', 'confirmed', 'missing', 'retired');

-- CreateTable
CREATE TABLE "activities" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "kind" "activity_kind" NOT NULL DEFAULT 'task',
    "lifecycle" "activity_lifecycle" NOT NULL DEFAULT 'staged',
    "title" TEXT,
    "description" TEXT,
    "parent_id" TEXT,
    "position" INTEGER NOT NULL DEFAULT 0,
    "completed_at" TIMESTAMP(3),
    "keep" BOOLEAN NOT NULL DEFAULT false,
    "highlighted" BOOLEAN NOT NULL DEFAULT false,
    "revision" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "activities_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "activity_calendar_links" (
    "id" TEXT NOT NULL,
    "activity_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "google_calendar_id" TEXT NOT NULL,
    "google_event_id" TEXT NOT NULL,
    "state" "activity_link_state" NOT NULL DEFAULT 'pending',
    "etag" TEXT,
    "start_snapshot" TIMESTAMP(3),
    "end_snapshot" TIMESTAMP(3),
    "all_day" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "activity_calendar_links_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "activity_legacy_sources" (
    "id" TEXT NOT NULL,
    "activity_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "source" VARCHAR(30) NOT NULL,
    "source_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "activity_legacy_sources_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "activities_user_id_lifecycle_completed_at_idx" ON "activities"("user_id", "lifecycle", "completed_at");

-- CreateIndex
CREATE INDEX "activities_user_id_parent_id_position_idx" ON "activities"("user_id", "parent_id", "position");

-- CreateIndex
CREATE UNIQUE INDEX "activities_id_user_id_key" ON "activities"("id", "user_id");

-- CreateIndex
CREATE UNIQUE INDEX "activity_calendar_links_activity_id_key" ON "activity_calendar_links"("activity_id");

-- CreateIndex
CREATE UNIQUE INDEX "activity_calendar_links_activity_id_user_id_key" ON "activity_calendar_links"("activity_id", "user_id");

-- CreateIndex
CREATE UNIQUE INDEX "activity_calendar_links_user_id_google_calendar_id_google_e_key" ON "activity_calendar_links"("user_id", "google_calendar_id", "google_event_id");

-- CreateIndex
CREATE INDEX "activity_legacy_sources_activity_id_idx" ON "activity_legacy_sources"("activity_id");

-- CreateIndex
CREATE UNIQUE INDEX "activity_legacy_sources_user_id_source_source_id_key" ON "activity_legacy_sources"("user_id", "source", "source_id");

-- AddForeignKey
ALTER TABLE "activities" ADD CONSTRAINT "activities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "activities" ADD CONSTRAINT "activities_parent_id_user_id_fkey" FOREIGN KEY ("parent_id", "user_id") REFERENCES "activities"("id", "user_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "activity_calendar_links" ADD CONSTRAINT "activity_calendar_links_activity_id_user_id_fkey" FOREIGN KEY ("activity_id", "user_id") REFERENCES "activities"("id", "user_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "activity_legacy_sources" ADD CONSTRAINT "activity_legacy_sources_activity_id_user_id_fkey" FOREIGN KEY ("activity_id", "user_id") REFERENCES "activities"("id", "user_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Serialize structural changes per owner; enforce one level even outside the API.
CREATE FUNCTION check_activity_structure() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    PERFORM pg_advisory_xact_lock(hashtext(NEW.user_id));
    IF TG_OP = 'UPDATE' AND (NEW.kind <> OLD.kind OR NEW.user_id <> OLD.user_id) THEN
        RAISE EXCEPTION 'Activity owner and kind are immutable' USING ERRCODE = '23514';
    END IF;
    IF NEW.parent_id IS NOT NULL THEN
        IF NEW.parent_id = NEW.id OR EXISTS (
            SELECT 1 FROM activities WHERE id = NEW.parent_id AND user_id = NEW.user_id AND parent_id IS NOT NULL
        ) OR EXISTS (
            SELECT 1 FROM activities WHERE parent_id = NEW.id AND user_id = NEW.user_id
        ) THEN
            RAISE EXCEPTION 'Only one level of activity children is allowed' USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER activities_structure BEFORE INSERT OR UPDATE OF parent_id, kind, user_id
ON activities FOR EACH ROW EXECUTE FUNCTION check_activity_structure();
