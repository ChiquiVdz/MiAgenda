CREATE TABLE "scheduled_subtasks" (
  "id" TEXT NOT NULL,
  "user_id" TEXT NOT NULL,
  "parent_key" VARCHAR(64) NOT NULL,
  "parent_inbox_id" TEXT,
  "parent_calendar_id" TEXT,
  "parent_event_id" TEXT,
  "step_id" VARCHAR(100) NOT NULL,
  "google_calendar_id" TEXT NOT NULL,
  "google_event_id" TEXT NOT NULL,
  "end_snapshot" TIMESTAMP(3) NOT NULL,
  "parent_end_snapshot" TIMESTAMP(3),
  "pending_payload" JSONB,
  "active" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "scheduled_subtasks_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "scheduled_subtasks_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "scheduled_subtasks_user_id_parent_key_step_id_key" ON "scheduled_subtasks"("user_id", "parent_key", "step_id");
CREATE UNIQUE INDEX "scheduled_subtasks_user_id_google_calendar_id_google_event_id_key" ON "scheduled_subtasks"("user_id", "google_calendar_id", "google_event_id");
CREATE INDEX "scheduled_subtasks_user_id_parent_inbox_id_idx" ON "scheduled_subtasks"("user_id", "parent_inbox_id");
CREATE INDEX "scheduled_subtasks_user_id_parent_calendar_id_parent_event_id_idx" ON "scheduled_subtasks"("user_id", "parent_calendar_id", "parent_event_id");
