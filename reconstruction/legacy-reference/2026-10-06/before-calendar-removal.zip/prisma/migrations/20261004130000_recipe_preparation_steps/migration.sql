ALTER TABLE "recipes" ADD COLUMN "steps" JSONB;
ALTER TABLE "meal_plans" ADD COLUMN "preparation_steps" JSONB;

-- Freeze existing preparations before recipes can be edited with the new step editor.
UPDATE "meal_plans" AS p SET "preparation_steps" =
  jsonb_build_array(jsonb_build_object(
    'id', 'instructions', 'text', COALESCE(r."instructions", 'Preparar la receta'),
    'isOptional', false, 'completed', p."completed_at" IS NOT NULL,
    'ingredientKeys', COALESCE((SELECT jsonb_agg(i."ingredient_id" || ':required') FROM "meal_plan_ingredients" i WHERE i."meal_plan_id" = p."id" AND NOT i."is_optional"), '[]'::jsonb)))
  || COALESCE((SELECT jsonb_agg(jsonb_build_object(
    'id', 'ingredient-' || i."ingredient_id" || ':optional', 'text', 'Agregar ' || i."name_snapshot",
    'isOptional', true, 'completed', COALESCE(i."optional_used", false),
    'ingredientKeys', jsonb_build_array(i."ingredient_id" || ':optional')))
    FROM "meal_plan_ingredients" i WHERE i."meal_plan_id" = p."id" AND i."is_optional"), '[]'::jsonb)
FROM "recipes" r WHERE r."id" = p."recipe_id";
