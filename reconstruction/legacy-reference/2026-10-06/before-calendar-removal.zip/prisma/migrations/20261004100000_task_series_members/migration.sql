CREATE TABLE "task_series_members" (
  "id" TEXT NOT NULL,
  "user_id" TEXT NOT NULL,
  "google_calendar_id" TEXT NOT NULL,
  "google_event_id" TEXT NOT NULL,
  "root_id" TEXT NOT NULL,
  CONSTRAINT "task_series_members_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "task_series_members_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "task_series_members_user_id_google_calendar_id_google_event_id_key" ON "task_series_members"("user_id", "google_calendar_id", "google_event_id");
CREATE INDEX "task_series_members_user_id_google_calendar_id_root_id_idx" ON "task_series_members"("user_id", "google_calendar_id", "root_id");
