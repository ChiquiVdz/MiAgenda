ALTER TABLE "inbox_items" ADD COLUMN "checklist" JSONB;
