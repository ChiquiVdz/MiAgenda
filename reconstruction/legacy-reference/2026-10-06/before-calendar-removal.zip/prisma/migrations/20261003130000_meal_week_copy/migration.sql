CREATE TABLE "meal_week_copies" (
  "id" TEXT NOT NULL,
  "user_id" TEXT NOT NULL,
  "idempotency_key" VARCHAR(100) NOT NULL,
  "source_week" VARCHAR(10) NOT NULL,
  "target_week" VARCHAR(10) NOT NULL,
  "fingerprint" VARCHAR(64) NOT NULL,
  "total" INTEGER NOT NULL,
  "cursor" INTEGER NOT NULL DEFAULT 0,
  "copied" INTEGER NOT NULL DEFAULT 0,
  "blocks" JSONB NOT NULL,
  "omissions" JSONB NOT NULL,
  "finished_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "meal_week_copies_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "meal_week_copies_progress_check" CHECK ("total" >= 0 AND "cursor" BETWEEN 0 AND "total" AND "copied" BETWEEN 0 AND "cursor")
);
CREATE UNIQUE INDEX "meal_week_copies_user_id_idempotency_key_key" ON "meal_week_copies"("user_id", "idempotency_key");
CREATE INDEX "meal_week_copies_user_id_finished_at_idx" ON "meal_week_copies"("user_id", "finished_at");
ALTER TABLE "meal_week_copies" ADD CONSTRAINT "meal_week_copies_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
