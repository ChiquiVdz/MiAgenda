ALTER TABLE "event_overlays" ADD COLUMN "checklist_marked_at" TIMESTAMP(3);
UPDATE "event_overlays" SET "checklist_marked_at" = "updated_at" WHERE "checklist" IS NOT NULL;
ALTER TABLE "task_series_members" ADD COLUMN "mark_scan_from" TIMESTAMP(3);
ALTER TABLE "task_series_members" ADD COLUMN "mark_scan_page_token" TEXT, ADD COLUMN "mark_scan_upper" TIMESTAMP(3);
ALTER TABLE "task_series_members" ADD COLUMN "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
CREATE TABLE "task_checklist_marks" (
  "id" TEXT NOT NULL,
  "user_id" TEXT NOT NULL,
  "google_calendar_id" TEXT NOT NULL,
  "root_id" TEXT NOT NULL,
  "from_date" TIMESTAMP(3),
  "changes" JSONB NOT NULL,
  "fingerprint" TEXT NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "task_checklist_marks_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "task_checklist_marks_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "task_checklist_marks_user_id_google_calendar_id_root_id_created_at_idx" ON "task_checklist_marks"("user_id", "google_calendar_id", "root_id", "created_at");
