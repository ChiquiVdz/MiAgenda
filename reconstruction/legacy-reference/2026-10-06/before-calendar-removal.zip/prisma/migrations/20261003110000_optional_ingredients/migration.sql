ALTER TABLE "recipe_ingredients" ADD COLUMN "is_optional" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "meal_plan_ingredients" ADD COLUMN "is_optional" BOOLEAN NOT NULL DEFAULT false,
 ADD COLUMN "optional_used" BOOLEAN;
ALTER TABLE "shopping_list_items" ADD COLUMN "required_quantity" DECIMAL(12,3),
 ADD COLUMN "optional_quantity" DECIMAL(12,3);
UPDATE "shopping_list_items" SET "required_quantity" = "quantity", "optional_quantity" = 0
 WHERE "ingredient_id" IS NOT NULL;
DROP INDEX "recipe_ingredients_recipe_id_ingredient_id_key";
DROP INDEX "meal_plan_ingredients_meal_plan_id_ingredient_id_key";
CREATE UNIQUE INDEX "recipe_ingredients_recipe_id_ingredient_id_is_optional_key"
 ON "recipe_ingredients"("recipe_id", "ingredient_id", "is_optional");
CREATE UNIQUE INDEX "meal_plan_ingredients_meal_plan_id_ingredient_id_is_optional_key"
 ON "meal_plan_ingredients"("meal_plan_id", "ingredient_id", "is_optional");
