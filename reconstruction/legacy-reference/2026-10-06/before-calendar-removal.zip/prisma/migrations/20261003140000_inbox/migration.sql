CREATE TABLE "inbox_items" (
  "id" TEXT NOT NULL,
  "user_id" TEXT NOT NULL,
  "create_key" VARCHAR(100) NOT NULL,
  "text" VARCHAR(250) NOT NULL,
  "completed_at" TIMESTAMP(3),
  "transfer_payload" JSONB,
  "google_calendar_id" TEXT,
  "google_event_id" TEXT,
  "transferred_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "inbox_items_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "inbox_items_user_id_create_key_key" ON "inbox_items"("user_id", "create_key");
CREATE INDEX "inbox_items_user_id_transferred_at_created_at_idx" ON "inbox_items"("user_id", "transferred_at", "created_at");
CREATE INDEX "inbox_items_completed_at_idx" ON "inbox_items"("completed_at");
CREATE INDEX "inbox_items_transferred_at_idx" ON "inbox_items"("transferred_at");
ALTER TABLE "inbox_items" ADD CONSTRAINT "inbox_items_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
