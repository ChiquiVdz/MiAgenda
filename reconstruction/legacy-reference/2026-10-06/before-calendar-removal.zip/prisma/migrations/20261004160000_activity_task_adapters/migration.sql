-- AlterTable
ALTER TABLE "inbox_items" ALTER COLUMN "text" SET DATA TYPE TEXT;

-- CreateTable
CREATE TABLE "activity_operations" (
    "id" TEXT NOT NULL,
    "activity_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "action" VARCHAR(20) NOT NULL,
    "google_calendar_id" TEXT NOT NULL,
    "google_event_id" TEXT NOT NULL,
    "payload" JSONB NOT NULL,
    "finished_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "activity_operations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "activity_operations_user_id_finished_at_idx" ON "activity_operations"("user_id", "finished_at");

-- CreateIndex
CREATE UNIQUE INDEX "activity_operations_user_id_action_google_calendar_id_googl_key" ON "activity_operations"("user_id", "action", "google_calendar_id", "google_event_id");

-- AddForeignKey
ALTER TABLE "activity_operations" ADD CONSTRAINT "activity_operations_activity_id_user_id_fkey" FOREIGN KEY ("activity_id", "user_id") REFERENCES "activities"("id", "user_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Transitional adapters: legacy commands write Activity in the same transaction.
-- Legacy common fields are projections; checklists/series remain in their old models.
CREATE FUNCTION task_activity_identity(owner_id TEXT, source_kind TEXT, source_id TEXT,
    calendar_id TEXT DEFAULT NULL, event_id TEXT DEFAULT NULL) RETURNS TEXT LANGUAGE plpgsql AS $$
#variable_conflict use_variable
DECLARE activity_id TEXT; linked_id TEXT; current_link RECORD;
BEGIN
    PERFORM pg_advisory_xact_lock(hashtext(owner_id));
    SELECT s.activity_id INTO activity_id FROM activity_legacy_sources s
      WHERE s.user_id=owner_id AND s.source=source_kind AND s.source_id=task_activity_identity.source_id;
    IF calendar_id IS NOT NULL AND event_id IS NOT NULL THEN
      SELECT l.activity_id INTO linked_id FROM activity_calendar_links l
        WHERE l.user_id=owner_id AND l.google_calendar_id=calendar_id AND l.google_event_id=event_id;
    END IF;
    IF activity_id IS NOT NULL AND linked_id IS NOT NULL AND activity_id<>linked_id THEN
      RAISE EXCEPTION 'Conflicting activity identities' USING ERRCODE='23514';
    END IF;
    activity_id := COALESCE(activity_id,linked_id);
    IF activity_id IS NULL THEN
      activity_id := source_id;
      IF EXISTS(SELECT 1 FROM activities a WHERE a.id=activity_id) THEN
        activity_id := 'act' || md5(owner_id || source_kind || source_id);
      END IF;
      INSERT INTO activities(id,user_id,kind,lifecycle,updated_at)
        VALUES(activity_id,owner_id,'task','visible',CURRENT_TIMESTAMP);
    END IF;
    INSERT INTO activity_legacy_sources(id,activity_id,user_id,source,source_id)
      VALUES('src' || md5(owner_id || source_kind || source_id),activity_id,owner_id,source_kind,source_id)
      ON CONFLICT(user_id,source,source_id) DO NOTHING;
    IF calendar_id IS NOT NULL AND event_id IS NOT NULL THEN
      SELECT * INTO current_link FROM activity_calendar_links l WHERE l.activity_id=activity_id;
      IF current_link.id IS NULL THEN
        INSERT INTO activity_calendar_links(id,activity_id,user_id,google_calendar_id,google_event_id,state,updated_at)
          VALUES('lnk' || md5(activity_id),activity_id,owner_id,calendar_id,event_id,'pending',CURRENT_TIMESTAMP);
      ELSIF current_link.google_calendar_id<>calendar_id OR current_link.google_event_id<>event_id THEN
        -- Same source ID moved by the existing recurrence adapter; preserve identity.
        UPDATE activity_calendar_links l SET google_calendar_id=calendar_id,google_event_id=event_id,
          state='pending',etag=NULL,start_snapshot=NULL,end_snapshot=NULL,updated_at=CURRENT_TIMESTAMP
          WHERE l.id=current_link.id;
      END IF;
    END IF;
    RETURN activity_id;
END;
$$;

CREATE FUNCTION assert_task_activity_available(activity_id TEXT) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    IF EXISTS(SELECT 1 FROM activity_operations o WHERE o.activity_id=assert_task_activity_available.activity_id
      AND o.finished_at IS NULL AND o.id IS DISTINCT FROM current_setting('miagenda.activity_operation',true)) THEN
      RAISE EXCEPTION 'Resume pending activity operation' USING ERRCODE='P0001';
    END IF;
END;
$$;

CREATE FUNCTION inbox_activity_adapter() RETURNS trigger LANGUAGE plpgsql AS $$
#variable_conflict use_variable
DECLARE activity_id TEXT;
BEGIN
    IF pg_trigger_depth()>1 THEN RETURN NEW; END IF;
    IF NEW.transferred_at IS NOT NULL THEN RETURN NEW; END IF;
    activity_id := task_activity_identity(NEW.user_id,'inbox_item',NEW.id);
    PERFORM assert_task_activity_available(activity_id);
    UPDATE activities a SET title=NEW.text,completed_at=NEW.completed_at,keep=false,highlighted=false,
      lifecycle='visible',revision=a.revision+1,updated_at=NEW.updated_at WHERE a.id=activity_id;
    RETURN NEW;
END;
$$;
CREATE TRIGGER inbox_activity_adapter AFTER INSERT OR UPDATE ON inbox_items
  FOR EACH ROW EXECUTE FUNCTION inbox_activity_adapter();

CREATE FUNCTION overlay_activity_adapter() RETURNS trigger LANGUAGE plpgsql AS $$
#variable_conflict use_variable
DECLARE activity_id TEXT;
BEGIN
    IF pg_trigger_depth()>1 OR NEW.kind='meal' OR EXISTS(SELECT 1 FROM scheduled_subtasks s
      WHERE s.user_id=NEW.user_id AND s.google_calendar_id=NEW.google_calendar_id AND s.google_event_id=NEW.google_event_id)
      THEN RETURN NEW; END IF;
    activity_id := task_activity_identity(NEW.user_id,'event_overlay',NEW.id,NEW.google_calendar_id,NEW.google_event_id);
    -- Claiming retention also respects an unschedule operation already in flight.
    PERFORM assert_task_activity_available(activity_id);
    UPDATE activities a SET completed_at=NEW.completed_at,keep=NEW.keep,highlighted=NEW.highlighted,
      lifecycle=CASE WHEN a.lifecycle='retired' THEN a.lifecycle ELSE 'visible'::activity_lifecycle END,
      revision=a.revision+1,updated_at=NEW.updated_at WHERE a.id=activity_id;
    RETURN NEW;
END;
$$;
CREATE TRIGGER overlay_activity_adapter AFTER INSERT OR UPDATE ON event_overlays
  FOR EACH ROW EXECUTE FUNCTION overlay_activity_adapter();

CREATE FUNCTION project_task_activity() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF pg_trigger_depth()>1 OR NEW.kind<>'task' OR NEW.lifecycle='staged' THEN RETURN NEW; END IF;
    PERFORM assert_task_activity_available(NEW.id);
    UPDATE inbox_items i SET text=COALESCE(NEW.title,i.text),completed_at=NEW.completed_at,updated_at=NEW.updated_at
      FROM activity_legacy_sources s WHERE s.activity_id=NEW.id AND s.user_id=NEW.user_id AND s.source='inbox_item'
      AND i.id=s.source_id AND i.user_id=NEW.user_id AND i.transferred_at IS NULL;
    UPDATE event_overlays e SET completed_at=NEW.completed_at,keep=NEW.keep,highlighted=NEW.highlighted,updated_at=NEW.updated_at
      FROM activity_legacy_sources s JOIN activity_calendar_links l ON l.activity_id=s.activity_id
      WHERE s.activity_id=NEW.id AND s.user_id=NEW.user_id AND s.source='event_overlay'
      AND e.id=s.source_id AND e.user_id=NEW.user_id AND e.kind<>'meal'
      AND e.google_calendar_id=l.google_calendar_id AND e.google_event_id=l.google_event_id;
    RETURN NEW;
END;
$$;
CREATE TRIGGER project_task_activity AFTER UPDATE OF completed_at,keep,highlighted,title,lifecycle ON activities
  FOR EACH ROW EXECUTE FUNCTION project_task_activity();

CREATE FUNCTION remove_task_activity_source() RETURNS trigger LANGUAGE plpgsql AS $$
#variable_conflict use_variable
DECLARE activity_id TEXT; source_kind TEXT; has_children BOOLEAN;
BEGIN
    source_kind := CASE WHEN TG_TABLE_NAME='inbox_items' THEN 'inbox_item' ELSE 'event_overlay' END;
    SELECT s.activity_id INTO activity_id FROM activity_legacy_sources s
      WHERE s.user_id=OLD.user_id AND s.source=source_kind AND s.source_id=OLD.id;
    IF activity_id IS NULL THEN RETURN OLD; END IF;
    PERFORM pg_advisory_xact_lock(hashtext(OLD.user_id));
    PERFORM assert_task_activity_available(activity_id);
    DELETE FROM activity_legacy_sources s WHERE s.user_id=OLD.user_id AND s.source=source_kind AND s.source_id=OLD.id;
    IF EXISTS(SELECT 1 FROM activity_operations o WHERE o.activity_id=activity_id AND o.finished_at IS NULL) THEN RETURN OLD; END IF;
    IF source_kind='event_overlay' THEN
      UPDATE activity_calendar_links l SET state='retired',updated_at=CURRENT_TIMESTAMP
        WHERE l.activity_id=activity_id AND l.google_calendar_id=OLD.google_calendar_id AND l.google_event_id=OLD.google_event_id;
    END IF;
    IF EXISTS(SELECT 1 FROM activity_calendar_links l WHERE l.activity_id=activity_id AND l.state IN ('pending','confirmed'))
      OR EXISTS(SELECT 1 FROM inbox_items i JOIN activity_legacy_sources s ON s.source='inbox_item' AND s.source_id=i.id
        AND s.user_id=i.user_id WHERE s.activity_id=activity_id AND i.transferred_at IS NULL) THEN RETURN OLD; END IF;
    SELECT EXISTS(SELECT 1 FROM scheduled_subtasks s WHERE s.user_id=OLD.user_id AND
      ((source_kind='inbox_item' AND s.parent_inbox_id=OLD.id)
      OR (source_kind='event_overlay' AND s.parent_calendar_id=OLD.google_calendar_id AND s.parent_event_id=OLD.google_event_id))) INTO has_children;
    IF has_children THEN
      UPDATE activities a SET lifecycle='retired',updated_at=CURRENT_TIMESTAMP WHERE a.id=activity_id;
    ELSE DELETE FROM activities a WHERE a.id=activity_id; END IF;
    RETURN OLD;
END;
$$;
CREATE TRIGGER remove_inbox_activity_source AFTER DELETE ON inbox_items FOR EACH ROW EXECUTE FUNCTION remove_task_activity_source();
CREATE TRIGGER remove_overlay_activity_source AFTER DELETE ON event_overlays FOR EACH ROW EXECUTE FUNCTION remove_task_activity_source();

-- Adopt root groups without pending legacy operations. No Google calls or food changes.
DO $$
DECLARE owner RECORD;
BEGIN
  FOR owner IN SELECT id FROM users ORDER BY id LOOP
    PERFORM pg_advisory_xact_lock(hashtext(owner.id));
    IF EXISTS(SELECT 1 FROM inbox_items WHERE user_id=owner.id AND transfer_payload IS NOT NULL)
      OR EXISTS(SELECT 1 FROM recurrence_changes WHERE user_id=owner.id AND finished_at IS NULL)
      OR EXISTS(SELECT 1 FROM scheduled_subtasks WHERE user_id=owner.id AND (NOT active OR pending_payload IS NOT NULL)) THEN CONTINUE; END IF;
    UPDATE inbox_items SET updated_at=updated_at WHERE user_id=owner.id AND transferred_at IS NULL;
    UPDATE event_overlays e SET updated_at=e.updated_at WHERE e.user_id=owner.id AND e.kind<>'meal'
      AND NOT EXISTS(SELECT 1 FROM scheduled_subtasks s WHERE s.user_id=e.user_id AND s.google_calendar_id=e.google_calendar_id AND s.google_event_id=e.google_event_id);
  END LOOP;
END;
$$;
