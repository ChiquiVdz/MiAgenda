import type { Prisma } from "@/generated/prisma/client";

// Caller holds the user lock. Deleting a calendar meal never reverses consumption.
export async function cleanupMealRecords(tx: Prisma.TransactionClient, userId: string) {
  const batches = await tx.cookedBatch.findMany({ where: { userId }, include: { uses: true } });
  for (const batch of batches) {
    const consumed = batch.uses.reduce((sum, use) => sum + use.servings, 0);
    // A live origin or consumer can still be undone until its overlay is removed.
    if (!batch.originMealPlanId && consumed >= batch.servings && batch.uses.every((use) => !use.mealPlanId)) {
      await tx.portionUse.deleteMany({ where: { batchId: batch.id } });
      await tx.cookedBatch.delete({ where: { id: batch.id } });
      continue;
    }
    // Keep one anonymous total for permanently consumed portions, not one row per old event.
    const permanent = batch.uses.filter((use) => !use.mealPlanId);
    if (permanent.length > 1) {
      await tx.portionUse.update({ where: { id: permanent[0].id }, data: { servings: permanent.reduce((sum, use) => sum + use.servings, 0) } });
      await tx.portionUse.deleteMany({ where: { id: { in: permanent.slice(1).map((use) => use.id) } } });
    }
  }
}
