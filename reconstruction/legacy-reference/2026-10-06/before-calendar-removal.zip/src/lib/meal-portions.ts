import type { Prisma } from "@/generated/prisma/client";
import { readMealState } from "@/lib/meal-state";
import { projectMeals } from "@/lib/meal-availability";
import { ingredientStepKey, preparationSteps } from "@/lib/recipe-steps";
import { syncMealStepChildren } from "@/lib/meal-step-links";

export type OptionalIngredientChoice = { ingredientId: string; name: string; unit: string; requiredQuantity: number; availableQuantity: number };
export class OptionalSelectionRequired extends Error {
  constructor(readonly ingredients: OptionalIngredientChoice[]) { super("Confirma qué ingredientes opcionales usaste al cocinar."); }
}

export class MealActionError extends Error {
  constructor(message: string, readonly details?: Array<{ name: string; unit: string; missingQuantity: number }>) {
    super(message); this.name = "MealActionError";
  }
}

// The caller holds the user's advisory lock and commits the entire block together.
export async function completeMealBlock(tx: Prisma.TransactionClient, userId: string, overlayId: string, now: Date, choices?: string[], stepAmounts?: Record<string, number>) {
  const plans = await tx.mealPlan.findMany({ where: { userId, overlayId }, orderBy: [{ createdAt: "asc" }, { id: "asc" }], include: { ingredients: true, recipe: { select: { name: true } } } });
  const pantry = await tx.pantryItem.findMany({ where: { userId } });
  const optional = plans.flatMap((plan) => plan.completedAt || !plan.cookingEnabled ? [] : plan.ingredients.filter((line) => line.isOptional && Number(line.requiredQuantity) > 0).map((line) => ({
    ingredientId: `${plan.id}:${line.ingredientId}`, name: `${plan.recipe?.name ?? "Receta"} · ${line.nameSnapshot}`, unit: line.unit,
    requiredQuantity: Number(line.requiredQuantity), availableQuantity: Number(pantry.find((item) => item.ingredientId === line.ingredientId)?.quantity ?? 0),
  })));
  if (plans.every((plan) => plan.completedAt)) return;
  if (optional.length && choices === undefined) throw new OptionalSelectionRequired(optional);
  if (choices?.some((key) => !optional.some((item) => item.ingredientId === key))) throw new MealActionError("Los opcionales cambiaron. Abre de nuevo la comida.");
  for (const plan of plans) {
    const amounts = stepAmounts ? Object.fromEntries(Object.entries(stepAmounts).filter(([key]) => key.startsWith(`${plan.id}:`)).map(([key, amount]) => [key.slice(plan.id.length + 1), amount])) : undefined;
    await completeMeal(tx, userId, plan.id, now, (choices ?? []).filter((key) => key.startsWith(`${plan.id}:`)).map((key) => key.slice(plan.id.length + 1)), amounts);
    const used = new Set(plan.ingredients.filter((line) => !line.isOptional || choices?.includes(`${plan.id}:${line.ingredientId}`)).map(ingredientStepKey));
    await tx.mealPlan.update({ where: { id: plan.id }, data: { preparationSteps: preparationSteps(plan.preparationSteps).map((step) => ({ ...step,
      completed: !step.isOptional || (stepAmounts ? step.completed : step.ingredientKeys.length > 0 ? step.ingredientKeys.every((key) => used.has(key)) : step.completed) })) } });
  }
  await syncMealStepChildren(tx, userId, overlayId);
}

export async function uncompleteMealBlock(tx: Prisma.TransactionClient, userId: string, overlayId: string) {
  const plans = await tx.mealPlan.findMany({ where: { userId, overlayId } });
  const ids = plans.map((plan) => plan.id);
  const batches = await tx.cookedBatch.findMany({ where: { userId, originMealPlanId: { in: ids } } });
  const uses = await tx.portionUse.findMany({ where: { batchId: { in: batches.map((batch) => batch.id) } } });
  if (uses.some((use) => !use.mealPlanId || !ids.includes(use.mealPlanId))) throw new MealActionError("Primero deshaz las comidas posteriores que consumieron sobras de este bloque.");
  await tx.portionUse.deleteMany({ where: { mealPlanId: { in: ids } } });
  for (const plan of plans) await uncompleteMeal(tx, userId, plan.id);
  await syncMealStepChildren(tx, userId, overlayId);
}

export async function completeMeal(tx: Prisma.TransactionClient, userId: string, planId: string, now: Date, optionalIngredientIds?: string[], optionalAmounts?: Record<string, number>) {
  const plan = await tx.mealPlan.findFirstOrThrow({ where: { id: planId, userId } });
  if (plan.completedAt) return;
  const overlay = await tx.eventOverlay.findUniqueOrThrow({ where: { id: plan.overlayId } });
  if (overlay.completedAt || await tx.inventoryLedger.count({ where: { mealPlanId: plan.id, delta: { lt: 0 }, reversals: { none: {} } } })) {
    throw new MealActionError("Esta comida tiene un completado anterior. Deshazlo primero para evitar descontar ingredientes dos veces.");
  }
  if (plan.eventMissing) throw new MealActionError("Esta comida ya no existe en Google Calendar.");
  const ingredients = await tx.mealPlanIngredient.findMany({ where: { mealPlanId: plan.id } });
  const state = await readMealState(tx, userId);
  const optional = ingredients.filter((line) => plan.cookingEnabled && line.isOptional && Number(line.requiredQuantity) > 0);
  if (optional.length && optionalIngredientIds === undefined) {
    throw new OptionalSelectionRequired(optional.map((line) => ({ ingredientId: line.ingredientId, name: line.nameSnapshot, unit: line.unit,
      requiredQuantity: Number(line.requiredQuantity), availableQuantity: state.inventory.get(line.ingredientId) ?? 0 })));
  }
  const selected = new Set(optionalIngredientIds ?? []);
  if ([...selected].some((id) => !optional.some((line) => line.ingredientId === id))) throw new MealActionError("La selección de opcionales ya no corresponde a esta comida. Actualiza el planificador.");
  if (optionalAmounts && Object.entries(optionalAmounts).some(([id, amount]) => !selected.has(id) || !Number.isFinite(amount) || amount < 0
    || amount > Number(optional.find((line) => line.ingredientId === id)?.requiredQuantity ?? -1))) throw new MealActionError("Las cantidades opcionales cambiaron. Actualiza los pasos.");
  const projection = projectMeals(state.inventory, state.plans.map((meal) => meal.id !== plan.id ? meal : {
    ...meal, ingredients: meal.ingredients.filter((line) => !line.isOptional || selected.has(line.ingredientId))
      .map((line) => ({ ...line, requiredQuantity: line.isOptional ? optionalAmounts?.[line.ingredientId] ?? line.requiredQuantity : line.requiredQuantity, isOptional: false })),
  }), state.batches);
  const forecast = projection.meals.find((meal) => meal.id === plan.id);
  if (!forecast || !plan.scheduledAt) throw new MealActionError("Actualiza el planificador para verificar el horario de esta comida.");
  if (forecast.missingIngredients.length) throw new MealActionError("Faltan ingredientes para esta comida; las comidas anteriores tienen prioridad.", forecast.missingIngredients);
  if (forecast.missingCookServings) throw new MealActionError(`Falta cocinar ${forecast.missingCookServings} porción(es). Edita la comida para activar Cocinar o aumentar las porciones a cocinar.`);
  if (forecast.portionAllocations.some((allocation) => !allocation.actual && allocation.originMealPlanId !== plan.id)) {
    throw new MealActionError("Primero completa la comida anterior que cocinará las porciones reservadas para esta comida.");
  }

  for (const line of ingredients) {
    if (line.isOptional) {
      await tx.mealPlanIngredient.update({ where: { id: line.id }, data: { optionalUsed: plan.cookingEnabled ? selected.has(line.ingredientId) : null } });
      if (!selected.has(line.ingredientId)) continue;
    }
    const amount = line.isOptional ? optionalAmounts?.[line.ingredientId] ?? Number(line.requiredQuantity) : Number(line.requiredQuantity);
    if (amount <= 0) continue;
    const updated = await tx.pantryItem.updateMany({ where: { userId, ingredientId: line.ingredientId, quantity: { gte: amount } },
      data: { quantity: { decrement: amount } } });
    if (!updated.count) throw new MealActionError("La alacena cambió. Actualiza el planificador antes de completar.");
    await tx.inventoryLedger.create({ data: { mealPlanId: plan.id, ingredientId: line.ingredientId, delta: -amount, unit: line.unit } });
  }
  const recipe = plan.recipeId ? await tx.recipe.findFirst({ where: { id: plan.recipeId, userId }, select: { name: true } }) : null;
  const batch = plan.cookingEnabled && plan.cookedServings > 0 ? await tx.cookedBatch.create({ data: {
    userId, recipeKey: plan.recipeId ?? `deleted:${plan.id}`, recipeName: recipe?.name ?? "Receta eliminada",
    originMealPlanId: plan.id, servings: plan.cookedServings, cookedAt: plan.scheduledAt,
  } }) : null;
  for (const allocation of forecast.portionAllocations) {
    const batchId = allocation.actual ? allocation.batchId : batch!.id;
    await tx.portionUse.create({ data: { batchId, mealPlanId: plan.id, servings: allocation.servings } });
  }
  await tx.mealPlan.update({ where: { id: plan.id }, data: { completedAt: now } });
}

export async function uncompleteMeal(tx: Prisma.TransactionClient, userId: string, planId: string) {
  const plan = await tx.mealPlan.findFirstOrThrow({ where: { id: planId, userId } });
  const batches = await tx.cookedBatch.findMany({ where: { userId, originMealPlanId: plan.id } });
  const uses = await tx.portionUse.findMany({ where: { batchId: { in: batches.map((batch) => batch.id) } } });
  if (uses.some((use) => use.mealPlanId !== plan.id)) {
    throw new MealActionError("Primero deshaz o corrige las comidas posteriores que ya consumieron sobras de esta cocinada.");
  }
  await tx.portionUse.deleteMany({ where: { mealPlanId: plan.id } });
  await tx.cookedBatch.deleteMany({ where: { userId, originMealPlanId: plan.id } });
  const deductions = await tx.inventoryLedger.findMany({ where: { mealPlanId: plan.id, delta: { lt: 0 }, reversals: { none: {} } } });
  for (const deduction of deductions) {
    const amount = -Number(deduction.delta);
    const item = await tx.pantryItem.upsert({ where: { userId_ingredientId: { userId, ingredientId: deduction.ingredientId } },
      create: { userId, ingredientId: deduction.ingredientId, quantity: amount }, update: { quantity: { increment: amount } } });
    if (item.quantity.greaterThan("999999999.999")) throw new MealActionError("Devolver los ingredientes superaría el límite de la alacena. Ajusta su cantidad antes de deshacer.");
    await tx.inventoryLedger.create({ data: { mealPlanId: plan.id, ingredientId: deduction.ingredientId, delta: amount, unit: deduction.unit, reversalOfId: deduction.id } });
  }
  await tx.mealPlan.update({ where: { id: plan.id }, data: { completedAt: null, preparationSteps: preparationSteps(plan.preparationSteps).map((step) => ({ ...step, completed: false })) } });
  await tx.mealPlanIngredient.updateMany({ where: { mealPlanId: plan.id, isOptional: true }, data: { optionalUsed: null } });
}
