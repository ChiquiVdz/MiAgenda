import { roundQuantity } from "@/lib/meal-availability";
import type { IngredientUnit } from "@/generated/prisma/client";

type Shortage = { ingredientId: string; name: string; unit: string; missingQuantity: number };
export function shoppingNeeds(meals: Array<{ missingIngredients: Shortage[]; missingOptionalIngredients: Shortage[] }>) {
  const totals = new Map<string, { ingredientId: string; name: string; unit: IngredientUnit; quantity: number; requiredQuantity: number; optionalQuantity: number }>();
  for (const meal of meals) for (const [lines, optional] of [[meal.missingIngredients, false], [meal.missingOptionalIngredients, true]] as const) {
    for (const line of lines) {
      const current = totals.get(line.ingredientId) ?? { ingredientId: line.ingredientId, name: line.name, unit: line.unit as IngredientUnit, quantity: 0, requiredQuantity: 0, optionalQuantity: 0 };
      current[optional ? "optionalQuantity" : "requiredQuantity"] = roundQuantity(current[optional ? "optionalQuantity" : "requiredQuantity"] + line.missingQuantity);
      current.quantity = roundQuantity(current.requiredQuantity + current.optionalQuantity);
      totals.set(line.ingredientId, current);
    }
  }
  return [...totals.values()];
}
