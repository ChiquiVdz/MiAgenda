type PlannedIngredients = {
  id: string;
  completedAt: unknown;
  ingredients: Array<{ ingredientId: string; requiredQuantity: number }>;
};

export function inventoryAfterPlans(inventory: ReadonlyMap<string, number>, plans: PlannedIngredients[], excludedPlanId?: string) {
  const available = new Map(inventory);
  for (const plan of plans) {
    if (plan.completedAt || plan.id === excludedPlanId) continue;
    for (const line of plan.ingredients) {
      available.set(line.ingredientId, Math.round(Math.max(0, (available.get(line.ingredientId) ?? 0) - line.requiredQuantity) * 1000) / 1000);
    }
  }
  return available;
}

type ScheduledPlan = Omit<PlannedIngredients, "ingredients"> & {
  startDateTime: string | null;
  startDate: string | null;
  ingredients: Array<{ ingredientId: string; name: string; unit: string; requiredQuantity: number }>;
};

function scheduledTime(plan: ScheduledPlan) {
  const value = plan.startDateTime ?? (plan.startDate ? `${plan.startDate}T00:00:00-06:00` : "");
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? timestamp : Infinity;
}

export function plansWithShortages<T extends ScheduledPlan>(inventory: ReadonlyMap<string, number>, plans: T[]) {
  const available = new Map(inventory);
  // Recompute the whole visible menu by its scheduled time after every change.
  // Creation order must never give a later meal priority over an earlier meal.
  const ordered = [...plans].sort((a, b) => scheduledTime(a) - scheduledTime(b) || a.id.localeCompare(b.id));
  return ordered.map((plan) => {
    const missingIngredients = plan.completedAt ? [] : plan.ingredients.flatMap((line) => {
      const stock = available.get(line.ingredientId) ?? 0;
      const missingQuantity = Math.round(Math.max(0, line.requiredQuantity - stock) * 1000) / 1000;
      available.set(line.ingredientId, Math.round(Math.max(0, stock - line.requiredQuantity) * 1000) / 1000);
      return missingQuantity > 0 ? [{ name: line.name, unit: line.unit, missingQuantity }] : [];
    });
    return { ...plan, missingIngredients };
  });
}
