import { validPriorTiming, type RecipeStep } from "@/lib/recipe-steps";
export type RecipeInput = {
  name: string;
  instructions: string;
  servings: number;
  durationMinutes: number;
  steps: RecipeStep[];
  ingredients: Array<{ ingredientId: string; quantityPerServing: number; equivalent: string | null; isOptional: boolean }>;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validPositiveAmount(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0
    && value <= 999_999_999.999 && Number(value.toFixed(3)) === value;
}

export function parseRecipeInput(value: unknown, fromSteps = false): RecipeInput | null {
  if (!isRecord(value)) return null;
  // The steps editor sends ingredient entries once; the server owns aggregation.
  if (value.format === "steps") {
    if (!Array.isArray(value.steps) || !value.steps.length || value.steps.length > 100) return null;
    const entries: RecipeInput["ingredients"] = [];
    const steps: RecipeStep[] = [];
    for (const item of value.steps) {
      if (!isRecord(item) || typeof item.isOptional !== "boolean") return null;
      if (item.priorTiming !== undefined && item.priorTiming !== null && !validPriorTiming(item.priorTiming)) return null;
      let ingredient: RecipeStep["ingredient"] = null;
      if (item.ingredient !== null) {
        const line = item.ingredient;
        if (!isRecord(line) || typeof line.ingredientId !== "string" || !line.ingredientId || line.ingredientId.length > 30
          || !validPositiveAmount(line.quantityPerServing) || typeof line.equivalent !== "string" && line.equivalent !== null) return null;
        const equivalent = typeof line.equivalent === "string" ? line.equivalent.trim() || null : null;
        if (equivalent && equivalent.length > 120) return null;
        ingredient = { ingredientId: line.ingredientId, quantityPerServing: line.quantityPerServing, equivalent };
        entries.push({ ...ingredient, isOptional: item.isOptional });
      }
      steps.push({ id: item.id as string, text: item.text as string, isOptional: item.isOptional, ingredient,
        ...(validPriorTiming(item.priorTiming) ? { priorTiming: { minutesBefore: item.priorTiming.minutesBefore, durationMinutes: item.priorTiming.durationMinutes } } : {}),
        ingredientKeys: ingredient ? [`${ingredient.ingredientId}:${item.isOptional ? "optional" : "required"}`] : [] });
    }
    if (!steps.some((step) => !step.isOptional) || steps.some((step) => typeof step.text !== "string")) return null;
    return parseRecipeInput({ ...value, format: undefined, instructions: steps.map((step) => step.text.trim()).join("\n"), ingredients: entries, steps }, true);
  }
  const name = typeof value.name === "string" ? value.name.trim().replace(/\s+/g, " ") : "";
  const instructions = typeof value.instructions === "string" ? value.instructions.trim() : "";
  const servings = value.servings;
  const durationMinutes = value.durationMinutes;
  if (!name || name.length > 150 || !instructions || instructions.length > 10_000
    || typeof servings !== "number" || !Number.isInteger(servings) || servings < 1 || servings > 100
    || typeof durationMinutes !== "number" || !Number.isInteger(durationMinutes) || durationMinutes < 5 || durationMinutes > 480
    || !Array.isArray(value.ingredients) || value.ingredients.length < 1 || value.ingredients.length > 100) return null;

  const ingredients: RecipeInput["ingredients"] = [];
  const usedIds = new Set<string>();
  for (const item of value.ingredients) {
    if (!isRecord(item) || typeof item.ingredientId !== "string" || !item.ingredientId || item.ingredientId.length > 30
      || !validPositiveAmount(item.quantityPerServing)) return null;
    if (item.isOptional !== undefined && typeof item.isOptional !== "boolean") return null;
    const isOptional = item.isOptional === true;
    const key = `${item.ingredientId}:${isOptional}`;
    const equivalent = item.equivalent === undefined || item.equivalent === null || item.equivalent === ""
      ? null
      : typeof item.equivalent === "string" ? item.equivalent.trim() : undefined;
    if (equivalent === undefined || (equivalent !== null && equivalent.length > 120)) return null;
    if (usedIds.has(key)) {
      const previous = ingredients.find((line) => line.ingredientId === item.ingredientId && line.isOptional === isOptional)!;
      const sum = Math.round((previous.quantityPerServing + item.quantityPerServing) * 1000) / 1000;
      if (!validPositiveAmount(sum)) return null;
      previous.quantityPerServing = sum;
      previous.equivalent = null;
    } else ingredients.push({ ingredientId: item.ingredientId, quantityPerServing: item.quantityPerServing, equivalent, isOptional });
    usedIds.add(key);
  }

  const steps: RecipeStep[] = [];
  if (value.steps !== undefined) {
    if (!Array.isArray(value.steps) || value.steps.length > 100) return null;
    const ids = new Set<string>(), assigned = new Set<string>();
    for (const step of value.steps) {
      if (isRecord(step) && step.priorTiming !== undefined && step.priorTiming !== null && !validPriorTiming(step.priorTiming)) return null;
      if (!isRecord(step) || typeof step.id !== "string" || !/^[\w:-]{1,100}$/.test(step.id) || ids.has(step.id)
        || typeof step.text !== "string" || !step.text.trim() || step.text.length > 10000 || typeof step.isOptional !== "boolean"
        || !Array.isArray(step.ingredientKeys) || step.ingredientKeys.length > 50) return null;
      for (const key of step.ingredientKeys) {
        if (typeof key !== "string" || (assigned.has(key) && !step.ingredient) || !ingredients.some((line) => `${line.ingredientId}:${line.isOptional ? "optional" : "required"}` === key && line.isOptional === step.isOptional)) return null;
        assigned.add(key);
      }
      if (step.ingredient !== undefined && step.ingredient !== null) {
        if (!fromSteps || !isRecord(step.ingredient) || typeof step.ingredient.ingredientId !== "string" || !validPositiveAmount(step.ingredient.quantityPerServing)
          || step.ingredientKeys.length !== 1 || step.ingredientKeys[0] !== `${step.ingredient.ingredientId}:${step.isOptional ? "optional" : "required"}`
          || (step.ingredient.equivalent !== null && typeof step.ingredient.equivalent !== "string")) return null;
      }
      ids.add(step.id); steps.push({ id: step.id, text: step.text.trim(), isOptional: step.isOptional, ingredientKeys: step.ingredientKeys as string[],
        ...(validPriorTiming(step.priorTiming) ? { priorTiming: { minutesBefore: step.priorTiming.minutesBefore, durationMinutes: step.priorTiming.durationMinutes } } : {}),
        ...(step.ingredient ? { ingredient: step.ingredient as RecipeStep["ingredient"] } : {}) });
    }
  }
  // Unassigned lines become explicit ingredient steps when planning, never silently optional.
  return { name, instructions, servings, durationMinutes, ingredients, steps };
}
