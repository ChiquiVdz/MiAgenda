import "server-only";
import type { calendar_v3 } from "googleapis";
import type { Prisma } from "@/generated/prisma/client";

export class TaskActivityError extends Error {
  constructor(message: string, readonly status = 409) { super(message); }
}

export async function taskActivityForInbox(tx: Prisma.TransactionClient, userId: string, inboxId: string) {
  const source = await tx.activityLegacySource.findUnique({ where: { userId_source_sourceId: { userId, source: "inbox_item", sourceId: inboxId } }, include: { activity: { include: { calendarLink: true } } } });
  if (!source || source.activity.kind !== "task" || source.activity.lifecycle !== "visible") throw new TaskActivityError("Actualiza Inbox antes de continuar.");
  return source.activity;
}

// Call under the owner's lock, using a live Google response. Reading an untouched
// Google event does not create an activity; its first app state change does.
export async function cacheTaskEvent(tx: Prisma.TransactionClient, userId: string, calendarId: string, event: calendar_v3.Schema$Event) {
  if (!event.id || event.status === "cancelled" || !event.start || !event.end) return null;
  const child = await tx.scheduledSubtask.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: event.id } } });
  if (child) return null; // Child identities are migrated in block 3.
  const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: event.id } } });
  if (!overlay || overlay.kind === "meal") return null;
  const link = await tx.activityCalendarLink.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: event.id } }, include: { activity: true } });
  if (!link) return null;
  if (await tx.activityOperation.count({ where: { userId, activityId: link.activityId, finishedAt: null } })) return link.activity;
  const title = event.summary ?? "(Sin título)", description = event.description ?? null;
  if (link.activity.title !== title || link.activity.description !== description || link.activity.lifecycle !== "visible") {
    await tx.activity.update({ where: { id: link.activityId }, data: { title, description, lifecycle: "visible", revision: { increment: 1 } } });
  }
  const start = event.start.dateTime ?? (event.start.date ? `${event.start.date}T00:00:00-06:00` : null);
  const end = event.end.dateTime ?? (event.end.date ? `${event.end.date}T00:00:00-06:00` : null);
  if (link.state !== "confirmed" || link.etag !== event.etag || link.startSnapshot?.getTime() !== (start ? Date.parse(start) : undefined) || link.endSnapshot?.getTime() !== (end ? Date.parse(end) : undefined)) {
    await tx.activityCalendarLink.update({ where: { id: link.id }, data: { state: "confirmed", etag: event.etag,
      startSnapshot: start ? new Date(start) : null, endSnapshot: end ? new Date(end) : null, allDay: Boolean(event.start.date) } });
  }
  return tx.activity.findUniqueOrThrow({ where: { id: link.activityId } });
}

export async function assertTaskAvailable(tx: Prisma.TransactionClient, userId: string, calendarId: string, eventId: string) {
  const pending = await tx.activityOperation.findFirst({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId, finishedAt: null } });
  if (pending) throw new TaskActivityError("Hay un traslado a Inbox pendiente. Reintenta Quitar horario o abre Inbox para recuperar el traslado.");
}

export async function retireTaskEvent(tx: Prisma.TransactionClient, userId: string, calendarId: string, eventId: string) {
  const link = await tx.activityCalendarLink.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: eventId } } });
  if (!link) return;
  await assertTaskAvailable(tx, userId, calendarId, eventId);
  await tx.activityCalendarLink.update({ where: { id: link.id }, data: { state: "retired" } });
  await tx.activity.update({ where: { id: link.activityId }, data: { lifecycle: "retired" } });
}

type VisibleTaskEvent = { id: string; calendarId: string; summary: string; description?: string | null;
  etag: string | null; startDate: string | null; endDate: string | null; startDateTime: string | null; endDateTime: string | null };
export async function refreshTaskEventCaches(tx: Prisma.TransactionClient, userId: string, events: VisibleTaskEvent[]) {
  if (!events.length) return [];
  const input = JSON.stringify(events);
  // Batch remote cache refreshes; do not issue a database round trip per calendar cell.
  await tx.$executeRaw`UPDATE activities a SET title=v.summary,description=v.description,lifecycle='visible',
    revision=a.revision+1,updated_at=CURRENT_TIMESTAMP
    FROM activity_calendar_links l JOIN jsonb_to_recordset(${input}::jsonb)
      AS v(id text,"calendarId" text,summary text,description text) ON l.google_calendar_id=v."calendarId" AND l.google_event_id=v.id
    WHERE l.user_id=${userId} AND a.id=l.activity_id AND a.kind='task'
      AND NOT EXISTS(SELECT 1 FROM activity_operations o WHERE o.activity_id=a.id AND o.finished_at IS NULL)
      AND NOT EXISTS(SELECT 1 FROM inbox_items i JOIN activity_legacy_sources s ON s.source_id=i.id AND s.user_id=i.user_id AND s.source='inbox_item'
        WHERE s.activity_id=a.id AND i.transfer_payload IS NOT NULL)
      AND (a.title IS DISTINCT FROM v.summary OR a.description IS DISTINCT FROM v.description OR a.lifecycle<>'visible')`;
  await tx.$executeRaw`UPDATE activity_calendar_links l SET state='confirmed',etag=v.etag,
    start_snapshot=COALESCE(v."startDateTime",v."startDate" || 'T00:00:00-06:00')::timestamptz AT TIME ZONE 'UTC',
    end_snapshot=COALESCE(v."endDateTime",v."endDate" || 'T00:00:00-06:00')::timestamptz AT TIME ZONE 'UTC',
    all_day=(v."startDate" IS NOT NULL),updated_at=CURRENT_TIMESTAMP
    FROM jsonb_to_recordset(${input}::jsonb) AS v(id text,"calendarId" text,etag text,"startDateTime" text,"endDateTime" text,"startDate" text,"endDate" text)
    WHERE l.user_id=${userId} AND l.google_calendar_id=v."calendarId" AND l.google_event_id=v.id
      AND NOT EXISTS(SELECT 1 FROM activity_operations o WHERE o.activity_id=l.activity_id AND o.finished_at IS NULL)
      AND NOT EXISTS(SELECT 1 FROM inbox_items i JOIN activity_legacy_sources s ON s.source_id=i.id AND s.user_id=i.user_id AND s.source='inbox_item'
        WHERE s.activity_id=l.activity_id AND i.transfer_payload IS NOT NULL)
      AND (l.state<>'confirmed' OR l.etag IS DISTINCT FROM v.etag)`;
  return tx.activityCalendarLink.findMany({ where: { userId, OR: events.map((event) => ({ googleCalendarId: event.calendarId, googleEventId: event.id })) }, include: { activity: true } });
}
