import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { syncMealSchedules } from "@/lib/meal-state";

// Refresh Google's meal times before entering the completion transaction/lock.
export async function refreshScheduledMeal(userId: string, calendarId: string, eventId: string) {
  const visited = new Set<string>();
  for (;;) {
    const key = `${calendarId}\0${eventId}`;
    if (visited.has(key)) return;
    visited.add(key);
    const link = await prisma.scheduledSubtask.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: eventId } } });
    if (!link?.active || !link.parentCalendarId || !link.parentEventId) return;
    calendarId = link.parentCalendarId; eventId = link.parentEventId;
    const parent = await prisma.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: eventId } }, select: { kind: true } });
    if (parent?.kind === "meal") {
      await syncMealSchedules(userId, await getGoogleCalendarClient(userId));
      return;
    }
  }
}
