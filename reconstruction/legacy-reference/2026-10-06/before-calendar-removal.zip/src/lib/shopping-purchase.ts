import type { Prisma } from "@/generated/prisma/client";

export class ShoppingPurchaseError extends Error {
  constructor(readonly status: number, message: string) { super(message); }
}

// Shared by individual and bulk purchases so both follow the same inventory rules.
export async function purchaseItem(tx: Prisma.TransactionClient, userId: string, listId: string, itemId: string, quantity: number) {
  const item = await tx.shoppingListItem.findFirst({ where: { id: itemId, shoppingListId: listId, shoppingList: { userId } } });
  if (!item) throw new ShoppingPurchaseError(404, "No encontramos ese artículo en tu lista.");
  if (item.purchasedAt) return { alreadyPurchased: true, pantryItems: 0 };
  const claim = await tx.shoppingListItem.updateMany({ where: { id: itemId, purchasedAt: null }, data: { quantity, purchasedAt: new Date(), purchasedQuantity: quantity } });
  if (!claim.count) return { alreadyPurchased: true, pantryItems: 0 };
  if (item.ingredientId) {
    const pantry = await tx.pantryItem.upsert({
      where: { userId_ingredientId: { userId, ingredientId: item.ingredientId } },
      create: { userId, ingredientId: item.ingredientId, quantity },
      update: { quantity: { increment: quantity } },
    });
    if (pantry.quantity.greaterThan("999999999.999")) throw new ShoppingPurchaseError(400, "La compra superaría el máximo permitido en alacena.");
  }
  return { alreadyPurchased: false, pantryItems: item.ingredientId ? 1 : 0 };
}

export async function undoPurchase(tx: Prisma.TransactionClient, userId: string, listId: string, itemId: string) {
  const item = await tx.shoppingListItem.findFirst({ where: { id: itemId, shoppingListId: listId, shoppingList: { userId } } });
  if (!item) throw new ShoppingPurchaseError(404, "No encontramos esa compra.");
  if (!item.purchasedAt) return { alreadyUndone: true };
  if (!item.purchasedQuantity) throw new ShoppingPurchaseError(409, "No encontramos la cantidad de esta compra para deshacerla.");
  const claim = await tx.shoppingListItem.updateMany({ where: { id: itemId, purchasedAt: item.purchasedAt }, data: { purchasedAt: null, purchasedQuantity: null } });
  if (!claim.count) return { alreadyUndone: true };
  if (item.ingredientId) {
    const updated = await tx.pantryItem.updateMany({
      where: { userId, ingredientId: item.ingredientId, quantity: { gte: item.purchasedQuantity } },
      data: { quantity: { decrement: item.purchasedQuantity } },
    });
    if (!updated.count) throw new ShoppingPurchaseError(409, "No puedes deshacer esta compra porque parte de la cantidad ya se consumió o se quitó de la alacena. Deshaz primero ese consumo o ajusta las existencias.");
    const key = `ingredient:${item.ingredientId}`;
    const pending = await tx.shoppingListItem.findUnique({ where: { shoppingListId_itemKey: { shoppingListId: listId, itemKey: key } } });
    if (pending && pending.id !== item.id) {
      if (pending.purchasedAt) {
        await tx.shoppingListItem.update({ where: { id: pending.id }, data: { itemKey: `purchased:${pending.id}` } });
      } else {
        // Keep this row's identity for safe retries. The automatic calculation refreshes its quantity.
        await tx.shoppingListItem.delete({ where: { id: pending.id } });
      }
    }
    await tx.shoppingListItem.update({ where: { id: item.id }, data: { itemKey: key, quantity: item.purchasedQuantity } });
  }
  return { alreadyUndone: false };
}
