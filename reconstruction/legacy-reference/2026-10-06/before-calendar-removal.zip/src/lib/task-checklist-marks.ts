import "server-only";
import { createHash } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@/generated/prisma/client";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { readChecklist, ChecklistError } from "@/lib/activity-checklist";

export async function applyChecklistMarks(userId: string, calendarId: string, eventId: string, body: { scope?: unknown; changes?: unknown; key?: unknown; version?: unknown }) {
  if (!["following", "all"].includes(String(body.scope)) || typeof body.key !== "string" || !/^[\w-]{8,100}$/.test(body.key)
    || typeof body.version !== "string" || !Array.isArray(body.changes) || !body.changes.length || body.changes.length > 50) throw new ChecklistError("Elige el alcance de las marcas y las subtareas que cambiaste.", 400);
  const ids = new Set<string>();
  const changes = body.changes.map((change) => {
    if (!change || typeof change.id !== "string" || !/^[\w-]{1,100}$/.test(change.id) || ids.has(change.id) || typeof change.completed !== "boolean") throw new ChecklistError("Revisa las marcas seleccionadas.", 400);
    ids.add(change.id); return { id: change.id as string, completed: change.completed as boolean };
  });
  const fingerprint = createHash("sha256").update(JSON.stringify([calendarId, eventId, body.scope, changes])).digest("hex");
  const id = createHash("sha256").update(JSON.stringify([userId, body.key])).digest("hex");
  const google = await getGoogleCalendarClient(userId);
  const { data: calendar } = await google.calendarList.get({ calendarId });
  if (!["owner", "writer"].includes(calendar.accessRole ?? "")) throw new ChecklistError("Necesitas permiso para modificar este calendario.", 403);
  const { data: event } = await google.events.get({ calendarId, eventId });
  if (!event.recurringEventId || event.status === "cancelled") throw new ChecklistError("Abre una repetición vigente para aplicar marcas a la serie.");
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const existing = await tx.taskChecklistMark.findUnique({ where: { id } });
    if (existing && existing.fingerprint !== fingerprint) throw new ChecklistError("Este intento corresponde a otras marcas.");
    if (!existing) {
      if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Reanuda el cambio pendiente de Agenda antes de aplicar marcas.");
      const state = await readChecklist(tx, userId, calendarId, event);
      if (state.overlay?.purgeStartedAt) throw new ChecklistError("La retención está procesando esta repetición.");
      if (state.version !== body.version) throw new ChecklistError("Las subtareas cambiaron. Actualiza antes de aplicar las marcas.");
      if (changes.some((change) => !state.steps.some((step) => step.id === change.id && step.completed === change.completed))) throw new ChecklistError("Guarda primero las marcas de esta repetición.");
      const key = { userId, googleCalendarId: calendarId, googleEventId: event.recurringEventId! };
      const member = await tx.taskSeriesMember.findUnique({ where: { userId_googleCalendarId_googleEventId: key } });
      const rootId = member?.rootId ?? event.recurringEventId!;
      await tx.taskSeriesMember.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: { ...key, rootId }, update: {} });
      const previous = await tx.taskChecklistMark.findFirst({ where: { userId, googleCalendarId: calendarId, rootId }, orderBy: { createdAt: "desc" } });
      const createdAt = new Date(Math.max(Date.now(), (previous?.createdAt.getTime() ?? 0) + 1, (state.overlay?.checklistMarkedAt?.getTime() ?? 0) + 1));
      const origin = event.originalStartTime ?? event.start;
      await tx.taskChecklistMark.create({ data: { id, userId, googleCalendarId: calendarId, rootId, fingerprint, changes: changes as Prisma.InputJsonValue,
        from: body.scope === "following" ? new Date(origin?.dateTime ?? `${origin?.date}T00:00:00-06:00`) : null, createdAt } });
      await tx.taskSeriesMember.updateMany({ where: { userId, googleCalendarId: calendarId, rootId }, data: { markScanFrom: null, markScanPageToken: null, markScanUpper: null } });
    }
    const state = await readChecklist(tx, userId, calendarId, event);
    return { steps: state.steps, version: state.version, completedAt: state.overlay?.completedAt?.toISOString() ?? null, keep: state.overlay?.keep ?? false, applied: true };
  }, { timeout: 30000 });
}
