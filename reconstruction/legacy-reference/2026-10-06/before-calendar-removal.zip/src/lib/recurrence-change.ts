import "server-only";
import { createHash } from "node:crypto";
import type { calendar_v3 } from "googleapis";
import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { buildRecurrence, parseRecurrence, type RepeatConfig } from "@/lib/task-recurrence";
import { readChecklist, writeChecklist, pendingSteps, validateSteps, ChecklistError, type ActivityStep } from "@/lib/activity-checklist";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { renameScheduledParent } from "@/lib/scheduled-subtask-state";
import { deleteScheduledChildren, unlinkScheduledEvent } from "@/lib/scheduled-subtask-lifecycle";

type Event = calendar_v3.Schema$Event;
export type ChangeInput = { calendarId: string; eventId: string; etag: string; seriesEtag?: string; key: string;
  scope: "this" | "following" | "all"; action: "edit" | "delete";
  summary?: string; start?: Event["start"]; end?: Event["end"]; repeat?: RepeatConfig | null; steps?: ActivityStep[]; version?: string };
type Plan = { input: ChangeInput; original: Event; master: Event; targetId: string; newId?: string;
  patch?: Event; trim?: string[]; steps: ActivityStep[]; affectedIds: string[]; origins: Record<string, number>; structural: boolean; split: boolean;
  owners?: Record<string, string>; family?: Event[]; extra?: { event: Event; patch?: Event; remove: boolean }[] };
const hash = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const status = (error: unknown) => Number((error as { code?: number; response?: { status?: number } }).response?.status ?? (error as { code?: number }).code);
const at = (value: Event["start"]) => Date.parse(value?.dateTime ?? `${value?.date}T00:00:00-06:00`);
const originalAt = (event: Event) => at(event.originalStartTime ?? event.start);
const compact = (time: number) => new Date(time).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
const dayKey = (time: number) => new Intl.DateTimeFormat("en-CA", { timeZone: "America/Mexico_City", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(time));
const json = (value: unknown) => JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;

// Only supported RRULEs are expanded locally to keep COUNT correct after splitting a series.
function countBefore(master: Event, cutoff: number) {
  const config = parseRecurrence(master.recurrence ?? [], dayKey(at(master.start)));
  if (!config) throw new ChecklistError("Esta serie tiene una regla especial de Google. Cambia su repetición o edítala directamente en Google Calendar.");
  const start = at(master.start); let count = 0;
  const anchor = new Date(`${dayKey(start)}T12:00:00Z`);
  const anchorWeek = new Date(anchor); anchorWeek.setUTCDate(anchorWeek.getUTCDate() - (anchorWeek.getUTCDay() + 6) % 7);
  for (let day = 0; day < 100000; day++) {
    const current = new Date(anchor.getTime() + day * 86400000);
    const instant = start + day * 86400000;
    if (instant >= cutoff) return count;
    const weekday = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][current.getUTCDay()];
    const monthDiff = (current.getUTCFullYear() - anchor.getUTCFullYear()) * 12 + current.getUTCMonth() - anchor.getUTCMonth();
    const hit = config.frequency === "daily" ? day % config.interval === 0
      : config.frequency === "weekly" ? Math.floor((current.getTime() - anchorWeek.getTime()) / (7 * 86400000)) % config.interval === 0 && config.days.includes(weekday)
      : config.frequency === "monthly" ? monthDiff % config.interval === 0 && current.getUTCDate() === anchor.getUTCDate()
      : (current.getUTCFullYear() - anchor.getUTCFullYear()) % config.interval === 0 && current.getUTCMonth() === anchor.getUTCMonth() && current.getUTCDate() === anchor.getUTCDate();
    if (hit) count++;
  }
  throw new ChecklistError("La serie abarca demasiado tiempo para dividirla desde aquí.");
}
function trimRule(master: Event, cutoff: number) {
  if (master.recurrence?.length !== 1 || !master.recurrence[0].startsWith("RRULE:")) throw new ChecklistError("Esta serie usa reglas especiales. Divide la serie desde Google Calendar.");
  const until = master.start?.date ? dayKey(cutoff - 86400000).replaceAll("-", "") : compact(cutoff - 1000);
  return [master.recurrence[0].split(";").filter((part) => !part.startsWith("COUNT=") && !part.startsWith("UNTIL=")).join(";") + `;UNTIL=${until}`];
}
function shiftedStart(master: Event, original: Event, desired: Event["start"]): Event["start"] {
  const value = at(master.start) + at(desired) - at(original.start);
  return desired?.date ? { date: dayKey(value) } : { dateTime: new Date(value).toISOString(), timeZone: desired?.timeZone ?? "America/Mexico_City" };
}
export function validateChange(input: ChangeInput) {
  if (!input || !["this", "following", "all"].includes(input.scope) || !["edit", "delete"].includes(input.action)
    || typeof input.calendarId !== "string" || !input.calendarId || input.calendarId.length > 1024
    || typeof input.eventId !== "string" || !input.eventId || input.eventId.length > 1024
    || typeof input.etag !== "string" || !input.etag || input.etag.length > 300
    || typeof input.key !== "string" || !/^[\w-]{8,100}$/.test(input.key)) throw new ChecklistError("Revisa la actividad y el alcance del cambio.", 400);
  if (input.action === "edit") {
    if (typeof input.summary !== "string" || !input.summary.trim() || input.summary.trim().length > 250
      || !Number.isFinite(at(input.start)) || !Number.isFinite(at(input.end)) || at(input.end) <= at(input.start)
      || Boolean(input.start?.date) !== Boolean(input.end?.date)) throw new ChecklistError("Revisa el título, las fechas y las horas.", 400);
    validateSteps(input.steps ?? []);
    if (typeof input.version !== "string" || !input.version) throw new ChecklistError("Carga las subtareas antes de guardar la tarea.", 400);
    if (input.repeat) {
      try {
        buildRecurrence(input.repeat, Boolean(input.start?.date));
        if (input.repeat.frequency !== "none" && input.repeat.ending === "date" && input.repeat.until < dayKey(at(input.start))) throw new Error("La repetición no puede terminar antes de iniciar.");
      } catch (error) { throw new ChecklistError(error instanceof Error ? error.message : "Revisa la repetición.", 400); }
    }
  }
}
export async function prepareChange(userId: string, input: ChangeInput) {
  validateChange(input);
  const id = hash([userId, input.key]); const fingerprint = hash(input);
  const google = await getGoogleCalendarClient(userId);
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    if (await tx.activityOperation.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Termina el traslado pendiente a Inbox antes de cambiar o eliminar tareas.");
    const existing = await tx.recurrenceChange.findFirst({ where: { id, userId } });
    if (existing) {
      if (existing.fingerprint !== fingerprint) throw new ChecklistError("Hay un intento pendiente con otros datos. Reanúdalo antes de cambiar la actividad.");
      return existing;
    }
    if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Reanuda el cambio pendiente de Agenda antes de iniciar otro.");
    const { data: calendar } = await google.calendarList.get({ calendarId: input.calendarId });
    if (!["owner", "writer"].includes(calendar.accessRole ?? "")) throw new ChecklistError("Necesitas permiso para escribir en este calendario.", 403);
    const { data: original } = await google.events.get({ calendarId: input.calendarId, eventId: input.eventId });
    const scheduledChild = await tx.scheduledSubtask.findFirst({ where: { userId, googleCalendarId: input.calendarId, googleEventId: input.eventId } });
    const childTitleLimit = scheduledChild?.stepId.startsWith("meal") ? 250 : 150;
    if (scheduledChild && input.action === "edit" && (input.summary!.trim().length > childTitleLimit || input.start?.date || input.repeat && input.repeat.frequency !== "none")) throw new ChecklistError(`La subtarea usa un horario de inicio y fin, hasta ${childTitleLimit} caracteres y solo esta instancia.`);
    if (original.etag !== input.etag || original.status === "cancelled") throw new ChecklistError("La tarea cambió en Google. Actualiza Agenda antes de guardar.");
    const state = await readChecklist(tx, userId, input.calendarId, original);
    if (state.overlay?.purgeStartedAt) throw new ChecklistError("La retención está procesando esta tarea.");
    if (input.action === "edit" && input.version && state.version !== input.version) throw new ChecklistError("Las subtareas cambiaron. Actualízalas antes de guardar.");
    let master = original.recurringEventId ? (await google.events.get({ calendarId: input.calendarId, eventId: original.recurringEventId })).data : original;
    if (input.scope !== "this" && input.seriesEtag && master.etag !== input.seriesEtag) throw new ChecklistError("La serie cambió en Google. Vuelve a abrir la tarea.");
    const series = Boolean(master.recurrence?.length);
    const memberKey = { userId, googleCalendarId: input.calendarId, googleEventId: master.id! };
    const member = await tx.taskSeriesMember.findUnique({ where: { userId_googleCalendarId_googleEventId: memberKey } });
    const rootId = member?.rootId ?? master.id!;
    const family: Event[] = [master];
    if (series && input.scope !== "this") {
      const members = await tx.taskSeriesMember.findMany({ where: { userId, googleCalendarId: input.calendarId, rootId } });
      for (const linked of members) {
        if (linked.googleEventId === master.id) continue;
        try {
          const remote = (await google.events.get({ calendarId: input.calendarId, eventId: linked.googleEventId })).data;
          if (remote.status !== "cancelled") family.push(remote);
        } catch (error) { if (![404, 410].includes(status(error))) throw error; }
      }
      family.sort((a, b) => at(a.start) - at(b.start));
      if (input.scope === "all" && input.repeat) master = family[0];
    }
    const familyIds = family.map((event) => event.id!);
    const split = series && input.scope === "following" && originalAt(original) > at(master.start);
    const targetId = series && input.scope !== "this" ? master.id! : original.id!;
    const steps = validateSteps(input.steps ?? state.steps);
    let recurrence = input.repeat ? buildRecurrence(input.repeat, Boolean(input.start?.date)) : master.recurrence ?? [];
    if (series && input.scope === "this" && input.repeat) throw new ChecklistError("Para cambiar la repetición, elige esta y las siguientes o toda la serie.");
    if (split && input.action === "edit" && !input.repeat) {
      const count = /(?:^|;)COUNT=(\d+)/.exec(recurrence[0] ?? "");
      if (count) recurrence = recurrence.map((rule) => rule.replace(/COUNT=\d+/, `COUNT=${Math.max(1, Number(count[1]) - countBefore(master, originalAt(original)))}`));
    }
    const structural = input.action === "edit" && (at(input.start) !== at(original.start) || at(input.end) !== at(original.end)
      || (input.repeat !== undefined && input.repeat !== null && hash(recurrence) !== hash(master.recurrence ?? [])));
    const candidates = await tx.eventOverlay.findMany({ where: { userId, googleCalendarId: input.calendarId,
      OR: [{ googleEventId: { in: familyIds } }, { recurringEventId: { in: familyIds } }, ...familyIds.map((id) => ({ googleEventId: { startsWith: `${id}_` } }))],
    } });
    const affectedIds: string[] = [];
    const origins: Record<string, number> = {};
    const owners: Record<string, string> = {};
    for (const overlay of candidates) {
      let affected = input.scope === "all" || !series || input.scope === "this" && overlay.googleEventId === original.id;
      if (series && input.scope !== "this") {
        try { const remote = (await google.events.get({ calendarId: input.calendarId, eventId: overlay.googleEventId })).data; const origin = originalAt(remote); if (input.scope === "following") affected = origin >= originalAt(original); origins[overlay.id] = origin; owners[overlay.id] = remote.recurringEventId ?? remote.id!; }
        catch (error) { if (![404, 410].includes(status(error))) throw error; }
      }
      if (!affected) continue;
      if (overlay.purgeStartedAt) throw new ChecklistError("La retención está procesando una tarea de esta serie.");
      affectedIds.push(overlay.id);
    }
    if (await tx.mealPlan.count({ where: { userId, googleCalendarId: input.calendarId, OR: [{ googleEventId: master.id! }, { googleEventId: { startsWith: `${master.id}_` } }] } })) throw new ChecklistError("Las comidas se editan desde su flujo especializado.");
    const scheduled = await tx.scheduledSubtask.findMany({ where: { userId, parentCalendarId: input.calendarId,
      parentEventId: { in: candidates.filter((overlay) => affectedIds.includes(overlay.id)).map((overlay) => overlay.googleEventId) } } });
    if (scheduled.length && input.action === "edit" && !series && input.repeat && input.repeat.frequency !== "none") throw new ChecklistError("Quita primero los horarios de las subtareas antes de convertir la principal en una serie recurrente.");
    if (!series && recurrence.length && (state.overlay?.completedAt || state.steps.some((step) => step.completed))) throw new ChecklistError("Deshaz el progreso de esta tarea antes de convertirla en una serie recurrente.");
    let patch: Event | undefined;
    if (input.action === "edit") {
      const start = series && input.scope === "all" ? shiftedStart(master, original, input.start) : input.start;
      const duration = at(input.end) - at(input.start);
      const end = start?.date ? { date: dayKey(at(start) + duration) } : { dateTime: new Date(at(start) + duration).toISOString(), timeZone: start?.timeZone ?? "America/Mexico_City" };
      patch = { summary: input.summary!.trim(), start, end,
        ...(series && input.scope !== "this" || !series ? { recurrence } : {}) };
    }
    const extra: NonNullable<Plan["extra"]> = [];
    const delta = input.action === "edit" ? at(input.start) - at(original.start) : 0;
    for (const linked of family) {
      if (linked.id === targetId || input.scope === "this" || input.scope === "following" && at(linked.start) < originalAt(original)) continue;
      const remove = input.action === "delete" || Boolean(input.repeat);
      if (remove) { extra.push({ event: linked, remove: true }); continue; }
      const start = shiftedStart(linked, original, input.start);
      const endTime = at(start) + at(input.end) - at(input.start);
      extra.push({ event: linked, remove, ...(!remove ? { patch: { summary: input.summary!.trim(), start, end: start?.date ? { date: dayKey(endTime) } : { dateTime: new Date(endTime).toISOString(), timeZone: start?.timeZone } } } : {}) });
    }
    // Google exceptions keep their own fields when only their master is patched.
    if (series && input.scope !== "this") {
      let pageToken: string | undefined;
      do {
        const response = await google.events.list({ calendarId: input.calendarId, singleEvents: false, showDeleted: false, maxResults: 2500, pageToken });
        for (const exception of response.data.items ?? []) {
          if (!exception.recurringEventId || !familyIds.includes(exception.recurringEventId) || input.scope === "following" && originalAt(exception) < originalAt(original)) continue;
          const remove = input.action === "delete" || split && exception.recurringEventId === targetId || Boolean(input.repeat);
          const startTime = originalAt(exception) + delta;
          const start = input.start?.date ? { date: dayKey(startTime) } : { dateTime: new Date(startTime).toISOString(), timeZone: input.start?.timeZone };
          const endTime = startTime + at(input.end) - at(input.start);
          extra.push({ event: exception, remove, ...(!remove ? { patch: { summary: input.summary!.trim(), ...(structural ? { start, end: start.date ? { date: dayKey(endTime) } : { dateTime: new Date(endTime).toISOString(), timeZone: input.end?.timeZone } } : {}) } } : {}) });
        }
        pageToken = response.data.nextPageToken ?? undefined;
      } while (pageToken);
    }
    const newId = split && input.action === "edit" ? `task${id.slice(0, 40)}` : undefined;
    if (series || patch?.recurrence?.length) {
      await tx.taskSeriesMember.upsert({ where: { userId_googleCalendarId_googleEventId: memberKey }, create: { ...memberKey, rootId }, update: {} });
      if (newId) await tx.taskSeriesMember.upsert({ where: { userId_googleCalendarId_googleEventId: { ...memberKey, googleEventId: newId } }, create: { ...memberKey, googleEventId: newId, rootId }, update: {} });
    }
    const plan: Plan = { input, original, master, targetId, ...(newId ? { newId } : {}),
      ...(patch ? { patch } : {}), ...(split ? { trim: trimRule(master, originalAt(original)) } : {}), steps, affectedIds, origins, owners, family, extra, structural, split };
    return tx.recurrenceChange.create({ data: { id, userId, fingerprint, plan: json(plan) } });
  }, { timeout: 60000, maxWait: 10000 });
}

function matches(event: Event, patch: Event) {
  return (patch.summary === undefined || event.summary === patch.summary)
    && (!patch.start || at(event.start) === at(patch.start)) && (!patch.end || at(event.end) === at(patch.end))
    && (patch.recurrence === undefined || hash(event.recurrence ?? []) === hash(patch.recurrence));
}
export async function resumeChange(userId: string, id: string) {
  const google = await getGoogleCalendarClient(userId);
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const job = await tx.recurrenceChange.findFirst({ where: { id, userId } });
    if (!job) throw new ChecklistError("Este cambio ya no está disponible.", 404);
    if (job.finishedAt) return { done: true };
    const plan = job.plan as unknown as Plan;
    const { input } = plan;
    const checkpoints = await tx.eventOverlay.findMany({ where: { userId, id: { in: plan.affectedIds } } });
    if (checkpoints.some((overlay) => overlay.purgeStartedAt)) throw new ChecklistError("Espera a que termine la retención y reanuda el cambio.");
    const { data: calendar } = await google.calendarList.get({ calendarId: input.calendarId });
    if (!["owner", "writer"].includes(calendar.accessRole ?? "")) throw new ChecklistError("Google no permite modificar ese calendario.", 403);
    const expected = input.scope === "this" ? plan.original : plan.master;
    const remotePatch = plan.split ? { recurrence: plan.trim } : plan.patch;
    let current: Event | null = null;
    try { current = (await google.events.get({ calendarId: input.calendarId, eventId: plan.targetId })).data; }
    catch (error) { if (![404, 410].includes(status(error))) throw error; }
    const deleting = input.action === "delete" && !plan.split;
    const removeChildren = async () => { if (input.action === "delete") {
      // The persisted recurrence job includes every private instance, including exceptions.
      for (const overlay of checkpoints) await deleteScheduledChildren(tx, userId, { calendarId: input.calendarId, eventId: overlay.googleEventId });
      await deleteScheduledChildren(tx, userId, { calendarId: input.calendarId, eventId: plan.targetId });
    } };
    if (current && current.status !== "cancelled") {
      const applied = current.extendedProperties?.private?.miagendaChange === job.id;
      if (!applied && current.etag !== expected.etag) throw new ChecklistError("La tarea o serie cambió en Google mientras se guardaba. Revisa Google antes de reanudar.");
      if (applied && !deleting && !matches(current, remotePatch!)) throw new ChecklistError("Google tiene cambios posteriores a este intento. Revísalos antes de reanudar.");
      await removeChildren();
      if (deleting) await google.events.delete({ calendarId: input.calendarId, eventId: plan.targetId, sendUpdates: "none" }, { headers: { "If-Match": current.etag! } });
      else if (!applied) current = (await google.events.patch({ calendarId: input.calendarId, eventId: plan.targetId, sendUpdates: "none", requestBody: {
        ...remotePatch, extendedProperties: { ...current.extendedProperties, private: { ...current.extendedProperties?.private, miagendaChange: job.id } },
      } }, { headers: { "If-Match": current.etag! } })).data;
    } else if (!deleting) throw new ChecklistError("La tarea o serie fue eliminada de Google.", 404);
    else await removeChildren();
    let destination = current;
    if (plan.newId) {
      try { destination = (await google.events.get({ calendarId: input.calendarId, eventId: plan.newId })).data; }
      catch (error) { if (![404, 410].includes(status(error))) throw error; destination = null; }
      if (!destination) destination = (await google.events.insert({ calendarId: input.calendarId, sendUpdates: "none", requestBody: {
        id: plan.newId, description: plan.master.description, location: plan.master.location, colorId: plan.master.colorId,
        reminders: plan.master.reminders, visibility: plan.master.visibility, transparency: plan.master.transparency,
        ...plan.patch, extendedProperties: { private: { miagendaChange: job.id } },
      } })).data;
      if (destination.status === "cancelled" || destination.extendedProperties?.private?.miagendaChange !== job.id || !matches(destination, plan.patch!)) throw new ChecklistError("La nueva serie tiene otros cambios en Google. Revísala antes de reanudar.");
    }
    for (const change of plan.extra ?? []) {
      let remote: Event | undefined;
      try { remote = (await google.events.get({ calendarId: input.calendarId, eventId: change.event.id! })).data; }
      catch (error) { if (![404, 410].includes(status(error))) throw error; }
      if (!remote || remote.status === "cancelled") continue;
      const applied = remote.extendedProperties?.private?.miagendaChange === job.id;
      if (!applied && remote.etag !== change.event.etag && !(change.patch && matches(remote, change.patch))) throw new ChecklistError("Una repetición cambió en Google durante el guardado. Revisa y reanuda el cambio.");
      if (change.remove) await google.events.delete({ calendarId: input.calendarId, eventId: remote.id!, sendUpdates: "none" }, { headers: { "If-Match": remote.etag! } });
      else if (!applied) await google.events.patch({ calendarId: input.calendarId, eventId: remote.id!, sendUpdates: "none", requestBody: {
        ...change.patch, extendedProperties: { ...remote.extendedProperties, private: { ...remote.extendedProperties?.private, miagendaChange: job.id } },
      } }, { headers: { "If-Match": remote.etag! } });
      else if (!matches(remote, change.patch!)) throw new ChecklistError("Una repetición recibió otros cambios después de este intento. Revísala antes de reanudar.");
    }
    const affected = await tx.eventOverlay.findMany({ where: { userId, id: { in: plan.affectedIds } } });
    if (affected.some((overlay) => overlay.purgeStartedAt)) throw new ChecklistError("Espera a que termine la retención y reanuda el cambio.");
    if (input.action === "delete") {
      for (const eventId of [...affected.map((overlay) => overlay.googleEventId), plan.targetId]) await unlinkScheduledEvent(tx, userId, input.calendarId, eventId, true);
      await tx.eventOverlay.deleteMany({ where: { userId, id: { in: plan.affectedIds } } });
      await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: input.calendarId,
        googleEventId: { in: affected.map((overlay) => overlay.googleEventId) },
      } });
    }
    if (deleting) await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: input.calendarId, googleEventId: plan.targetId } });
    const removedMasters = (plan.extra ?? []).filter((change) => change.remove && !change.event.recurringEventId).map((change) => change.event.id!);
    if (removedMasters.length) await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: input.calendarId, googleEventId: { in: removedMasters } } });
    if (input.action === "edit" && destination) {
      if (destination.end?.dateTime) await tx.scheduledSubtask.updateMany({ where: { userId, googleCalendarId: input.calendarId, googleEventId: destination.id! }, data: { endSnapshot: new Date(destination.end.dateTime) } });
      await renameScheduledParent(tx, userId, input.calendarId, destination.id!, destination.summary ?? input.summary!);
      await tx.scheduledSubtask.updateMany({ where: { userId, parentCalendarId: input.calendarId, parentEventId: destination.id! }, data: {
        parentEndSnapshot: destination.end?.dateTime ? new Date(destination.end.dateTime) : destination.end?.date ? new Date(`${destination.end.date}T00:00:00-06:00`) : null,
      } });
      const key = { userId, googleCalendarId: input.calendarId, googleEventId: destination.id! };
      if (input.scope === "this" && plan.original.recurringEventId || !destination.recurrence?.length) {
        if (input.scope !== "this" && plan.master.recurrence?.length && !destination.recurrence?.length) {
          const selected = affected.find((overlay) => overlay.googleEventId === plan.original.id);
          await tx.eventOverlay.deleteMany({ where: { userId, id: { in: plan.affectedIds } } });
          if (selected) await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: {
            ...key, kind: "app_task", checklist: selected.checklist ?? Prisma.DbNull, completedAt: selected.completedAt, keep: selected.keep, highlighted: selected.highlighted,
            purgeAfter: selected.completedAt ? eventPurgeAfter(selected.completedAt, destination.end) : null,
          }, update: {} });
        }
        // Read/validate occurred before Google; no competing app edit can pass the user lock.
        await writeChecklist(tx, userId, input.calendarId, destination, plan.steps, undefined, true);
      } else {
        if (!plan.original.recurringEventId && !plan.master.recurrence?.length) await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: input.calendarId, googleEventId: plan.original.id! } });
        const versions = [{ effectiveAt: "1970-01-01T00:00:00.000Z", steps: pendingSteps(plan.steps) }];
        await tx.activityChecklist.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: { ...key, versions: json(versions) }, update: { versions: json(versions), templateId: null } });
        for (const change of plan.extra ?? []) if (!change.remove && !change.event.recurringEventId) {
          const linkedKey = { ...key, googleEventId: change.event.id! };
          await tx.activityChecklist.upsert({ where: { userId_googleCalendarId_googleEventId: linkedKey }, create: { ...linkedKey, versions: json(versions) }, update: { versions: json(versions), templateId: null } });
        }
        for (const overlay of affected) {
          let occurrence: Event | undefined;
          if (plan.split || plan.structural || removedMasters.length > 0) {
            const previousOwner = plan.owners?.[overlay.id] ?? plan.master.id!;
            const owner = previousOwner === plan.master.id || removedMasters.includes(previousOwner) ? destination.id! : previousOwner;
            const origin = plan.origins[overlay.id] + (plan.split && owner === destination.id ? at(plan.patch?.start) - originalAt(plan.original) : at(input.start) - at(plan.original.start));
            if (!Number.isFinite(origin)) { await deleteScheduledChildren(tx, userId, { calendarId: input.calendarId, eventId: overlay.googleEventId }); await tx.eventOverlay.delete({ where: { id: overlay.id } }); continue; }
            const instances = (await google.events.instances({ calendarId: input.calendarId, eventId: owner,
              timeMin: new Date(origin - 86400000).toISOString(), timeMax: new Date(origin + 86400000).toISOString(), maxResults: 100 })).data.items ?? [];
            occurrence = instances.find((event) => event.status !== "cancelled" && originalAt(event) === origin);
            if (!occurrence?.id) { await deleteScheduledChildren(tx, userId, { calendarId: input.calendarId, eventId: overlay.googleEventId }); await tx.eventOverlay.delete({ where: { id: overlay.id } }); continue; }
          } else {
            try { occurrence = (await google.events.get({ calendarId: input.calendarId, eventId: overlay.googleEventId })).data; }
            catch (error) { if (![404, 410].includes(status(error))) throw error; }
            if (!occurrence || occurrence.status === "cancelled") { await deleteScheduledChildren(tx, userId, { calendarId: input.calendarId, eventId: overlay.googleEventId }); await tx.eventOverlay.delete({ where: { id: overlay.id } }); continue; }
          }
          const old = Array.isArray(overlay.checklist) ? overlay.checklist as unknown as ActivityStep[] : [];
          const steps = plan.steps.map((step) => ({ ...step, completed: old.find((item) => item.id === step.id)?.completed ?? (old.length === 0 && Boolean(overlay.completedAt)) }));
          // A Google series split may assign a new ID to this particular parent.
          // Its child's explicit schedule and completion remain independent.
          await tx.scheduledSubtask.updateMany({ where: { userId, parentCalendarId: input.calendarId, parentEventId: overlay.googleEventId }, data: {
            parentEventId: occurrence.id!, parentEndSnapshot: occurrence.end?.dateTime ? new Date(occurrence.end.dateTime)
              : occurrence.end?.date ? new Date(`${occurrence.end.date}T00:00:00-06:00`) : null,
          } });
          await tx.eventOverlay.update({ where: { id: overlay.id }, data: { googleEventId: occurrence.id!, recurringEventId: occurrence.recurringEventId, etag: occurrence.etag } });
          await writeChecklist(tx, userId, input.calendarId, occurrence, steps, undefined, true);
        }
      }
      if (input.scope === "this") {
        const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: key } });
        if (overlay?.completedAt) await tx.eventOverlay.update({ where: { id: overlay.id }, data: { purgeAfter: eventPurgeAfter(overlay.completedAt, destination.end) } });
      }
    }
    if (input.action === "delete" && input.scope === "all") {
      const where = { userId, googleCalendarId: input.calendarId, googleEventId: { in: (plan.family ?? [plan.master]).map((event) => event.id!) } };
      const members = await tx.taskSeriesMember.findMany({ where });
      await tx.taskChecklistMark.deleteMany({ where: { userId, googleCalendarId: input.calendarId, rootId: { in: members.map((member) => member.rootId) } } });
      await tx.taskSeriesMember.deleteMany({ where });
    }
    await tx.recurrenceChange.update({ where: { id: job.id }, data: { finishedAt: new Date(), plan: {} } });
    return { done: true };
  }, { timeout: 60000, maxWait: 10000 });
}

export async function discardChange(userId: string, id: string) {
  const google = await getGoogleCalendarClient(userId);
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const job = await tx.recurrenceChange.findFirst({ where: { userId, id, finishedAt: null } });
    if (!job) return { done: true };
    const plan = job.plan as unknown as Plan;
    const event = (await google.events.get({ calendarId: plan.input.calendarId, eventId: plan.targetId })).data;
    if (event.status === "cancelled" || event.extendedProperties?.private?.miagendaChange === job.id) throw new ChecklistError("Parte del cambio ya se aplicó. Reanúdalo para mantener la serie íntegra.");
    const owners = await tx.eventOverlay.findMany({ where: { userId, id: { in: plan.affectedIds } }, select: { googleEventId: true } });
    const children = (await tx.scheduledSubtask.findMany({ where: { userId, active: true, parentCalendarId: plan.input.calendarId,
      parentEventId: { in: [...owners.map((owner) => owner.googleEventId), plan.targetId] } } })).filter((child) => plan.input.action === "delete" || !plan.steps.some((step) => step.id === child.stepId));
    const seen = new Set(children.map((child) => child.id));
    for (let index = 0; index < children.length; index++) {
      const descendants = await tx.scheduledSubtask.findMany({ where: { userId, active: true, parentCalendarId: children[index].googleCalendarId, parentEventId: children[index].googleEventId } });
      for (const child of descendants) if (!seen.has(child.id)) { seen.add(child.id); children.push(child); }
    }
    for (const child of children) {
      try {
        const remote = (await google.events.get({ calendarId: child.googleCalendarId, eventId: child.googleEventId })).data;
        if (remote.status === "cancelled") throw new ChecklistError("Ya se eliminó una subtarea de este cambio. Reanuda el intento para terminarlo.");
      } catch (error) {
        if ([404, 410].includes(status(error))) throw new ChecklistError("Ya se eliminó una subtarea de este cambio. Reanuda el intento para terminarlo.");
        throw error;
      }
    }
    if (plan.newId) {
      try { await google.events.get({ calendarId: plan.input.calendarId, eventId: plan.newId }); throw new ChecklistError("La nueva serie ya existe. Reanuda el cambio."); }
      catch (error) { if (![404, 410].includes(status(error))) throw error; }
    }
    await tx.recurrenceChange.delete({ where: { id: job.id } });
    return { done: true };
  }, { timeout: 15000 });
}
