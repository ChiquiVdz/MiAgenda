export type MealRequirement = {
  ingredientId: string; name: string; unit: string; requiredQuantity: number; quantityPerServing: number; isOptional?: boolean;
};
export type AvailabilityPlan = {
  id: string; recipeId: string | null; scheduledAt: string | null; completedAt: unknown;
  eventMissing: boolean; servings: number; cookingEnabled: boolean; cookedServings: number;
  createdAt?: Date | string;
  ingredients: MealRequirement[];
};
export type AvailableBatch = {
  id: string; recipeKey: string; originMealPlanId: string | null; cookedAt: string; remainingServings: number;
};
export const roundQuantity = (amount: number) => Math.round(amount * 1000) / 1000;
export function mealTime(plan: AvailabilityPlan) {
  return plan.scheduledAt ? Date.parse(plan.scheduledAt) : Infinity;
}

/** One projection, shared by planning, suggestions, purchases and completion.
 * Pending plans reserve quantities; only completed actions move actual inventory.
 */
export function projectMeals<T extends AvailabilityPlan>(inventory: ReadonlyMap<string, number>, plans: T[], batches: AvailableBatch[]) {
  const stock = new Map(inventory);
  const portions = batches.map((batch) => ({ ...batch, actual: true }));
  const ordered = [...plans].sort((a, b) => mealTime(a) - mealTime(b)
    || (a.createdAt ? new Date(a.createdAt).getTime() : 0) - (b.createdAt ? new Date(b.createdAt).getTime() : 0)
    || a.id.localeCompare(b.id));
  const meals = ordered.map((plan) => {
    const inventoryBefore = new Map(stock);
    const portionAllocations: Array<{ batchId: string; originMealPlanId: string | null; servings: number; actual: boolean }> = [];
    const requiredIngredients: MealRequirement[] = [];
    const missingIngredients: Array<{ ingredientId: string; name: string; unit: string; missingQuantity: number }> = [];
    let missingCookServings = 0;
    if (!plan.completedAt && !plan.eventMissing && plan.scheduledAt) {
      if (plan.cookingEnabled && plan.cookedServings > 0) {
        portions.push({ id: `planned:${plan.id}`, recipeKey: plan.recipeId ?? `deleted:${plan.id}`,
          originMealPlanId: plan.id, cookedAt: plan.scheduledAt, remainingServings: plan.cookedServings, actual: false });
      }
      let remaining = plan.servings;
      const eligible = portions.filter((batch) => batch.recipeKey === (plan.recipeId ?? `deleted:${plan.id}`) && Date.parse(batch.cookedAt) <= mealTime(plan))
        .sort((a, b) => Number(b.originMealPlanId === plan.id) - Number(a.originMealPlanId === plan.id)
          || Date.parse(a.cookedAt) - Date.parse(b.cookedAt) || a.id.localeCompare(b.id));
      for (const batch of eligible) {
        const used = Math.min(remaining, batch.remainingServings);
        if (used <= 0) continue;
        batch.remainingServings -= used;
        remaining -= used;
        portionAllocations.push({ batchId: batch.id, originMealPlanId: batch.originMealPlanId, servings: used, actual: batch.actual });
      }
      missingCookServings = remaining;
      for (const line of plan.ingredients) {
        // Uncovered portions reserve raw ingredients too, but never silently enable cooking.
        const requiredQuantity = roundQuantity(line.requiredQuantity + line.quantityPerServing * missingCookServings);
        requiredIngredients.push({ ...line, requiredQuantity });
        if (line.isOptional) continue;
        const available = stock.get(line.ingredientId) ?? 0;
        const missingQuantity = roundQuantity(Math.max(0, requiredQuantity - available));
        stock.set(line.ingredientId, roundQuantity(Math.max(0, available - requiredQuantity)));
        if (missingQuantity > 0) missingIngredients.push({ ingredientId: line.ingredientId, name: line.name, unit: line.unit, missingQuantity });
      }
    }
    return { ...plan, inventoryBefore, portionAllocations, missingCookServings, missingIngredients, requiredIngredients };
  });
  // Mandatory reservations across the entire timeline take priority over electives.
  const optionalStock = new Map(stock);
  const withOptionals = meals.map((meal) => ({ ...meal, missingOptionalIngredients: meal.requiredIngredients
    .filter((line) => line.isOptional).flatMap((line) => {
      const available = optionalStock.get(line.ingredientId) ?? 0;
      optionalStock.set(line.ingredientId, roundQuantity(Math.max(0, available - line.requiredQuantity)));
      const missingQuantity = roundQuantity(Math.max(0, line.requiredQuantity - available));
      return missingQuantity > 0 ? [{ ingredientId: line.ingredientId, name: line.name, unit: line.unit, missingQuantity }] : [];
    }) }));
  return { meals: withOptionals, inventory: stock, portions };
}
