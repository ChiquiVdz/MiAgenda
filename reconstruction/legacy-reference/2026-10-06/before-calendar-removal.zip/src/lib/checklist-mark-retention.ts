import "server-only";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { readChecklist } from "@/lib/activity-checklist";

// Materialize completed past instances even when their calendar has not been opened.
// Keep a cursor so a long series is handled in bounded cron batches.
export async function synchronizeMarkedSeries(now: Date) {
  const roots = await prisma.taskChecklistMark.findMany({ distinct: ["userId", "googleCalendarId", "rootId"], select: { userId: true, googleCalendarId: true, rootId: true } });
  let budget = 40;
  for (const root of roots) {
    const members = await prisma.taskSeriesMember.findMany({ where: root });
    const google = await getGoogleCalendarClient(root.userId).catch(() => null);
    if (!google) continue;
    for (const member of members) {
      if (budget <= 0) return;
      if (member.markScanFrom && member.markScanFrom >= now) continue;
      try {
        const master = (await google.events.get({ calendarId: root.googleCalendarId, eventId: member.googleEventId })).data;
        if (master.status === "cancelled") continue;
        const upper = member.markScanUpper ?? now;
        const list = master.recurrence?.length ? (await google.events.instances({ calendarId: root.googleCalendarId, eventId: member.googleEventId,
          timeMin: member.markScanFrom?.toISOString(), timeMax: upper.toISOString(), pageToken: member.markScanPageToken ?? undefined, maxResults: Math.min(20, budget), showDeleted: false })).data : { items: [master] };
        const events = (list.items ?? []).filter((event) => event.id && event.start && event.end && event.status !== "cancelled");
        await prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${root.userId}))`;
          const checkpoint = await tx.taskSeriesMember.findUnique({ where: { id: member.id } });
          // A newly applied rule resets this cursor; do not overwrite that reset.
          if (checkpoint?.markScanFrom?.getTime() !== member.markScanFrom?.getTime() || checkpoint?.markScanPageToken !== member.markScanPageToken || checkpoint?.updatedAt.getTime() !== member.updatedAt.getTime()) return;
          if (await tx.recurrenceChange.count({ where: { userId: root.userId, finishedAt: null } })) return;
          for (const event of events) await readChecklist(tx, root.userId, root.googleCalendarId, event);
          await tx.taskSeriesMember.update({ where: { id: member.id }, data: list.nextPageToken ? { markScanPageToken: list.nextPageToken, markScanUpper: upper } : { markScanFrom: upper, markScanPageToken: null, markScanUpper: null } });
        }, { timeout: 30000 });
        budget -= Math.max(1, events.length);
      } catch (error) {
        const code = Number((error as { code?: number; response?: { status?: number } }).response?.status ?? (error as { code?: number }).code);
        if (code === 410) await prisma.taskSeriesMember.update({ where: { id: member.id }, data: { markScanPageToken: null, markScanUpper: null } });
        else if (code !== 404) console.error("No se pudo revisar la retención de subtareas recurrentes.");
      }
    }
  }
}
