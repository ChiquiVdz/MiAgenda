import { createHash } from "node:crypto";
import type { calendar_v3 } from "googleapis";
import { Prisma, type Prisma as PrismaTypes } from "@/generated/prisma/client";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { syncScheduledChildren, syncScheduledParent } from "@/lib/scheduled-subtask-state";
import { assertTaskAvailable, cacheTaskEvent } from "@/lib/task-activity";

export type ActivityStep = { id: string; text: string; completed: boolean };
export type ChecklistVersion = { effectiveAt: string; steps: ActivityStep[] };
export type ChecklistMark = { from: Date | null; changes: unknown; createdAt: Date };
export function resolveChecklistMarks(steps: ActivityStep[], completedAt: Date | null, markedAt: Date | null, origin: string, rules: ChecklistMark[]) {
  let list = steps; let completion = completedAt; let revision = markedAt;
  for (const rule of rules) {
    if (markedAt && rule.createdAt <= markedAt || rule.from && Date.parse(origin) < rule.from.getTime()) continue;
    const changes = new Map((rule.changes as { id: string; completed: boolean }[]).map((change) => [change.id, change.completed]));
    let changed = false;
    list = list.map((step) => {
      const value = changes.get(step.id);
      if (value === undefined || value === step.completed) return step;
      changed = true; return { ...step, completed: value };
    });
    if (changed) completion = list.length && list.every((step) => step.completed) ? completion ?? rule.createdAt : null;
    revision = rule.createdAt;
  }
  return { steps: list, completedAt: completion, markedAt: revision };
}
export class ChecklistError extends Error { constructor(message: string, readonly status = 409) { super(message); } }
export function validateSteps(value: unknown): ActivityStep[] {
  if (!Array.isArray(value) || value.length > 50) throw new ChecklistError("Puedes añadir hasta 50 pasos.", 400);
  const ids = new Set<string>();
  return value.map((step) => {
    if (!step || typeof step !== "object" || typeof step.id !== "string" || !/^[\w-]{1,100}$/.test(step.id)
      || ids.has(step.id) || typeof step.text !== "string" || !step.text.trim() || step.text.trim().length > 150
      || typeof step.completed !== "boolean") throw new ChecklistError("Revisa el texto de los pasos; cada uno admite hasta 150 caracteres.", 400);
    ids.add(step.id); return { id: step.id, text: step.text.trim(), completed: step.completed };
  });
}
export const pendingSteps = (steps: ActivityStep[]) => steps.map((step) => ({ ...step, completed: false }));
export function resolveSteps(snapshot: unknown, versions: unknown, scheduledAt: string, completed: boolean): ActivityStep[] {
  if (Array.isArray(snapshot)) return snapshot as ActivityStep[];
  const history = Array.isArray(versions) ? versions as ChecklistVersion[] : [];
  const effective = history.filter((v) => Date.parse(v.effectiveAt) <= Date.parse(scheduledAt)).at(-1) ?? history[0];
  return (effective?.steps ?? []).map((step) => ({ ...step, completed }));
}
export function checklistVersion(steps: ActivityStep[], updatedAt?: Date | null, completedAt?: Date | null) {
  return createHash("sha256").update(JSON.stringify([steps, updatedAt?.toISOString(), completedAt?.toISOString()])).digest("hex");
}
export async function readChecklist(tx: PrismaTypes.TransactionClient, userId: string, calendarId: string, event: calendar_v3.Schema$Event) {
  await cacheTaskEvent(tx, userId, calendarId, event);
  const key = { userId, googleCalendarId: calendarId, googleEventId: event.id! };
  let overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: key } });
  if (overlay?.kind === "meal") throw new ChecklistError("Las comidas utilizan su propio flujo de recetas y fases.", 400);
  const definition = await tx.activityChecklist.findUnique({ where: { userId_googleCalendarId_googleEventId: {
    ...key, googleEventId: event.recurringEventId ?? event.id!,
  } } });
  const at = event.start?.dateTime ?? `${event.start?.date}T00:00:00-06:00`;
  const sourceId = event.recurringEventId ?? event.id!;
  const member = await tx.taskSeriesMember.findUnique({ where: { userId_googleCalendarId_googleEventId: { ...key, googleEventId: sourceId } } });
  const rules = await tx.taskChecklistMark.findMany({ where: { userId, googleCalendarId: calendarId, rootId: member?.rootId ?? sourceId }, orderBy: { createdAt: "asc" } });
  const base = resolveSteps(overlay?.checklist, definition?.versions, at, Boolean(overlay?.completedAt));
  const origin = event.originalStartTime ?? event.start;
  const marked = resolveChecklistMarks(base, overlay?.completedAt ?? null, overlay?.checklistMarkedAt ?? null, origin?.dateTime ?? `${origin?.date}T00:00:00-06:00`, rules);
  const steps = marked.steps;
  if (marked.markedAt && marked.markedAt.getTime() !== overlay?.checklistMarkedAt?.getTime() && !overlay?.purgeStartedAt && steps.length) {
    const data = { checklist: steps as unknown as Prisma.InputJsonValue, checklistMarkedAt: marked.markedAt, completedAt: marked.completedAt,
      purgeAfter: marked.completedAt ? eventPurgeAfter(marked.completedAt, event.end) : null, recurringEventId: event.recurringEventId, etag: event.etag };
    overlay = await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: { ...key, ...data, kind: "app_task" }, update: data });
    await syncScheduledChildren(tx, userId, { calendarId, eventId: event.id! }, steps);
  }
  return { key, overlay, definition, steps, version: checklistVersion(steps, overlay?.updatedAt, overlay?.completedAt) };
}
export async function writeChecklist(tx: PrismaTypes.TransactionClient, userId: string, calendarId: string, event: calendar_v3.Schema$Event,
  steps: ActivityStep[], expectedVersion?: string, allowPending = false) {
  await assertTaskAvailable(tx, userId, calendarId, event.id!);
  if (!allowPending && await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Reanuda el cambio pendiente de Agenda antes de modificar subtareas.");
  const state = await readChecklist(tx, userId, calendarId, event);
  if (state.overlay?.purgeStartedAt) throw new ChecklistError("La retención está procesando esta actividad. Reintenta en un momento.");
  if (expectedVersion && state.version !== expectedVersion) throw new ChecklistError("Los pasos cambiaron en otra pestaña. Actualízalos antes de guardar.");
  const complete = steps.length > 0 ? steps.every((step) => step.completed) : Boolean(state.overlay?.completedAt);
  const completedAt = complete ? state.overlay?.completedAt ?? new Date() : null;
  const data = { checklist: steps as unknown as Prisma.InputJsonValue, checklistMarkedAt: new Date(Math.max(Date.now(), (state.overlay?.checklistMarkedAt?.getTime() ?? 0) + 1)), completedAt,
    purgeAfter: completedAt ? eventPurgeAfter(completedAt, event.end) : null, etag: event.etag, recurringEventId: event.recurringEventId };
  const overlay = await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: state.key },
    create: { ...state.key, ...data, kind: "app_task" }, update: data });
  await syncScheduledChildren(tx, userId, { calendarId, eventId: event.id! }, steps, state.steps);
  await syncScheduledParent(tx, userId, calendarId, event.id!, overlay.completedAt);
  await cacheTaskEvent(tx, userId, calendarId, event);
  const finalOverlay = await tx.eventOverlay.findUniqueOrThrow({ where: { id: overlay.id } });
  const finalSteps = Array.isArray(finalOverlay.checklist) ? finalOverlay.checklist as unknown as ActivityStep[] : steps;
  return { steps: finalSteps, completedAt: finalOverlay.completedAt?.toISOString() ?? null, keep: finalOverlay.keep,
    version: checklistVersion(finalSteps, finalOverlay.updatedAt, finalOverlay.completedAt) };
}
