export type TimingMode = "move" | "start" | "end";
const MINUTE = 60_000;
const snap = (time: number) => Math.round(time / (15 * MINUTE)) * 15 * MINUTE;

export function adjustCalendarTiming(start: number, end: number, mode: TimingMode, minutes: number, days = 0, maxMinutes = Infinity) {
  if (![start, end, minutes, days].every(Number.isFinite) || end <= start) throw new Error("Invalid event timing");
  if (mode === "move") {
    const nextStart = snap(start + (minutes + days * 1440) * MINUTE);
    return { start: nextStart, end: nextStart + end - start };
  }
  if (mode === "start") return { start: Math.max(end - maxMinutes * MINUTE, Math.min(end - 15 * MINUTE, snap(start + minutes * MINUTE))), end };
  return { start, end: Math.min(start + maxMinutes * MINUTE, Math.max(start + 15 * MINUTE, snap(end + minutes * MINUTE))) };
}

/** Longest recipe plus half of every other cooking time, rounded upward. */
export function combinedCookingMinutes(durations: number[]) {
  const valid = durations.filter((time) => Number.isFinite(time) && time > 0);
  if (!valid.length) return 0;
  const longest = Math.max(...valid);
  return Math.ceil((longest + (valid.reduce((sum, time) => sum + time, 0) - longest) / 2) / 5) * 5;
}
