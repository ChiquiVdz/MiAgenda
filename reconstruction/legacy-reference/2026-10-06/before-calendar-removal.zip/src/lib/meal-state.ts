import type { Prisma } from "@/generated/prisma/client";
import type { calendar_v3 } from "googleapis";
import { prisma } from "@/lib/prisma";
import { projectMeals } from "@/lib/meal-availability";
import { cleanupMealRecords } from "@/lib/meal-record-cleanup";

export async function readMealState(tx: Prisma.TransactionClient, userId: string) {
  // A transaction uses one PostgreSQL connection; don't overlap its queries.
  const plans = await tx.mealPlan.findMany({ where: { userId } });
  const overlays = await tx.eventOverlay.findMany({ where: { userId } });
  const ingredients = await tx.mealPlanIngredient.findMany({ where: { mealPlanId: { in: plans.map((plan) => plan.id) } } });
  const pantry = await tx.pantryItem.findMany({ where: { userId }, select: { ingredientId: true, quantity: true } });
  const batches = await tx.cookedBatch.findMany({ where: { userId } });
  const uses = await tx.portionUse.findMany({ where: { batchId: { in: batches.map((batch) => batch.id) } } });
  return {
    plans: plans.map((plan) => ({ ...plan,
      requestedServings: plan.servings,
      servings: overlays.some((overlay) => overlay.id === plan.overlayId && overlay.mealBlockConfigured && !overlay.mealEatingEnabled) ? 0 : plan.servings,
      scheduledAt: plan.scheduledAt?.toISOString() ?? null,
      completedAt: plan.completedAt ?? overlays.find((overlay) => overlay.id === plan.overlayId)?.completedAt ?? null,
      ingredients: ingredients.filter((line) => line.mealPlanId === plan.id).map((line) => ({ ingredientId: line.ingredientId, name: line.nameSnapshot,
        isOptional: line.isOptional, unit: line.unit, requiredQuantity: Number(line.requiredQuantity), quantityPerServing: Number(line.quantityPerServing) })) })),
    inventory: new Map(pantry.map((row) => [row.ingredientId, Number(row.quantity)])),
    batches: batches.map((batch) => ({ ...batch, cookedAt: batch.cookedAt.toISOString(),
      remainingServings: batch.servings - uses.filter((use) => use.batchId === batch.id).reduce((sum, use) => sum + use.servings, 0) })),
  };
}
export async function mealProjection(tx: Prisma.TransactionClient, userId: string) {
  const state = await readMealState(tx, userId);
  return { ...state, ...projectMeals(state.inventory, state.plans, state.batches) };
}

// Dates remain owned by Google, including plans outside the currently displayed week.
export async function syncMealSchedules(userId: string, calendar: calendar_v3.Calendar) {
  const plans = await prisma.mealPlan.findMany({ where: { userId } });
  const events = new Map<string, calendar_v3.Schema$Event>();
  const updates: Array<{ id: string; scheduledAt?: Date; eventMissing: boolean }> = [];
  const remoteByCalendar = new Map<string, Map<string, calendar_v3.Schema$Event>>();
  // Usually one request per meal calendar, rather than one request per future meal.
  for (const calendarId of new Set(plans.map((plan) => plan.googleCalendarId))) {
    const rows = new Map<string, calendar_v3.Schema$Event>();
    let pageToken: string | undefined;
    try {
      do {
        const { data } = await calendar.events.list({ calendarId, privateExtendedProperty: ["miagendaMealPlan=1"],
          maxResults: 2500, pageToken, fields: "items(id,summary,etag,start,end,status),nextPageToken" });
        for (const event of data.items ?? []) if (event.id) rows.set(event.id, event);
        pageToken = data.nextPageToken ?? undefined;
      } while (pageToken);
    } catch (error) {
      const status = (error as { response?: { status?: number }; code?: number }).response?.status ?? (error as { code?: number }).code;
      if (status !== 404 && status !== 410) throw error;
    }
    remoteByCalendar.set(calendarId, rows);
  }
  let cursor = 0;
  await Promise.all(Array.from({ length: Math.min(4, plans.length) }, async () => {
    while (cursor < plans.length) {
      const plan = plans[cursor++];
      try {
        // Fallback preserves links if a user removes our private property in Google.
        const event = remoteByCalendar.get(plan.googleCalendarId)?.get(plan.googleEventId)
          ?? (await calendar.events.get({ calendarId: plan.googleCalendarId, eventId: plan.googleEventId,
            fields: "id,summary,etag,start,end,status" })).data;
        const value = event.start?.dateTime ?? (event.start?.date ? `${event.start.date}T00:00:00-06:00` : null);
        if (event.status === "cancelled" || !value) { updates.push({ id: plan.id, eventMissing: true }); continue; }
        events.set(plan.id, event);
        updates.push({ id: plan.id, scheduledAt: new Date(value), eventMissing: false });
      } catch (error) {
        const status = (error as { response?: { status?: number }; code?: number }).response?.status ?? (error as { code?: number }).code;
        if (status === 404 || status === 410) updates.push({ id: plan.id, eventMissing: true });
        else throw error;
      }
    }
  }));
  await prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    await cleanupMealRecords(tx, userId);
    for (const update of updates) {
      // A concurrent edit wins over a schedule fetched before that edit.
      const original = plans.find((plan) => plan.id === update.id)!;
      const sameTime = original.scheduledAt?.getTime() === update.scheduledAt?.getTime();
      if (sameTime && original.eventMissing === update.eventMissing) continue;
      await tx.mealPlan.updateMany({ where: { id: update.id, userId, updatedAt: original.updatedAt },
        data: { scheduledAt: update.scheduledAt, eventMissing: update.eventMissing } });
    }
  }, { timeout: 15000 });
  return events;
}
