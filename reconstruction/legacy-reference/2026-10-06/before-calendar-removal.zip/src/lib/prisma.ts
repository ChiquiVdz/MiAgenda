import "server-only";

import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@/generated/prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
  schemaVersion?: number;
};

function createPrismaClient() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("Falta configurar DATABASE_URL para conectar PostgreSQL.");
  }

  const adapter = new PrismaPg({ connectionString });
  return new PrismaClient({ adapter });
}

// Hot reload can retain a client created before `prisma generate` added a model.
// Reuse it only when it exposes the current model, otherwise load the new client.
const cachedPrisma = globalForPrisma.prisma;
export const prisma = cachedPrisma?.activityOperation && cachedPrisma.constructor === PrismaClient && globalForPrisma.schemaVersion === 8 ? cachedPrisma : createPrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
  globalForPrisma.schemaVersion = 8;
}
