import "server-only";
import type { calendar_v3 } from "googleapis";
import type { Prisma, ScheduledSubtask } from "@/generated/prisma/client";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { parentWhere, renameScheduledParent, ScheduledSubtaskError, type SubtaskParent } from "@/lib/scheduled-subtask-state";

const status = (error: unknown) => Number((error as { response?: { status?: number }; code?: number })?.response?.status ?? (error as { code?: number })?.code);
const eventKey = (calendarId: string, eventId: string) => `${calendarId}\0${eventId}`;
type Step = { id: string; text: string; completed: boolean };

// Remove private origins as soon as their last child disappears. Live parents stay intact.
export async function cleanupSubtaskOrigin(tx: Prisma.TransactionClient, userId: string, link: ScheduledSubtask) {
  const remaining = await tx.scheduledSubtask.count({ where: { userId, ...(link.parentInboxId ? { parentInboxId: link.parentInboxId }
    : { parentCalendarId: link.parentCalendarId, parentEventId: link.parentEventId }) } });
  if (remaining) return;
  if (link.parentInboxId) await tx.inboxItem.deleteMany({ where: { userId, id: link.parentInboxId, transferredAt: { not: null }, googleEventId: null } });
  else if (link.parentCalendarId && link.parentEventId && !link.parentEndSnapshot) {
    await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId, etag: null, purgeAfter: null, purgeStartedAt: null } });
  }
}

export async function unlinkScheduledEvent(tx: Prisma.TransactionClient, userId: string, calendarId: string, eventId: string, removeStep = false) {
  const link = await tx.scheduledSubtask.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: eventId } } });
  if (!link) return;
  if (removeStep) {
    const owner = link.parentInboxId ? await tx.inboxItem.findFirst({ where: { userId, id: link.parentInboxId } })
      : link.parentCalendarId && link.parentEventId ? await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId } } }) : null;
    if (owner && Array.isArray(owner.checklist)) {
      const checklist = (owner.checklist as unknown as Step[]).filter((step) => step.id !== link.stepId);
      // Removing a step does not silently complete or undo its principal.
      if (link.parentInboxId) await tx.inboxItem.update({ where: { id: owner.id }, data: { checklist } });
      else await tx.eventOverlay.update({ where: { id: owner.id }, data: { checklist, checklistMarkedAt: new Date() } });
    }
  }
  await tx.scheduledSubtask.delete({ where: { id: link.id } });
  await cleanupSubtaskOrigin(tx, userId, link);
}

// Call under the user's advisory lock. Preflight the entire tree before any deletion.
// Google deletions are idempotent; rollback leaves the links available for the same retry.
export async function deleteScheduledChildren(tx: Prisma.TransactionClient, userId: string, parent: SubtaskParent, stepIds?: string[]) {
  const roots = await tx.scheduledSubtask.findMany({ where: { userId, ...parentWhere(parent), ...(stepIds ? { stepId: { in: stepIds } } : {}) } });
  if (!roots.length) return new Set<string>();
  const google = await getGoogleCalendarClient(userId);
  const visited = new Set<string>();
  const ordered: ScheduledSubtask[] = [];
  async function visit(link: ScheduledSubtask) {
    if (visited.has(link.id)) throw new ScheduledSubtaskError("Hay una relación circular entre subtareas. Actualiza antes de borrar.");
    visited.add(link.id);
    for (const child of await tx.scheduledSubtask.findMany({ where: { userId, parentCalendarId: link.googleCalendarId, parentEventId: link.googleEventId } })) await visit(child);
    ordered.push(link);
  }
  for (const link of roots) await visit(link);
  const permissions = new Set<string>();
  const events = new Map<string, calendar_v3.Schema$Event>();
  for (const link of ordered) {
    if (!permissions.has(link.googleCalendarId)) {
      const calendar = (await google.calendarList.get({ calendarId: link.googleCalendarId })).data;
      if (!["owner", "writer"].includes(calendar.accessRole ?? "")) throw new ScheduledSubtaskError("Necesitas permiso para borrar todas las subtareas programadas de esta principal.");
      permissions.add(link.googleCalendarId);
    }
    const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } } });
    if (overlay?.purgeStartedAt) throw new ScheduledSubtaskError("La retención está procesando una subtarea. Reintenta en un momento.");
    let remote;
    try { remote = (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId })).data; }
    catch (error) { if (![404, 410].includes(status(error))) throw error; }
    if (!remote || remote.status === "cancelled") continue;
    if (remote.extendedProperties?.private?.miagendaSubtask !== link.id || remote.recurrence?.length || !remote.etag)
      throw new ScheduledSubtaskError("Una subtarea cambió de identidad o se convirtió en serie en Google. Revísala antes de borrar la principal.");
    events.set(link.id, remote);
  }
  for (const link of ordered) {
    const remote = events.get(link.id);
    if (remote) {
      try { await google.events.delete({ calendarId: link.googleCalendarId, eventId: link.googleEventId, sendUpdates: "none" }, { headers: { "If-Match": remote.etag! } }); }
      catch (error) { if (![404, 410].includes(status(error))) throw error; }
    }
    await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } });
    await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } });
    await unlinkScheduledEvent(tx, userId, link.googleCalendarId, link.googleEventId);
  }
  return new Set(ordered.map((link) => eventKey(link.googleCalendarId, link.googleEventId)));
}

// Check only linked items in the viewed range (or a particular Inbox principal).
// A missing list result alone is never treated as proof of deletion.
export async function reconcileScheduledSubtasks(tx: Prisma.TransactionClient, userId: string,
  filter: Prisma.ScheduledSubtaskWhereInput, visible: { calendarId: string; id: string; summary?: string; etag?: string | null; endDate?: string | null; endDateTime?: string | null }[] = []) {
  // A partially applied series split must resume before IDs are reconciled.
  if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) return new Set<string>();
  const links = await tx.scheduledSubtask.findMany({ where: { userId, ...filter }, take: 100, orderBy: { updatedAt: "asc" } });
  if (!links.length) return new Set<string>();
  const google = await getGoogleCalendarClient(userId);
  const cache = new Map<string, calendar_v3.Schema$Event | null>();
  for (const item of visible) cache.set(eventKey(item.calendarId, item.id), { id: item.id, summary: item.summary, etag: item.etag,
    end: { date: item.endDate, dateTime: item.endDateTime } });
  const removed = new Set<string>();
  async function read(calendarId: string, eventId: string) {
    const key = eventKey(calendarId, eventId);
    if (!cache.has(key)) {
      try { const event = (await google.events.get({ calendarId, eventId })).data; cache.set(key, event.status === "cancelled" ? null : event); }
      catch (error) { if (![404, 410].includes(status(error))) throw error; cache.set(key, null); }
    }
    return cache.get(key)!;
  }
  for (const candidate of links) {
    const link = await tx.scheduledSubtask.findFirst({ where: { userId, id: candidate.id } });
    if (!link?.active || link.pendingPayload) continue;
    // A persisted unschedule may already have deleted the parent in Google.
    // Its independent children must wait for reassignment to Inbox, never cascade.
    if (await tx.activityOperation.count({ where: { userId, finishedAt: null, OR: [
      { googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId },
      ...(link.parentCalendarId && link.parentEventId ? [{ googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId }] : []),
    ] } })) continue;
    const ownOverlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } } });
    if (ownOverlay?.purgeStartedAt) continue;
    if (link.parentCalendarId && link.parentEventId && link.parentEndSnapshot && visible.some((item) => item.calendarId === link.googleCalendarId && item.id === link.googleEventId)) {
      const origin = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId } } });
      // A cron deletion in progress is retention, not a user-requested cascade.
      if (origin?.purgeStartedAt) continue;
      const parent = await read(link.parentCalendarId, link.parentEventId);
      if (!parent) {
        for (const key of await deleteScheduledChildren(tx, userId, { calendarId: link.parentCalendarId, eventId: link.parentEventId })) removed.add(key);
        await unlinkScheduledEvent(tx, userId, link.parentCalendarId, link.parentEventId);
        await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId } });
        await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId } });
        continue;
      }
      const end = parent.end?.dateTime ?? (parent.end?.date ? `${parent.end.date}T00:00:00-06:00` : null);
      if (end && Date.parse(end) !== link.parentEndSnapshot.getTime()) await tx.scheduledSubtask.update({ where: { id: link.id }, data: { parentEndSnapshot: new Date(end) } });
    }
    const event = await read(link.googleCalendarId, link.googleEventId);
    if (!event) {
      for (const key of await deleteScheduledChildren(tx, userId, { calendarId: link.googleCalendarId, eventId: link.googleEventId })) removed.add(key);
      await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } });
      await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } });
      await unlinkScheduledEvent(tx, userId, link.googleCalendarId, link.googleEventId);
      removed.add(eventKey(link.googleCalendarId, link.googleEventId));
      continue;
    }
    const end = event.end?.dateTime ?? (event.end?.date ? `${event.end.date}T00:00:00-06:00` : null);
    await renameScheduledParent(tx, userId, link.googleCalendarId, link.googleEventId, event.summary ?? "(Sin título)");
    // Advance the scan position so a page of unchanged items cannot starve later links.
    await tx.scheduledSubtask.update({ where: { id: link.id }, data: { ...(end ? { endSnapshot: new Date(end) } : {}), updatedAt: new Date() } });
    const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } } });
    if (overlay && !overlay.purgeStartedAt && overlay.etag !== event.etag) await tx.eventOverlay.update({ where: { id: overlay.id }, data: {
      etag: event.etag, purgeAfter: overlay.completedAt ? eventPurgeAfter(overlay.completedAt, event.end) : null,
    } });
  }
  return removed;
}
