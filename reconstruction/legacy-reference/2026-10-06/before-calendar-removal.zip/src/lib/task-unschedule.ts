import "server-only";
import { randomUUID } from "node:crypto";
import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { readChecklist, type ActivityStep } from "@/lib/activity-checklist";
import { cacheTaskEvent, TaskActivityError } from "@/lib/task-activity";

type Snapshot = { inboxId: string; title: string; description: string | null; etag: string; steps: ActivityStep[]; cancelled?: boolean };
const status = (error: unknown) => Number((error as { response?: { status?: number }; code?: number })?.response?.status ?? (error as { code?: number })?.code);

async function finishUnschedule(userId: string, operationId: string, removeRemote: boolean) {
  const google = await getGoogleCalendarClient(userId);
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const operation = await tx.activityOperation.findFirst({ where: { id: operationId, userId }, include: { activity: true } });
    if (!operation) throw new TaskActivityError("El traslado ya no está disponible. Actualiza Inbox.", 404);
    const snapshot = operation.payload as unknown as Snapshot;
    if (snapshot.cancelled) throw new TaskActivityError("El evento cambió en Google. Actualiza la agenda antes de quitar su horario.");
    if (operation.finishedAt) return { activityId: operation.activityId, inboxId: snapshot.inboxId };
    if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new TaskActivityError("Reanuda el cambio de recurrencia antes de terminar el traslado.");
    const links = await tx.scheduledSubtask.findMany({ where: { userId, parentCalendarId: operation.googleCalendarId, parentEventId: operation.googleEventId } });
    if (links.some((link) => !link.active || link.pendingPayload)) throw new TaskActivityError("Termina la programación pendiente de subtareas antes de quitar horario.");
    let event;
    try { event = (await google.events.get({ calendarId: operation.googleCalendarId, eventId: operation.googleEventId })).data; }
    catch (error) { if (![404, 410].includes(status(error))) throw error; }
    if (event && event.status !== "cancelled") {
      if (!removeRemote) return null;
      const role = (await google.calendarList.get({ calendarId: operation.googleCalendarId })).data.accessRole;
      if (!["owner", "writer"].includes(role ?? "")) throw new TaskActivityError("Necesitas permiso para quitar el evento de este calendario.");
      if (!event.etag || event.etag !== snapshot.etag) throw new TaskActivityError("El evento cambió en Google. Actualiza la agenda antes de quitar su horario.");
      try { await google.events.delete({ calendarId: operation.googleCalendarId, eventId: operation.googleEventId, sendUpdates: "none" }, { headers: { "If-Match": snapshot.etag } }); }
      catch (error) { if (![404, 410].includes(status(error))) throw error; }
    }
    // This persisted intent distinguishes an intentional unschedule from external
    // deletion. Children keep their Google events and switch their parent surface.
    await tx.$executeRaw`SELECT set_config('miagenda.activity_operation', ${operation.id}, true)`;
    await tx.scheduledSubtask.updateMany({ where: { userId, parentCalendarId: operation.googleCalendarId, parentEventId: operation.googleEventId }, data: {
      parentInboxId: snapshot.inboxId, parentCalendarId: null, parentEventId: null, parentEndSnapshot: null,
    } });
    await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: operation.googleCalendarId, googleEventId: operation.googleEventId } });
    await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: operation.googleCalendarId, googleEventId: operation.googleEventId } });
    await tx.activityCalendarLink.deleteMany({ where: { userId, activityId: operation.activityId } });
    await tx.activity.update({ where: { id: operation.activityId }, data: { title: snapshot.title, description: snapshot.description,
      keep: false, highlighted: false, lifecycle: "visible", revision: { increment: 1 } } });
    // Ensure the Inbox adapter attaches to the existing identity, not a new root.
    await tx.activityLegacySource.upsert({ where: { userId_source_sourceId: { userId, source: "inbox_item", sourceId: snapshot.inboxId } },
      create: { userId, source: "inbox_item", sourceId: snapshot.inboxId, activityId: operation.activityId }, update: {} });
    const data = { text: snapshot.title, completedAt: operation.activity.completedAt, checklist: snapshot.steps as unknown as Prisma.InputJsonValue,
      transferredAt: null, googleCalendarId: null, googleEventId: null, transferPayload: Prisma.DbNull };
    await tx.inboxItem.upsert({ where: { id: snapshot.inboxId }, create: { id: snapshot.inboxId, userId, createKey: `unschedule:${operation.id}`, ...data }, update: data });
    await tx.activityOperation.update({ where: { id: operation.id }, data: { finishedAt: new Date() } });
    return { activityId: operation.activityId, inboxId: snapshot.inboxId };
  }, { timeout: 45000 });
}

export async function unscheduleTask(userId: string, calendarId: string, eventId: string, etag: string) {
  const google = await getGoogleCalendarClient(userId);
  const operation = await prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const key = { userId, action: "unschedule", googleCalendarId: calendarId, googleEventId: eventId };
    const previous = await tx.activityOperation.findUnique({ where: { userId_action_googleCalendarId_googleEventId: key } });
    if (previous && !(previous.payload as unknown as Snapshot).cancelled) return previous;
    if (previous) await tx.activityOperation.delete({ where: { id: previous.id } });
    if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new TaskActivityError("Reanuda el cambio pendiente de Agenda antes de quitar horario.");
    const overlayKey = { userId, googleCalendarId: calendarId, googleEventId: eventId };
    const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: overlayKey } });
    if (overlay?.kind === "meal" || await tx.mealPlan.count({ where: overlayKey })) throw new TaskActivityError("Las comidas requieren fecha y hora; puedes reprogramarlas desde su editor.");
    if (await tx.scheduledSubtask.count({ where: overlayKey })) throw new TaskActivityError("Quita el horario de esta subtarea desde su principal; su casilla se conservará.");
    if (overlay?.purgeStartedAt) throw new TaskActivityError("La retención está procesando esta tarea. Reintenta en un momento.");
    const children = await tx.scheduledSubtask.findMany({ where: { userId, parentCalendarId: calendarId, parentEventId: eventId } });
    if (children.some((child) => !child.active || child.pendingPayload)) throw new TaskActivityError("Termina la programación pendiente de subtareas antes de quitar horario.");
    const role = (await google.calendarList.get({ calendarId })).data.accessRole;
    if (!["owner", "writer"].includes(role ?? "")) throw new TaskActivityError("Necesitas permiso para quitar el evento de este calendario.");
    const event = (await google.events.get({ calendarId, eventId })).data;
    if (event.status === "cancelled") throw new TaskActivityError("El evento ya fue eliminado en Google. Eso no lo devuelve a Inbox.", 404);
    if (event.recurrence?.length) throw new TaskActivityError("Abre una instancia concreta de la serie para quitar su horario.");
    if (!event.etag || event.etag !== etag) throw new TaskActivityError("El evento cambió en Google. Actualiza la agenda antes de quitar su horario.");
    if (!overlay) await tx.eventOverlay.create({ data: { ...overlayKey, kind: "app_task", recurringEventId: event.recurringEventId, etag: event.etag } });
    await cacheTaskEvent(tx, userId, calendarId, event);
    const checklist = await readChecklist(tx, userId, calendarId, event);
    const link = await tx.activityCalendarLink.findUniqueOrThrow({ where: { userId_googleCalendarId_googleEventId: overlayKey } });
    const source = await tx.activityLegacySource.findFirst({ where: { userId, activityId: link.activityId, source: "inbox_item" }, orderBy: { createdAt: "asc" } });
    const snapshot: Snapshot = { inboxId: source?.sourceId ?? `inb${randomUUID().replaceAll("-", "").slice(0, 22)}`,
      title: event.summary ?? "(Sin título)", description: event.description ?? null, etag: event.etag, steps: checklist.steps };
    return tx.activityOperation.create({ data: { ...key, activityId: link.activityId, payload: snapshot as unknown as Prisma.InputJsonValue } });
  }, { timeout: 45000 });
  try { return await finishUnschedule(userId, operation.id, true); }
  catch (error) {
    // An etag conflict cancels this intent, leaving the current Google event intact.
    // Network failures keep it pending so a response lost after deletion is recoverable.
    if (status(error) === 412 || error instanceof TaskActivityError && error.message.includes("cambió en Google")) {
      await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        await tx.activityOperation.updateMany({ where: { id: operation.id, userId, finishedAt: null }, data: {
          finishedAt: new Date(), payload: { ...(operation.payload as unknown as Snapshot), cancelled: true } as unknown as Prisma.InputJsonValue,
        } });
      });
      throw new TaskActivityError("El evento cambió en Google. Actualiza la agenda antes de quitar su horario.");
    }
    throw error;
  }
}

// Only recover deletions already confirmed by Google. GET never deletes a new event.
export async function recoverUnscheduledTasks(userId: string) {
  const operations = await prisma.activityOperation.findMany({ where: { userId, action: "unschedule", finishedAt: null }, orderBy: { createdAt: "asc" }, take: 10 });
  for (const operation of operations) await finishUnschedule(userId, operation.id, false);
}
