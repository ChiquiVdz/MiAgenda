import "server-only";
import { coreModeEnabled } from "./core-mode";
import { coreAuthOptions } from "./core-runtime";
import { legacyAuthOptions } from "./legacy-auth";

export const authOptions = coreModeEnabled() ? coreAuthOptions() : legacyAuthOptions;
