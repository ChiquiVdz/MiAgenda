import type { Prisma } from "@/generated/prisma/client";
import { shoppingNeeds } from "@/lib/shopping-needs";
import { mealProjection } from "@/lib/meal-state";
const MAX_AMOUNT = 999_999_999.999;

// The caller locks the user so planning and purchases cannot race this projection.
export async function syncPlannedShopping(tx: Prisma.TransactionClient, userId: string) {
  const key = "planned:all";
  const projection = await mealProjection(tx, userId);
  const plans = projection.meals.filter((plan) => !plan.completedAt && !plan.eventMissing && plan.scheduledAt);
  const neededToBuy = shoppingNeeds(plans);
  if (neededToBuy.some((line) => !Number.isFinite(line.quantity) || line.quantity > MAX_AMOUNT)) throw new Error("AMOUNT_OUT_OF_RANGE");

  const shoppingList = await tx.shoppingList.upsert({
    where: { userId_idempotencyKey: { userId, idempotencyKey: key } },
    create: { userId, recipeNameSnapshot: "Todas las comidas pendientes", servings: 1, idempotencyKey: key },
    update: {},
    include: { items: true },
  });

  // Preserve purchases (and their undo IDs) and free articles from former weekly lists.
  const former = await tx.shoppingList.findMany({ where: { userId, id: { not: shoppingList.id }, idempotencyKey: { startsWith: "planned:" } }, select: { id: true } });
  const formerIds = former.map((list) => list.id);
  const retained = await tx.shoppingListItem.findMany({ where: { shoppingListId: { in: formerIds }, OR: [{ purchasedAt: { not: null } }, { ingredientId: null }] } });
  for (const item of retained) await tx.shoppingListItem.update({ where: { id: item.id }, data: { shoppingListId: shoppingList.id, itemKey: `legacy:${item.id}` } });
  await tx.shoppingListItem.deleteMany({ where: { shoppingListId: { in: formerIds }, purchasedAt: null, ingredientId: { not: null } } });
  await tx.shoppingList.deleteMany({ where: { userId, id: { in: formerIds }, items: { none: {} } } });

  const wantedIds = new Set(neededToBuy.map((line) => line.ingredientId));
  const pendingRows = await tx.shoppingListItem.findMany({ where: { shoppingListId: shoppingList.id, ingredientId: { not: null }, purchasedAt: null } });
  for (const line of neededToBuy) {
    const itemKey = `ingredient:${line.ingredientId}`;
    let existing = pendingRows.find((item) => item.itemKey === itemKey)
      ?? shoppingList.items.find((item) => item.itemKey === itemKey);
    if (existing?.purchasedAt) {
      await tx.shoppingListItem.update({ where: { id: existing.id }, data: { itemKey: `purchased:${existing.id}` } });
      existing = undefined;
    }
    if (existing) {
      await tx.shoppingListItem.update({ where: { id: existing.id }, data: { quantity: line.quantity, requiredQuantity: line.requiredQuantity, optionalQuantity: line.optionalQuantity, nameSnapshot: line.name, unit: line.unit } });
    } else {
      await tx.shoppingListItem.upsert({
        where: { shoppingListId_itemKey: { shoppingListId: shoppingList.id, itemKey } },
        create: { shoppingListId: shoppingList.id, itemKey, ingredientId: line.ingredientId, nameSnapshot: line.name, unit: line.unit, quantity: line.quantity, requiredQuantity: line.requiredQuantity, optionalQuantity: line.optionalQuantity },
        update: { quantity: line.quantity, requiredQuantity: line.requiredQuantity, optionalQuantity: line.optionalQuantity, nameSnapshot: line.name, unit: line.unit },
      });
    }
  }
  for (const item of pendingRows) {
    if (item.ingredientId && !wantedIds.has(item.ingredientId)) await tx.shoppingListItem.delete({ where: { id: item.id } });
  }
  return tx.shoppingList.findUniqueOrThrow({ where: { id: shoppingList.id }, include: { items: { orderBy: { nameSnapshot: "asc" } } } });
}
