import type { IngredientUnit } from "@/generated/prisma/client";
import type { PreparationStep } from "@/lib/recipe-steps";

export type CopyOmission = { summary: string; date: string; slot: string; reason: string };
export type WeekCopyBlock = {
  sourceId: string; calendarId: string; summary: string; sourceEtag: string | null;
  startDateTime: string; durationMinutes: number; mealSlotId: string | null; slotName: string;
  phases: { mealBlockConfigured: boolean; mealCookingEnabled: boolean; mealEatingEnabled: boolean;
    mealWashingEnabled: boolean; mealEatingMinutes: number; mealWashingMinutes: number; mealDurationOverride: number | null };
  recipes: Array<{ recipeId: string; servings: number; cookedServings: number; cookingEnabled: boolean; preparationMinutes: number; preparationSteps?: PreparationStep[];
    ingredients: Array<{ ingredientId: string; nameSnapshot: string; unit: IngredientUnit; quantityPerServing: number; isOptional: boolean }> }>;
};

export function addWeekDays(key: string, days: number) {
  const date = new Date(`${key}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}
export function validMonday(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value && date.getUTCDay() === 1;
}
export function mexicoCopyDateTime(value: string) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: "America/Mexico_City", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(new Date(value)).map((p) => [p.type, p.value]));
  return { date: `${parts.year}-${parts.month}-${parts.day}`, time: `${parts.hour}:${parts.minute}:${parts.second}` };
}
export function shiftWeekTime(value: string, sourceWeek: string, targetWeek: string) {
  const delta = Math.round((Date.parse(`${targetWeek}T12:00:00Z`) - Date.parse(`${sourceWeek}T12:00:00Z`)) / 86400000);
  const local = mexicoCopyDateTime(value);
  return `${addWeekDays(local.date, delta)}T${local.time}-06:00`;
}
export function copyCellKey(block: Pick<WeekCopyBlock, "startDateTime" | "mealSlotId" | "calendarId">) {
  const local = mexicoCopyDateTime(block.startDateTime);
  return `${local.date}\0${block.mealSlotId ?? `unassigned:${block.calendarId}:${local.time}`}`;
}
export function selectEmptyCopyCells(blocks: WeekCopyBlock[], occupied: Set<string>) {
  const reserved = new Set(occupied);
  const selected: WeekCopyBlock[] = [];
  const omissions: CopyOmission[] = [];
  for (const block of [...blocks].sort((a, b) => Date.parse(a.startDateTime) - Date.parse(b.startDateTime) || a.sourceId.localeCompare(b.sourceId))) {
    const key = copyCellKey(block);
    if (reserved.has(key)) omissions.push({ summary: block.summary, date: mexicoCopyDateTime(block.startDateTime).date,
      slot: block.slotName, reason: occupied.has(key) ? "La celda ya tiene una comida." : "Otra comida de la semana de origen ocupa la misma celda." });
    else { selected.push(block); reserved.add(key); }
  }
  return { selected, omissions };
}
