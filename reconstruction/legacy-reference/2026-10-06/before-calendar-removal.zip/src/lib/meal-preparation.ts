import { createHash } from "node:crypto";
import type { Prisma } from "@/generated/prisma/client";
import type { calendar_v3 } from "googleapis";
import { completeMealBlock, uncompleteMealBlock } from "@/lib/meal-portions";
import { ingredientStepKey, preparationSteps, snapshotRecipeSteps, stepIngredientAmounts } from "@/lib/recipe-steps";
import { mealStepKey, syncMealStepChildren } from "@/lib/meal-step-links";
import { eventPurgeAfter } from "@/lib/google/event-retention";

export class MealStepError extends Error { constructor(message: string, readonly status = 409) { super(message); } }
export async function readMealPreparation(tx: Prisma.TransactionClient, userId: string, calendarId: string, eventId: string) {
  const block = await tx.eventOverlay.findFirst({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId, kind: "meal" },
    include: { mealPlans: { orderBy: [{ createdAt: "asc" }, { id: "asc" }], include: { ingredients: true, recipe: { select: { name: true, instructions: true, steps: true } } } } } });
  if (!block) throw new MealStepError("No encontramos esta comida.", 404);
  if (block.purgeStartedAt) throw new MealStepError("La retención está procesando esta comida.");
  for (const plan of block.mealPlans) if (!Array.isArray(plan.preparationSteps)) {
    const steps = snapshotRecipeSteps(plan.recipe ?? { instructions: "Preparar la receta" }, plan.ingredients).map((step) => ({ ...step,
      completed: Boolean(plan.completedAt) && (!step.isOptional || step.ingredientKeys.some((key) => plan.ingredients.some((line) => ingredientStepKey(line) === key && line.optionalUsed))) }));
    await tx.mealPlan.update({ where: { id: plan.id }, data: { preparationSteps: steps } });
    plan.preparationSteps = steps;
  }
  return block;
}
type Block = Awaited<ReturnType<typeof readMealPreparation>>;
export function mealPreparationState(block: Block) {
  return {
    version: createHash("sha256").update(JSON.stringify([block.updatedAt, block.completedAt, block.mealPlans.map((plan) => [plan.id, plan.cookingEnabled, plan.preparationSteps, plan.ingredients])])).digest("hex"),
    completedAt: block.completedAt?.toISOString() ?? null, keep: block.keep,
    recipes: block.mealPlans.map((plan) => ({ id: plan.id, name: plan.recipe?.name ?? "Receta eliminada", cookingEnabled: plan.cookingEnabled,
      steps: plan.cookingEnabled ? preparationSteps(plan.preparationSteps).map((step) => ({ ...step, scheduleStepId: mealStepKey(plan.id, step.id),
        ingredients: step.ingredientKeys.flatMap((key) => plan.ingredients.filter((line) => ingredientStepKey(line) === key).map((line) => ({ name: line.nameSnapshot,
          quantity: stepIngredientAmounts(preparationSteps(plan.preparationSteps), key, Number(line.requiredQuantity), Number(line.quantityPerServing)).get(step.id) ?? Number(line.requiredQuantity),
          equivalent: step.ingredient?.equivalent ?? null, unit: line.unit, used: line.isOptional ? plan.completedAt ? step.completed : null : Boolean(plan.completedAt) }))) })) : [] })),
  };
}

// Both the meal checkbox and its scheduled preparation use this transaction.
export async function markMealPreparation(tx: Prisma.TransactionClient, userId: string, block: Block, planId: string, stepId: string,
  completed: boolean, event: calendar_v3.Schema$Event, completionPrepared = true) {
  const plan = block.mealPlans.find((row) => row.id === planId && row.cookingEnabled);
  const steps = preparationSteps(plan?.preparationSteps);
  const step = steps.find((row) => row.id === stepId);
  if (!plan || !step) throw new MealStepError("El paso ya no está en esta preparación. Actualiza.");
  if (step.completed === completed) return;
  if (block.completedAt || block.mealPlans.some((row) => row.completedAt)) {
    if (completed) throw new MealStepError("La comida ya está completada. Deshaz el bloque antes de marcar un paso que se había omitido.");
    // Correcting a completed child must undo the same ledger, subject to leftover dependencies.
    await uncompleteMealBlock(tx, userId, block.id);
    await tx.eventOverlay.update({ where: { id: block.id }, data: { completedAt: null, purgeAfter: null, etag: event.etag } });
    await syncMealStepChildren(tx, userId, block.id);
    return;
  }
  const updated = steps.map((row) => row.id === step.id ? { ...row, completed } : row);
  await tx.mealPlan.update({ where: { id: plan.id }, data: { preparationSteps: updated } });
  plan.preparationSteps = updated;
  const required = block.mealPlans.filter((row) => row.cookingEnabled).flatMap((row) => preparationSteps(row.preparationSteps).filter((item) => !item.isOptional));
  if (completed && required.length && required.every((item) => item.completed)) {
    if (!completionPrepared) throw new MealStepError("Los pasos cambiaron mientras guardabas. Actualiza y vuelve a marcar el último paso.");
    const choices = block.mealPlans.flatMap((row) => !row.cookingEnabled ? [] : row.ingredients.filter((line) => line.isOptional && preparationSteps(row.preparationSteps).some((item) => item.completed && item.ingredientKeys.includes(ingredientStepKey(line)))).map((line) => `${row.id}:${line.ingredientId}`));
    const amounts = Object.fromEntries(block.mealPlans.flatMap((row) => !row.cookingEnabled ? [] : row.ingredients.filter((line) => line.isOptional && choices.includes(`${row.id}:${line.ingredientId}`)).map((line) => {
      const current = preparationSteps(row.preparationSteps);
      const shares = stepIngredientAmounts(current, ingredientStepKey(line), Number(line.requiredQuantity), Number(line.quantityPerServing));
      const amount = Math.round(current.filter((item) => item.completed).reduce((sum, item) => sum + (shares.get(item.id) ?? 0), 0) * 1000) / 1000;
      return [`${row.id}:${line.ingredientId}`, amount];
    })));
    const now = new Date();
    await completeMealBlock(tx, userId, block.id, now, choices, amounts);
    await tx.eventOverlay.update({ where: { id: block.id }, data: { completedAt: now, purgeAfter: eventPurgeAfter(now, event.end), etag: event.etag } });
  }
  await syncMealStepChildren(tx, userId, block.id);
}
