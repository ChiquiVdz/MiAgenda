import type { Prisma } from "@/generated/prisma/client";
import { normalizeIngredientName } from "@/lib/ingredients";
import { preparationSteps } from "@/lib/recipe-steps";

export class IngredientChangeError extends Error {
  constructor(readonly status: number, message: string) { super(message); }
}

export type IngredientRemoval = { replacementId?: string; newName?: string };

export async function ingredientUsage(tx: Prisma.TransactionClient, userId: string, ingredientId: string) {
  const [pantry, recipes, meals, movements, purchases] = await Promise.all([
    tx.pantryItem.count({ where: { userId, ingredientId } }),
    tx.recipeIngredient.count({ where: { ingredientId, recipe: { userId } } }),
    tx.mealPlanIngredient.count({ where: { ingredientId, mealPlan: { userId } } }),
    tx.inventoryLedger.count({ where: { ingredientId, mealPlan: { userId } } }),
    tx.shoppingListItem.count({ where: { ingredientId, shoppingList: { userId } } }),
  ]);
  return { pantry, recipes, meals, movements, purchases };
}

export async function removeIngredient(tx: Prisma.TransactionClient, userId: string, id: string, choice: IngredientRemoval) {
  const user = await tx.user.findUniqueOrThrow({ where: { id: userId }, select: { deletedIngredientIds: true, hiddenIngredientIds: true } });
  const source = await tx.ingredient.findFirst({ where: { id, OR: [{ catalogScope: "global" }, { ownerUserId: userId }] } });
  if (!source || user.deletedIngredientIds.includes(id)) throw new IngredientChangeError(404, "No encontramos este ingrediente en tu catálogo.");
  let target = choice.replacementId ? await tx.ingredient.findFirst({ where: { id: choice.replacementId, OR: [{ catalogScope: "global" }, { ownerUserId: userId }] } }) : null;
  if (choice.replacementId && (!target || target.id === id || user.deletedIngredientIds.includes(target.id))) throw new IngredientChangeError(400, "Elige otro ingrediente existente.");
  if (choice.newName) {
    const name = choice.newName.trim().replace(/\s+/g, " ");
    if (!name || name.length > 100) throw new IngredientChangeError(400, "Indica un nombre válido de hasta 100 caracteres.");
    const normalizedName = normalizeIngredientName(name);
    const existing = await tx.ingredient.findFirst({ where: { normalizedName, OR: [{ catalogScope: "global" }, { ownerUserId: userId }] } });
    if (existing) throw new IngredientChangeError(409, "Ese nombre ya existe. Selecciónalo como reemplazo o escribe otro nombre.");
    target = await tx.ingredient.create({ data: { name, normalizedName, unit: source.unit, ownerUserId: userId, catalogScope: userId } });
  }
  if (target && target.unit !== source.unit) throw new IngredientChangeError(400, "El reemplazo debe usar la misma unidad para conservar las cantidades correctamente.");

  if (target) {
    const pantry = await tx.pantryItem.findUnique({ where: { userId_ingredientId: { userId, ingredientId: id } } });
    if (pantry) {
      const merged = await tx.pantryItem.upsert({ where: { userId_ingredientId: { userId, ingredientId: target.id } }, create: { userId, ingredientId: target.id, quantity: pantry.quantity }, update: { quantity: { increment: pantry.quantity } } });
      if (merged.quantity.greaterThan("999999999.999")) throw new IngredientChangeError(400, "La suma supera la cantidad máxima de alacena.");
      await tx.pantryItem.delete({ where: { id: pantry.id } });
    }
    for (const line of await tx.recipeIngredient.findMany({ where: { ingredientId: id, recipe: { userId } } })) {
      const other = await tx.recipeIngredient.findUnique({ where: { recipeId_ingredientId_isOptional: { recipeId: line.recipeId, ingredientId: target.id, isOptional: line.isOptional } } });
      if (other) {
        const quantity = other.quantityPerServing.add(line.quantityPerServing);
        if (quantity.greaterThan("999999999.999")) throw new IngredientChangeError(400, "La suma supera la cantidad máxima de una receta.");
        await tx.recipeIngredient.update({ where: { id: other.id }, data: { quantityPerServing: quantity, equivalent: null } });
        await tx.recipeIngredient.delete({ where: { id: line.id } });
      } else await tx.recipeIngredient.update({ where: { id: line.id }, data: { ingredientId: target.id } });
    }
    for (const line of await tx.mealPlanIngredient.findMany({ where: { ingredientId: id, mealPlan: { userId } } })) {
      const other = await tx.mealPlanIngredient.findUnique({ where: { mealPlanId_ingredientId_isOptional: { mealPlanId: line.mealPlanId, ingredientId: target.id, isOptional: line.isOptional } } });
      if (other) {
        const quantity = other.requiredQuantity.add(line.requiredQuantity);
        if (quantity.greaterThan("999999999.999")) throw new IngredientChangeError(400, "La suma supera la cantidad máxima de una comida.");
        await tx.mealPlanIngredient.update({ where: { id: other.id }, data: { requiredQuantity: quantity, quantityPerServing: other.quantityPerServing.add(line.quantityPerServing), nameSnapshot: target.name } });
        await tx.mealPlanIngredient.delete({ where: { id: line.id } });
      } else await tx.mealPlanIngredient.update({ where: { id: line.id }, data: { ingredientId: target.id, nameSnapshot: target.name } });
    }
    // Keep each movement and reversal identity, so undo still restores the exact deduction.
    await tx.inventoryLedger.updateMany({ where: { ingredientId: id, mealPlan: { userId } }, data: { ingredientId: target.id } });
    for (const line of await tx.shoppingListItem.findMany({ where: { ingredientId: id, shoppingList: { userId } } })) {
      if (line.purchasedAt) {
        await tx.shoppingListItem.update({ where: { id: line.id }, data: { ingredientId: target.id, nameSnapshot: target.name, itemKey: `purchased:${line.id}` } });
        continue;
      }
      const itemKey = `ingredient:${target.id}`;
      const other = await tx.shoppingListItem.findUnique({ where: { shoppingListId_itemKey: { shoppingListId: line.shoppingListId, itemKey } } });
      if (other && !other.purchasedAt) {
        const quantity = other.quantity.add(line.quantity);
        if (quantity.greaterThan("999999999.999")) throw new IngredientChangeError(400, "La suma supera la cantidad máxima de compras.");
        await tx.shoppingListItem.update({ where: { id: other.id }, data: { quantity, requiredQuantity: other.requiredQuantity?.add(line.requiredQuantity ?? 0) ?? line.requiredQuantity, optionalQuantity: other.optionalQuantity?.add(line.optionalQuantity ?? 0) ?? line.optionalQuantity } });
        await tx.shoppingListItem.delete({ where: { id: line.id } });
      } else {
        if (other) await tx.shoppingListItem.update({ where: { id: other.id }, data: { itemKey: `purchased:${other.id}` } });
        await tx.shoppingListItem.update({ where: { id: line.id }, data: { ingredientId: target.id, nameSnapshot: target.name, itemKey } });
      }
    }
  } else {
    // Explicit removal erases this ingredient's uses, including its undo movements.
    await tx.inventoryLedger.deleteMany({ where: { ingredientId: id, mealPlan: { userId } } });
    await tx.mealPlanIngredient.deleteMany({ where: { ingredientId: id, mealPlan: { userId } } });
    await tx.recipeIngredient.deleteMany({ where: { ingredientId: id, recipe: { userId } } });
    await tx.shoppingListItem.deleteMany({ where: { ingredientId: id, shoppingList: { userId } } });
    await tx.pantryItem.deleteMany({ where: { userId, ingredientId: id } });
  }
  // Ingredient references in preparation snapshots follow the same explicit replacement/removal.
  const rewriteSteps = (value: unknown) => {
    const seen = new Set<string>();
    return preparationSteps(value).map((step) => ({ ...step,
      ...(step.ingredient?.ingredientId === id ? { ingredient: target ? { ...step.ingredient, ingredientId: target.id } : null } : {}),
      ingredientKeys: step.ingredientKeys.flatMap((key) => {
      let next = key;
      if (key === `${id}:optional` || key === `${id}:required`) {
        if (!target) return [];
        next = `${target.id}:${key.endsWith(":optional") ? "optional" : "required"}`;
      }
      if (seen.has(next) && !step.ingredient) return [];
      seen.add(next); return [next];
    }) }));
  };
  for (const recipe of await tx.recipe.findMany({ where: { userId }, select: { id: true, steps: true } })) {
    if (Array.isArray(recipe.steps) && JSON.stringify(recipe.steps).includes(id)) await tx.recipe.update({ where: { id: recipe.id }, data: { steps: rewriteSteps(recipe.steps).map(({ completed: _completed, ...step }) => step) } });
  }
  for (const plan of await tx.mealPlan.findMany({ where: { userId }, select: { id: true, preparationSteps: true } })) {
    if (Array.isArray(plan.preparationSteps) && JSON.stringify(plan.preparationSteps).includes(id)) await tx.mealPlan.update({ where: { id: plan.id }, data: { preparationSteps: rewriteSteps(plan.preparationSteps) } });
  }
  if (source.ownerUserId === userId) {
    await tx.ingredient.delete({ where: { id } });
  } else {
    // The shared catalog belongs to everyone; the user's catalog has a permanent removal.
    await tx.user.update({ where: { id: userId }, data: { deletedIngredientIds: { push: id } } });
  }
  await tx.user.update({ where: { id: userId }, data: { hiddenIngredientIds: user.hiddenIngredientIds.filter((ingredientId) => ingredientId !== id && ingredientId !== target?.id) } });
  return { replacement: target ? { id: target.id, name: target.name, unit: target.unit } : null };
}
