import type { Prisma } from "@/generated/prisma/client";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { deleteScheduledChildren } from "@/lib/scheduled-subtask-lifecycle";
import { readMealPreparation, markMealPreparation } from "@/lib/meal-preparation";
import { linkedMealSteps, mealStepKey } from "@/lib/meal-step-links";
import { preparationSteps } from "@/lib/recipe-steps";

type Step = { id: string; text: string; completed: boolean };
export class ScheduledSubtaskError extends Error { readonly status = 409; }
export type SubtaskParent = { inboxId: string } | { calendarId: string; eventId: string };
export const parentWhere = (parent: SubtaskParent) => "inboxId" in parent
  ? { parentInboxId: parent.inboxId } : { parentCalendarId: parent.calendarId, parentEventId: parent.eventId };

// Both surfaces write the same completion; times remain Google's responsibility.
export async function syncScheduledChildren(tx: Prisma.TransactionClient, userId: string, parent: SubtaskParent, steps: Step[], previousSteps: Step[] = []) {
  const links = await tx.scheduledSubtask.findMany({ where: { userId, ...parentWhere(parent) } });
  for (const link of links) {
    const step = steps.find((item) => item.id === link.stepId);
    if (!step) { await deleteScheduledChildren(tx, userId, parent, [link.stepId]); continue; }
    if (!link.active) continue;
    const previous = previousSteps.find((item) => item.id === step.id);
    if (previous && previous.text !== step.text) {
      const google = await getGoogleCalendarClient(userId);
      const event = (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId })).data;
      if (event.status !== "cancelled" && event.summary !== step.text) {
        if (event.summary !== previous.text) throw new ScheduledSubtaskError("El nombre de una subtarea cambió en Google. Actualiza su evento antes de renombrarla.");
        await google.events.patch({ calendarId: link.googleCalendarId, eventId: link.googleEventId, requestBody: { summary: step.text } }, { headers: { "If-Match": event.etag! } });
      }
    }
    const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: {
      userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId,
    } } });
    if (!overlay || Boolean(overlay.completedAt) === step.completed) continue;
    if (overlay.purgeStartedAt) throw new ScheduledSubtaskError("La retención está procesando una subtarea. Reintenta en un momento.");
    const completedAt = step.completed ? new Date() : null;
    await tx.eventOverlay.update({ where: { id: overlay.id }, data: { completedAt,
      purgeAfter: completedAt ? eventPurgeAfter(completedAt, { dateTime: link.endSnapshot.toISOString() }) : null,
      ...(Array.isArray(overlay.checklist) ? { checklist: (overlay.checklist as unknown as Step[]).map((item) => ({ ...item, completed: step.completed })), checklistMarkedAt: new Date() } : {}),
    } });
    if (Array.isArray(overlay.checklist)) await syncScheduledChildren(tx, userId, { calendarId: link.googleCalendarId, eventId: link.googleEventId },
      (overlay.checklist as unknown as Step[]).map((item) => ({ ...item, completed: step.completed })));
  }
}

export async function renameScheduledParent(tx: Prisma.TransactionClient, userId: string, calendarId: string, eventId: string, text: string) {
  const taskText = text.slice(0, 150);
  const link = await tx.scheduledSubtask.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: eventId } } });
  if (!link?.active) return;
  if (link.parentInboxId) {
    const item = await tx.inboxItem.findFirst({ where: { id: link.parentInboxId, userId, transferredAt: null } });
    if (item && Array.isArray(item.checklist) && (item.checklist as unknown as Step[]).some((step) => step.id === link.stepId && step.text !== taskText)) await tx.inboxItem.update({ where: { id: item.id }, data: { checklist: (item.checklist as unknown as Step[]).map((step) => step.id === link.stepId ? { ...step, text: taskText } : step) } });
  } else if (link.parentCalendarId && link.parentEventId) {
    const item = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId } } });
    if (item?.kind === "meal" && !item.purgeStartedAt) {
      const plans = await tx.mealPlan.findMany({ where: { userId, overlayId: item.id } });
      for (const plan of plans) {
        const steps = preparationSteps(plan.preparationSteps);
        if (steps.some((step) => mealStepKey(plan.id, step.id) === link.stepId && step.text !== text && step.text.slice(0, 250) !== text)) await tx.mealPlan.update({ where: { id: plan.id }, data: {
          preparationSteps: steps.map((step) => mealStepKey(plan.id, step.id) === link.stepId ? { ...step, text: text.slice(0, 10000) } : step),
        } });
      }
      return;
    }
    if (item && !item.purgeStartedAt && Array.isArray(item.checklist) && (item.checklist as unknown as Step[]).some((step) => step.id === link.stepId && step.text !== taskText)) await tx.eventOverlay.update({ where: { id: item.id }, data: { checklist: (item.checklist as unknown as Step[]).map((step) => step.id === link.stepId ? { ...step, text: taskText } : step) } });
  }
}

export async function syncScheduledParent(tx: Prisma.TransactionClient, userId: string, calendarId: string, eventId: string, completedAt: Date | null) {
  const link = await tx.scheduledSubtask.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: calendarId, googleEventId: eventId } } });
  if (!link?.active) return;
  if (link.parentInboxId) {
    const item = await tx.inboxItem.findFirst({ where: { id: link.parentInboxId, userId, transferredAt: null } });
    if (!item || !Array.isArray(item.checklist)) return;
    const steps = (item.checklist as unknown as Step[]).map((step) => step.id === link.stepId ? { ...step, completed: Boolean(completedAt) } : step);
    await tx.inboxItem.update({ where: { id: item.id }, data: { checklist: steps, completedAt: steps.length && steps.every((step) => step.completed) ? item.completedAt ?? new Date() : null } });
  } else if (link.parentCalendarId && link.parentEventId) {
    const parent = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: {
      userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId,
    } } });
    if (parent?.kind === "meal" && parent.purgeStartedAt) throw new ScheduledSubtaskError("La retención está procesando la comida. Reintenta en un momento.");
    if (!parent || parent.purgeStartedAt) return;
    if (parent.kind === "meal") {
      const block = await readMealPreparation(tx, userId, link.parentCalendarId, link.parentEventId);
      const step = linkedMealSteps(block.mealPlans).find((item) => item.id === link.stepId);
      if (!step) throw new ScheduledSubtaskError("Esta preparación ya no pertenece a la comida. Actualiza.");
      const google = await getGoogleCalendarClient(userId);
      const role = (await google.calendarList.get({ calendarId: link.parentCalendarId })).data.accessRole;
      if (!["owner", "writer"].includes(role ?? "")) throw new ScheduledSubtaskError("Necesitas permiso para modificar la comida de esta preparación.");
      const event = (await google.events.get({ calendarId: link.parentCalendarId, eventId: link.parentEventId })).data;
      if (event.status === "cancelled") throw new ScheduledSubtaskError("La comida ya no existe. Actualiza la agenda.");
      await markMealPreparation(tx, userId, block, step.planId, step.sourceStepId, Boolean(completedAt), event);
      return;
    }
    if (!Array.isArray(parent.checklist)) return;
    const steps = (parent.checklist as unknown as Step[]).map((step) => step.id === link.stepId ? { ...step, completed: Boolean(completedAt) } : step);
    const done = steps.length && steps.every((step) => step.completed) ? parent.completedAt ?? new Date() : null;
    await tx.eventOverlay.update({ where: { id: parent.id }, data: { checklist: steps, checklistMarkedAt: new Date(), completedAt: done,
      purgeAfter: done && link.parentEndSnapshot ? eventPurgeAfter(done, { dateTime: link.parentEndSnapshot.toISOString() }) : null } });
    await syncScheduledParent(tx, userId, link.parentCalendarId, link.parentEventId, done);
  }
}
