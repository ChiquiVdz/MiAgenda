export type RepeatConfig = {
  frequency: "none" | "daily" | "weekly" | "monthly" | "yearly";
  interval: number; days: string[]; ending: "never" | "count" | "date"; count: number; until: string;
};
export const repeatDays = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];
export const emptyRepeat = (): RepeatConfig => ({ frequency: "none", interval: 1, days: [], ending: "never", count: 10, until: "" });
export function buildRecurrence(config: RepeatConfig, allDay: boolean): string[] {
  if (!config || typeof config !== "object") throw new Error("Revisa la repetición.");
  if (config.frequency === "none") return [];
  if (!["daily", "weekly", "monthly", "yearly"].includes(config.frequency) || !Number.isInteger(config.interval) || config.interval < 1 || config.interval > 99
    || !["never", "count", "date"].includes(config.ending)) throw new Error("Revisa la repetición y su intervalo.");
  const parts = [`FREQ=${config.frequency.toUpperCase()}`, `INTERVAL=${config.interval}`];
  if (config.frequency === "weekly") {
    if (!Array.isArray(config.days) || !config.days.length || config.days.some((day) => !repeatDays.includes(day))) throw new Error("Selecciona al menos un día de la semana.");
    parts.push(`BYDAY=${repeatDays.filter((day) => config.days.includes(day)).join(",")}`);
  }
  if (config.ending === "count") {
    if (!Number.isInteger(config.count) || config.count < 1 || config.count > 1000) throw new Error("El número de repeticiones debe estar entre 1 y 1000.");
    parts.push(`COUNT=${config.count}`);
  } else if (config.ending === "date") {
    const end = new Date(`${config.until}T12:00:00Z`);
    if (typeof config.until !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(config.until) || !Number.isFinite(end.getTime()) || end.toISOString().slice(0, 10) !== config.until) throw new Error("Elige una fecha final válida.");
    parts.push(`UNTIL=${allDay ? config.until.replaceAll("-", "") : new Date(`${config.until}T23:59:59-06:00`).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "")}`);
  }
  return [`RRULE:${parts.join(";")}`];
}
export function parseRecurrence(rules: string[], startDate: string): RepeatConfig | null {
  if (!rules.length) return emptyRepeat();
  if (rules.length !== 1 || !rules[0].startsWith("RRULE:")) return null;
  const fields: Record<string, string> = Object.fromEntries(rules[0].slice(6).split(";").map((part) => part.split("=")));
  if (Object.keys(fields).some((key) => !["FREQ", "INTERVAL", "BYDAY", "COUNT", "UNTIL", "WKST"].includes(key))) return null;
  const frequency = fields.FREQ?.toLowerCase() as RepeatConfig["frequency"];
  if (!["daily", "weekly", "monthly", "yearly"].includes(frequency)) return null;
  if ((fields.BYDAY && frequency !== "weekly") || (fields.WKST && fields.WKST !== "MO")) return null;
  if (!Number.isInteger(Number(fields.INTERVAL ?? 1)) || Number(fields.INTERVAL ?? 1) < 1 || Number(fields.INTERVAL ?? 1) > 99) return null;
  const defaultDay = repeatDays[(new Date(`${startDate}T12:00:00Z`).getUTCDay() + 6) % 7] ?? "MO";
  const days = fields.BYDAY?.split(",") ?? [defaultDay];
  if (days.some((day) => !repeatDays.includes(day))) return null;
  let until = "";
  if (fields.UNTIL) {
    const raw = fields.UNTIL;
    const iso = `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
    until = raw.length === 8 ? iso : new Date(`${iso}T${raw.slice(9, 11)}:${raw.slice(11, 13)}:${raw.slice(13, 15)}Z`).toLocaleDateString("en-CA", { timeZone: "America/Mexico_City" });
  }
  return { frequency, interval: Number(fields.INTERVAL ?? 1), days, ending: fields.COUNT ? "count" : fields.UNTIL ? "date" : "never", count: Number(fields.COUNT ?? 10), until };
}
