/** Server environment switch; never expose connection variables to the client. */
export function coreModeEnabled(): boolean {
  return process.env.MIAGENDA_CORE_ENABLED === "true";
}
