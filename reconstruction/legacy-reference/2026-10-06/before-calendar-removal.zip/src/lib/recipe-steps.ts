export type StepIngredient = { ingredientId: string; quantityPerServing: number; equivalent: string | null };
export type PriorTiming = { minutesBefore: number; durationMinutes: number };
export type RecipeStep = { id: string; text: string; isOptional: boolean; ingredientKeys: string[]; ingredient?: StepIngredient | null; priorTiming?: PriorTiming | null };
export function validPriorTiming(value: unknown): value is PriorTiming {
  if (!value || typeof value !== "object") return false;
  const timing = value as PriorTiming;
  return Number.isInteger(timing.minutesBefore) && timing.minutesBefore >= 15 && timing.minutesBefore <= 43200 && timing.minutesBefore % 15 === 0
    && Number.isInteger(timing.durationMinutes) && timing.durationMinutes >= 1 && timing.durationMinutes <= 1440 && timing.durationMinutes <= timing.minutesBefore;
}
export const priorTimingLabel = (timing: PriorTiming) => `Previo · ${timing.minutesBefore / 60} h antes · ${timing.durationMinutes} min`;
export type PreparationStep = RecipeStep & { completed: boolean };
type Line = { ingredientId: string; isOptional: boolean; nameSnapshot?: string; ingredient?: { name: string } };
export const ingredientStepKey = (line: { ingredientId: string; isOptional: boolean }) => `${line.ingredientId}:${line.isOptional ? "optional" : "required"}`;

// Legacy steps assign each total once. New steps carry their own share of that total.
export function recipeSteps(value: unknown, instructions: string, lines: Line[]): RecipeStep[] {
  const known = new Map(lines.map((line) => [ingredientStepKey(line), line]));
  const used = new Set<string>();
  const legacyAssigned = new Set<string>();
  const source = Array.isArray(value) && value.length ? value as RecipeStep[] : [{ id: "instructions", text: instructions || "Preparar la receta", isOptional: false, ingredientKeys: [] }];
  const steps = source.map((step) => ({ id: step.id, text: step.text, isOptional: step.isOptional,
    ...(step.ingredient ? { ingredient: step.ingredient } : {}),
    ...(validPriorTiming(step.priorTiming) ? { priorTiming: step.priorTiming } : {}),
    ingredientKeys: step.ingredientKeys.filter((key) => {
      const line = known.get(key);
      if (!line || line.isOptional !== step.isOptional || (!step.ingredient && legacyAssigned.has(key))) return false;
      if (!step.ingredient) legacyAssigned.add(key);
      used.add(key); return true;
    }) }));
  const ids = new Set(steps.map((step) => step.id));
  const uniqueId = (base: string) => {
    let id = base, suffix = 1;
    while (ids.has(id)) id = `${base}-${suffix++}`;
    ids.add(id); return id;
  };
  for (const [key, line] of known) if (!used.has(key)) steps.push({
    id: uniqueId(`ingredient-${key}`), text: `Agregar ${line.nameSnapshot ?? line.ingredient?.name ?? "ingrediente"}`,
    isOptional: line.isOptional, ingredientKeys: [key],
  });
  if (!steps.some((step) => !step.isOptional)) steps.unshift({ id: uniqueId("prepare"), text: "Preparar la receta", isOptional: false, ingredientKeys: [] });
  return steps;
}

export function preparationSteps(value: unknown): PreparationStep[] {
  return Array.isArray(value) ? value as PreparationStep[] : [];
}

export function snapshotRecipeSteps(recipe: { steps?: unknown; instructions: string }, lines: Line[]): PreparationStep[] {
  return recipeSteps(recipe.steps, recipe.instructions, lines).map((step) => ({ ...step, completed: false }));
}

// Split frozen plan totals between steps; integer thousandths keep their sum exact.
export function stepIngredientAmounts(steps: RecipeStep[], key: string, total: number, quantityPerServing?: number): Map<string, number> {
  const matching = steps.filter((step) => step.ingredientKeys.includes(key));
  const legacyCount = matching.filter((step) => !step.ingredient).length;
  const explicit = matching.reduce((sum, step) => sum + (step.ingredient?.quantityPerServing ?? 0), 0);
  const legacyWeight = legacyCount && quantityPerServing !== undefined ? Math.max(0, quantityPerServing - explicit) / legacyCount : 1;
  const weights = matching.map((step) => step.ingredient?.quantityPerServing ?? legacyWeight);
  const sum = weights.reduce((a, b) => a + b, 0);
  let allocated = 0, cumulativeWeight = 0;
  return new Map(matching.map((step, index) => {
    cumulativeWeight += weights[index];
    const next = index === matching.length - 1 ? Math.round(total * 1000) : Math.round(total * 1000 * (sum ? cumulativeWeight / sum : (index + 1) / matching.length));
    const amount = next - allocated;
    allocated = next;
    return [step.id, amount / 1000];
  }));
}
