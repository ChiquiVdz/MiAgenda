import "server-only";
import { createHash } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient } from "@/lib/google/calendar";

export class CalendarManagementError extends Error {
  constructor(message: string, readonly status = 409) { super(message); }
}

export async function cookingCalendar(userId: string) {
  return prisma.calendarSubscription.findFirst({ where: { userId, isMeals: true }, select: { googleCalendarId: true, summarySnapshot: true } });
}

export async function manageCalendar(userId: string, input: { calendarId?: string; name?: string; color?: string; key?: string; cooking?: boolean }) {
  const google = await getGoogleCalendarClient(userId);
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const bound = await tx.calendarSubscription.findFirst({ where: { userId, isMeals: true } });
    if (input.cooking && bound && !input.calendarId) {
      const { data: remote } = await google.calendarList.get({ calendarId: bound.googleCalendarId });
      if (!["owner", "writer"].includes(remote.accessRole ?? "")) throw new CalendarManagementError("Necesitas permiso para escribir en el calendario de Cocina.", 403);
      return { id: bound.googleCalendarId, summary: remote.summary ?? "Cocina" };
    }
    // Binding changes cannot strand meals or unfinished copies in another calendar.
    if (input.cooking && (!bound || bound.googleCalendarId !== input.calendarId)) {
      const plans = await tx.mealPlan.count({ where: { userId, ...(input.calendarId ? { googleCalendarId: { not: input.calendarId } } : {}) } });
      const copies = await tx.mealWeekCopy.count({ where: { userId, finishedAt: null } });
      if (plans || copies) throw new CalendarManagementError("Hay comidas o copias pendientes en otro calendario. Elimínalas desde el planificador antes de cambiar el calendario de Cocina.");
    }
    let calendarId = input.calendarId;
    if (!calendarId) {
      const marker = `MiAgenda:${createHash("sha256").update(JSON.stringify([userId, input.key, input.name, input.color, input.cooking])).digest("hex")}`;
      let pageToken: string | undefined;
      do {
        const { data } = await google.calendarList.list({ maxResults: 250, pageToken, fields: "items(id,description,accessRole),nextPageToken" });
        calendarId = data.items?.find((item) => item.description === marker && item.accessRole === "owner")?.id ?? undefined;
        pageToken = data.nextPageToken ?? undefined;
      } while (!calendarId && pageToken);
      if (!calendarId) {
        const { data } = await google.calendars.insert({ requestBody: { summary: input.name, description: marker, timeZone: "America/Mexico_City" } });
        calendarId = data.id ?? undefined;
      }
      if (!calendarId) throw new CalendarManagementError("Google no devolvió el calendario. Reintenta la misma solicitud.", 502);
      await google.calendarList.patch({ calendarId, colorRgbFormat: true, requestBody: { backgroundColor: input.color, foregroundColor: "#ffffff" } });
    }
    const { data: remote } = await google.calendarList.get({ calendarId });
    if (!["owner", "writer"].includes(remote.accessRole ?? "")) throw new CalendarManagementError("Necesitas permiso para escribir en ese calendario.", 403);
    if (input.cooking) await tx.calendarSubscription.updateMany({ where: { userId, isMeals: true }, data: { isMeals: false } });
    await tx.calendarSubscription.upsert({
      where: { userId_googleCalendarId: { userId, googleCalendarId: calendarId } },
      create: { userId, googleCalendarId: calendarId, summarySnapshot: remote.summary, color: remote.backgroundColor, isMeals: Boolean(input.cooking), selected: true },
      update: { summarySnapshot: remote.summary, color: remote.backgroundColor, ...(input.cooking ? { isMeals: true } : {}) },
    });
    return { id: calendarId, summary: remote.summary ?? "Calendario" };
  }, { timeout: 60000, maxWait: 10000 });
}
