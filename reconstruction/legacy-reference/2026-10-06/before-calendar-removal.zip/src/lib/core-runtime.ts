import "server-only";
import { createCoreDatabase } from "../../reconstruction/core/src/database";
import { identityAuthOptions } from "../../reconstruction/core/src/authentication";
import { ActivityService } from "../../reconstruction/core/src/service";
import { ActivityQueries } from "../../reconstruction/core/src/queries";
import { PantryService } from "../../reconstruction/core/src/pantry";
import { RecipeService } from "../../reconstruction/core/src/recipes";
import { PlannerService } from "../../reconstruction/core/src/planner";
import { ShoppingService } from "../../reconstruction/core/src/shopping";

const shared = globalThis as typeof globalThis & { miagendaCore?: ReturnType<typeof createCoreDatabase> };
export function coreRuntime() {
  const db = shared.miagendaCore ??= createCoreDatabase();
  return { db, service: new ActivityService(db), queries: new ActivityQueries(db), pantry: new PantryService(db), recipes: new RecipeService(db), planner: new PlannerService(db), shopping: new ShoppingService(db) };
}
export function coreOrigin() {
  const url = process.env.NEXTAUTH_URL;
  if (!url) throw new Error("Falta NEXTAUTH_URL para configurar el origen de MiAgenda.");
  return new URL(url).origin;
}
export function coreAuthOptions() {
  const options = identityAuthOptions(coreRuntime().db, {
    clientId: process.env.AUTH_GOOGLE_ID ?? "",
    clientSecret: process.env.AUTH_GOOGLE_SECRET ?? "",
    sessionSecret: process.env.NEXTAUTH_SECRET ?? "",
  });
  const secure = coreOrigin().startsWith("https:");
  options.cookies = { sessionToken: {
    name: `${secure ? "__Secure-" : ""}miagenda-core.session-token`,
    options: { httpOnly: true, sameSite: "lax", path: "/", secure },
  } };
  options.pages = { signIn: "/login", error: "/login" };
  options.logger = {
    error(code) { console.error(`[MiAgenda acceso] ${code}`); },
    warn(code) { console.warn(`[MiAgenda acceso] ${code}`); }, debug() {},
  };
  return options;
}
