import { createHash, randomUUID } from "node:crypto";
import { Prisma, type Prisma as PrismaTypes } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient } from "@/lib/google/calendar";
import { cacheTaskEvent, taskActivityForInbox, TaskActivityError } from "@/lib/task-activity";
import { eventPurgeAfter } from "@/lib/google/event-retention";

export type InboxSchedule = { calendarId: string; startDateTime?: string; endDateTime?: string; allDay?: boolean; startDate?: string; endDate?: string };
export class InboxError extends Error { constructor(message: string, readonly status = 409) { super(message); } }
export const inboxGoogleStatus = (error: unknown) => Number((error as { response?: { status?: number }; code?: number })?.response?.status ?? (error as { code?: number })?.code);
export async function cleanupInbox(tx: PrismaTypes.TransactionClient, userId?: string, now = new Date()) {
  const cutoff = new Date(now.getTime() - 5 * 86400000);
  await tx.activityOperation.deleteMany({ where: { ...(userId ? { userId } : {}), finishedAt: { lte: cutoff } } });
  const linked = await tx.scheduledSubtask.findMany({ where: { ...(userId ? { userId } : {}), parentInboxId: { not: null } }, select: { parentInboxId: true } });
  // Expired parents disappear from Inbox; children retain a minimal private origin.
  await tx.inboxItem.updateMany({ where: { ...(userId ? { userId } : {}), id: { in: linked.map((link) => link.parentInboxId!) },
    transferredAt: null, completedAt: { lte: cutoff }, transferPayload: { equals: Prisma.DbNull } }, data: { transferredAt: now, text: "" } });
  return tx.inboxItem.deleteMany({ where: { ...(userId ? { userId } : {}), OR: [
    { transferredAt: { lte: cutoff } }, { transferredAt: null, completedAt: { lte: cutoff }, transferPayload: { equals: Prisma.DbNull } },
  ], id: { notIn: linked.map((link) => link.parentInboxId!) } } });
}
// Persist the intended request before touching Google; retries recover one deterministic event.
export async function transferInbox(userId: string, id: string, version: string, schedule: InboxSchedule) {
  const calendar = await getGoogleCalendarClient(userId);
  const prepared = await prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    await cleanupInbox(tx, userId);
    const item = await tx.inboxItem.findFirst({ where: { id, userId } });
    if (!item) throw new InboxError("Este pendiente ya no está en Inbox. Actualiza la lista.", 404);
    if (item.transferredAt || item.transferPayload) return item;
    if (item.updatedAt.toISOString() !== version) throw new InboxError("El pendiente cambió. Actualiza Inbox antes de pasarlo a agenda.");
    const activity = await taskActivityForInbox(tx, userId, id);
    if (activity.calendarLink && !["missing", "retired"].includes(activity.calendarLink.state)) throw new TaskActivityError("Esta tarea ya tiene un traslado o evento. Actualiza Inbox.");
    const { data: remote } = await calendar.calendarList.get({ calendarId: schedule.calendarId });
    if (!["owner", "writer"].includes(remote.accessRole ?? "")) throw new InboxError("Elige un calendario en el que puedas crear eventos.");
    // Each new scheduling gets a fresh attempt; retries reuse its persisted ID.
    // Google does not allow recreating an event whose ID was previously deleted.
    const eventId = `inb${createHash("sha256").update(`${userId}\0${id}\0${randomUUID()}`).digest("hex").slice(0, 40)}`;
    if (activity.calendarLink) await tx.activityCalendarLink.delete({ where: { id: activity.calendarLink.id } });
    const prepared = await tx.inboxItem.update({ where: { id }, data: { transferPayload: schedule, googleCalendarId: schedule.calendarId, googleEventId: eventId } });
    await tx.activityCalendarLink.create({ data: { userId, activityId: activity.id, googleCalendarId: schedule.calendarId, googleEventId: eventId, state: "pending" } });
    return prepared;
  }, { timeout: 30000 });
  if (prepared.transferredAt) return { id: prepared.googleEventId, calendarId: prepared.googleCalendarId };
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
    const item = await tx.inboxItem.findFirst({ where: { id, userId } });
    if (!item) throw new InboxError("No encontramos el pendiente.", 404);
    if (item.transferredAt) return { id: item.googleEventId, calendarId: item.googleCalendarId };
    const payload = item.transferPayload as unknown as InboxSchedule;
    if (!payload || !item.googleEventId || !item.googleCalendarId) throw new InboxError("Actualiza Inbox antes de continuar.");
    const calendarId = item.googleCalendarId, eventId = item.googleEventId;
    const activity = await taskActivityForInbox(tx, userId, item.id);
    let event;
    try { event = (await calendar.events.get({ calendarId, eventId })).data; }
    catch (error) { if (![404, 410].includes(inboxGoogleStatus(error))) throw error; }
    if (!event) {
      try { event = (await calendar.events.insert({ calendarId, requestBody: {
        id: eventId, summary: activity.title ?? item.text, description: activity.description,
        start: payload.allDay ? { date: payload.startDate } : { dateTime: payload.startDateTime, timeZone: "America/Mexico_City" },
        end: payload.allDay ? { date: payload.endDate } : { dateTime: payload.endDateTime, timeZone: "America/Mexico_City" },
        extendedProperties: { private: { miagendaInbox: item.id, miagendaActivity: activity.id } },
      } })).data; }
      catch (error) {
        if (inboxGoogleStatus(error) !== 409) throw error;
        event = (await calendar.events.get({ calendarId, eventId })).data;
      }
    }
    if (event.status === "cancelled" || event.id !== eventId || event.extendedProperties?.private?.miagendaInbox !== item.id) throw new InboxError("El evento de este traslado cambió o fue eliminado en Google. Revisa la agenda antes de continuar.");
    const key = { userId, googleCalendarId: calendarId, googleEventId: eventId };
    await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key },
      create: { ...key, kind: "app_task", completedAt: activity.completedAt, etag: event.etag,
        purgeAfter: activity.completedAt ? eventPurgeAfter(activity.completedAt, event.end) : null,
        ...(Array.isArray(item.checklist) ? { checklist: item.checklist as PrismaTypes.InputJsonValue } : {}) }, update: {} });
    await cacheTaskEvent(tx, userId, calendarId, event);
    await tx.scheduledSubtask.updateMany({ where: { userId, parentInboxId: item.id }, data: {
      parentInboxId: null, parentCalendarId: calendarId, parentEventId: eventId,
      parentEndSnapshot: event.end?.dateTime ? new Date(event.end.dateTime) : event.end?.date ? new Date(`${event.end.date}T00:00:00-06:00`) : null,
    } });
    // Keep only a short-lived receipt so a lost HTTP response cannot create another event.
    await tx.inboxItem.update({ where: { id }, data: { transferredAt: new Date(), text: "", transferPayload: Prisma.DbNull, checklist: Prisma.DbNull } });
    return { id: eventId, calendarId, activityId: activity.id };
  }, { timeout: 30000 });
}

