import { createHash } from "node:crypto";
import type { calendar_v3 } from "googleapis";
import type { Prisma, MealWeekCopy } from "@/generated/prisma/client";
import { addWeekDays, copyCellKey, mexicoCopyDateTime, selectEmptyCopyCells, shiftWeekTime, type WeekCopyBlock, type CopyOmission } from "@/lib/meal-week-copy";
import { syncPlannedShopping } from "@/lib/planned-shopping";
import { preparationSteps } from "@/lib/recipe-steps";

export class WeekCopyError extends Error { constructor(message: string, readonly status = 409) { super(message); } }
export const copyGoogleStatus = (error: unknown) => (error as { response?: { status?: number }; code?: number })?.response?.status ?? (error as { code?: number })?.code;
const hash = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
export function copyProgress(job: MealWeekCopy) {
  return { copyId: job.id, sourceWeek: job.sourceWeek, targetWeek: job.targetWeek, total: job.total,
    processed: job.cursor, copied: job.copied, omissions: job.omissions as CopyOmission[], done: Boolean(job.finishedAt) };
}

export async function previewWeekCopy(tx: Prisma.TransactionClient, userId: string, sourceWeek: string, targetWeek: string, events: Map<string, calendar_v3.Schema$Event>) {
  const overlays = await tx.eventOverlay.findMany({ where: { userId, kind: "meal" }, orderBy: { id: "asc" }, include: {
    mealPlans: { orderBy: [{ createdAt: "asc" }, { id: "asc" }], include: { ingredients: { orderBy: { id: "asc" } }, recipe: { select: { id: true, userId: true } }, mealSlot: { select: { name: true } } } },
  } });
  const sourceEnd = addWeekDays(sourceWeek, 7), targetEnd = addWeekDays(targetWeek, 7);
  const blocks: WeekCopyBlock[] = [];
  const occupied = new Set<string>();
  const destination: Array<{ id: string; etag: string | null; cell: string }> = [];
  const invalid: string[] = [];
  for (const overlay of overlays) {
    const first = overlay.mealPlans[0];
    if (!first) continue;
    const event = events.get(first.id);
    if (!event || event.status === "cancelled") continue;
    const start = event.start?.dateTime ?? (event.start?.date ? `${event.start.date}T00:00:00-06:00` : null);
    if (!start) continue;
    const date = mexicoCopyDateTime(start).date;
    const cell = copyCellKey({ startDateTime: start, mealSlotId: first.mealSlotId, calendarId: overlay.googleCalendarId });
    if (date >= targetWeek && date < targetEnd) { occupied.add(cell); destination.push({ id: overlay.id, etag: event.etag ?? null, cell }); }
    if (date < sourceWeek || date >= sourceEnd) continue;
    const duration = event.start?.dateTime && event.end?.dateTime ? (Date.parse(event.end.dateTime) - Date.parse(event.start.dateTime)) / 60000 : null;
    if (!duration || !Number.isInteger(duration) || duration < 5 || duration > 1440 || overlay.purgeStartedAt
      || overlay.mealPlans.some((plan) => !plan.recipeId || plan.recipe?.userId !== userId)) {
      invalid.push(event.summary ?? "Comida sin título"); continue;
    }
    blocks.push({ sourceId: overlay.id, sourceEtag: event.etag ?? null, calendarId: overlay.googleCalendarId, summary: event.summary ?? "Comida",
      startDateTime: shiftWeekTime(start, sourceWeek, targetWeek), durationMinutes: duration, mealSlotId: first.mealSlotId, slotName: first.mealSlot?.name ?? "Sin fila",
      phases: { mealBlockConfigured: overlay.mealBlockConfigured, mealCookingEnabled: overlay.mealCookingEnabled, mealEatingEnabled: overlay.mealEatingEnabled,
        mealWashingEnabled: overlay.mealWashingEnabled, mealEatingMinutes: overlay.mealEatingMinutes, mealWashingMinutes: overlay.mealWashingMinutes,
        mealDurationOverride: duration !== first.durationMinutes ? duration : overlay.mealDurationOverride },
      recipes: overlay.mealPlans.map((plan) => ({ recipeId: plan.recipeId!, servings: plan.servings, cookedServings: plan.cookedServings,
        cookingEnabled: plan.cookingEnabled, preparationMinutes: plan.preparationMinutes,
        preparationSteps: preparationSteps(plan.preparationSteps).map((step) => ({ ...step, completed: false })),
        ingredients: plan.ingredients.map((line) => ({ ingredientId: line.ingredientId, nameSnapshot: line.nameSnapshot, unit: line.unit,
          quantityPerServing: Number(line.quantityPerServing), isOptional: line.isOptional })) })),
    });
  }
  if (invalid.length) throw new WeekCopyError(`Revisa estas comidas de origen antes de copiar: ${invalid.slice(0, 5).join(", ")}. Necesitan una receta disponible y un horario concreto de hasta un día.`);
  const { selected, omissions } = selectEmptyCopyCells(blocks, occupied);
  if (blocks.length > 100) throw new WeekCopyError("Esta semana tiene más de 100 comidas. Reduce el número antes de copiar.", 400);
  return { sourceWeek, targetWeek, sourceCount: blocks.length, destinationCount: destination.length, selected, omissions,
    fingerprint: hash({ sourceWeek, targetWeek, blocks, destination }) };
}
export type WeekCopyPreview = Awaited<ReturnType<typeof previewWeekCopy>>;

export async function startWeekCopy(tx: Prisma.TransactionClient, userId: string, key: string, fingerprint: string, preview: WeekCopyPreview) {
  const existing = await tx.mealWeekCopy.findUnique({ where: { userId_idempotencyKey: { userId, idempotencyKey: key } } });
  if (existing) {
    if (existing.sourceWeek !== preview.sourceWeek || existing.targetWeek !== preview.targetWeek || existing.fingerprint !== fingerprint) throw new WeekCopyError("Ese intento corresponde a otra copia. Abre de nuevo Copiar semana.");
    return existing;
  }
  if (preview.fingerprint !== fingerprint) throw new WeekCopyError("Las semanas cambiaron. Revisa de nuevo lo que se copiará antes de confirmar.");
  if (!preview.selected.length) throw new WeekCopyError(preview.sourceCount ? "Todas las celdas de destino correspondientes ya tienen comida." : "La semana de origen no tiene comidas para copiar.");
  if (await tx.mealWeekCopy.findFirst({ where: { userId, targetWeek: preview.targetWeek, finishedAt: null } })) throw new WeekCopyError("Ya hay una copia pendiente hacia esta semana. Reanúdala desde Copiar semana.");
  return tx.mealWeekCopy.create({ data: { userId, idempotencyKey: key, sourceWeek: preview.sourceWeek, targetWeek: preview.targetWeek, fingerprint,
    total: preview.selected.length, blocks: preview.selected as unknown as Prisma.InputJsonValue, omissions: preview.omissions } });
}

/** One event per transaction makes interruption recoverable without a long-running week transaction. */
export async function advanceWeekCopy(tx: Prisma.TransactionClient, userId: string, copyId: string, calendar: calendar_v3.Calendar) {
  const job = await tx.mealWeekCopy.findFirst({ where: { id: copyId, userId } });
  if (!job) throw new WeekCopyError("No encontramos esta copia en tu cuenta.", 404);
  if (job.finishedAt) return job;
  if (job.cursor === job.total) {
    await syncPlannedShopping(tx, userId);
    // Completed requests retain only counts and skipped-cell explanations, not recipe snapshots.
    return tx.mealWeekCopy.update({ where: { id: job.id }, data: { finishedAt: new Date(), blocks: [] } });
  }
  const block = (job.blocks as unknown as WeekCopyBlock[])[job.cursor];
  if (!block) throw new WeekCopyError("El avance de esta copia no está disponible.");
  const eventId = `meal${hash([userId, job.id, block.sourceId]).slice(0, 40)}`;
  const requestHash = hash(block);
  const duplicate = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: block.calendarId, googleEventId: eventId } } });
  if (duplicate) return tx.mealWeekCopy.update({ where: { id: job.id }, data: { cursor: { increment: 1 }, copied: { increment: 1 } } });
  const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId: block.calendarId });
  const binding = await tx.calendarSubscription.findFirst({ where: { userId, isMeals: true } });
  if (binding?.googleCalendarId !== block.calendarId) throw new WeekCopyError("La copia pertenece a otro calendario de Cocina. Revisa su configuración.");
  if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) throw new WeekCopyError("Comprueba que puedas escribir en el calendario de la comida para continuar.");
  const local = mexicoCopyDateTime(block.startDateTime);
  const candidates = await tx.mealPlan.findMany({ where: { userId, eventMissing: false, scheduledAt: { gte: new Date(`${local.date}T00:00:00-06:00`), lt: new Date(`${addWeekDays(local.date, 1)}T00:00:00-06:00`) } } });
  const occupied = candidates.some((plan) => plan.scheduledAt && copyCellKey({ startDateTime: plan.scheduledAt.toISOString(), mealSlotId: plan.mealSlotId, calendarId: plan.googleCalendarId }) === copyCellKey(block));
  const slot = block.mealSlotId ? await tx.mealSlot.findFirst({ where: { id: block.mealSlotId, userId } }) : true;
  const recipeIds = [...new Set(block.recipes.map((r) => r.recipeId))];
  const recipes = await tx.recipe.count({ where: { userId, id: { in: recipeIds } } });
  const ingredientIds = [...new Set(block.recipes.flatMap((r) => r.ingredients.map((line) => line.ingredientId)))];
  const user = await tx.user.findUniqueOrThrow({ where: { id: userId }, select: { deletedIngredientIds: true } });
  const ingredients = await tx.ingredient.count({ where: { id: { in: ingredientIds, notIn: user.deletedIngredientIds }, OR: [{ ownerUserId: null }, { ownerUserId: userId }] } });
  const reason = occupied ? "La celda se ocupó mientras se copiaba." : !slot ? "La fila se eliminó mientras se copiaba." : recipes !== recipeIds.length || ingredients !== ingredientIds.length ? "Una receta o ingrediente dejó de estar disponible." : null;
  let event: calendar_v3.Schema$Event | null = null;
  try { event = (await calendar.events.get({ calendarId: block.calendarId, eventId })).data; }
  catch (error) { if (copyGoogleStatus(error) !== 404 && copyGoogleStatus(error) !== 410) throw error; }
  if (event && (event.extendedProperties?.private?.weekCopy !== job.id || event.extendedProperties?.private?.weekCopyItem !== requestHash)) throw new WeekCopyError("El evento de esta copia cambió en Google. Revisa la agenda antes de reanudar.");
  if (reason) {
    if (event && event.status !== "cancelled") {
      if (!event.etag) throw new WeekCopyError("Actualiza Google antes de continuar esta copia.");
      try { await calendar.events.delete({ calendarId: block.calendarId, eventId, sendUpdates: "none" }, { headers: { "If-Match": event.etag } }); }
      catch (error) { if (copyGoogleStatus(error) !== 404 && copyGoogleStatus(error) !== 410) throw error; }
    }
    return tx.mealWeekCopy.update({ where: { id: job.id }, data: { cursor: { increment: 1 }, omissions: [...job.omissions as CopyOmission[], { summary: block.summary, date: local.date, slot: block.slotName, reason }] } });
  }
  if (event?.status === "cancelled") return tx.mealWeekCopy.update({ where: { id: job.id }, data: {
    cursor: { increment: 1 }, omissions: [...job.omissions as CopyOmission[], {
      summary: block.summary, date: local.date, slot: block.slotName, reason: "La comida de esta copia fue eliminada de Google." }],
  } });
  if (!event) {
    try { event = (await calendar.events.insert({ calendarId: block.calendarId, requestBody: { id: eventId, summary: block.summary,
      start: { dateTime: block.startDateTime, timeZone: "America/Mexico_City" },
      end: { dateTime: new Date(Date.parse(block.startDateTime) + block.durationMinutes * 60000).toISOString(), timeZone: "America/Mexico_City" },
      extendedProperties: { private: { miagendaMealPlan: "1", weekCopy: job.id, weekCopyItem: requestHash } } } })).data; }
    catch (error) {
      if (copyGoogleStatus(error) !== 409) throw error;
      event = (await calendar.events.get({ calendarId: block.calendarId, eventId })).data;
      if (event.status === "cancelled" || event.extendedProperties?.private?.weekCopy !== job.id || event.extendedProperties?.private?.weekCopyItem !== requestHash) throw new WeekCopyError("El evento de esta copia cambió. Revisa la agenda antes de continuar.");
    }
  }
  if (!event.id || !event.start?.dateTime || !event.end?.dateTime || Date.parse(event.start.dateTime) !== Date.parse(block.startDateTime)
    || Date.parse(event.end.dateTime) !== Date.parse(block.startDateTime) + block.durationMinutes * 60000 || event.summary !== block.summary) throw new WeekCopyError("La comida recuperada cambió en Google. Revisa su horario antes de reanudar.");
  const overlay = await tx.eventOverlay.create({ data: { userId, googleCalendarId: block.calendarId, googleEventId: eventId, etag: event.etag, kind: "meal", ...block.phases } });
  for (const [index, recipe] of block.recipes.entries()) {
    const lines = recipe.ingredients.map((line) => ({ ...line, requiredQuantity: Math.round(line.quantityPerServing * (recipe.cookingEnabled ? recipe.cookedServings : 0) * 1000) / 1000 }));
    if (lines.some((line) => line.requiredQuantity < 0 || line.requiredQuantity > 999999999.999)) throw new WeekCopyError("Las cantidades de ingredientes superan el límite permitido.");
    await tx.mealPlan.create({ data: { userId, overlayId: overlay.id, recipeId: recipe.recipeId, mealSlotId: block.mealSlotId,
      googleCalendarId: block.calendarId, googleEventId: eventId, idempotencyKey: hash([job.id, block.sourceId, index]),
      servings: recipe.servings, cookedServings: recipe.cookedServings, cookingEnabled: recipe.cookingEnabled,
      preparationSteps: (recipe.preparationSteps ?? []).map((step) => ({ ...step, completed: false })),
      preparationMinutes: recipe.preparationMinutes, durationMinutes: block.durationMinutes, scheduledAt: new Date(block.startDateTime), ingredients: { create: lines } } });
  }
  return tx.mealWeekCopy.update({ where: { id: job.id }, data: { cursor: { increment: 1 }, copied: { increment: 1 } } });
}


