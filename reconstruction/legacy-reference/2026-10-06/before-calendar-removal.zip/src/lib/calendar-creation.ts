/** Round forward in absolute time before formatting, including midnight rollover. */
export function nextCalendarStart(now: Date) {
  const rounded = new Date(Math.ceil(now.getTime() / 900000) * 900000);
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Mexico_City", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(rounded).map((part) => [part.type, part.value]));
  return { date: `${parts.year}-${parts.month}-${parts.day}`, time: `${parts.hour}:${parts.minute}` };
}

export function calendarSlotTime(hour: number, offset: number, height: number) {
  const quarter = height > 0 ? Math.min(3, Math.max(0, Math.floor(offset / height * 4))) : 0;
  return `${String(hour).padStart(2, "0")}:${String(quarter * 15).padStart(2, "0")}`;
}
