import { createHash } from "node:crypto";
import type { Prisma } from "@/generated/prisma/client";
import { preparationSteps } from "@/lib/recipe-steps";
import { syncScheduledChildren } from "@/lib/scheduled-subtask-state";

// Plan identity keeps repeated recipes and equal step IDs in separate meals distinct.
export function mealStepKey(planId: string, stepId: string) {
  return `meal${createHash("sha256").update(`${planId}\0${stepId}`).digest("hex")}`;
}
export function linkedMealSteps(plans: Array<{ id: string; cookingEnabled: boolean; preparationSteps: unknown }>) {
  return plans.flatMap((plan) => plan.cookingEnabled ? preparationSteps(plan.preparationSteps).map((step) => ({
    ...step, id: mealStepKey(plan.id, step.id), planId: plan.id, sourceStepId: step.id,
  })) : []);
}
export async function syncMealStepChildren(tx: Prisma.TransactionClient, userId: string, overlayId: string) {
  const block = await tx.eventOverlay.findFirst({ where: { id: overlayId, userId }, include: { mealPlans: true } });
  if (!block) return;
  await syncScheduledChildren(tx, userId, { calendarId: block.googleCalendarId, eventId: block.googleEventId }, linkedMealSteps(block.mealPlans));
}
