import { NextResponse, type NextRequest } from "next/server";
import { coreModeEnabled } from "./lib/core-mode";

/** Transitional route boundary; authorization belongs to the authenticated API. */
export function proxy(request: NextRequest) {
  if (!coreModeEnabled()) return NextResponse.next();
  const path = request.nextUrl.pathname;
  if (["/", "/inbox", "/agenda", "/cocina", "/cocina/recetas", "/cocina/planificar", "/cocina/compras", "/login", "/favicon.ico", "/robots.txt"].includes(path) ||
    path.startsWith("/_next/") || path === "/api/core" || path === "/api/core/retention" || path === "/api/cron/retention" || path.startsWith("/api/auth/")) {
    return NextResponse.next();
  }
  if (path.startsWith("/api/")) return NextResponse.json({
    error: "MODULE_PENDING", message: "Este apartado se está adaptando al núcleo nuevo.",
  }, { status: 503, headers: { "Cache-Control": "no-store" } });
  return NextResponse.redirect(new URL("/inbox", request.url));
}
