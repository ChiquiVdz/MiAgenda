"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { nextCalendarStart } from "@/lib/calendar-creation";
import { SubtaskSchedule } from "@/app/components/subtask-schedule";
import { InboxSubtasks } from "@/app/components/inbox-subtasks";
type Schedule = { calendarId: string; startDateTime?: string; endDateTime?: string; allDay?: boolean; startDate?: string; endDate?: string };
type Step = { id: string; text: string; completed: boolean };
type Item = { id: string; text: string; completedAt: string | null; updatedAt: string; transferPayload: Schedule | null; checklist: Step[] | null; scheduledCount?: number };
type Calendar = { id: string; summary: string; primary: boolean; selected: boolean; canWrite: boolean };
async function post(body: unknown) {
  const response = await fetch("/api/inbox", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const result = await response.json().catch(() => null);
  if (!response.ok || !result) throw new Error(result?.error ?? "No pudimos guardar el pendiente.");
  return result;
}
const inputNow = () => { const value = nextCalendarStart(new Date()); return `${value.date}T${value.time}`; };
function nextDate(value: string) {
  const date = new Date(`${value}T12:00:00Z`);
  if (!Number.isFinite(date.getTime())) return "";
  return new Date(date.getTime() + 86400000).toISOString().slice(0, 10);
}
function hourLater(value: string) {
  const date = new Date(`${value}:00-06:00`);
  if (!Number.isFinite(date.getTime())) return "";
  const next = nextCalendarStart(new Date(date.getTime() + 3600000));
  return `${next.date}T${next.time}`;
}
export function InboxView() {
  const [items, setItems] = useState<Item[]>([]), [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null), [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<Item | null>(null), [editText, setEditText] = useState("");
  const [editSteps, setEditSteps] = useState<Step[]>([]);
  const [transfer, setTransfer] = useState<Item | null>(null), [calendars, setCalendars] = useState<Calendar[]>([]);
  const [calendarId, setCalendarId] = useState(""), [start, setStart] = useState(""), [end, setEnd] = useState("");
  const [allDay, setAllDay] = useState(false), [startDate, setStartDate] = useState(""), [endDate, setEndDate] = useState("");
  const dialog = useRef<HTMLDialogElement>(null), busyRef = useRef(false), createKey = useRef<string | null>(null);
  const loadVersion = useRef(0);
  const setGlobalBusy = (value: boolean) => { busyRef.current = value; setBusy(value); };
  const pending = items.filter((item) => !item.completedAt), completed = items.filter((item) => item.completedAt)
    .sort((a, b) => Date.parse(b.completedAt!) - Date.parse(a.completedAt!));
  async function load(signal?: AbortSignal) {
    const version = ++loadVersion.current;
    const response = await fetch("/api/inbox", { cache: "no-store", signal });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error ?? "No pudimos abrir Inbox.");
    if (version === loadVersion.current) setItems(result.items);
    return result.items as Item[];
  }
  useEffect(() => {
    const added = (event: Event) => {
      const item = (event as CustomEvent<{ item: Item }>).detail.item;
      loadVersion.current += 1;
      setItems((current) => [item, ...current.filter((row) => row.id !== item.id)]);
    };
    window.addEventListener("miagenda:inbox-added", added);
    return () => window.removeEventListener("miagenda:inbox-added", added);
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch((cause) => { if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "No pudimos abrir Inbox."); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    const refresh = () => { if (!busyRef.current && document.visibilityState === "visible") void load().catch(() => undefined); };
    const timer = window.setInterval(refresh, 60000);
    window.addEventListener("focus", refresh); document.addEventListener("visibilitychange", refresh);
    return () => { controller.abort(); window.clearInterval(timer); window.removeEventListener("focus", refresh); document.removeEventListener("visibilitychange", refresh); };
  }, []);
  useEffect(() => { if (editing || transfer) dialog.current?.showModal(); }, [editing, transfer]);
  async function save(action: string, item?: Item, text?: string, steps?: Step[], keepOpen = false) {
    if (busyRef.current) return false;
    busyRef.current = true; setBusy(true); setError(null); setNotice(null);
    try {
      if (action === "add") createKey.current ??= crypto.randomUUID();
      const result = await post({ action, id: item?.id, version: item?.updatedAt, text, steps, createKey: action === "add" ? createKey.current : undefined });
      if (action === "add") { setDraft(""); createKey.current = null; }
      if (action === "edit") { setEditing(keepOpen ? result.item : null); if (keepOpen) setEditSteps(result.item.checklist ?? []); }
      if (result.item) setItems((current) => current.some((row) => row.id === result.item.id)
        ? current.map((row) => row.id === result.item.id ? { ...row, ...result.item } : row) : [result.item, ...current]);
      if (result.deleted) setItems((current) => current.filter((row) => row.id !== item?.id));
      return true;
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos guardar el cambio."); await load().catch(() => undefined); return false; }
    finally { busyRef.current = false; setBusy(false); }
  }
  async function openTransfer(item: Item) {
    if (busyRef.current) return;
    setError(null); setNotice(null); setCalendars([]);
    const saved = item.transferPayload;
    const beginning = saved?.startDateTime?.slice(0, 16) ?? inputNow();
    const date = saved?.startDate ?? beginning.slice(0, 10);
    setAllDay(saved?.allDay ?? false); setStartDate(date); setEndDate(saved?.endDate ?? nextDate(date));
    setCalendarId(saved?.calendarId ?? ""); setStart(beginning); setEnd(saved?.endDateTime?.slice(0, 16) ?? hourLater(beginning)); setTransfer(item);
    try {
      const response = await fetch("/api/calendars", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No pudimos consultar los calendarios.");
      const available = (result.calendars as Calendar[]).filter((calendar) => calendar.canWrite);
      setCalendars(available);
      if (!saved) setCalendarId(available.find((calendar) => calendar.primary)?.id ?? available[0]?.id ?? "");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos consultar los calendarios."); }
  }
  async function move(event: FormEvent) {
    event.preventDefault();
    if (!transfer || busyRef.current) return;
    busyRef.current = true; setBusy(true); setError(null);
    try {
      await post({ action: "transfer", id: transfer.id, version: transfer.updatedAt, calendarId, allDay,
        ...(allDay ? { startDate, endDate } : { startDateTime: `${start}:00-06:00`, endDateTime: `${end}:00-06:00` }) });
      setItems((current) => current.filter((item) => item.id !== transfer.id)); setTransfer(null); setNotice("El pendiente salió de Inbox y ya está en la agenda.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos pasar el pendiente a agenda.");
      const fresh = await load().catch(() => null);
      const next = fresh?.find((item) => item.id === transfer.id);
      if (next) setTransfer(next);
      else if (fresh) { setTransfer(null); setError(null); setNotice("El traslado se confirmó. El pendiente ya está en la agenda."); }
    } finally { busyRef.current = false; setBusy(false); }
  }
  function row(item: Item) {
    const moving = Boolean(item.transferPayload);
    return <li className={`today-item inbox-item${item.completedAt ? " today-item-completed" : ""}`} key={item.id}>
      <button className="today-completion" type="button" disabled={busy || moving} aria-pressed={Boolean(item.completedAt)} aria-label={`${item.completedAt ? "Deshacer completado de" : "Completar"} ${item.text}`} onClick={() => void save(item.completedAt ? "uncomplete" : "complete", item)}>{item.completedAt ? "✓" : ""}</button>
      <div className="today-event-content"><div className="inbox-text"><strong>{item.text}</strong><span>Inbox · {item.checklist?.length ?? 0} subtareas{item.scheduledCount ? ` · ${item.scheduledCount} agendadas` : ""}</span>{moving && <span>Traslado pendiente de confirmar en Google.</span>}</div>
        <InboxSubtasks item={item} disabled={busy || moving} onBusy={setGlobalBusy} onSave={(steps) => save("edit", item, item.text, steps)} onScheduled={async () => { await load(); }} />
      </div>
      <div className="inbox-actions"><button type="button" disabled={busy || moving} onClick={() => { setEditing(item); setEditText(item.text); setEditSteps(item.checklist ?? []); setError(null); }}>Editar</button>
        <button type="button" disabled={busy} onClick={() => void openTransfer(item)}>{moving ? "Reanudar traslado" : "Pasar a agenda"}</button>
        <button type="button" disabled={busy || moving} aria-label={`Eliminar ${item.text}`} onClick={() => { if (window.confirm(`¿Eliminar “${item.text}” de Inbox y los eventos de sus subtareas programadas?`)) void save("delete", item); }}>×</button></div>
    </li>;
  }
  return <main className="app-shell"><aside className="sidebar">
    <a className="brand" href="/"><span className="brand-mark">m</span><span>miagenda</span></a>
    <nav className="primary-nav" aria-label="Navegación principal"><a className="nav-item nav-item-active" href="/inbox" aria-current="page"><span className="nav-icon" aria-hidden="true">▱</span>Inbox</a><a className="nav-item" href="/"><span className="nav-icon" aria-hidden="true">▦</span>Agenda</a><a className="nav-item" href="/cocina"><span className="nav-icon" aria-hidden="true">♨</span>Cocina</a></nav>
    <div className="sidebar-bottom"><div className="privacy-line"><span className="privacy-dot" />Tus datos, bajo tu control</div></div>
  </aside><section className="workspace"><header className="topbar"><div className="breadcrumb"><span>Mi espacio</span><span className="breadcrumb-slash">/</span><strong>Inbox</strong></div></header>
    <div className="page-content"><div className="today-agenda"><div className="page-heading-row"><div><p className="eyebrow">CAPTURA RÁPIDA</p><h1>Inbox</h1><p className="week-range">Anota lo que tengas pendiente. Tú decides cuándo pasarlo a la agenda.</p></div></div>
      <form className="inbox-add" onSubmit={(event) => { event.preventDefault(); void save("add", undefined, draft); }}><label className="form-field">Nuevo pendiente<input type="text" autoFocus maxLength={250} required placeholder="Examen a las 3 el jueves" value={draft} disabled={busy} onChange={(event) => { setDraft(event.target.value); createKey.current = null; }} /></label><button className="pantry-add-button" type="submit" disabled={busy || !draft.trim()}>＋ Agregar</button></form>
      {error && !editing && !transfer && <p className="pantry-message pantry-error" role="alert">{error} <button type="button" disabled={busy} onClick={() => void load().then(() => setError(null)).catch((cause) => setError(cause.message))}>Actualizar</button></p>}
      {notice && <p className="pantry-message" role="status">{notice} <a href="/">Ver agenda</a></p>}
      {loading ? <p className="pantry-empty">Cargando Inbox…</p> : <><section className="today-group"><h2>Pendientes <span>{pending.length}</span></h2>{pending.length ? <ul>{pending.map(row)}</ul> : <p className="today-empty">No tienes pendientes en Inbox.</p>}</section>
        {completed.length > 0 && <details className="inbox-completed"><summary>Completados ({completed.length})</summary><p className="form-hint">Puedes deshacer durante cinco días desde que los completas; después se eliminan.</p><ul>{completed.map(row)}</ul></details>}</>}
    </div></div>
  </section>
  {(editing || transfer) && <dialog className="event-dialog" ref={dialog} aria-labelledby="inbox-dialog-title" onCancel={(event) => { if (busy) event.preventDefault(); else { setEditing(null); setTransfer(null); } }}>
    <div className="dialog-heading"><h2 id="inbox-dialog-title">{editing ? "Editar pendiente" : "Pasar a agenda"}</h2><button className="dialog-close" type="button" disabled={busy} onClick={() => { setEditing(null); setTransfer(null); }} aria-label="Cerrar">×</button></div>
    {error && <p className="pantry-message pantry-error" role="alert">{error}</p>}
    {editing ? <form onSubmit={(event) => { event.preventDefault(); void save("edit", editing, editText, editSteps); }}><label className="form-field">Texto<input autoFocus maxLength={250} required value={editText} disabled={busy} onChange={(event) => setEditText(event.target.value)} /></label><section className="activity-checklist" aria-label="Subtareas de Inbox"><div className="activity-checklist-heading"><strong>Subtareas · opcional</strong></div>
{editSteps.map((step, index) => <div className="activity-step" key={step.id}><input type="checkbox" checked={step.completed} disabled={busy || !editText.trim() || editSteps.some((item) => !item.text.trim())} aria-label={`Completar ${step.text}`} onChange={() => { const list = editSteps.map((item) => item.id === step.id ? { ...item, completed: !item.completed } : item); void save("edit", editing, editText, list, true); }} />
<input type="text" value={step.text} maxLength={150} disabled={busy} aria-label={`Subtarea ${index + 1}`} placeholder="Ej. Preparar materiales" onChange={(event) => setEditSteps((list) => list.map((item) => item.id === step.id ? { ...item, text: event.target.value } : item))} /><button type="button" disabled={busy} aria-label={`Quitar subtarea ${index + 1}`} onClick={() => setEditSteps((list) => list.filter((item) => item.id !== step.id))}>×</button><SubtaskSchedule parent={{ inboxId: editing.id }} stepId={step.id} version={editing.updatedAt} disabled={busy || editText !== editing.text || JSON.stringify(editSteps) !== JSON.stringify(editing.checklist ?? [])} onBusy={setGlobalBusy} onSaved={async () => { const fresh = await load(); const item = fresh.find((row) => row.id === editing.id); if (item) { setEditing(item); setEditSteps(item.checklist ?? []); } }} /></div>)}
<div className="activity-checklist-actions"><button type="button" disabled={busy || editSteps.length >= 50} onClick={() => setEditSteps((list) => [...list, { id: crypto.randomUUID(), text: "", completed: false }])}>＋ Añadir subtarea</button></div><p className="form-hint">Las subtareas se conservan al pasar esta tarea a Agenda.</p></section><div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={busy} onClick={() => setEditing(null)}>Cancelar</button><button className="dialog-submit" disabled={busy || !editText.trim() || editSteps.some((step) => !step.text.trim())} type="submit">Guardar</button></div></form>
      : transfer && <form onSubmit={(event) => void move(event)}><p>{transfer.text}</p>{transfer.transferPayload && <p className="form-hint">Se reintentará el traslado con el calendario y horario originales para recuperar el mismo evento.</p>}
        <label className="form-field">Calendario<select required value={calendarId} disabled={busy || Boolean(transfer.transferPayload)} onChange={(event) => setCalendarId(event.target.value)}><option value="">Elige un calendario</option>{calendarId && !calendars.some((calendar) => calendar.id === calendarId) && <option value={calendarId}>Calendario del traslado</option>}{calendars.map((calendar) => <option key={calendar.id} value={calendar.id}>{calendar.summary}</option>)}</select></label>
        <label className="form-field"><span><input type="checkbox" checked={allDay} disabled={busy || Boolean(transfer.transferPayload)} onChange={(event) => setAllDay(event.target.checked)} /> Todo el día</span></label>
        {allDay ? <><label className="form-field">Fecha inicial<input type="date" required value={startDate} disabled={busy || Boolean(transfer.transferPayload)} onChange={(event) => { setStartDate(event.target.value); setEndDate(nextDate(event.target.value)); }} /></label><label className="form-field">Hasta (fecha final no incluida)<input type="date" required min={nextDate(startDate)} value={endDate} disabled={busy || Boolean(transfer.transferPayload)} onChange={(event) => setEndDate(event.target.value)} /></label></> : <><label className="form-field">Inicio<input type="datetime-local" required value={start} disabled={busy || Boolean(transfer.transferPayload)} onChange={(event) => { setStart(event.target.value); setEnd(hourLater(event.target.value)); }} /></label>
        <label className="form-field">Fin<input type="datetime-local" required min={start} value={end} disabled={busy || Boolean(transfer.transferPayload)} onChange={(event) => setEnd(event.target.value)} /></label></>}
        <p className="form-hint">{allDay ? "Sin hora. Puedes conservar o destacar la tarea en Agenda." : "Horario de Ciudad de México. El fin debe ser posterior al inicio."} El progreso y las subtareas se conservan.</p>
        <div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={busy} onClick={() => setTransfer(null)}>Cancelar</button><button className="dialog-submit" type="submit" disabled={busy || !calendarId || (allDay ? !startDate || !endDate || endDate <= startDate : !start || !end || end <= start)}>{busy ? "Creando…" : transfer.transferPayload ? "Reanudar traslado" : "Crear en agenda"}</button></div>
      </form>}
  </dialog>}
  </main>;
}


