import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { InboxView } from "./inbox-view";
import { CoreInboxView } from "./core-inbox-view";
import { coreModeEnabled } from "@/lib/core-mode";
import { coreRuntime } from "@/lib/core-runtime";
export default async function Inbox() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/login");
  if (!coreModeEnabled()) return <InboxView />;
  const [inbox, calendars] = await Promise.all([coreRuntime().queries.inbox(session.user.id), coreRuntime().queries.calendars(session.user.id)]);
  return <CoreInboxView initialData={inbox} calendars={calendars.items} />;
}
