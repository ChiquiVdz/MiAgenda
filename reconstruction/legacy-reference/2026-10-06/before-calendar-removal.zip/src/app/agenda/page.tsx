import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { coreRuntime } from "@/lib/core-runtime";
import { coreModeEnabled } from "@/lib/core-mode";
import { CoreAgenda } from "../core/core-agenda";
import { dateParts, weekStart, atTime, plusDays } from "../core/dates";

export default async function Agenda() {
  if (!coreModeEnabled()) redirect("/");
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/login");
  const today = dateParts(new Date()).date, start = weekStart(today), end = plusDays(start, 7);
  const [agenda, calendars] = await Promise.all([
    coreRuntime().queries.agenda(session.user.id, { startsAt: atTime(start), endsAt: atTime(end), startDate: start, endDate: end }),
    coreRuntime().queries.calendars(session.user.id),
  ]);
  return <CoreAgenda initialData={agenda} initialCalendars={calendars.items} initialToday={today} />;
}
