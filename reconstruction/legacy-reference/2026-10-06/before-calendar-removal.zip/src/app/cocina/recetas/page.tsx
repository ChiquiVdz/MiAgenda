import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { RecipesView } from "@/app/cocina/recetas/recipes-view";
import { coreModeEnabled } from "@/lib/core-mode";
import { coreRuntime } from "@/lib/core-runtime";
import { CoreRecipesView } from "./core-recipes-view";

export default async function RecipesPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/login");

  if (coreModeEnabled()) {
    const core = coreRuntime();
    const [initial, pantry] = await Promise.all([core.recipes.snapshot(session.user.id), core.pantry.snapshot(session.user.id)]);
    return <CoreRecipesView initial={initial} pantry={pantry} />;
  }

  return <RecipesView />;
}
