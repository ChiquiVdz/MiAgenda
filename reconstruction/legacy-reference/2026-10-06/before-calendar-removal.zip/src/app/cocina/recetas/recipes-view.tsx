"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { normalizeIngredientName } from "@/lib/ingredients";
import { ingredientStepKey, recipeSteps, stepIngredientAmounts, priorTimingLabel, validPriorTiming, type RecipeStep } from "@/lib/recipe-steps";

type Unit = "g" | "kg" | "ml" | "l" | "piece";
type IngredientOption = { id: string; name: string; unit: Unit; isBuiltin: boolean };
type DraftStep = { id: string; text: string; isOptional: boolean; ingredientId: string; quantityPerServing: string; equivalent: string; priorEnabled: boolean; priorHours: string; priorDuration: string };
type Recipe = {
  id: string;
  name: string;
  instructions: string;
  servings: number;
  durationMinutes: number;
  steps: RecipeStep[] | null;
  ingredients: Array<{ id: string; isOptional: boolean; ingredientId: string; quantityPerServing: string; equivalent: string | null; ingredient: IngredientOption }>;
};
type RecipeDraft = { id: string | null; name: string; servings: string; durationMinutes: string; steps: DraftStep[] };

const unitLabels: Record<Unit, string> = { g: "g", kg: "kg", ml: "ml", l: "l", piece: "piezas" };
const newStep = (): DraftStep => ({ id: crypto.randomUUID(), text: "", isOptional: false, ingredientId: "", quantityPerServing: "1", equivalent: "", priorEnabled: false, priorHours: "12", priorDuration: "15" });
const emptyDraft: RecipeDraft = { id: null, name: "", servings: "2", durationMinutes: "45", steps: [] };

export function RecipesView() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [catalog, setCatalog] = useState<IngredientOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [draft, setDraft] = useState<RecipeDraft | null>(null);
  const [search, setSearch] = useState("");
  const [pickerStepId, setPickerStepId] = useState<string | null>(null);

  async function loadData() {
    const [recipeResponse, catalogResponse] = await Promise.all([
      fetch("/api/recipes", { cache: "no-store" }), fetch("/api/ingredients", { cache: "no-store" }),
    ]);
    const [recipeResult, catalogResult] = await Promise.all([
      recipeResponse.json().catch(() => null), catalogResponse.json().catch(() => null),
    ]);
    if (!recipeResponse.ok || !Array.isArray(recipeResult?.recipes)) throw new Error(recipeResult?.error ?? "No pudimos cargar tus recetas.");
    if (!catalogResponse.ok || !Array.isArray(catalogResult?.ingredients)) throw new Error(catalogResult?.error ?? "No pudimos cargar el catálogo.");
    setRecipes(recipeResult.recipes as Recipe[]);
    setCatalog(catalogResult.ingredients as IngredientOption[]);
  }

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        await loadData();
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "No pudimos cargar tus recetas.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => { cancelled = true; };
  }, []);

  const filteredCatalog = useMemo(() => {
    const query = normalizeIngredientName(search);
    return catalog.filter((ingredient) => !query || normalizeIngredientName(ingredient.name).includes(query));
  }, [catalog, search]);

  function startNew() {
    setError(null);
    setNotice(null);
    setDraft({ ...emptyDraft, steps: [newStep()] });
    setPickerStepId(null);
  }

  function startEdit(recipe: Recipe) {
    setError(null);
    setNotice(null);
    const steps = recipeSteps(recipe.steps, recipe.instructions, recipe.ingredients);
    setDraft({
      id: recipe.id,
      name: recipe.name,
      steps: steps.flatMap((step) => {
        const prior = { priorEnabled: Boolean(step.priorTiming), priorHours: String((step.priorTiming?.minutesBefore ?? 720) / 60), priorDuration: String(step.priorTiming?.durationMinutes ?? 15) };
        const lines = step.ingredientKeys.flatMap((key) => recipe.ingredients.filter((line) => ingredientStepKey(line) === key));
        if (!lines.length) return [{ ...prior, id: step.id, text: step.text, isOptional: step.isOptional, ingredientId: "", quantityPerServing: "1", equivalent: "" }];
        return lines.map((line, index) => ({ ...prior, priorEnabled: index === 0 && prior.priorEnabled, id: index === 0 ? step.id : crypto.randomUUID(), text: index === 0 ? step.text : `Agregar ${line.ingredient.name}`,
          isOptional: step.isOptional, ingredientId: line.ingredientId,
          quantityPerServing: String(stepIngredientAmounts(steps, ingredientStepKey(line), Number(line.quantityPerServing), Number(line.quantityPerServing)).get(step.id) ?? Number(line.quantityPerServing)),
          equivalent: step.ingredient?.equivalent ?? line.equivalent ?? "" }));
      }),
      servings: String(recipe.servings),
      durationMinutes: String(recipe.durationMinutes),
    });
    setPickerStepId(null);
  }

  function updateStep(id: string, changes: Partial<DraftStep>) {
    setDraft((current) => current ? { ...current, steps: current.steps.map((step) => step.id === id ? { ...step, ...changes } : step) } : current);
  }

  function moveStep(index: number, direction: number) {
    setDraft((current) => {
      if (!current || index + direction < 0 || index + direction >= current.steps.length) return current;
      const steps = [...current.steps];
      [steps[index], steps[index + direction]] = [steps[index + direction], steps[index]];
      return { ...current, steps };
    });
  }

  const totals = useMemo(() => {
    const grouped = new Map<string, { ingredient: IngredientOption; isOptional: boolean; amount: number }>();
    for (const step of draft?.steps ?? []) {
      const ingredient = catalog.find((line) => line.id === step.ingredientId) ?? recipes.flatMap((recipe) => recipe.ingredients.map((line) => line.ingredient)).find((line) => line.id === step.ingredientId);
      if (!ingredient) continue;
      const key = `${ingredient.id}:${step.isOptional}`;
      const previous = grouped.get(key);
      grouped.set(key, { ingredient, isOptional: step.isOptional, amount: Math.round(((previous?.amount ?? 0) + (Number(step.quantityPerServing) || 0)) * 1000) / 1000 });
    }
    return [...grouped.values()];
  }, [draft, catalog, recipes]);

  async function saveRecipe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!draft) return;
    if (draft.steps.some((step) => step.priorEnabled && !validPriorTiming({ minutesBefore: Number(step.priorHours) * 60, durationMinutes: Number(step.priorDuration) }))) {
      setError("Revisa los pasos previos: anticipación de 0.25 a 720 horas en intervalos de 0.25; duración de 1 a 1440 minutos, sin superar la anticipación."); return;
    }
    if (draft.steps.map((step) => step.text.trim()).join("\n").length > 10000) {
      setError("Las instrucciones completas admiten hasta 10 000 caracteres.");
      return;
    }
    setSaving(true);
    setError(null);
    setNotice(null);
    const payload = {
      name: draft.name,
      format: "steps",
      steps: draft.steps.map((step) => ({ id: step.id, text: step.text, isOptional: step.isOptional,
        priorTiming: step.priorEnabled ? { minutesBefore: Number(step.priorHours) * 60, durationMinutes: Number(step.priorDuration) } : null,
        ingredient: step.ingredientId ? { ingredientId: step.ingredientId, quantityPerServing: Number(step.quantityPerServing), equivalent: step.equivalent } : null })),
      servings: Number(draft.servings),
      durationMinutes: Number(draft.durationMinutes),
    };
    try {
      const response = await fetch(draft.id ? `/api/recipes/${encodeURIComponent(draft.id)}` : "/api/recipes", {
        method: draft.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos guardar la receta.");
      const recipeName = result.recipe.name as string;
      await loadData();
      setDraft(null);
      setNotice(`“${recipeName}” se guardó.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos guardar la receta.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteRecipe(recipe: Recipe) {
    if (!window.confirm(`¿Eliminar la receta “${recipe.name}”?`)) return;
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(`/api/recipes/${encodeURIComponent(recipe.id)}`, { method: "DELETE" });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos eliminar la receta.");
      await loadData();
      setNotice(`“${recipe.name}” se eliminó.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos eliminar la receta.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="/" aria-label="MiAgenda, inicio"><span className="brand-mark">m</span><span>miagenda</span></a>
        <nav className="primary-nav" aria-label="Navegación principal">
          <a className="nav-item" href="/inbox"><span className="nav-icon" aria-hidden="true">▱</span>Inbox</a>
          
          <a className="nav-item" href="/"><span className="nav-icon" aria-hidden="true">▦</span>Agenda</a>
          <a className="nav-item" href="/cocina"><span className="nav-icon" aria-hidden="true">♨</span>Alacena</a>
          <a className="nav-item nav-item-active" href="/cocina/recetas" aria-current="page"><span className="nav-icon" aria-hidden="true">▤</span>Recetas</a>
          <a className="nav-item" href="/cocina/planificar"><span className="nav-icon" aria-hidden="true">◷</span>Planificar</a>
          <a className="nav-item" href="/cocina/compras"><span className="nav-icon" aria-hidden="true">☷</span>Compras</a>
        </nav>
        <div className="sidebar-bottom">
          <div className="privacy-line"><span className="privacy-dot" />Tus datos, bajo tu control</div>
          <div className="profile-row"><div className="avatar">E</div><div className="profile-copy"><strong>Tu espacio</strong><span>Cuenta personal</span></div></div>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar"><div className="breadcrumb"><span>Mi espacio</span><span className="breadcrumb-slash">/</span><strong>Cocina</strong><span className="breadcrumb-slash">/</span><strong>Recetas</strong></div></header>
        <div className="page-content pantry-content">
          <div className="page-heading-row pantry-heading"><div><p className="eyebrow">ORGANIZA TU COCINA</p><h1>Recetas</h1><p className="week-range">Usa los mismos ingredientes del catálogo que tienes en la alacena.</p></div><button className="pantry-add-button" type="button" onClick={startNew}>＋ Nueva receta</button></div>

          {error && <p className="pantry-message pantry-error" role="alert">{error}</p>}
          {notice && <p className="pantry-message" role="status">{notice}</p>}

          {draft && <form className="recipe-editor" onSubmit={(event) => void saveRecipe(event)}>
            <div className="pantry-list-heading"><h2>{draft.id ? "Editar receta" : "Nueva receta"}</h2><button className="recipe-editor-close" type="button" disabled={saving} onClick={() => setDraft(null)}>Cerrar</button></div>
            <div className="recipe-fields">
              <label className="form-field">Nombre<input type="text" maxLength={150} value={draft.name} required onChange={(event) => setDraft((current) => current ? { ...current, name: event.target.value } : current)} placeholder="Ej. Pasta con tomate" /></label>
              <label className="form-field">Porciones<input type="number" min="1" max="100" step="1" value={draft.servings} required onChange={(event) => setDraft((current) => current ? { ...current, servings: event.target.value } : current)} /></label>
              <label className="form-field">Duración (minutos)<input type="number" min="5" max="480" step="5" value={draft.durationMinutes} required onChange={(event) => setDraft((current) => current ? { ...current, durationMinutes: event.target.value } : current)} /></label>
            </div>

            <section className="recipe-step-editor" aria-labelledby="recipe-steps-heading">
              <div className="pantry-list-heading"><h3 id="recipe-steps-heading">Pasos de preparación</h3><button className="pantry-save-button" type="button" disabled={saving || draft.steps.length >= 100} onClick={() => setDraft((current) => current ? { ...current, steps: [...current.steps, newStep()] } : current)}>＋ Paso</button></div>
              <p className="form-hint">Escribe cada paso y agrega un ingrediente si lo necesita. Las cantidades son por porción; los ingredientes repetidos se suman automáticamente.</p>
              <ol className="recipe-step-list">{draft.steps.map((step, index) => {
                const ingredient = catalog.find((item) => item.id === step.ingredientId) ?? recipes.flatMap((recipe) => recipe.ingredients.map((line) => line.ingredient)).find((item) => item.id === step.ingredientId);
                return <li key={step.id}>
                  <div className="recipe-step-heading"><label className="form-field">Paso {index + 1}<textarea required rows={2} maxLength={10000} value={step.text} disabled={saving} onChange={(event) => updateStep(step.id, { text: event.target.value })} placeholder="Ej. Agregar la pasta al agua hirviendo" /></label><button type="button" className="pantry-remove-button" disabled={saving} aria-label={`Eliminar paso ${index + 1}`} onClick={() => setDraft((current) => current ? { ...current, steps: current.steps.filter((item) => item.id !== step.id) } : current)}>×</button></div>
                  <div className="recipe-step-controls">
                    <button type="button" className="pantry-save-button" disabled={saving || index === 0} aria-label={`Subir paso ${index + 1}`} onClick={() => moveStep(index, -1)}>↑</button>
                    <button type="button" className="pantry-save-button" disabled={saving || index === draft.steps.length - 1} aria-label={`Bajar paso ${index + 1}`} onClick={() => moveStep(index, 1)}>↓</button>
                    <label className="ingredient-optional-toggle"><input type="checkbox" disabled={saving} checked={step.isOptional} onChange={(event) => updateStep(step.id, { isOptional: event.target.checked })} /> {step.ingredientId ? "Ingrediente y paso opcionales" : "Paso opcional"}</label>
                    <label className="ingredient-optional-toggle"><input type="checkbox" disabled={saving} checked={step.priorEnabled} onChange={(event) => updateStep(step.id, { priorEnabled: event.target.checked })} /> Realizar antes de cocinar</label>
                    <button className="pantry-save-button" type="button" disabled={saving} onClick={() => { setPickerStepId(pickerStepId === step.id ? null : step.id); setSearch(""); }}>{ingredient ? `Cambiar ${ingredient.name}` : "＋ Ingrediente"}</button>
                  </div>
                  {step.priorEnabled && <div className="recipe-prior-timing">
                    <label className="form-field">Horas antes del inicio de la comida<input type="number" required min="0.25" max="720" step="0.25" value={step.priorHours} disabled={saving} onChange={(event) => updateStep(step.id, { priorHours: event.target.value })} /></label>
                    <label className="form-field">Duración del pendiente (minutos)<input type="number" required min="1" max={Math.min(1440, Number(step.priorHours) * 60) || 1440} step="1" value={step.priorDuration} disabled={saving} onChange={(event) => updateStep(step.id, { priorDuration: event.target.value })} /></label>
                    <p className="form-hint">Ej. sacar el pollo 12 horas antes. Es una sugerencia para cada preparación; no crea un evento al guardar la receta ni aumenta su tiempo de cocina.</p>
                  </div>}
                  {pickerStepId === step.id && <div className="recipe-step-picker">
                    <label className="pantry-search">Buscar ingrediente<input type="search" value={search} disabled={saving} onChange={(event) => setSearch(event.target.value)} placeholder="Busca en el catálogo" /></label>
                    <div className="ingredient-picker recipe-picker">{filteredCatalog.map((item) => <button key={item.id} className="ingredient-chip" type="button" disabled={saving} onClick={() => { updateStep(step.id, { ingredientId: item.id, quantityPerServing: "1", equivalent: "" }); setPickerStepId(null); }}><span>{item.name}</span><small>{unitLabels[item.unit]}</small></button>)}</div>
                    {!filteredCatalog.length && <p className="form-hint">No hay ingredientes que coincidan. Puedes agregar uno desde Alacena.</p>}
                  </div>}
                  {step.ingredientId && <div className="recipe-step-amount">
                    <strong>{ingredient?.name ?? "Ingrediente no disponible"}</strong>
                    <label className="form-field">Cantidad por porción ({ingredient ? unitLabels[ingredient.unit] : "unidad"})<input type="number" required min="0.001" max="999999999.999" step="0.001" value={step.quantityPerServing} disabled={saving} onChange={(event) => updateStep(step.id, { quantityPerServing: event.target.value })} /></label>
                    <label className="form-field">Equivalencia por porción<input type="text" maxLength={120} value={step.equivalent} disabled={saving} placeholder="Ej. 2 cucharadas" onChange={(event) => updateStep(step.id, { equivalent: event.target.value })} /></label>
                    <button type="button" className="pantry-remove-button" disabled={saving} onClick={() => updateStep(step.id, { ingredientId: "", equivalent: "", quantityPerServing: "1" })}>Quitar ingrediente</button>
                  </div>}
                </li>;
              })}</ol>
              {!draft.steps.length && <p className="pantry-empty">Agrega un paso para empezar.</p>}
            </section>
            <section className="recipe-ingredient-summary" aria-label="Totales de ingredientes">
              <h3>Ingredientes totales por porción</h3>
              {!totals.length ? <p className="form-hint">Agrega al menos un ingrediente en los pasos.</p> : <ul className="recipe-card-ingredients">{totals.map((line) => <li key={`${line.ingredient.id}:${line.isOptional}`}><span>{line.ingredient.name}{line.isOptional && <small className="optional-badge">Opcional</small>}</span><span>{line.amount} {unitLabels[line.ingredient.unit]}</span></li>)}</ul>}
              <p className="form-hint">Este resumen se calcula automáticamente. Las equivalencias se muestran en cada paso; la alacena usa la unidad fija.</p>
              {!draft.steps.some((step) => !step.isOptional) && <p className="form-hint">Incluye al menos un paso obligatorio para poder completar la preparación.</p>}
            </section>
            <div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={saving} onClick={() => setDraft(null)}>Cancelar</button><button className="dialog-submit" type="submit" disabled={saving || !draft.steps.length || !totals.length || !draft.steps.some((step) => !step.isOptional)}>{saving ? "Guardando…" : draft.id ? "Guardar cambios" : "Guardar receta"}</button></div>
          </form>}

          <section className="recipe-list" aria-labelledby="recipe-list-heading">
            <div className="pantry-list-heading"><h2 id="recipe-list-heading">Mis recetas</h2><span>{recipes.length}</span></div>
            {loading ? <p className="pantry-empty">Cargando recetas…</p>
              : recipes.length === 0 ? <p className="pantry-empty">Aún no tienes recetas. Crea una para empezar a organizar tus comidas.</p>
                : <ul className="recipe-cards">{recipes.map((recipe) => <li className="today-item recipe-card" key={recipe.id}>
                  <div className="today-event-content"><div className="recipe-card-heading"><div><h3>{recipe.name}</h3><span>{recipe.servings} porciones · {recipe.durationMinutes} min · {new Set(recipe.ingredients.map((line) => line.ingredientId)).size} ingredientes</span></div><div className="pantry-item-actions"><button className="pantry-save-button" type="button" disabled={saving} onClick={() => startEdit(recipe)}>Editar</button><button className="pantry-remove-button" type="button" disabled={saving} onClick={() => void deleteRecipe(recipe)}>Eliminar</button></div></div>
                  <details className="day-subtasks recipe-subtasks"><summary>Pasos · {recipeSteps(recipe.steps, recipe.instructions, recipe.ingredients).length}</summary>
                  <ol className="recipe-card-steps">{recipeSteps(recipe.steps, recipe.instructions, recipe.ingredients).map((step) => <li key={step.id}>
                    <span>{step.text}{step.isOptional && <small className="optional-badge">Opcional</small>}</span>
                    {step.priorTiming && <small className="recipe-prior-badge">{priorTimingLabel(step.priorTiming)}</small>}
                    {step.ingredient && <small>{recipe.ingredients.find((line) => line.ingredientId === step.ingredient!.ingredientId)?.ingredient.name} · {step.ingredient.quantityPerServing} {unitLabels[recipe.ingredients.find((line) => line.ingredientId === step.ingredient!.ingredientId)?.ingredient.unit ?? "g"]} por porción{step.ingredient.equivalent ? ` (${step.ingredient.equivalent})` : ""}</small>}
                  </li>)}</ol>
                  <details className="recipe-ingredient-summary"><summary>Ingredientes por porción</summary><ul className="recipe-card-ingredients">{recipe.ingredients.map((item) => <li key={item.id}><span>{item.ingredient.name}{item.isOptional && <small className="optional-badge">Opcional</small>}</span><span>{item.quantityPerServing} {unitLabels[item.ingredient.unit]}{item.equivalent ? ` (${item.equivalent})` : ""}</span></li>)}</ul></details>
                  <p className="form-hint">Esta es la receta guardada. Cada comida planificada tiene sus propias casillas.</p>
                  </details></div>
                </li>)}</ul>}
          </section>
        </div>
      </section>
    </main>
  );
}

