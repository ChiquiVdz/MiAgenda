import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { PantryView } from "@/app/cocina/pantry-view";
import { CorePantryView } from "./core-pantry-view";
import { coreModeEnabled } from "@/lib/core-mode";
import { coreRuntime } from "@/lib/core-runtime";

export default async function CocinaPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/login");

  if (coreModeEnabled()) return <CorePantryView initial={await coreRuntime().pantry.snapshot(session.user.id)} />;

  return <PantryView />;
}
