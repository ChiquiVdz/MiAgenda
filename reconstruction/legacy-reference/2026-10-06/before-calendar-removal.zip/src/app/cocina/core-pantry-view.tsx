"use client";
import Link from "next/link";
import { useContext, useEffect, useState } from "react";
import { signOut } from "next-auth/react";
import { IngredientRetirementDialog, RemovedIngredients } from "./ingredient-retirement-dialog";
import type { IngredientView, PantryItemView, PantrySnapshot } from "../../../reconstruction/core/src/pantry";
import { normalizedIngredientName, quantityInput, similarIngredientName, type IngredientUnit } from "../../../reconstruction/core/src/ingredient-input";
import { usePantryFeed, type PantryMutate } from "../core/use-pantry-feed";
import { CoreDialog, CoreFeedback } from "../core/schedule-editor";

const units: Record<IngredientUnit, string> = { g: "g", ml: "ml", piece: "piezas" };
function parsedQuantity(value: string) { try { return quantityInput(value); } catch { return null; } }
export function CorePantryView({ initial }: { initial: PantrySnapshot }) {
  const feed = usePantryFeed(initial);
  const [search, setSearch] = useState(""), [selectedId, setSelectedId] = useState<string | null>(null), [quantity, setQuantity] = useState("");
  const [retiring, setRetiring] = useState<IngredientView | null>(null);
  const [editor, setEditor] = useState<{ item?: IngredientView } | null>(null), [history, setHistory] = useState<IngredientView | null>(null);
  const [selectionBase, setSelectionBase] = useState<{ balanceRevision: number | null; ingredientRevision: number } | null>(null);
  const selected = feed.data.ingredients.find(item => item.id === selectedId);
  useEffect(() => { if (selected && !selectionBase) setSelectionBase({ balanceRevision: selected.balanceRevision, ingredientRevision: selected.revision }); }, [selected, selectionBase]);
  const selectionStale = !!selected && !!selectionBase && (selected.balanceRevision !== selectionBase.balanceRevision || selected.revision !== selectionBase.ingredientRevision);
  const matches = feed.data.ingredients.filter(item => !item.hidden && normalizedIngredientName(item.name).includes(normalizedIngredientName(search))).sort((a, b) => a.name.localeCompare(b.name, "es"));
  const hidden = feed.data.ingredients.filter(item => item.hidden).sort((a, b) => a.name.localeCompare(b.name, "es"));
  const stock = [...feed.data.items].sort((a, b) => a.ingredient.name.localeCompare(b.ingredient.name, "es"));
  const available = stock.filter(item => Number(item.quantity) > 0);
  const empty = stock.filter(item => Number(item.quantity) === 0);
  function stockRows(items: PantryItemView[]) { return items.map(item => <StockRow key={item.ingredient.id} item={item} disabled={feed.locked} mutate={feed.mutate} edit={() => setEditor({ item: item.ingredient })} history={() => setHistory(item.ingredient)} />); }
  function choose(item: IngredientView) { setSelectedId(item.id); setQuantity(item.listed ? item.quantity : ""); setSelectionBase({ balanceRevision: item.balanceRevision, ingredientRevision: item.revision }); }
  return <CoreFeedback.Provider value={{ error: feed.error, retry: feed.retry, busy: feed.busy, reattempt: feed.reattempt }}><main className="app-shell"><aside className="sidebar">
    <Link prefetch={false} className="brand" href="/inbox"><span className="brand-mark">m</span><span>miagenda</span></Link>
    <nav className="primary-nav" aria-label="Navegación principal"><Link prefetch={false} className="nav-item" href="/inbox">▱ Inbox</Link><Link prefetch={false} className="nav-item" href="/agenda">▦ Agenda</Link><Link prefetch={false} className="nav-item nav-item-active" href="/cocina" aria-current="page">♨ Alacena</Link><Link prefetch={false} className="nav-item" href="/cocina/recetas">▤ Recetario</Link><Link prefetch={false} className="nav-item" href="/cocina/planificar">▦ Planificar</Link><Link prefetch={false} className="nav-item" href="/cocina/compras">▱ Compras</Link></nav>
    <div className="sidebar-bottom"><div className="privacy-line"><span className="privacy-dot" />Tu alacena es privada</div></div>
  </aside><section className="workspace"><header className="topbar"><div className="breadcrumb">Mi espacio / <strong>Alacena</strong></div><button className="core-text-button" disabled={feed.locked} onClick={() => void signOut({ callbackUrl: "/login" })}>Cerrar sesión</button></header>
    <div className="page-content"><div className="page-heading-row"><div><p className="eyebrow">COCINA</p><h1>Alacena</h1><p className="week-range">Elige un ingrediente y registra cuánto tienes.</p></div><button className="core-text-button" disabled={feed.busy || feed.reading || feed.retry} onClick={() => void feed.load()}>{feed.reading ? "Actualizando…" : "Actualizar"}</button></div>
    {feed.error && <p className="pantry-message pantry-error" role="alert">{feed.error} {feed.retry && <button className="core-text-button" disabled={feed.busy} onClick={feed.reattempt}>Reintentar cambio</button>}</p>}
    {feed.notice && <p className="pantry-message" role="status">{feed.notice}</p>}
    <div className="pantry-layout"><section className="pantry-panel"><div className="pantry-section-heading"><h2>Ingredientes</h2><button className="core-text-button" disabled={feed.locked} onClick={() => setEditor({})}>＋ Personalizado</button></div>
      <label className="form-field">Buscar ingrediente<input type="search" placeholder="Arroz, huevo, leche…" value={search} onChange={event => setSearch(event.target.value)} /></label>
      <div className="core-ingredient-options">{matches.map(item => <div className="core-ingredient-option" key={item.id}><button className={`core-ingredient-pick${selectedId === item.id ? " core-ingredient-selected" : ""}`} disabled={feed.locked} onClick={() => choose(item)}><strong>{item.name}</strong><small>{units[item.unit]}{item.scope === "private" ? " · Personalizado" : ""}{item.listed ? " · En alacena" : ""}</small></button>{item.scope === "private" && <button className="core-text-button" disabled={feed.locked} aria-label={`Editar ingrediente ${item.name}`} onClick={() => setEditor({ item })}>Editar</button>}<button className="core-text-button" disabled={feed.locked} aria-label={`Eliminar ingrediente ${item.name}`} title="Eliminar o reemplazar este ingrediente solo para ti" onClick={() => setRetiring(item)}>×</button></div>)}</div>
      {!matches.length && <p className="today-empty">No hay coincidencias entre los ingredientes cargados. Puedes crear uno personalizado.</p>}
      {feed.data.nextCatalogId && <button className="core-text-button" disabled={feed.locked || feed.reading} onClick={() => void feed.load("catalog", feed.data.nextCatalogId!)}>Cargar más ingredientes</button>}
      {selected && !selected.listed && <form className="core-stock-add" onSubmit={event => { event.preventDefault(); if (!selectionBase || selectionStale) return; void feed.mutate({ action: "setPantryQuantity", id: selected.id, expectedBalanceRevision: selectionBase.balanceRevision, expectedIngredientRevision: selectionBase.ingredientRevision, quantity: quantityInput(quantity), listed: true }, () => { setSelectedId(null); setSelectionBase(null); setQuantity(""); }); }}><h3>{selected.name}</h3><label className="form-field">Cantidad que tienes ({units[selected.unit]})<input inputMode="decimal" required value={quantity} disabled={feed.locked} placeholder="0" onChange={event => setQuantity(event.target.value)} /></label><button className="pantry-add-button" disabled={feed.locked || parsedQuantity(quantity) === null || selectionStale || !selectionBase}>Agregar a Alacena</button>{selectionStale && <p className="pantry-error">La selección cambió en otra pestaña. <button className="core-text-button" type="button" disabled={feed.locked} onClick={() => choose(selected)}>Actualizar selección</button></p>}</form>}
      {selected?.listed && <p className="core-muted">{selected.name} ya está en Alacena. {Number(selected.quantity) === 0 ? "Abre Sin existencias para actualizar su cantidad." : "Modifica su cantidad en la lista."}</p>}
      {hidden.length > 0 && <details className="inbox-completed"><summary>Sugerencias ocultas ({hidden.length})</summary><ul className="core-hidden-ingredients">{hidden.map(item => <li key={item.id}><span>{item.name}</span><button className="core-text-button" disabled={feed.locked} onClick={() => void feed.mutate({ action: "setIngredientHidden", id: item.id, expectedPreferenceRevision: item.preferenceRevision, hidden: false })}>Mostrar</button><button className="core-text-button" disabled={feed.locked} onClick={() => setRetiring(item)}>Eliminar</button></li>)}</ul></details>}
      <RemovedIngredients dataRevision={feed.data.dataRevision} disabled={feed.locked} mutate={feed.mutate} />
    </section><section className="pantry-panel"><h2>Lo que tienes</h2>{available.length ? <ul className="pantry-items-list">{stockRows(available)}</ul> : <p className="today-empty">No tienes ingredientes con existencias en esta lista.</p>}
      {empty.length > 0 && <details className="inbox-completed"><summary>Sin existencias ({empty.length})</summary><ul className="pantry-items-list">{stockRows(empty)}</ul></details>}
      {feed.data.nextPantryId && <button className="core-text-button" disabled={feed.locked || feed.reading} onClick={() => void feed.load("pantry", feed.data.nextPantryId!)}>Cargar más de Alacena</button>}
    </section></div></div>
  </section>{editor && <IngredientEditor item={editor.item} catalog={feed.data.ingredients} disabled={feed.locked} mutate={feed.mutate} close={() => { if (!feed.busy) setEditor(null); }} choose={item => { choose(item); setEditor(null); }} created={id => { setSelectedId(id); setSelectionBase(null); setQuantity(""); setEditor(null); }} />}
  {retiring && <IngredientRetirementDialog item={retiring} data={feed.data} disabled={feed.locked} mutate={feed.mutate} refreshCatalog={() => void feed.load()} close={() => { if (!feed.busy) { setRetiring(null); setSelectedId(null); setSelectionBase(null); } }} />}
  {history && <StockHistory ingredient={history} close={() => setHistory(null)} />}
  </main></CoreFeedback.Provider>;
}

function StockRow({ item, disabled, mutate, edit, history }: { item: PantryItemView; disabled: boolean; mutate: PantryMutate; edit: () => void; history: () => void }) {
  const [draft, setDraft] = useState(item.quantity), [editing, setEditing] = useState(false), [base, setBase] = useState({ quantity: item.quantity, revision: item.revision, ingredientRevision: item.ingredient.revision });
  useEffect(() => { if (!editing) { setDraft(item.quantity); setBase({ quantity: item.quantity, revision: item.revision, ingredientRevision: item.ingredient.revision }); } }, [item.quantity, item.revision, item.ingredient.revision, editing]);
  const amount = parsedQuantity(draft), changed = amount !== null && amount !== base.quantity, stale = editing && (base.revision !== item.revision || base.ingredientRevision !== item.ingredient.revision);
  return <li className="core-stock-row"><div className="core-stock-name"><strong>{item.ingredient.name}</strong><small>{units[item.ingredient.unit]}{item.ingredient.scope === "private" ? " · Personalizado" : ""}</small></div>
    <div className="core-stock-controls"><label className="form-field">Cantidad<input aria-label={`Cantidad de ${item.ingredient.name}`} inputMode="decimal" value={draft} disabled={disabled} onChange={event => { setDraft(event.target.value); setEditing(true); }} /></label>
      <button className="core-text-button" disabled={disabled || !changed || stale} onClick={() => void mutate({ action: "setPantryQuantity", id: item.ingredient.id, expectedBalanceRevision: base.revision, expectedIngredientRevision: base.ingredientRevision, quantity: amount!, listed: true }, () => setEditing(false))}>Guardar</button>
      <button className="core-text-button" disabled={disabled} onClick={() => { if (window.confirm(`¿Quitar ${item.ingredient.name} de Alacena? Su cantidad quedará en cero; se conservará el registro del ajuste.`)) void mutate({ action: "setPantryQuantity", id: item.ingredient.id, expectedBalanceRevision: item.revision, expectedIngredientRevision: item.ingredient.revision, quantity: "0", listed: false }); }}>Quitar</button>
      {item.ingredient.scope === "private" && <button className="core-text-button" disabled={disabled} onClick={edit}>Editar ingrediente</button>}<button className="core-text-button" disabled={disabled} onClick={history}>Movimientos</button>
    </div>{stale && <p className="pantry-error">La cantidad o el ingrediente cambió. Ahora hay {item.quantity} {units[item.ingredient.unit]}. <button className="core-text-button" disabled={disabled} onClick={() => setEditing(false)}>Cargar cantidad actual</button></p>}
  </li>;
}

export function IngredientEditor({ item, catalog, disabled, mutate, close, choose, created, fixedUnit }: { item?: IngredientView; catalog: IngredientView[]; disabled: boolean; mutate: PantryMutate; close: () => void; choose: (item: IngredientView) => void; created: (id: string) => void; fixedUnit?: IngredientUnit }) {
  const feedback = useContext(CoreFeedback);
  const [name, setName] = useState(item?.name ?? ""), [unit, setUnit] = useState<IngredientUnit>(item?.unit ?? fixedUnit ?? "g"), [confirm, setConfirm] = useState(false);
  const normalized = normalizedIngredientName(name), exact = catalog.find(candidate => candidate.id !== item?.id && candidate.normalizedName === normalized), similar = catalog.filter(candidate => candidate.id !== item?.id && similarIngredientName(candidate.normalizedName, normalized)).slice(0, 5);
  return <CoreDialog title={item ? "Editar ingrediente personalizado" : "Nuevo ingrediente personalizado"} close={close}><form className="core-edit-form" onSubmit={event => {
    event.preventDefault(); const id = item?.id ?? crypto.randomUUID();
    void mutate(item ? { action: "editIngredient", id, expectedRevision: item.revision, name, unit, confirmSimilar: confirm } : { action: "createIngredient", id, name, unit, confirmSimilar: confirm }, () => item ? close() : created(id));
  }}><label className="form-field">Nombre<input required maxLength={120} value={name} disabled={disabled} onChange={event => { setName(event.target.value); setConfirm(false); }} /></label>
    <label className="form-field">Unidad<select value={unit} disabled={disabled || item?.unitLocked || !!fixedUnit} onChange={event => setUnit(event.target.value as IngredientUnit)}><option value="g">Gramos (g)</option><option value="ml">Mililitros (ml)</option><option value="piece">Piezas</option></select></label>
    {fixedUnit && <p className="core-muted">El sustituto usa la misma unidad para conservar las cantidades.</p>}
    {item?.unitLocked && <p className="core-muted">La unidad queda fija porque este ingrediente ya se usa en recetas, compras, existencias o movimientos.</p>}
    {similar.length > 0 && <section><p>{exact ? "Este ingrediente ya existe. Usa el existente para evitar duplicados." : "Hay nombres parecidos. Revisa si alguno corresponde al mismo ingrediente."}</p>{similar.map(candidate => <button key={candidate.id} className="core-text-button" type="button" disabled={disabled} onClick={() => choose(candidate)}>Usar {candidate.name}</button>)}
      {!exact && <label className="core-check"><input type="checkbox" checked={confirm} disabled={disabled} onChange={event => setConfirm(event.target.checked)} />Es un ingrediente distinto; crear o guardar por separado</label>}</section>}
    <button className="pantry-add-button" disabled={disabled || !name.trim() || !!exact || (similar.length > 0 && !confirm) || (!!item && name.trim() === item.name && unit === item.unit)}>{item ? "Guardar ingrediente" : "Crear ingrediente"}</button>
  </form>{feedback.error && <p className="pantry-error" role="alert">{feedback.error}</p>}{feedback.retry && <button className="core-text-button" disabled={feedback.busy} onClick={feedback.reattempt}>Reintentar cambio</button>}</CoreDialog>;
}

function StockHistory({ ingredient, close }: { ingredient: IngredientView; close: () => void }) {
  const [items, setItems] = useState<{ id: string; delta: string; at: string }[]>([]), [error, setError] = useState<string | null>(null), [reading, setReading] = useState(true);
  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/core?${new URLSearchParams({ view: "stockHistory", id: ingredient.id })}`, { cache: "no-store", signal: controller.signal }).then(async response => { const result = await response.json(); if (!response.ok) throw new Error(result.message ?? "No pudimos cargar los movimientos."); if (!controller.signal.aborted) setItems(result.items); })
      .catch(cause => { if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "No pudimos cargar los movimientos."); }).finally(() => { if (!controller.signal.aborted) setReading(false); });
    return () => controller.abort();
  }, [ingredient.id]);
  return <CoreDialog title={`Movimientos de ${ingredient.name}`} close={close}><p>Últimos 20 ajustes de tu inventario.</p>{reading && <p>Cargando…</p>}{error && <p className="pantry-error" role="alert">{error}</p>}<ul className="core-stock-history">{items.map(item => <li key={item.id}><strong>{Number(item.delta) > 0 ? "+" : ""}{item.delta} {units[ingredient.unit]}</strong><time dateTime={item.at}>{new Date(item.at).toLocaleString("es-MX")}</time></li>)}</ul>{!reading && !error && !items.length && <p>Todavía no hay movimientos. Registrar cero no crea un ajuste de cantidad.</p>}</CoreDialog>;
}
