"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { CalendarManagerDialog } from "@/app/components/calendar-manager-dialog";
import { CalendarMealForm } from "@/app/components/calendar-meal-form";
import { WeekCopyDialog } from "@/app/components/week-copy-dialog";
import { WeekDeleteDialog } from "@/app/components/week-delete-dialog";
import { ExpandableMealPreparationSteps } from "@/app/components/meal-preparation-steps";

import { OptionalIngredientsDialog, type OptionalChoice } from "@/app/components/optional-ingredients-dialog";

const TIME_ZONE = "America/Mexico_City";
type Unit = "g" | "kg" | "ml" | "l" | "piece";
type Calendar = { id: string; summary: string; primary: boolean; selected: boolean; canWrite: boolean; isMeals: boolean };
type MealSlot = { id: string; name: string; defaultTime: string; position: number };
type PlannedMeal = {
  overlayId: string; recipeName: string; recipeDetails?: string;
  pendingSourceServings: number;
  cookingEnabled: boolean; cookedServings: number; missingCookServings: number;
  missingIngredients: Array<{ name: string; unit: Unit; missingQuantity: number }>;
  id: string;
  recipeId: string | null;
  mealSlotId: string | null;
  servings: number;
  durationMinutes: number;
  completedAt: string | null;
  googleEventId: string;
  calendarId: string;
  calendarName: string;
  etag: string | null;
  summary: string;
  startDate: string | null;
  startDateTime: string | null;
  endDate: string | null;
  endDateTime: string | null;
};

const unitLabels: Record<Unit, string> = { g: "g", kg: "kg", ml: "ml", l: "l", piece: "piezas" };

function mealWarning(plan: PlannedMeal) {
  return [plan.missingCookServings > 0 ? `Falta cocinar ${plan.missingCookServings} porción(es)` : "",
    ...plan.missingIngredients.map((line) => `${line.name}: faltan ${line.missingQuantity} ${unitLabels[line.unit]}`)]
    .filter(Boolean).join(" · ");
}

function dateKeyInMexico(date: Date) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-US", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date).map((part) => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function addDaysToKey(value: string, amount: number) {
  const date = new Date(`${value}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + amount);
  return date.toISOString().slice(0, 10);
}

function weekStart(value: string) {
  const date = new Date(`${value}T12:00:00Z`);
  const day = date.getUTCDay();
  return addDaysToKey(value, day === 0 ? -6 : 1 - day);
}

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("es-MX", { timeZone: TIME_ZONE, weekday: "short", day: "numeric" })
    .format(new Date(`${value}T12:00:00Z`));
}

function dateRangeLabel(start: string, count: number) {
  const end = addDaysToKey(start, count - 1);
  const format = (key: string, options: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat("es-MX", { ...options, timeZone: TIME_ZONE })
    .format(new Date(`${key}T12:00:00Z`));
  return `${format(start, { day: "numeric", month: "short" })} – ${format(end, { day: "numeric", month: "short", year: "numeric" })}`;
}

function timeLabel(value: string | null) {
  return value ? new Intl.DateTimeFormat("es-MX", { timeZone: TIME_ZONE, hour: "numeric", minute: "2-digit" }).format(new Date(value)) : "";
}

function dateTimeInput(value: string | null) {
  if (!value) return "";
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(value)).map((part) => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
}

function weekDates(start: string) {
  return Array.from({ length: 7 }, (_, index) => addDaysToKey(start, index));
}

async function readJson(response: Response) {
  return response.json().catch(() => null);
}

export function PlannerView() {
  const [optionalSelection, setOptionalSelection] = useState<{ plan: PlannedMeal; ingredients: OptionalChoice[] } | null>(null);
  const [slots, setSlots] = useState<MealSlot[]>([]);
  const [calendars, setCalendars] = useState<Calendar[]>([]);
  const [weekStartKey, setWeekStartKey] = useState(() => weekStart(dateKeyInMexico(new Date())));
  const [weeksToShow, setWeeksToShow] = useState<1 | 2>(1);
  const [leftovers, setLeftovers] = useState<Array<{ id: string; recipeId: string; name: string; servings: number; reservedServings: number }>>([]);
  const [plans, setPlans] = useState<PlannedMeal[]>([]);
  const [pageLoading, setPageLoading] = useState(true);
  const [plansLoading, setPlansLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [editingSlot, setEditingSlot] = useState<MealSlot | null>(null);
  const [slotDraft, setSlotDraft] = useState({ name: "", defaultTime: "12:00" });
  const [addingSlot, setAddingSlot] = useState(false);
  const [addSlotDraft, setAddSlotDraft] = useState({ name: "", defaultTime: "12:00" });
  const [editor, setEditor] = useState<{ overlayId?: string; slotId?: string } | null>(null);
  const [copyWeeks, setCopyWeeks] = useState<{ source: string; target: string } | null>(null);
  const [deleteWeek, setDeleteWeek] = useState<string | null>(null);
  const [pendingCopies, setPendingCopies] = useState<string[]>([]);
  const [schedule, setSchedule] = useState({ calendarId: "", startDate: "", startTime: "12:00" });
  const [calendarManager, setCalendarManager] = useState(false);
  const [baseReload, setBaseReload] = useState(0);
  const [calendarId, setCalendarId] = useState("");
  const editorDialog = useRef<HTMLDialogElement>(null);
  useEffect(() => { if (editor) editorDialog.current?.showModal(); }, [editor]);
  const [plansReload, setPlansReload] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    void fetch("/api/meals/copy-week", { cache: "no-store", signal: controller.signal }).then(async (response) => {
      const result = await response.json();
      if (response.ok) setPendingCopies((result.pending as Array<{ targetWeek: string }>).map((job) => job.targetWeek));
    }).catch(() => undefined);
    return () => controller.abort();
  }, [plansReload]);
  useEffect(() => {
    let cancelled = false;
    async function loadBaseData() {
      setPageLoading(true);
      try {
        const [slotsResponse, calendarsResponse] = await Promise.all([
          fetch("/api/meal-slots", { cache: "no-store" }),
          fetch("/api/calendars", { cache: "no-store" }),
        ]);
        const [slotsResult, calendarsResult] = await Promise.all([
          readJson(slotsResponse), readJson(calendarsResponse),
        ]);
        if (!slotsResponse.ok || !Array.isArray(slotsResult?.mealSlots)) throw new Error(slotsResult?.error ?? "No pudimos cargar tus comidas habituales.");
        if (!calendarsResponse.ok || !Array.isArray(calendarsResult?.calendars)) throw new Error(calendarsResult?.error ?? "No pudimos cargar tus calendarios.");
        if (cancelled) return;
        const availableCalendars = (calendarsResult.calendars as Calendar[]).filter((item) => item.canWrite);
        setSlots(slotsResult.mealSlots as MealSlot[]);
        setCalendars(availableCalendars);
        setCalendarId(availableCalendars.find((item) => item.isMeals)?.id ?? "");
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "No pudimos preparar el planificador.");
      } finally {
        if (!cancelled) setPageLoading(false);
      }
    }
    void loadBaseData();
    return () => { cancelled = true; };
  }, [baseReload]);

  useEffect(() => {
    let cancelled = false;
    async function loadPlans() {
      setPlansLoading(true);
      const rangeEnd = addDaysToKey(weekStartKey, weeksToShow * 7);
      const from = `${weekStartKey}T00:00:00-06:00`;
      const to = `${rangeEnd}T00:00:00-06:00`;
      try {
        const response = await fetch(`/api/meals?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`, { cache: "no-store" });
        const result = await readJson(response);
        if (!response.ok || !Array.isArray(result?.plans)) throw new Error(result?.error ?? "No pudimos cargar las comidas planeadas.");
        if (!cancelled) { setPlans(result.plans as PlannedMeal[]); setLeftovers(result.leftovers ?? []); }
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "No pudimos cargar las comidas planeadas.");
      } finally {
        if (!cancelled) setPlansLoading(false);
      }
    }
    void loadPlans();
    return () => { cancelled = true; };
  }, [weekStartKey, weeksToShow, plansReload]);

  useEffect(() => {
    let refreshTimer: number | undefined;
    const refreshPlansWhenVisible = () => {
      if (document.visibilityState !== "visible") return;
      window.clearTimeout(refreshTimer);
      refreshTimer = window.setTimeout(() => setPlansReload((current) => current + 1), 150);
    };
    window.addEventListener("focus", refreshPlansWhenVisible);
    document.addEventListener("visibilitychange", refreshPlansWhenVisible);
    return () => {
      window.clearTimeout(refreshTimer);
      window.removeEventListener("focus", refreshPlansWhenVisible);
      document.removeEventListener("visibilitychange", refreshPlansWhenVisible);
    };
  }, []);

  function openCell(slot: MealSlot, date: string) {
    if (!calendarId) { setCalendarManager(true); return; }
    if (pageLoading || plansLoading || saving) return;
    setError(null); setNotice(null);
    setSchedule({ calendarId, startDate: date, startTime: slot.defaultTime });
    setEditor({ slotId: slot.id });
  }
  function openPlanEditor(plan: PlannedMeal) {
    if (plan.completedAt) { setError("Deshaz el completado desde el círculo del bloque antes de editarlo."); return; }
    const input = dateTimeInput(plan.startDateTime);
    setSchedule({ calendarId: plan.calendarId, startDate: input.slice(0, 10), startTime: input.slice(11, 16) });
    setEditor({ overlayId: plan.overlayId }); setError(null); setNotice(null);
  }

  function changeWeeks(value: string) {
    const weeks = value === "2" ? 2 : 1;
    setWeeksToShow(weeks);
  }

  function shiftWeeks(amount: number) {
    setWeekStartKey((current) => addDaysToKey(current, amount * weeksToShow * 7));
  }

  function editSlot(slot: MealSlot) {
    setEditingSlot(slot);
    setSlotDraft({ name: slot.name, defaultTime: slot.defaultTime });
    setError(null);
    setNotice(null);
  }

  async function saveSlot(event: FormEvent<HTMLFormElement>, slotId?: string) {
    event.preventDefault();
    const draft = slotId ? slotDraft : addSlotDraft;
    const editing = Boolean(slotId);
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(editing ? `/api/meal-slots/${encodeURIComponent(slotId!)}` : "/api/meal-slots", {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(draft),
      });
      const result = await readJson(response);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos guardar esta fila.");
      if (editing) {
        setSlots((current) => current.map((slot) => slot.id === slotId ? result.mealSlot as MealSlot : slot));
        setEditingSlot(null);
        setNotice("La comida habitual se actualizó. Los eventos ya planeados conservan su horario.");
      } else {
        setSlots((current) => [...current, result.mealSlot as MealSlot].sort((a, b) => a.position - b.position));
        setAddingSlot(false);
        setAddSlotDraft({ name: "", defaultTime: "12:00" });
        setNotice("Se agregó una fila a tu planificador.");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos guardar esta fila.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteSlot(slot: MealSlot) {
    if (!window.confirm(`¿Eliminar la fila “${slot.name}”? Las comidas que ya programaste seguirán en Google Calendar.`)) return;
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(`/api/meal-slots/${encodeURIComponent(slot.id)}`, { method: "DELETE" });
      const result = response.status === 204 ? null : await readJson(response);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos eliminar esta fila.");
      setSlots((current) => current.filter((item) => item.id !== slot.id));
      setPlansReload((current) => current + 1);
      setNotice(`Se eliminó la fila “${slot.name}”. Las comidas ya planeadas no se borraron.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos eliminar esta fila.");
    } finally {
      setSaving(false);
    }
  }

  async function deletePlan(plan: PlannedMeal) {
    if (plan.completedAt) { setError("Deshaz el completado desde el círculo antes de eliminar esta comida."); return; }
    if (!window.confirm(`¿Eliminar “${plan.summary}” del menú y de Google Calendar?`)) return;
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(plan.googleEventId)}`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ calendarId: plan.calendarId, etag: plan.etag }) });
      const result = response.status === 204 ? null : await readJson(response);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos eliminar la comida.");
      setNotice(`“${plan.summary}” se eliminó del menú y de Google Calendar.`);
      setPlansLoading(true);
      setPlansReload((current) => current + 1);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos eliminar la comida.");
    } finally { setSaving(false); }
  }

  async function togglePlanCompletion(plan: PlannedMeal, optionalIngredientIds?: string[]) {
    const action = plan.completedAt ? "uncomplete" : "complete";
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(plan.googleEventId)}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ calendarId: plan.calendarId, optionalIngredientIds }),
      });
      const result = await readJson(response);
      if (result?.requiresOptionalSelection) { setOptionalSelection({ plan, ingredients: result.optionalIngredients }); return; }
      if (!response.ok) throw new Error(result?.error ?? `No pudimos ${action === "complete" ? "completar" : "deshacer"} esta comida.`);
      setOptionalSelection(null);
      setNotice(action === "complete" ? `“${plan.summary}” se marcó como completada.` : `“${plan.summary}” volvió a estar pendiente.`);
      setPlansLoading(true);
      setPlansReload((current) => current + 1);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos actualizar esta comida.");
    } finally { setSaving(false); }
  }

  const blocks = useMemo(() => {
    const groups = new Map<string, PlannedMeal[]>();
    for (const plan of plans) groups.set(plan.overlayId, [...(groups.get(plan.overlayId) ?? []), plan]);
    return [...groups.values()].map((group) => ({ ...group[0],
      recipeDetails: group.map((plan) => `${plan.recipeName} · ${plan.servings} a comer · ${plan.cookingEnabled ? plan.cookedServings + " a cocinar" : "sin cocinar"}`).join(" / "),
      missingIngredients: group.flatMap((plan) => plan.missingIngredients),
      missingCookServings: group.reduce((sum, plan) => sum + plan.missingCookServings, 0),
      pendingSourceServings: group.reduce((sum, plan) => sum + plan.pendingSourceServings, 0),
    }));
  }, [plans]);
  const plansByCell = useMemo(() => {
    const grouped = new Map<string, PlannedMeal[]>();
    for (const plan of blocks) {
      const date = plan.startDate ?? (plan.startDateTime ? dateKeyInMexico(new Date(plan.startDateTime)) : null);
      if (!date || !plan.mealSlotId) continue;
      const key = `${plan.mealSlotId}\u0000${date}`;
      grouped.set(key, [...(grouped.get(key) ?? []), plan]);
    }
    return grouped;
  }, [blocks]);
  const unassignedPlans = blocks.filter((plan) => !plan.mealSlotId);

  return (
    <main className="app-shell">
      {optionalSelection && <OptionalIngredientsDialog ingredients={optionalSelection.ingredients} busy={saving} error={error} onCancel={() => setOptionalSelection(null)} onConfirm={(ids) => void togglePlanCompletion(optionalSelection.plan, ids)} />}
      <aside className="sidebar">
        <a className="brand" href="/" aria-label="MiAgenda, inicio"><span className="brand-mark">m</span><span>miagenda</span></a>
        <nav className="primary-nav" aria-label="Navegación principal">
          <a className="nav-item" href="/inbox"><span className="nav-icon" aria-hidden="true">▱</span>Inbox</a>
          
          <a className="nav-item" href="/"><span className="nav-icon" aria-hidden="true">▦</span>Agenda</a>
          <a className="nav-item" href="/cocina"><span className="nav-icon" aria-hidden="true">♨</span>Alacena</a>
          <a className="nav-item" href="/cocina/recetas"><span className="nav-icon" aria-hidden="true">▤</span>Recetas</a>
          <a className="nav-item nav-item-active" href="/cocina/planificar" aria-current="page"><span className="nav-icon" aria-hidden="true">◷</span>Planificar</a>
          <a className="nav-item" href="/cocina/compras"><span className="nav-icon" aria-hidden="true">☷</span>Compras</a>
        </nav>
        <div className="sidebar-bottom">
          <div className="privacy-line"><span className="privacy-dot" />Tus datos, bajo tu control</div>
          <div className="profile-row"><div className="avatar">E</div><div className="profile-copy"><strong>Tu espacio</strong><span>Cuenta personal</span></div></div>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar"><div className="breadcrumb"><span>Mi espacio</span><span className="breadcrumb-slash">/</span><strong>Cocina</strong><span className="breadcrumb-slash">/</span><strong>Planificar</strong></div></header>
        <div className="page-content pantry-content meal-planner-content">
          <div className="page-heading-row pantry-heading meal-planner-heading">
            <div><p className="eyebrow">MENÚ Y HORARIOS</p><h1>Planificar comidas</h1><p className="week-range">Organiza varias recetas en un bloque y elige cuánto tiempo dedicar a cocinar, comer y lavar.</p></div>
            <div className="meal-planner-toolbar">
              <button type="button" onClick={() => setCalendarManager(true)}>Calendario de Cocina</button>
              <label className="meal-weeks-select">Mostrar<select aria-label="Semanas visibles" value={weeksToShow} onChange={(event) => changeWeeks(event.target.value)}><option value="1">1 semana</option><option value="2">2 semanas</option></select></label>
              <div className="week-arrows"><button type="button" aria-label="Semanas anteriores" onClick={() => shiftWeeks(-1)}>‹</button><button type="button" aria-label="Semanas siguientes" onClick={() => shiftWeeks(1)}>›</button></div>
              <button className="today-button" type="button" onClick={() => setWeekStartKey(weekStart(dateKeyInMexico(new Date())))}>Hoy</button>
            </div>
          </div>

          {error && !editor && <p className="pantry-message pantry-error" role="alert">{error}</p>}
          {notice && !editor && <p className="pantry-message" role="status">{notice} <a href="/">Ver agenda</a></p>}

          {leftovers.length > 0 && <section className="meal-unassigned" aria-label="Porciones preparadas"><h2>Porciones preparadas</h2><ul>{leftovers.map((batch) => <li key={batch.id}><strong>{batch.name}</strong><span>{batch.servings} preparadas · {batch.reservedServings} reservadas · {batch.servings - batch.reservedServings} libres</span></li>)}</ul></section>}

          <div className="meal-planner-actions">
            <span>{dateRangeLabel(weekStartKey, weeksToShow * 7)}</span>
            <button className="pantry-add-button" type="button" disabled={addingSlot} onClick={() => { setAddingSlot(true); setError(null); setNotice(null); setAddSlotDraft({ name: "", defaultTime: "12:00" }); }}>＋ Agregar comida</button>
          </div>

          {addingSlot && <form className="meal-slot-create" onSubmit={(event) => void saveSlot(event)}>
            <label className="form-field">Nombre<input autoFocus type="text" maxLength={60} value={addSlotDraft.name} onChange={(event) => setAddSlotDraft((current) => ({ ...current, name: event.target.value }))} placeholder="Ej. Colación" required /></label>
            <label className="form-field">Hora habitual<input type="time" value={addSlotDraft.defaultTime} onChange={(event) => setAddSlotDraft((current) => ({ ...current, defaultTime: event.target.value }))} required /></label>
            <div className="meal-slot-edit-actions"><button type="button" className="dialog-cancel" disabled={saving} onClick={() => setAddingSlot(false)}>Cancelar</button><button type="submit" className="dialog-submit" disabled={saving}>{saving ? "Guardando…" : "Agregar fila"}</button></div>
          </form>}

          {calendarManager && <CalendarManagerDialog cooking calendars={calendars} onClose={() => setCalendarManager(false)} onSaved={() => { setCalendarManager(false); setBaseReload((n) => n + 1); setPlansReload((n) => n + 1); }} />}
          {!pageLoading && !calendarId && <p className="form-hint">Configura el calendario de Cocina para agregar comidas.</p>}
          {pageLoading ? <p className="pantry-empty">Cargando tu menú…</p> : <div className="meal-weeks">
            {Array.from({ length: weeksToShow }, (_, weekIndex) => {
              const currentStart = addDaysToKey(weekStartKey, weekIndex * 7);
              const days = weekDates(currentStart);
              const emptyWeek = !blocks.some((plan) => {
                const date = plan.startDate ?? (plan.startDateTime ? dateKeyInMexico(new Date(plan.startDateTime)) : null);
                return date && date >= currentStart && date < addDaysToKey(currentStart, 7);
              });
              return <section className="meal-week-card" key={currentStart} aria-label={`Semana ${dateRangeLabel(currentStart, 7)}`}>
                <div className="meal-week-heading"><h2>{dateRangeLabel(currentStart, 7)}</h2>{plansLoading ? <span>Sincronizando…</span> : <div className="meal-week-controls">
                  {(emptyWeek || pendingCopies.includes(currentStart)) && <button className="dialog-cancel" type="button" disabled={saving} onClick={() => setCopyWeeks({ source: addDaysToKey(currentStart, -7), target: currentStart })}>{pendingCopies.includes(currentStart) ? "Reanudar copia" : "Copiar semana anterior"}</button>}
                  <button className="week-delete-button" type="button" disabled={saving || emptyWeek || pendingCopies.includes(currentStart)} onClick={() => setDeleteWeek(currentStart)}>Borrar comidas</button>
                </div>}</div>
                <div className="meal-table-scroll"><table className="meal-plan-table">
                  <thead><tr><th className="meal-slot-column" scope="col">Comida</th>{days.map((day) => <th scope="col" key={day}>{dateLabel(day)}</th>)}</tr></thead>
                  <tbody>{slots.map((slot) => <tr key={slot.id}>
                    <th className="meal-slot-column" scope="row">
                      {editingSlot?.id === slot.id ? <form className="meal-slot-edit" onSubmit={(event) => void saveSlot(event, slot.id)}>
                        <label>Nombre<input autoFocus type="text" maxLength={60} value={slotDraft.name} onChange={(event) => setSlotDraft((current) => ({ ...current, name: event.target.value }))} required /></label>
                        <label>Hora<input type="time" value={slotDraft.defaultTime} onChange={(event) => setSlotDraft((current) => ({ ...current, defaultTime: event.target.value }))} required /></label>
                        <div className="meal-slot-edit-actions"><button type="button" disabled={saving} onClick={() => setEditingSlot(null)}>Cancelar</button><button type="submit" disabled={saving}>{saving ? "…" : "Guardar"}</button></div>
                      </form> : <div className="meal-slot-label"><strong>{slot.name}</strong><span>{slot.defaultTime}</span><div className="meal-slot-actions"><button type="button" aria-label={`Editar ${slot.name}`} title="Editar nombre y hora" disabled={saving} onClick={() => editSlot(slot)}>Editar</button><button type="button" aria-label={`Eliminar fila ${slot.name}`} title="Eliminar fila" disabled={saving} onClick={() => void deleteSlot(slot)}>×</button></div></div>}
                    </th>
                    {days.map((day) => {
                      const cellPlans = plansByCell.get(`${slot.id}\u0000${day}`) ?? [];
                      return <td key={day}><div className="meal-plan-cell">
                        {cellPlans.map((plan) => <div className={`meal-plan-chip${plan.completedAt ? " meal-plan-chip-completed" : ""}`} key={plan.id} title={`${plan.summary} · ${plan.servings} porciones`}>
                          {(plan.missingIngredients?.length > 0 || plan.missingCookServings > 0) && <span className="meal-missing-indicator" role="img" aria-label={mealWarning(plan)} title={mealWarning(plan)}>⚠</span>}
                          {plan.missingCookServings > 0 && <span className="meal-suggestion-missing">Falta cocinar {plan.missingCookServings} porción(es){plan.missingIngredients.length === 0 ? ": hay ingredientes disponibles" : ""}.</span>}
                          {plan.pendingSourceServings > 0 && <span className="form-hint">{plan.pendingSourceServings} porciones dependen de una cocinada anterior pendiente.</span>}
                          <strong>{plan.summary}</strong><span>{timeLabel(plan.startDateTime)} · {plan.recipeDetails} · {plan.durationMinutes} min</span><ExpandableMealPreparationSteps event={{ id: plan.googleEventId, calendarId: plan.calendarId, etag: plan.etag }} reloadKey={plansReload} disabled={saving} onBusy={setSaving} onApplied={() => setPlansReload((n) => n + 1)} />
                          <div className="meal-plan-actions"><button className={`meal-completion-toggle${plan.completedAt ? " meal-completion-toggle-checked" : ""}`} type="button" disabled={saving} aria-pressed={Boolean(plan.completedAt)} aria-label={`${plan.completedAt ? "Deshacer completado de" : "Completar"} ${plan.summary}`} title={plan.completedAt ? "Deshacer completado" : "Marcar como completada"} onClick={() => void togglePlanCompletion(plan)}>{plan.completedAt ? "✓" : ""}</button><button type="button" title={plan.completedAt ? "Deshaz el completado desde el círculo antes de editar" : "Editar receta, fecha, hora, porciones y duración"} disabled={saving || Boolean(plan.completedAt)} onClick={() => openPlanEditor(plan)}>Editar / agregar recetas</button><button type="button" disabled={saving || Boolean(plan.completedAt)} aria-label={`Eliminar ${plan.summary}`} title={plan.completedAt ? "Deshaz el completado desde el círculo antes de eliminar" : "Eliminar la comida planeada"} onClick={() => void deletePlan(plan)}>Eliminar</button></div>
                        </div>)}
                        {cellPlans.length === 0 && <button className="meal-cell-add" type="button" disabled={pageLoading || plansLoading || saving} aria-label={`Agregar comida para ${slot.name}, ${dateLabel(day)}`} onClick={() => openCell(slot, day)}><span aria-hidden="true">＋</span>Agregar comida</button>}
                      </div></td>;
                    })}
                  </tr>)}
                  {slots.length === 0 && <tr><td className="meal-no-slots" colSpan={8}>No hay filas. Usa “Agregar comida” para crear una.</td></tr>}
                  </tbody>
                </table></div>
              </section>;
            })}
          </div>}

          {unassignedPlans.length > 0 && <section className="meal-unassigned">
            <h2>Comidas planeadas sin una fila</h2><p>Son planes anteriores a las filas habituales; siguen en Google Calendar.</p>
            <ul>{unassignedPlans.map((plan) => <li key={plan.id}><strong>{plan.summary}</strong><ExpandableMealPreparationSteps event={{ id: plan.googleEventId, calendarId: plan.calendarId, etag: plan.etag }} reloadKey={plansReload} disabled={saving} onBusy={setSaving} onApplied={() => setPlansReload((n) => n + 1)} /><span>{plan.startDateTime ? `${dateLabel(dateKeyInMexico(new Date(plan.startDateTime)))} · ${timeLabel(plan.startDateTime)}` : plan.startDate}</span><div className="meal-plan-actions"><button className={`meal-completion-toggle${plan.completedAt ? " meal-completion-toggle-checked" : ""}`} type="button" disabled={saving} aria-pressed={Boolean(plan.completedAt)} aria-label={`${plan.completedAt ? "Deshacer completado de" : "Completar"} ${plan.summary}`} title={plan.completedAt ? "Deshacer completado" : "Marcar como completada"} onClick={() => void togglePlanCompletion(plan)}>{plan.completedAt ? "✓" : ""}</button><button type="button" disabled={saving || Boolean(plan.completedAt)} onClick={() => openPlanEditor(plan)}>Editar</button><button type="button" disabled={saving || Boolean(plan.completedAt)} onClick={() => void deletePlan(plan)}>Eliminar</button></div></li>)}</ul>
          </section>}
        </div>
      </section>

      {deleteWeek && <WeekDeleteDialog week={deleteWeek}
        onClose={() => { setDeleteWeek(null); setPlansLoading(true); setPlansReload((n) => n + 1); }}
        onDeleted={(count) => { setDeleteWeek(null); setPlansLoading(true); setPlansReload((n) => n + 1); setNotice(`${count} bloques eliminados. Lo consumido sigue descontado y las sobras se conservan. Compras actualizadas.`); }} />}
      {copyWeeks && <WeekCopyDialog initialSource={copyWeeks.source} initialTarget={copyWeeks.target}
        onClose={() => { setCopyWeeks(null); setPlansReload((n) => n + 1); }}
        onCopied={(target, copied, skipped) => { setCopyWeeks(null); setWeekStartKey(target); setPlansLoading(true); setPlansReload((n) => n + 1); setNotice(`${copied} comidas copiadas, todas pendientes.${skipped ? ` Se omitieron ${skipped} comidas.` : ""} Compras y disponibilidad actualizadas.`); }} />}
      {editor && <dialog ref={editorDialog} className="event-dialog meal-suggestion-dialog" aria-labelledby="block-editor-title" onCancel={(event) => { if (saving) event.preventDefault(); else setEditor(null); }}>
        <div className="dialog-heading"><h2 id="block-editor-title">{editor.overlayId ? "Editar bloque de comida" : "Planificar comida"}</h2><button type="button" className="dialog-close" disabled={saving} onClick={() => setEditor(null)} aria-label="Cerrar">×</button></div>
        <CalendarMealForm active schedule={schedule} calendars={calendars} overlayId={editor.overlayId} initialSlotId={editor.slotId}
          onPersisted={() => { setPlansReload((n) => n + 1); }}
          onScheduleChange={(change) => setSchedule((current) => ({ ...current, ...change }))} onBusyChange={setSaving}
          onCancel={() => setEditor(null)} onCreated={() => { setEditor(null); setNotice("Bloque guardado en el planificador y Google Calendar."); setPlansLoading(true); setPlansReload((n) => n + 1); }} />
      </dialog>}
    </main>
  );
}


