import { PlannerView } from "./planner-view";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { coreModeEnabled } from "@/lib/core-mode";
import { coreRuntime } from "@/lib/core-runtime";
import { localParts, shiftDate } from "../../../../reconstruction/core/src/local-time";
import { CorePlannerView } from "./core-planner-view";

export default async function PlanificarPage({ searchParams }: { searchParams: Promise<{ meal?: string }> }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/login");
  if (coreModeEnabled()) {
    const core = coreRuntime(), userId = session.user.id;
    const owner = await core.db.user.findUniqueOrThrow({ where: { id: userId }, select: { timeZone: true } });
    const params = await searchParams;
    const mealId = typeof params.meal === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(params.meal) ? params.meal : undefined;
    const selected = mealId ? await core.db.activitySchedule.findFirst({ where: { activityId: mealId, userId, activity: { is: { kind: "meal", lifecycle: "active" } } }, select: { startsAt: true, timeZone: true } }) : null;
    const day = localParts(selected?.startsAt ?? new Date(), selected?.timeZone ?? owner.timeZone).date;
    const start = shiftDate(day, -((new Date(`${day}T12:00:00Z`).getUTCDay() + 6) % 7));
    const initial = await core.planner.snapshot(userId, start);
    return <CorePlannerView key={`${start}:${mealId ?? "week"}`} initial={initial} initialMealId={mealId} />;
  }
  return <PlannerView />;
}
