import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { ShoppingView } from "./shopping-view";
import { coreModeEnabled } from "@/lib/core-mode";
import { coreRuntime } from "@/lib/core-runtime";
import { CoreShoppingView } from "./core-shopping-view";

export default async function ShoppingPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/login");
  if (coreModeEnabled()) {
    const core = coreRuntime();
    const [initial, pantry] = await Promise.all([core.shopping.snapshot(session.user.id), core.pantry.snapshot(session.user.id)]);
    return <CoreShoppingView initial={initial} pantry={pantry} />;
  }
  return <ShoppingView />;
}
