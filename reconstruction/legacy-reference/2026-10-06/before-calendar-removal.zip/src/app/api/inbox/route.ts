import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { cleanupInbox, transferInbox, InboxError, inboxGoogleStatus } from "@/lib/inbox";
import { GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { validateSteps, ChecklistError, type ActivityStep } from "@/lib/activity-checklist";
import type { Prisma } from "@/generated/prisma/client";
import { syncScheduledChildren } from "@/lib/scheduled-subtask-state";
import { deleteScheduledChildren, reconcileScheduledSubtasks } from "@/lib/scheduled-subtask-lifecycle";
import { recoverUnscheduledTasks } from "@/lib/task-unschedule";
import { TaskActivityError } from "@/lib/task-activity";
export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
const record = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);
const text = (value: unknown, max: number): value is string => typeof value === "string" && value.trim().length > 0 && value.length <= max;
function dateTime(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(value) && Number.isFinite(Date.parse(value))
    && new Date(`${value.slice(0, 10)}T12:00:00Z`).toISOString().slice(0, 10) === value.slice(0, 10);
}
function dateOnly(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(`${value}T12:00:00Z`).toISOString().slice(0, 10) === value;
}
function failure(error: unknown, loading = false) {
  if (error instanceof ChecklistError || error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
  if (error instanceof InboxError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
  if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
  if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409, headers });
  if ([401, 403].includes(inboxGoogleStatus(error))) return NextResponse.json({ error: "Google no permitió el traslado. El pendiente sigue en Inbox; revisa la conexión y reintenta." }, { status: 409, headers });
  console.error("[inbox] Failed", JSON.stringify({
    action: loading ? "load" : "change",
    name: record(error) && typeof error.name === "string" ? error.name.slice(0, 80) : "UnknownError",
    code: record(error) && (typeof error.code === "string" || typeof error.code === "number") ? String(error.code).slice(0, 40) : null,
  }));
  return NextResponse.json({ error: loading ? "No pudimos cargar Inbox. Pulsa Actualizar para reintentar." : "No pudimos guardar el cambio. Actualiza Inbox o reintenta el traslado; no se crearán eventos duplicados." }, { status: 502, headers });
}
export async function GET() {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para ver Inbox." }, { status: 401 });
  try {
    await recoverUnscheduledTasks(userId);
    const items = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await cleanupInbox(tx, userId);
      await reconcileScheduledSubtasks(tx, userId, { parentInboxId: { not: null } });
      const rows = await tx.inboxItem.findMany({ where: { userId, transferredAt: null }, orderBy: [{ createdAt: "desc" }, { id: "desc" }] });
      const links = await tx.scheduledSubtask.groupBy({ by: ["parentInboxId"], where: { userId, active: true, parentInboxId: { in: rows.map((row) => row.id) } }, _count: { _all: true } });
      const counts = new Map(links.map((link) => [link.parentInboxId, link._count._all]));
      const sources = await tx.activityLegacySource.findMany({ where: { userId, source: "inbox_item", sourceId: { in: rows.map((row) => row.id) } }, include: { activity: true } });
      const activities = new Map(sources.map((source) => [source.sourceId, source.activity]));
      return rows.map((row) => ({ ...row, activityId: activities.get(row.id)?.id ?? null,
        text: activities.get(row.id)?.title ?? row.text, completedAt: activities.get(row.id)?.completedAt ?? row.completedAt, scheduledCount: counts.get(row.id) ?? 0 }));
    }, { timeout: 30000 });
    return NextResponse.json({ items }, { headers });
  } catch (error) { return failure(error, true); }
}
export async function POST(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para modificar Inbox." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) return NextResponse.json({ error: "El formato no es válido." }, { status: 415 });
  const body: unknown = await request.json().catch(() => null);
  if (!record(body) || !["add", "edit", "complete", "uncomplete", "delete", "transfer"].includes(String(body.action))) return NextResponse.json({ error: "Revisa la acción solicitada." }, { status: 400 });
  try {
    if (body.action !== "add" && (!text(body.id, 30) || !text(body.version, 40))) throw new InboxError("Actualiza el pendiente antes de continuar.", 400);
    if ((body.action === "add" || body.action === "edit") && !text(body.text, 250)) throw new InboxError("Escribe un pendiente de hasta 250 caracteres.", 400);
    if (body.action === "add" && (!text(body.createKey, 100) || body.createKey.length < 16)) throw new InboxError("Reintenta agregar el pendiente.", 400);
    if (body.action === "transfer") {
      if (!text(body.calendarId, 1024) || body.allDay !== undefined && typeof body.allDay !== "boolean") throw new InboxError("Elige un calendario y programación válidos.", 400);
      if (body.allDay ? !dateOnly(body.startDate) || !dateOnly(body.endDate) || body.endDate <= body.startDate
        : !dateTime(body.startDateTime) || !dateTime(body.endDateTime) || Date.parse(body.endDateTime) <= Date.parse(body.startDateTime)) throw new InboxError("Elige una fecha final posterior al inicio.", 400);
      const event = await transferInbox(userId, body.id as string, body.version as string, body.allDay
        ? { calendarId: body.calendarId, allDay: true, startDate: body.startDate as string, endDate: body.endDate as string }
        : { calendarId: body.calendarId, startDateTime: body.startDateTime as string, endDateTime: body.endDateTime as string });
      return NextResponse.json({ transferred: true, event }, { headers });
    }
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await cleanupInbox(tx, userId);
      if (body.action === "add") {
        const existing = await tx.inboxItem.findUnique({ where: { userId_createKey: { userId, createKey: body.createKey as string } } });
        if (existing) {
          if (existing.text !== (body.text as string).trim()) throw new InboxError("Ese intento ya se guardó. Actualiza Inbox antes de agregar otro pendiente.");
          return { item: existing };
        }
        return { item: await tx.inboxItem.create({ data: { userId, text: (body.text as string).trim(), createKey: body.createKey as string } }) };
      }
      const item = await tx.inboxItem.findFirst({ where: { userId, id: body.id as string, transferredAt: null } });
      if (!item) throw new InboxError("El pendiente ya no está en Inbox. Actualiza la lista.", 404);
      if (item.transferPayload) throw new InboxError("Reanuda el traslado a agenda antes de modificar este pendiente.");
      if (item.updatedAt.toISOString() !== body.version) throw new InboxError("El pendiente cambió en otra ventana. Actualiza Inbox.");
      if (body.action === "delete") {
        await deleteScheduledChildren(tx, userId, { inboxId: item.id });
        await tx.inboxItem.delete({ where: { id: item.id } }); return { deleted: true };
      }
      const currentSteps = Array.isArray(item.checklist) ? item.checklist as unknown as ActivityStep[] : [];
      const steps = body.action === "edit" && body.steps !== undefined ? validateSteps(body.steps) : currentSteps;
      const list = body.action === "complete" || body.action === "uncomplete" ? steps.map((step) => ({ ...step, completed: body.action === "complete" })) : steps;
      await syncScheduledChildren(tx, userId, { inboxId: item.id }, list, currentSteps);
      const completedAt = body.action === "complete" ? item.completedAt ?? new Date() : body.action === "uncomplete" ? null
        : list.length ? list.every((step) => step.completed) ? item.completedAt ?? new Date() : null : item.completedAt;
      const data = { ...(body.action === "edit" ? { text: (body.text as string).trim() } : {}),
        completedAt, checklist: list as unknown as Prisma.InputJsonValue };
      return { item: await tx.inboxItem.update({ where: { id: item.id }, data }) };
    }, { timeout: 30000 });
    if ("item" in result && result.item) {
      const scheduledCount = await prisma.scheduledSubtask.count({ where: { userId, parentInboxId: result.item.id, active: true } });
      return NextResponse.json({ ...result, item: { ...result.item, scheduledCount } }, { headers });
    }
    return NextResponse.json(result, { headers });
  } catch (error) { return failure(error); }
}
