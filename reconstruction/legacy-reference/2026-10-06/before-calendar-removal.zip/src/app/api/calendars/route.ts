import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { prisma } from "@/lib/prisma";
import { manageCalendar, CalendarManagementError } from "@/lib/calendar-management";

export const runtime = "nodejs";

export async function GET() {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Inicia sesión para ver tus calendarios." }, { status: 401 });
  }

  try {
    const calendar = await getGoogleCalendarClient(userId);
    const calendars = [];
    let pageToken: string | undefined;

    do {
      const { data } = await calendar.calendarList.list({
        maxResults: 250,
        pageToken,
        fields: "items(id,summary,backgroundColor,primary,selected,accessRole),nextPageToken",
      });
      calendars.push(...(data.items ?? []));
      pageToken = data.nextPageToken ?? undefined;
    } while (pageToken);

    const calendarIds = calendars.flatMap((item) => item.id ? [item.id] : []);
    const subscriptions = calendarIds.length
      ? await prisma.calendarSubscription.findMany({
          where: { userId, googleCalendarId: { in: calendarIds } },
          select: { googleCalendarId: true, selected: true, isMeals: true },
        })
      : [];
    const selectedByCalendar = new Map(
      subscriptions.map((subscription) => [subscription.googleCalendarId, subscription.selected]),
    );

    return NextResponse.json({
      calendars: calendars.flatMap((item) => {
        if (!item.id) return [];
        return [{
          id: item.id,
          summary: item.summary ?? item.id,
          color: item.backgroundColor ?? null,
          primary: item.primary ?? false,
          selected: selectedByCalendar.get(item.id) ?? item.selected ?? true,
          connected: true,
          canWrite: ["owner", "writer"].includes(item.accessRole ?? ""),
          isMeals: subscriptions.some((subscription) => subscription.googleCalendarId === item.id && subscription.isMeals),
        }];
      }),
    }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof GoogleCalendarConnectionError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    return NextResponse.json(
      { error: "No pudimos cargar tus calendarios de Google." },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return NextResponse.json({ error: "Envía la solicitud como JSON." }, { status: 415 });
  const body = await request.json().catch(() => null);
  const binding = body?.action === "bindCooking";
  if (!body || (binding ? typeof body.calendarId !== "string" || !body.calendarId || body.calendarId.length > 1024
    : typeof body.name !== "string" || !body.name.trim() || body.name.trim().length > 150
      || typeof body.color !== "string" || !/^#[0-9a-f]{6}$/i.test(body.color)
      || typeof body.key !== "string" || !/^[\w-]{8,100}$/.test(body.key))) {
    return NextResponse.json({ error: "Revisa el nombre y color del calendario." }, { status: 400 });
  }
  try {
    const calendar = await manageCalendar(userId, binding
      ? { calendarId: body.calendarId, cooking: true }
      : { name: body.name.trim(), color: body.color, key: body.key, cooking: body.cooking === true });
    return NextResponse.json({ calendar }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof CalendarManagementError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    return NextResponse.json({ error: "No pudimos configurar el calendario. Reintenta con el mismo nombre y color." }, { status: 502 });
  }
}
