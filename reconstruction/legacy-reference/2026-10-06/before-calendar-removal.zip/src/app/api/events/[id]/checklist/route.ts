import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { readChecklist, writeChecklist, validateSteps, ChecklistError } from "@/lib/activity-checklist";
import { applyChecklistMarks } from "@/lib/task-checklist-marks";
import { reconcileScheduledSubtasks } from "@/lib/scheduled-subtask-lifecycle";
import { refreshScheduledMeal } from "@/lib/scheduled-meal-refresh";
import { MealStepError } from "@/lib/meal-preparation";
import { MealActionError } from "@/lib/meal-portions";
import { TaskActivityError } from "@/lib/task-activity";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
async function handle(request: Request, eventId: string, save: boolean) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (save && request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (save && !request.headers.get("content-type")?.includes("application/json")) return NextResponse.json({ error: "Envía JSON." }, { status: 415 });
  const body = save ? await request.json().catch(() => null) : null;
  const calendarId = save ? body?.calendarId : new URL(request.url).searchParams.get("calendarId");
  if (typeof calendarId !== "string" || !calendarId || calendarId.length > 1024 || (save && typeof body?.version !== "string")) {
    return NextResponse.json({ error: "Revisa la actividad que quieres abrir." }, { status: 400 });
  }
  try {
    if (save && body?.action === "apply-marks") return NextResponse.json(await applyChecklistMarks(userId, calendarId, eventId, body), { headers });
    const steps = save ? validateSteps(body.steps) : [];
    if (save && steps.length && steps.every((step) => step.completed)) await refreshScheduledMeal(userId, calendarId, eventId);
    const google = await getGoogleCalendarClient(userId);
    const { data: calendar } = await google.calendarList.get({ calendarId });
    const canWrite = ["owner", "writer"].includes(calendar.accessRole ?? "");
    if (save && !canWrite) throw new ChecklistError("Necesitas permiso para escribir en este calendario.", 403);
    const { data: event } = await google.events.get({ calendarId, eventId });
    if (event.status === "cancelled" || !event.start || !event.end) throw new ChecklistError("Esta actividad ya no existe.", 404);
    if (save && event.recurrence?.length && !event.recurringEventId) throw new ChecklistError("Abre un día concreto de la rutina para modificar sus pasos.");
    const master = !save && event.recurringEventId ? (await google.events.get({ calendarId, eventId: event.recurringEventId })).data : event;
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      if (save) return writeChecklist(tx, userId, calendarId, event, steps, body.version);
      await reconcileScheduledSubtasks(tx, userId, { parentCalendarId: calendarId, parentEventId: eventId });
      const state = await readChecklist(tx, userId, calendarId, event);
      return { steps: state.steps, version: state.version, completedAt: state.overlay?.completedAt?.toISOString() ?? null,
        keep: state.overlay?.keep ?? false, recurrence: master.recurrence ?? [], seriesEtag: master.etag, canWrite };
    }, { timeout: 30000 });
    return NextResponse.json(result, { headers });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof ChecklistError || error instanceof ScheduledSubtaskError || error instanceof MealStepError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof MealActionError) return NextResponse.json({ error: error.message }, { status: 409 });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    return NextResponse.json({ error: "No pudimos guardar o cargar los pasos. Actualiza y reintenta." }, { status: 502 });
  }
}
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) { return handle(request, (await params).id, false); }
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) { return handle(request, (await params).id, true); }
