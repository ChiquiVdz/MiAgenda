import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { prisma } from "@/lib/prisma";

import { completeMealBlock, uncompleteMealBlock, MealActionError, OptionalSelectionRequired } from "@/lib/meal-portions";
import { syncMealSchedules } from "@/lib/meal-state";
import { readChecklist, writeChecklist, ChecklistError } from "@/lib/activity-checklist";
import { syncScheduledParent } from "@/lib/scheduled-subtask-state";
import { refreshScheduledMeal } from "@/lib/scheduled-meal-refresh";
import { MealStepError } from "@/lib/meal-preparation";
import { assertTaskAvailable, cacheTaskEvent, TaskActivityError } from "@/lib/task-activity";

export const runtime = "nodejs";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function googleStatus(error: unknown) {
  if (typeof error !== "object" || error === null) return undefined;
  if ("response" in error && typeof error.response === "object" && error.response !== null && "status" in error.response) {
    return Number(error.response.status);
  }
  return "code" in error ? Number(error.code) : undefined;
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string; action: string }> },
) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Inicia sesión para actualizar una actividad." }, { status: 401 });
  }

  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  }
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    return NextResponse.json({ error: "El formato de la solicitud no es válido." }, { status: 415 });
  }

  const body: unknown = await request.json().catch(() => null);
  if (!isRecord(body)
    || typeof body.calendarId !== "string"
    || body.calendarId.trim().length === 0
    || body.calendarId.length > 1024) {
    return NextResponse.json({ error: "No pudimos verificar el calendario de esta actividad." }, { status: 400 });
  }

  const { id: eventId, action } = await params;
  if (!eventId || !["complete", "uncomplete", "keep", "unkeep"].includes(action)) {
    return NextResponse.json({ error: "La acción solicitada no está disponible." }, { status: 404 });
  }

  const calendarId = body.calendarId;
  if (body.optionalIngredientIds !== undefined && (!Array.isArray(body.optionalIngredientIds) || body.optionalIngredientIds.length > 600
    || !body.optionalIngredientIds.every((id) => typeof id === "string" && id.length > 0 && id.length <= 100)
    || new Set(body.optionalIngredientIds).size !== body.optionalIngredientIds.length)) {
    return NextResponse.json({ error: "Revisa la selección de ingredientes opcionales." }, { status: 400 });
  }
  try {
    const calendar = await getGoogleCalendarClient(userId);
    const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId });
    if ((action === "complete" || action === "uncomplete") && !["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) {
      return NextResponse.json({ error: "Necesitas permiso para escribir en ese calendario." }, { status: 403 });
    }

    const { data: event } = await calendar.events.get({ calendarId, eventId });
    if (event.status === "cancelled") {
      return NextResponse.json({ error: "Este evento ya no existe en Google Calendar." }, { status: 404 });
    }
    if (!event.start?.date && !event.start?.dateTime) return NextResponse.json({ error: "Conservar requiere una fecha programada." }, { status: 409 });

    const key = { userId, googleCalendarId: calendarId, googleEventId: eventId };
    const existingOverlay = await prisma.eventOverlay.findUnique({
      where: { userId_googleCalendarId_googleEventId: key },
      select: { purgeStartedAt: true },
    });
    if (existingOverlay?.purgeStartedAt) {
      return NextResponse.json({ error: "La retención está procesando esta actividad. Inténtalo de nuevo en un momento." }, { status: 409 });
    }

    const linkedMeal = await prisma.mealPlan.findFirst({ where: key, select: { id: true } });
    if (linkedMeal && (action === "complete" || action === "uncomplete")) await syncMealSchedules(userId, calendar);
    if (!linkedMeal) {
      if (action === "complete") await refreshScheduledMeal(userId, calendarId, eventId);
      const result = await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        await assertTaskAvailable(tx, userId, calendarId, eventId);
        if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Reanuda el cambio pendiente de Agenda antes de modificar otra tarea.");
        const state = await readChecklist(tx, userId, calendarId, event);
        if (state.overlay?.purgeStartedAt) throw new ChecklistError("La retención está procesando esta actividad.");
        if (state.steps.length && (action === "complete" || action === "uncomplete")) {
          const checklist = await writeChecklist(tx, userId, calendarId, event, state.steps.map((step) => ({ ...step, completed: action === "complete" })));
          return { ...checklist, progress: { done: checklist.steps.filter((step) => step.completed).length, total: checklist.steps.length } };
        }
        const completedAt = action === "complete" ? state.overlay?.completedAt ?? new Date() : action === "uncomplete" ? null : state.overlay?.completedAt ?? null;
        const data = { completedAt, purgeAfter: completedAt ? eventPurgeAfter(completedAt, event.end) : null,
          keep: action === "keep" ? true : action === "unkeep" ? false : state.overlay?.keep ?? false,
          etag: event.etag, recurringEventId: event.recurringEventId };
        const overlay = await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: { ...key, ...data }, update: data });
        if (action === "complete" || action === "uncomplete") await syncScheduledParent(tx, userId, calendarId, eventId, overlay.completedAt);
        await cacheTaskEvent(tx, userId, calendarId, event);
        return { completedAt: overlay.completedAt?.toISOString() ?? null, keep: overlay.keep };
      }, { timeout: 15000 });
      return NextResponse.json(result, {
        headers: { "Cache-Control": "private, no-store" },
      });
    }
    let completedAt: Date | null = null;
    if (action === "complete") {
      const now = new Date();
      const data = { completedAt: now, purgeAfter: eventPurgeAfter(now, event.end), etag: event.etag ?? null };
      const mealPlan = await prisma.mealPlan.findFirst({
        where: key,
        select: { id: true },
      });
      if (mealPlan) {
        await prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
          const plan = await tx.mealPlan.findUniqueOrThrow({ where: { id: mealPlan.id } });
          if (plan.completedAt) return;
          await completeMealBlock(tx, userId, plan.overlayId, now, body.optionalIngredientIds as string[] | undefined);
          const overlayUpdate = await tx.eventOverlay.updateMany({
            where: { id: plan.overlayId, purgeStartedAt: null },
            data,
          });
          if (!overlayUpdate.count) throw new MealActionError("La retención está procesando esta actividad. Inténtalo de nuevo en un momento.");
        }, { timeout: 30000 });
      } else if (existingOverlay) {
        const update = await prisma.eventOverlay.updateMany({ where: { ...key, purgeStartedAt: null }, data });
        if (!update.count) {
          return NextResponse.json({ error: "La retención está procesando esta actividad. Inténtalo de nuevo en un momento." }, { status: 409 });
        }
      } else {
        await prisma.eventOverlay.create({ data: { ...key, ...data } });
      }
      completedAt = now;
    } else if (action === "uncomplete") {
      const mealPlan = await prisma.mealPlan.findFirst({
        where: key,
        select: { id: true },
      });
      if (mealPlan) {
        await prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
          const plan = await tx.mealPlan.findUniqueOrThrow({ where: { id: mealPlan.id } });
          await uncompleteMealBlock(tx, userId, plan.overlayId);
          const overlayUpdate = await tx.eventOverlay.updateMany({
            where: { id: plan.overlayId, purgeStartedAt: null },
            data: { completedAt: null, purgeAfter: null, etag: event.etag ?? null },
          });
          if (!overlayUpdate.count) throw new MealActionError("La retención está procesando esta actividad. Inténtalo de nuevo en un momento.");
        }, { timeout: 30000 });
      } else {
        const update = await prisma.eventOverlay.updateMany({ where: { ...key, purgeStartedAt: null }, data: { completedAt: null, purgeAfter: null, etag: event.etag ?? null } });
        if (!update.count && existingOverlay?.purgeStartedAt) {
          return NextResponse.json({ error: "La retención está procesando esta actividad. Inténtalo de nuevo en un momento." }, { status: 409 });
        }
      }
      completedAt = null;
    } else if (action === "keep") {
      if (existingOverlay) {
        const update = await prisma.eventOverlay.updateMany({ where: { ...key, purgeStartedAt: null }, data: { keep: true, etag: event.etag ?? null } });
        if (!update.count) {
          return NextResponse.json({ error: "La retención está procesando esta actividad. Inténtalo de nuevo en un momento." }, { status: 409 });
        }
      } else {
        await prisma.eventOverlay.create({ data: { ...key, keep: true, etag: event.etag ?? null } });
      }
    } else {
      const update = await prisma.eventOverlay.updateMany({ where: { ...key, purgeStartedAt: null }, data: { keep: false, etag: event.etag ?? null } });
      if (!update.count && existingOverlay?.purgeStartedAt) {
        return NextResponse.json({ error: "La retención está procesando esta actividad. Inténtalo de nuevo en un momento." }, { status: 409 });
      }
    }

    const overlay = await prisma.eventOverlay.findUnique({
      where: { userId_googleCalendarId_googleEventId: key },
      select: { completedAt: true, keep: true },
    });
    return NextResponse.json({ completedAt: (overlay?.completedAt ?? completedAt)?.toISOString() ?? null, keep: overlay?.keep ?? false }, {
      headers: { "Cache-Control": "private, no-store" },
    });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof ChecklistError || error instanceof ScheduledSubtaskError || error instanceof MealStepError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof OptionalSelectionRequired) return NextResponse.json({ requiresOptionalSelection: true, optionalIngredients: error.ingredients }, { status: 409 });
    if (error instanceof GoogleCalendarConnectionError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    if (error instanceof MealActionError) {
      const shortageSummary = error.details?.map((item) => `${item.name}: faltan ${item.missingQuantity} ${item.unit}`).join("; ");
      const message = shortageSummary
        ? `${error.message} ${shortageSummary}. No se descontó ningún ingrediente.`
        : error.message;
      return NextResponse.json({ error: message, shortages: error.details ?? [] }, { status: 409 });
    }
    const status = googleStatus(error);
    if (status === 404) {
      return NextResponse.json({ error: "El evento o el calendario ya no están disponibles." }, { status: 404 });
    }
    if (status === 403) {
      return NextResponse.json({ error: "Google no permitió consultar este evento." }, { status: 403 });
    }
    return NextResponse.json({ error: "No pudimos actualizar el estado de la actividad." }, { status: 502 });
  }
}



