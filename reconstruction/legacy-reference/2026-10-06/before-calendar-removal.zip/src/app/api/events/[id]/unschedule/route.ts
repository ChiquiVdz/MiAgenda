import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { unscheduleTask } from "@/lib/task-unschedule";
import { TaskActivityError } from "@/lib/task-activity";
import { ChecklistError } from "@/lib/activity-checklist";
import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { GoogleCalendarConnectionError } from "@/lib/google/calendar";
export const runtime = "nodejs";
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) return NextResponse.json({ error: "Envía JSON." }, { status: 415 });
  const body = await request.json().catch(() => null);
  if (!body || typeof body.calendarId !== "string" || !body.calendarId || body.calendarId.length > 1024 || typeof body.etag !== "string" || !body.etag || body.etag.length > 300) return NextResponse.json({ error: "Actualiza el evento antes de quitar horario." }, { status: 400 });
  try {
    const { id } = await params;
    const result = await unscheduleTask(userId, body.calendarId, id, body.etag);
    return NextResponse.json({ ...result, movedToInbox: true }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof TaskActivityError || error instanceof ChecklistError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof ScheduledSubtaskError || error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    const code = Number((error as { response?: { status?: number }; code?: number })?.response?.status ?? (error as { code?: number })?.code);
    if ([404, 410].includes(code)) return NextResponse.json({ error: "El evento ya no existe en Google. Una eliminación externa no devuelve tareas a Inbox." }, { status: 404 });
    return NextResponse.json({ error: "No pudimos terminar el traslado. Reintenta Quitar horario o abre Inbox para recuperar un borrado ya confirmado." }, { status: 502 });
  }
}
