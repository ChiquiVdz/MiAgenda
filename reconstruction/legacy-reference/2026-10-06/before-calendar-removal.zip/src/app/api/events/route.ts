import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { prisma } from "@/lib/prisma";
import { createHash, randomUUID } from "node:crypto";
import { Prisma } from "@/generated/prisma/client";
import { validateSteps, pendingSteps, resolveSteps, resolveChecklistMarks, ChecklistError } from "@/lib/activity-checklist";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { syncScheduledChildren, ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { reconcileScheduledSubtasks } from "@/lib/scheduled-subtask-lifecycle";
import { buildRecurrence, type RepeatConfig } from "@/lib/task-recurrence";
import { cacheTaskEvent, refreshTaskEventCaches } from "@/lib/task-activity";

export const runtime = "nodejs";

const RFC3339 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/;
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;

function parseRangeValue(value: string | null) {
  if (!value || !RFC3339.test(value)) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function isValidDateOnly(value: unknown): value is string {
  if (typeof value !== "string" || !DATE_ONLY.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function isValidDateTime(value: unknown): value is string {
  return typeof value === "string"
    && RFC3339.test(value)
    && isValidDateOnly(value.slice(0, 10))
    && Number.isFinite(new Date(value).getTime());
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getCalendarErrorDetails(error: unknown) {
  if (!isRecord(error)) return { name: "UnknownError", code: null, googleStatus: null };
  const response = isRecord(error.response) ? error.response : null;
  const name = typeof error.name === "string" ? error.name.slice(0, 80) : "UnknownError";
  const code = typeof error.code === "string" || typeof error.code === "number"
    ? String(error.code).slice(0, 80)
    : null;
  const googleStatus = typeof response?.status === "number" ? response.status : null;
  return { name, code, googleStatus };
}

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Inicia sesión para ver tus eventos." }, { status: 401 });
  }

  const url = new URL(request.url);
  const from = parseRangeValue(url.searchParams.get("from"));
  const to = parseRangeValue(url.searchParams.get("to"));
  const rangeMs = from && to ? to.getTime() - from.getTime() : 0;
  if (!from || !to || rangeMs <= 0 || rangeMs > 42 * 24 * 60 * 60 * 1000) {
    return NextResponse.json({ error: "El rango de fechas no es válido." }, { status: 400 });
  }

  try {
    const calendar = await getGoogleCalendarClient(userId);
    const googleCalendars = [];
    let calendarPageToken: string | undefined;
    do {
      const { data } = await calendar.calendarList.list({
        maxResults: 250,
        pageToken: calendarPageToken,
        fields: "items(id,summary,backgroundColor,primary,selected),nextPageToken",
      });
      googleCalendars.push(...(data.items ?? []));
      calendarPageToken = data.nextPageToken ?? undefined;
    } while (calendarPageToken);

    const calendarIds = googleCalendars.flatMap((item) => item.id ? [item.id] : []);
    const subscriptions = calendarIds.length
      ? await prisma.calendarSubscription.findMany({
          where: { userId, googleCalendarId: { in: calendarIds } },
          select: { googleCalendarId: true, selected: true },
        })
      : [];
    const selectedByCalendar = new Map(
      subscriptions.map(({ googleCalendarId, selected }) => [googleCalendarId, selected]),
    );
    const selectedCalendars = googleCalendars.flatMap((item) => {
      if (!item.id || !(selectedByCalendar.get(item.id) ?? item.selected ?? true)) return [];
      return [{
        id: item.id,
        summary: item.summary ?? item.id,
        color: item.backgroundColor ?? null,
        primary: item.primary ?? false,
      }];
    });

    const events: Array<{ id: string; calendarId: string; calendarName: string; color: string | null; summary: string; description: string | null;
      startDate: string | null; endDate: string | null; startDateTime: string | null; endDateTime: string | null;
      recurringEventId: string | null; originalStartTime: { date?: string | null; dateTime?: string | null } | null | undefined; etag: string | null }> = [];
    for (const selectedCalendar of selectedCalendars) {
      let pageToken: string | undefined;
      do {
        const { data } = await calendar.events.list({
          calendarId: selectedCalendar.id,
          timeMin: from.toISOString(),
          timeMax: to.toISOString(),
          singleEvents: true,
          orderBy: "startTime",
          maxResults: 2500,
          pageToken,
          fields: "items(id,summary,description,start,end,status,htmlLink,recurringEventId,originalStartTime,etag),nextPageToken",
        });
        for (const event of data.items ?? []) {
          if (!event.id || event.status === "cancelled" || (!event.start?.date && !event.start?.dateTime) || (!event.end?.date && !event.end?.dateTime)) continue;
          events.push({
            id: event.id,
            calendarId: selectedCalendar.id,
            calendarName: selectedCalendar.summary,
            color: selectedCalendar.color,
            summary: event.summary ?? "(Sin título)",
            description: event.description ?? null,
            startDate: event.start?.date ?? null,
            endDate: event.end?.date ?? null,
            startDateTime: event.start?.dateTime ?? null,
            endDateTime: event.end?.dateTime ?? null,
            recurringEventId: event.recurringEventId ?? null,
            originalStartTime: event.originalStartTime ?? event.start,
            etag: event.etag ?? null,
          });
        }
        pageToken = data.nextPageToken ?? undefined;
      } while (pageToken);
    }

    const removedSubtasks = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      return reconcileScheduledSubtasks(tx, userId, {
        OR: [
          ...events.map((event) => ({ googleCalendarId: event.calendarId, googleEventId: event.id })),
          ...events.map((event) => ({ parentCalendarId: event.calendarId, parentEventId: event.id })),
          { googleCalendarId: { in: selectedCalendars.map((item) => item.id) }, endSnapshot: { gte: from, lte: to } },
        ],
      }, events);
    }, { timeout: 30000 });
    for (let index = events.length - 1; index >= 0; index--) if (removedSubtasks.has(`${events[index].calendarId}\0${events[index].id}`)) events.splice(index, 1);
    const eventIds = [...new Set(events.map((event) => event.id))];
    const overlays = eventIds.length && selectedCalendars.length
      ? await prisma.eventOverlay.findMany({
          where: {
            userId,
            googleCalendarId: { in: selectedCalendars.map(({ id }) => id) },
            googleEventId: { in: eventIds },
          },
          select: {
            googleCalendarId: true,
            googleEventId: true,
            completedAt: true,
            keep: true,
            highlighted: true,
            kind: true,
            checklist: true,
            checklistMarkedAt: true,
            purgeStartedAt: true,
          },
        })
      : [];
    const overlayByEvent = new Map(overlays.map((overlay) => [
      `${overlay.googleCalendarId}\u0000${overlay.googleEventId}`,
      { completedAt: overlay.completedAt?.toISOString() ?? null, keep: overlay.keep, highlighted: overlay.highlighted, kind: overlay.kind },
    ]));

    const definitions = await prisma.activityChecklist.findMany({ where: { userId,
      googleCalendarId: { in: selectedCalendars.map((item) => item.id) },
      googleEventId: { in: [...new Set(events.flatMap((event) => [event.id, ...(event.recurringEventId ? [event.recurringEventId] : [])]))] },
    } });
    const definitionByEvent = new Map(definitions.map((definition) => [`${definition.googleCalendarId}\u0000${definition.googleEventId}`, definition]));
    const snapshotByEvent = new Map(overlays.map((overlay) => [`${overlay.googleCalendarId}\u0000${overlay.googleEventId}`, overlay.checklist]));
    const rules = await prisma.taskChecklistMark.findMany({ where: { userId, googleCalendarId: { in: selectedCalendars.map((item) => item.id) } }, orderBy: { createdAt: "asc" } });
    if (rules.length) {
      const members = await prisma.taskSeriesMember.findMany({ where: { userId, googleCalendarId: { in: selectedCalendars.map((item) => item.id) } } });
      const rootByEvent = new Map(members.map((member) => [`${member.googleCalendarId}\u0000${member.googleEventId}`, member.rootId]));
      await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        for (const event of events) {
          const key = `${event.calendarId}\u0000${event.id}`;
          const sourceId = event.recurringEventId ?? event.id;
          const rootId = rootByEvent.get(`${event.calendarId}\u0000${sourceId}`) ?? sourceId;
          const instructions = rules.filter((rule) => rule.googleCalendarId === event.calendarId && rule.rootId === rootId);
          if (!instructions.length) continue;
          // Read the current snapshot under the lock; another tab may have changed it.
          const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: event.calendarId, googleEventId: event.id } } });
          if (overlay?.kind === "meal" || overlay?.purgeStartedAt) continue;
          const definition = definitionByEvent.get(`${event.calendarId}\u0000${sourceId}`);
          const steps = resolveSteps(overlay?.checklist, definition?.versions, event.startDateTime ?? `${event.startDate}T00:00:00-06:00`, Boolean(overlay?.completedAt));
          const marked = resolveChecklistMarks(steps, overlay?.completedAt ?? null, overlay?.checklistMarkedAt ?? null,
            event.originalStartTime?.dateTime ?? `${event.originalStartTime?.date}T00:00:00-06:00`, instructions);
          if (marked.steps.length && marked.markedAt && marked.markedAt.getTime() !== overlay?.checklistMarkedAt?.getTime()) {
            const data = { checklist: marked.steps as unknown as Prisma.InputJsonValue, checklistMarkedAt: marked.markedAt, completedAt: marked.completedAt,
              purgeAfter: marked.completedAt ? eventPurgeAfter(marked.completedAt, { date: event.endDate, dateTime: event.endDateTime }) : null, recurringEventId: event.recurringEventId, etag: event.etag };
            const updated = await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: event.calendarId, googleEventId: event.id } },
              create: { userId, googleCalendarId: event.calendarId, googleEventId: event.id, ...data, kind: "app_task" }, update: data });
            await syncScheduledChildren(tx, userId, { calendarId: event.calendarId, eventId: event.id }, marked.steps);
            overlayByEvent.set(key, { completedAt: updated.completedAt?.toISOString() ?? null, keep: updated.keep, highlighted: updated.highlighted, kind: updated.kind });
            snapshotByEvent.set(key, updated.checklist);
          } else if (overlay) {
            overlayByEvent.set(key, { completedAt: overlay.completedAt?.toISOString() ?? null, keep: overlay.keep, highlighted: overlay.highlighted, kind: overlay.kind });
            snapshotByEvent.set(key, overlay.checklist);
          }
        }
      }, { timeout: 30000 });
    }

    const activityLinks = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      return refreshTaskEventCaches(tx, userId, events);
    }, { timeout: 30000 });
    const activityByEvent = new Map(activityLinks.map((link) => [`${link.googleCalendarId}\u0000${link.googleEventId}`, link.activity]));
    const children = await prisma.scheduledSubtask.findMany({ where: { userId, OR: events.map((event) => ({ googleCalendarId: event.calendarId, googleEventId: event.id })) }, select: { googleCalendarId: true, googleEventId: true } });
    const childKeys = new Set(children.map((child) => `${child.googleCalendarId}\u0000${child.googleEventId}`));
    const moving = await prisma.inboxItem.findMany({ where: { userId, transferredAt: null, transferPayload: { not: Prisma.DbNull } }, select: { googleCalendarId: true, googleEventId: true } });
    const movingKeys = new Set(moving.map((item) => `${item.googleCalendarId}\u0000${item.googleEventId}`));
    return NextResponse.json({ events: events.filter((event) => !movingKeys.has(`${event.calendarId}\u0000${event.id}`)).map((event) => ({
      ...event,
      activityId: activityByEvent.get(`${event.calendarId}\u0000${event.id}`)?.id ?? null,
      isSubtask: childKeys.has(`${event.calendarId}\u0000${event.id}`),
      overlay: (() => {
        const overlay = overlayByEvent.get(`${event.calendarId}\u0000${event.id}`);
        const activity = activityByEvent.get(`${event.calendarId}\u0000${event.id}`);
        return overlay && activity?.lifecycle === "visible" ? { ...overlay, completedAt: activity.completedAt?.toISOString() ?? null, keep: activity.keep, highlighted: activity.highlighted } : overlay ?? null;
      })(),
      progress: (() => {
        const overlay = overlayByEvent.get(`${event.calendarId}\u0000${event.id}`);
        if (overlay?.kind === "meal") return null;
        const definition = definitionByEvent.get(`${event.calendarId}\u0000${event.recurringEventId ?? event.id}`);
        const steps = resolveSteps(snapshotByEvent.get(`${event.calendarId}\u0000${event.id}`), definition?.versions,
          event.startDateTime ?? `${event.startDate}T00:00:00-06:00`, Boolean(overlay?.completedAt));
        return steps.length ? { done: steps.filter((step) => step.completed).length, total: steps.length } : null;
      })(),
    })) }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    const details = getCalendarErrorDetails(error);
    console.error("[GET /api/events] Calendar sync failed", details);
    if (details.googleStatus === 401) {
      return NextResponse.json(
        { error: "La conexión con Google venció o fue revocada. Vuelve a conectar tu cuenta." },
        { status: 401 },
      );
    }
    if (details.googleStatus === 403) {
      return NextResponse.json(
        { error: "Google no permitió consultar los eventos. Revisa los permisos de Calendar de la conexión." },
        { status: 403 },
      );
    }
    return NextResponse.json(
      { error: "No pudimos cargar los eventos de Google Calendar." },
      { status: 502 },
    );
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Inicia sesión para crear una actividad." }, { status: 401 });
  }

  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  }
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    return NextResponse.json({ error: "El formato de la solicitud no es válido." }, { status: 415 });
  }

  const body: unknown = await request.json().catch(() => null);
  if (!isRecord(body)
    || typeof body.calendarId !== "string" || body.calendarId.trim().length === 0 || body.calendarId.length > 1024
    || typeof body.summary !== "string" || body.summary.trim().length === 0 || body.summary.trim().length > 250
    || typeof body.allDay !== "boolean") {
    return NextResponse.json({ error: "Revisa el título y el calendario de la actividad." }, { status: 400 });
  }

  let start: { date: string } | { dateTime: string; timeZone: string };
  let end: { date: string } | { dateTime: string; timeZone: string };
  if (body.allDay) {
    if (!isValidDateOnly(body.startDate) || !isValidDateOnly(body.endDate) || body.endDate <= body.startDate) {
      return NextResponse.json({ error: "La fecha final debe ser posterior a la fecha inicial." }, { status: 400 });
    }
    start = { date: body.startDate };
    end = { date: body.endDate };
  } else {
    if (!isValidDateTime(body.startDateTime) || !isValidDateTime(body.endDateTime)) {
      return NextResponse.json({ error: "Revisa la fecha y hora de la actividad." }, { status: 400 });
    }
    const startTime = new Date(body.startDateTime).getTime();
    const endTime = new Date(body.endDateTime).getTime();
    if (!Number.isFinite(startTime) || !Number.isFinite(endTime) || endTime <= startTime) {
      return NextResponse.json({ error: "La hora final debe ser posterior a la hora inicial." }, { status: 400 });
    }
    start = { dateTime: body.startDateTime, timeZone: "America/Mexico_City" };
    end = { dateTime: body.endDateTime, timeZone: "America/Mexico_City" };
  }

  try {
    const steps = pendingSteps(validateSteps(body.steps ?? []));
    let recurrence: string[];
    try {
      const repeat = body.repeat as RepeatConfig | undefined;
      recurrence = repeat ? buildRecurrence(repeat, body.allDay) : [];
      const firstDate = "date" in start ? start.date : new Date(start.dateTime).toLocaleDateString("en-CA", { timeZone: "America/Mexico_City" });
      if (repeat && repeat.frequency !== "none" && repeat.ending === "date" && repeat.until < firstDate) throw new Error("La repetición no puede terminar antes de iniciar.");
    }
    catch (error) { throw new ChecklistError(error instanceof Error ? error.message : "Revisa la repetición.", 400); }
    if (body.createKey !== undefined && (typeof body.createKey !== "string" || !/^[\w-]{8,100}$/.test(body.createKey))) throw new ChecklistError("Revisa la solicitud de creación.", 400);
    const createKey = typeof body.createKey === "string" ? body.createKey : randomUUID();
    const eventId = `task${createHash("sha256").update(JSON.stringify([userId, body.calendarId, createKey])).digest("hex").slice(0, 40)}`;
    const fingerprint = createHash("sha256").update(JSON.stringify([body.summary.trim(), start, end, steps, recurrence])).digest("hex");
    const calendar = await getGoogleCalendarClient(userId);
    const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId: body.calendarId });
    if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) {
      return NextResponse.json({ error: "Necesitas permiso para escribir en ese calendario." }, { status: 403 });
    }

    let event;
    try {
      event = (await calendar.events.insert({ calendarId: body.calendarId, requestBody: {
        id: eventId, summary: body.summary.trim(), start, end,
        ...(recurrence.length ? { recurrence } : {}),
        extendedProperties: { private: { miagendaCreate: fingerprint } },
      } })).data;
    } catch (error) {
      const status = (error as { code?: number; response?: { status?: number } }).response?.status ?? Number((error as { code?: number }).code);
      if (status !== 409) throw error;
      event = (await calendar.events.get({ calendarId: body.calendarId, eventId })).data;
      if (event.status === "cancelled" || event.extendedProperties?.private?.miagendaCreate !== fingerprint) throw new ChecklistError("Este intento corresponde a otra actividad o fue eliminado. Cierra el formulario y crea uno nuevo.");
    }
    if (!event.id) {
      return NextResponse.json({ error: "Google no devolvió el identificador del evento." }, { status: 502 });
    }
    const activity = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      const key = { userId, googleCalendarId: body.calendarId as string, googleEventId: event.id! };
      if (steps.length) await tx.activityChecklist.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: {
        ...key, versions: [{ effectiveAt: "1970-01-01T00:00:00.000Z", steps }] as unknown as Prisma.InputJsonValue,
      }, update: {} });
      if (!recurrence.length) await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key },
        create: { ...key, kind: "app_task", etag: event.etag, checklist: steps as unknown as Prisma.InputJsonValue }, update: {} });
      return cacheTaskEvent(tx, userId, body.calendarId as string, event);
    });
    return NextResponse.json({ id: event.id, activityId: activity?.id ?? null, summary: event.summary ?? body.summary.trim() }, {
      status: 201,
      headers: { "Cache-Control": "private, no-store" },
    });
  } catch (error) {
    if (error instanceof ChecklistError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    const status = typeof error === "object" && error !== null && "code" in error
      ? Number(error.code)
      : undefined;
    if (status === 404) {
      return NextResponse.json({ error: "Ese calendario ya no está disponible." }, { status: 404 });
    }
    if (status === 403) {
      return NextResponse.json({ error: "Google no permitió crear la actividad en ese calendario." }, { status: 403 });
    }
    return NextResponse.json({ error: "No pudimos crear la actividad en Google Calendar." }, { status: 502 });
  }
}



