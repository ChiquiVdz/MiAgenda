import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { reconcileScheduledSubtasks } from "@/lib/scheduled-subtask-lifecycle";
import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";

export const runtime = "nodejs";
export async function GET(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const year = Number(params.get("year")); const cursor = params.get("cursor");
  if (!Number.isInteger(year) || year < 1900 || year > 9998 || (cursor && !/^[\w-]{1,100}$/.test(cursor))) return NextResponse.json({ error: "Revisa el año." }, { status: 400 });
  try {
    const google = await getGoogleCalendarClient(userId);
    const subscriptions = await prisma.calendarSubscription.findMany({ where: { userId }, select: { googleCalendarId: true, selected: true } });
    const selected = new Map(subscriptions.map((item) => [item.googleCalendarId, item.selected]));
    const calendars = new Map<string, { name: string; color: string | null }>();
    let pageToken: string | undefined;
    do {
      const list = (await google.calendarList.list({ maxResults: 250, pageToken, fields: "items(id,summary,backgroundColor,selected),nextPageToken" })).data;
      for (const calendar of list.items ?? []) if (calendar.id && (selected.get(calendar.id) ?? calendar.selected ?? true)) calendars.set(calendar.id, { name: calendar.summary ?? calendar.id, color: calendar.backgroundColor ?? null });
      pageToken = list.nextPageToken ?? undefined;
    } while (pageToken);
    const overlays = await prisma.eventOverlay.findMany({ where: { userId, highlighted: true, googleCalendarId: { in: [...calendars.keys()] }, ...(cursor ? { id: { gt: cursor } } : {}) }, orderBy: { id: "asc" }, take: 26 });
    const page = overlays.slice(0, 25);
    const start = Date.parse(`${year}-01-01T00:00:00-06:00`); const end = Date.parse(`${year + 1}-01-01T00:00:00-06:00`);
    const events: Array<{ id: string; calendarId: string; calendarName: string; color: string | null; summary: string; description: string | null;
      startDate: string | null; endDate: string | null; startDateTime: string | null; endDateTime: string | null; etag: string | null; recurringEventId: string | null;
      overlay: { completedAt: string | null; keep: boolean; kind: string; highlighted: boolean }; progress: null }> = [];
    // Bound Google concurrency and paginate the private highlighted IDs.
    for (let index = 0; index < page.length; index += 5) {
      const batch = await Promise.all(page.slice(index, index + 5).map(async (overlay) => {
        try {
          const event = (await google.events.get({ calendarId: overlay.googleCalendarId, eventId: overlay.googleEventId })).data;
          if (event.status === "cancelled" || !event.start || !event.end) return null;
          const from = Date.parse(event.start.dateTime ?? `${event.start.date}T00:00:00-06:00`); const to = Date.parse(event.end.dateTime ?? `${event.end.date}T00:00:00-06:00`);
          if (!(from < end && to > start)) return null;
          const calendar = calendars.get(overlay.googleCalendarId)!;
          return { id: overlay.googleEventId, calendarId: overlay.googleCalendarId, calendarName: calendar.name, color: calendar.color, summary: event.summary ?? "(Sin título)", description: event.description ?? null,
            startDate: event.start.date ?? null, endDate: event.end.date ?? null, startDateTime: event.start.dateTime ?? null, endDateTime: event.end.dateTime ?? null, etag: event.etag ?? null, recurringEventId: event.recurringEventId ?? null,
            overlay: { completedAt: overlay.completedAt?.toISOString() ?? null, keep: overlay.keep, kind: overlay.kind, highlighted: true }, progress: null };
        } catch (error) {
          const code = Number((error as { response?: { status?: number }; code?: number }).response?.status ?? (error as { code?: number }).code);
          if ([404, 410].includes(code)) return null;
          throw error;
        }
      }));
      events.push(...batch.filter((event) => event !== null));
    }
    const removed = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      return reconcileScheduledSubtasks(tx, userId, { OR: page.map((item) => ({ googleCalendarId: item.googleCalendarId, googleEventId: item.googleEventId })) }, events);
    }, { timeout: 30000 });
    for (let index = events.length - 1; index >= 0; index--) if (removed.has(`${events[index].calendarId}\0${events[index].id}`)) events.splice(index, 1);
    events.sort((a, b) => (a.startDateTime ?? a.startDate ?? "").localeCompare(b.startDateTime ?? b.startDate ?? ""));
    return NextResponse.json({ events, nextCursor: overlays.length > 25 ? page.at(-1)!.id : null }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    return NextResponse.json({ error: "No pudimos cargar los destacados. Actualiza y reintenta." }, { status: 502 });
  }
}
