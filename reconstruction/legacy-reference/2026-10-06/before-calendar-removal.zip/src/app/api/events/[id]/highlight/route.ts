import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { ChecklistError } from "@/lib/activity-checklist";
import { assertTaskAvailable, cacheTaskEvent, TaskActivityError } from "@/lib/task-activity";

export const runtime = "nodejs";
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return NextResponse.json({ error: "Envía JSON." }, { status: 415 });
  const body = await request.json().catch(() => null);
  if (!body || typeof body.calendarId !== "string" || !body.calendarId || body.calendarId.length > 1024 || typeof body.highlighted !== "boolean" || typeof body.etag !== "string") return NextResponse.json({ error: "Revisa el evento." }, { status: 400 });
  const { id } = await params;
  try {
    const google = await getGoogleCalendarClient(userId);
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await assertTaskAvailable(tx, userId, body.calendarId, id);
      if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Reanuda el cambio pendiente antes de destacar otra actividad.");
      // Highlighting is private app metadata, also for calendars with read access.
      const event = (await google.events.get({ calendarId: body.calendarId, eventId: id })).data;
      if (event.status === "cancelled") throw new ChecklistError("Este evento ya no existe.", 404);
      if (event.recurrence?.length && !event.recurringEventId) throw new ChecklistError("Abre una instancia concreta para destacarla.");
      if (event.etag !== body.etag) throw new ChecklistError("El evento cambió en Google. Actualiza Agenda antes de destacarlo.");
      if (!event.start?.date && !event.start?.dateTime) throw new ChecklistError("Destacar y Conservar requieren una fecha programada.");
      const key = { userId, googleCalendarId: body.calendarId, googleEventId: id };
      const previous = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: key } });
      if (previous?.purgeStartedAt) throw new ChecklistError("La retención está procesando esta actividad.");
      // Only a new highlight enables Keep; retries preserve a later manual choice.
      const enableKeep = body.highlighted && !previous?.highlighted;
      const overlay = await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: { ...key, highlighted: body.highlighted, keep: enableKeep, recurringEventId: event.recurringEventId, etag: event.etag }, update: { highlighted: body.highlighted, ...(enableKeep ? { keep: true } : {}) } });
      await cacheTaskEvent(tx, userId, body.calendarId, event);
      return { highlighted: overlay.highlighted, keep: overlay.keep };
    }, { timeout: 15000 });
    return NextResponse.json(result, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof ChecklistError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    return NextResponse.json({ error: "No pudimos guardar el destacado. Actualiza y reintenta." }, { status: 502 });
  }
}
