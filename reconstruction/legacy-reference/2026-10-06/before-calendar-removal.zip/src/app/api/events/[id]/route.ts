import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { prisma } from "@/lib/prisma";
import { renameScheduledParent, ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { deleteScheduledChildren, unlinkScheduledEvent } from "@/lib/scheduled-subtask-lifecycle";
import { assertTaskAvailable, cacheTaskEvent, TaskActivityError } from "@/lib/task-activity";

class MealCalendarError extends Error {}

export const runtime = "nodejs";

const RFC3339 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/;
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isDateOnly(value: unknown): value is string {
  if (typeof value !== "string" || !DATE_ONLY.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function isDateTime(value: unknown): value is string {
  return typeof value === "string"
    && RFC3339.test(value)
    && isDateOnly(value.slice(0, 10))
    && Number.isFinite(new Date(value).getTime());
}

function googleStatus(error: unknown) {
  if (typeof error !== "object" || error === null) return undefined;
  if ("response" in error && typeof error.response === "object" && error.response !== null && "status" in error.response) {
    return Number(error.response.status);
  }
  return "code" in error ? Number(error.code) : undefined;
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Inicia sesión para editar una actividad." }, { status: 401 });
  }

  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  }
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    return NextResponse.json({ error: "El formato de la solicitud no es válido." }, { status: 415 });
  }

  const body: unknown = await request.json().catch(() => null);
  if (!isRecord(body)
    || typeof body.calendarId !== "string" || body.calendarId.trim().length === 0 || body.calendarId.length > 1024
    || typeof body.etag !== "string" || body.etag.length === 0 || body.etag.length > 300
    || typeof body.summary !== "string" || body.summary.trim().length === 0 || body.summary.trim().length > 250
    || typeof body.allDay !== "boolean") {
    return NextResponse.json({ error: "Revisa el título y los datos de la actividad." }, { status: 400 });
  }

  let start: { date: string } | { dateTime: string; timeZone: string };
  let end: { date: string } | { dateTime: string; timeZone: string };
  if (body.allDay) {
    if (!isDateOnly(body.startDate) || !isDateOnly(body.endDate) || body.endDate <= body.startDate) {
      return NextResponse.json({ error: "La fecha final debe ser posterior a la fecha inicial." }, { status: 400 });
    }
    start = { date: body.startDate };
    end = { date: body.endDate };
  } else {
    if (!isDateTime(body.startDateTime) || !isDateTime(body.endDateTime)) {
      return NextResponse.json({ error: "Revisa la fecha y hora de la actividad." }, { status: 400 });
    }
    const startTime = new Date(body.startDateTime).getTime();
    const endTime = new Date(body.endDateTime).getTime();
    if (endTime <= startTime) {
      return NextResponse.json({ error: "La hora final debe ser posterior a la hora inicial." }, { status: 400 });
    }
    start = { dateTime: body.startDateTime, timeZone: "America/Mexico_City" };
    end = { dateTime: body.endDateTime, timeZone: "America/Mexico_City" };
  }

  const { id: eventId } = await params;
  const calendarId = body.calendarId;
  try {
    const calendar = await getGoogleCalendarClient(userId);
    const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId });
    if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) {
      return NextResponse.json({ error: "Necesitas permiso para escribir en ese calendario." }, { status: 403 });
    }

    const linkedMeal = await prisma.mealPlan.findFirst({
      where: { userId, googleCalendarId: calendarId, googleEventId: eventId }, include: { overlay: true },
    });
    if (linkedMeal?.completedAt || linkedMeal?.overlay.completedAt) {
      return NextResponse.json({ error: "Deshaz el completado de esta comida antes de editarla o eliminarla." }, { status: 409 });
    }
    const mealDuration = !body.allDay && "dateTime" in start && "dateTime" in end
      ? (Date.parse(end.dateTime) - Date.parse(start.dateTime)) / 60000 : null;
    if (linkedMeal && (mealDuration === null || !Number.isInteger(mealDuration) || mealDuration < 5 || mealDuration > 1440)) {
      return NextResponse.json({ error: "Las comidas deben tener horario y durar entre 5 y 1440 minutos." }, { status: 400 });
    }
    const { data: currentEvent } = await calendar.events.get({ calendarId: body.calendarId, eventId });
    const child = await prisma.scheduledSubtask.findFirst({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId } });
    const childTitleLimit = child?.stepId.startsWith("meal") ? 250 : 150;
    if (child && (body.summary.trim().length > childTitleLimit || body.allDay)) return NextResponse.json({ error: `Esta subtarea admite hasta ${childTitleLimit} caracteres y un horario de inicio y fin.` }, { status: 400 });
    if (!currentEvent.etag || currentEvent.etag !== body.etag) {
      return NextResponse.json({ error: "Este evento cambió en Google Calendar. Recarga la semana antes de guardar." }, { status: 409 });
    }

    const editRemote = () => calendar.events.patch({
      calendarId, eventId,
      requestBody: { summary: (body.summary as string).trim(), start, end },
      fields: "id,summary,etag,start,end",
    }, { headers: { "If-Match": currentEvent.etag! } });
    const { data: updatedEvent } = linkedMeal ? await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      const current = await tx.mealPlan.findFirst({ where: { id: linkedMeal.id, userId }, include: { overlay: true } });
      if (!current || current.completedAt || current.overlay.completedAt || current.overlay.purgeStartedAt) throw new MealCalendarError("La comida cambió de estado. Deshaz el completado antes de editarla.");
      const result = await editRemote();
      await tx.mealPlan.updateMany({ where: { overlayId: current.overlayId, userId }, data: {
        scheduledAt: new Date("dateTime" in start ? start.dateTime : start.date + "T00:00:00-06:00"), eventMissing: false,
        durationMinutes: mealDuration!,
      } });
      await tx.eventOverlay.update({ where: { id: current.overlayId }, data: {
        etag: result.data.etag,
        ...(mealDuration !== current.durationMinutes ? { mealDurationOverride: mealDuration } : {}),
      } });
      return result;
    }, { timeout: 15000 }) : await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await assertTaskAvailable(tx, userId, calendarId, eventId);
      return editRemote();
    }, { timeout: 15000 });
    await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await cacheTaskEvent(tx, userId, calendarId, { ...currentEvent, ...updatedEvent });
      if (child && updatedEvent.end?.dateTime) {
        await tx.scheduledSubtask.updateMany({ where: { id: child.id, userId }, data: { endSnapshot: new Date(updatedEvent.end.dateTime) } });
        await renameScheduledParent(tx, userId, calendarId, eventId, updatedEvent.summary ?? (body.summary as string).trim());
      }
      await tx.scheduledSubtask.updateMany({ where: { userId, parentCalendarId: calendarId, parentEventId: eventId }, data: {
        parentEndSnapshot: updatedEvent.end?.dateTime ? new Date(updatedEvent.end.dateTime) : updatedEvent.end?.date ? new Date(`${updatedEvent.end.date}T00:00:00-06:00`) : null,
      } });
    });
    return NextResponse.json({ id: updatedEvent.id, summary: updatedEvent.summary, etag: updatedEvent.etag, start: updatedEvent.start, end: updatedEvent.end }, {
      headers: { "Cache-Control": "private, no-store" },
    });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof MealCalendarError) return NextResponse.json({ error: error.message }, { status: 409 });
    if (error instanceof GoogleCalendarConnectionError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    const status = googleStatus(error);
    if (status === 404) {
      return NextResponse.json({ error: "El evento o el calendario ya no están disponibles." }, { status: 404 });
    }
    if (status === 403) {
      return NextResponse.json({ error: "Google no permitió editar este evento." }, { status: 403 });
    }
    if (status === 412) {
      return NextResponse.json({ error: "Este evento cambió en Google Calendar. Recarga la semana antes de guardar." }, { status: 409 });
    }
    return NextResponse.json({ error: "No pudimos actualizar el evento en Google Calendar." }, { status: 502 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Inicia sesión para eliminar una actividad." }, { status: 401 });
  }

  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  }
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    return NextResponse.json({ error: "El formato de la solicitud no es válido." }, { status: 415 });
  }

  const body: unknown = await request.json().catch(() => null);
  if (!isRecord(body)
    || typeof body.calendarId !== "string" || body.calendarId.trim().length === 0 || body.calendarId.length > 1024
    || typeof body.etag !== "string" || body.etag.length === 0 || body.etag.length > 300) {
    return NextResponse.json({ error: "No pudimos verificar el evento que quieres eliminar." }, { status: 400 });
  }

  const { id: eventId } = await params;
  const calendarId = body.calendarId;
  const expectedEtag = body.etag;
  try {
    const calendar = await getGoogleCalendarClient(userId);
    const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId });
    if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) {
      return NextResponse.json({ error: "Necesitas permiso para escribir en ese calendario." }, { status: 403 });
    }

    const linkedMeal = await prisma.mealPlan.findFirst({
      where: { userId, googleCalendarId: calendarId, googleEventId: eventId }, include: { overlay: true },
    });
    if (linkedMeal?.completedAt || linkedMeal?.overlay.completedAt) {
      return NextResponse.json({ error: "Deshaz el completado de esta comida antes de editarla o eliminarla." }, { status: 409 });
    }
    const removeOverlay = () => prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await assertTaskAvailable(tx, userId, calendarId, eventId);
      const current = await tx.mealPlan.findFirst({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId }, include: { overlay: true } });
      if (current?.completedAt || current?.overlay.completedAt) throw new MealCalendarError("Deshaz el completado de esta comida antes de eliminarla.");
      await deleteScheduledChildren(tx, userId, { calendarId, eventId });
      await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId } });
      await unlinkScheduledEvent(tx, userId, calendarId, eventId, true);
      return tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId } });
    });
    let currentEvent;
    try {
      const response = await calendar.events.get({ calendarId, eventId });
      currentEvent = response.data;
    } catch (error) {
      if (![404, 410].includes(googleStatus(error)!)) throw error;
      await removeOverlay();
      return new Response(null, { status: 204, headers: { "Cache-Control": "private, no-store" } });
    }

    if (!currentEvent.etag || currentEvent.etag !== expectedEtag) {
      return NextResponse.json({ error: "Este evento cambió en Google Calendar. Recarga la semana antes de eliminarlo." }, { status: 409 });
    }

    if (linkedMeal) {
      await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        const current = await tx.mealPlan.findFirst({ where: { id: linkedMeal.id, userId }, include: { overlay: true } });
        if (current?.completedAt || current?.overlay.completedAt || current?.overlay.purgeStartedAt) throw new MealCalendarError("La comida cambió de estado. Deshaz el completado antes de eliminarla.");
        await deleteScheduledChildren(tx, userId, { calendarId, eventId });
        try { await calendar.events.delete({ calendarId, eventId, sendUpdates: "none" }, { headers: { "If-Match": currentEvent.etag! } }); }
        catch (error) { if (googleStatus(error) !== 404) throw error; }
        if (current) await tx.eventOverlay.delete({ where: { id: current.overlayId } });
      }, { timeout: 15000 });
      return new Response(null, { status: 204, headers: { "Cache-Control": "private, no-store" } });
    }

    await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      await assertTaskAvailable(tx, userId, calendarId, eventId);
      const latest = (await calendar.events.get({ calendarId, eventId })).data;
      if (latest.etag !== expectedEtag) throw new ScheduledSubtaskError("Este evento cambió en Google. Actualiza antes de eliminarlo.");
      await deleteScheduledChildren(tx, userId, { calendarId, eventId });
      try { await calendar.events.delete({ calendarId, eventId, sendUpdates: "none" }, { headers: { "If-Match": latest.etag! } }); }
      catch (error) { if (![404, 410].includes(googleStatus(error)!)) throw error; }
      await unlinkScheduledEvent(tx, userId, calendarId, eventId, true);
      await tx.activityChecklist.deleteMany({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId } });
      await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: calendarId, googleEventId: eventId } });
    }, { timeout: 30000 });
    return new Response(null, { status: 204, headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    const status = googleStatus(error);
    if (status === 404) {
      return NextResponse.json({ error: "Ese calendario ya no está disponible." }, { status: 404 });
    }
    if (status === 403) {
      return NextResponse.json({ error: "Google no permitió eliminar este evento." }, { status: 403 });
    }
    if (status === 412) {
      return NextResponse.json({ error: "Este evento cambió en Google Calendar. Recarga la semana antes de eliminarlo." }, { status: 409 });
    }
    return NextResponse.json({ error: "No pudimos eliminar el evento de Google Calendar." }, { status: 502 });
  }
}



