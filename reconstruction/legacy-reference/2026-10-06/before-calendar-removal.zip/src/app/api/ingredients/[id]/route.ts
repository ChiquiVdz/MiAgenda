import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { IngredientChangeError, ingredientUsage, removeIngredient } from "@/lib/ingredient-lifecycle";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Context) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  const { id } = await params;
  const ingredient = await prisma.ingredient.findFirst({ where: { id, OR: [{ catalogScope: "global" }, { ownerUserId: userId }] } });
  if (!ingredient) return NextResponse.json({ error: "Ingrediente no encontrado." }, { status: 404 });
  const usage = await prisma.$transaction((tx) => ingredientUsage(tx, userId, id));
  return NextResponse.json({ usage }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function DELETE(request: Request, { params }: Context) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  const body = await request.json().catch(() => null);
  if (!body || !["remove", "replace", "create"].includes(body.action)
    || (body.action === "replace" && (typeof body.replacementId !== "string" || !body.replacementId.trim() || body.replacementId.length > 30))
    || (body.action === "create" && (typeof body.newName !== "string" || !body.newName.trim()))) return NextResponse.json({ error: "Elige cómo eliminar el ingrediente." }, { status: 400 });
  const { id } = await params;
  try {
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      return removeIngredient(tx, userId, id, body.action === "replace" ? { replacementId: body.replacementId } : body.action === "create" ? { newName: body.newName } : {});
    }, { isolationLevel: "Serializable", timeout: 15000 });
    return NextResponse.json(result);
  } catch (error) {
    if (error instanceof IngredientChangeError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (typeof error === "object" && error && "code" in error && ["P2034", "P2002"].includes(String(error.code))) return NextResponse.json({ error: "Los datos cambiaron mientras se eliminaba el ingrediente. Recarga e inténtalo de nuevo." }, { status: 409 });
    return NextResponse.json({ error: "No pudimos eliminar el ingrediente; no se aplicaron cambios." }, { status: 500 });
  }
}
