import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { readMealState } from "@/lib/meal-state";
import { projectMeals, mealTime } from "@/lib/meal-availability";
import { recipeSteps } from "@/lib/recipe-steps";

export const runtime = "nodejs";
const MAX_MISSING_INGREDIENTS = 3;

function roundToUnitPrecision(value: number) {
  return Math.round(value * 1000) / 1000;
}

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para ver sugerencias." }, { status: 401 });
  const query = new URL(request.url).searchParams;
  const includeAll = query.get("includeAll") === "true";
  const reservedIds = [...new Set(query.getAll("reservedPlanId"))];
  if (reservedIds.length > 200 || reservedIds.some((id) => !id || id.length > 30)) return NextResponse.json({ error: "No pudimos verificar las comidas planeadas." }, { status: 400 });

  const atValue = query.get("at");
  const at = atValue ? Date.parse(atValue) : null;
  const excludePlanId = query.get("excludePlanId");
  const excludeOverlayId = query.get("excludeOverlayId");
  if ((atValue && !Number.isFinite(at)) || (excludePlanId && excludePlanId.length > 30)) return NextResponse.json({ error: "Revisa el horario del plan." }, { status: 400 });
  const { recipes, state } = await prisma.$transaction(async (tx) => ({
    recipes: await tx.recipe.findMany({ where: { userId }, include: { ingredients: { include: { ingredient: { select: { id: true, name: true, unit: true } } } } } }),
    state: await readMealState(tx, userId),
  }), { isolationLevel: "RepeatableRead", timeout: 15000 });
  const earlier = state.plans.filter((plan) => plan.id !== excludePlanId && plan.overlayId !== excludeOverlayId && (at !== null ? mealTime(plan) <= at : reservedIds.includes(plan.id)));
  const projection = projectMeals(state.inventory, earlier, state.batches);
  const inventory = projection.inventory;

  const suggestions = recipes.map((recipe) => {
    const ingredients = recipe.ingredients.map((line) => {
      const requiredQuantity = roundToUnitPrecision(Number(line.quantityPerServing.toString()) * recipe.servings);
      const availableQuantity = inventory.get(line.ingredientId) ?? 0;
      const missingQuantity = roundToUnitPrecision(Math.max(0, requiredQuantity - availableQuantity));
      return {
        isOptional: line.isOptional, ingredientId: line.ingredientId,
        name: line.ingredient.name,
        unit: line.ingredient.unit,
        requiredQuantity,
        availableQuantity,
        missingQuantity,
        equivalent: line.equivalent,
      };
    });
    const missingCount = ingredients.filter((ingredient) => !ingredient.isOptional && ingredient.missingQuantity > 0).length;
    return {
      id: recipe.id,
      name: recipe.name,
      servings: recipe.servings,
      durationMinutes: recipe.durationMinutes,
      priorPreparations: recipeSteps(recipe.steps, recipe.instructions, recipe.ingredients)
        .filter((step) => step.priorTiming).map((step) => ({ id: step.id, text: step.text, isOptional: step.isOptional, priorTiming: step.priorTiming })),
      preparedServings: projection.portions.filter((batch) => batch.recipeKey === recipe.id
        && Date.parse(batch.cookedAt) <= (at ?? Date.now())).reduce((sum, batch) => sum + batch.remainingServings, 0),
      actualPreparedServings: projection.portions.filter((batch) => batch.actual && batch.recipeKey === recipe.id
        && Date.parse(batch.cookedAt) <= (at ?? Date.now())).reduce((sum, batch) => sum + batch.remainingServings, 0),
      missingCount,
      ingredients,
    };
  }).filter((recipe) => includeAll || recipe.missingCount <= MAX_MISSING_INGREDIENTS)
    .sort((a, b) => a.missingCount - b.missingCount || a.name.localeCompare(b.name, "es"));

  return NextResponse.json({ suggestions, maxMissingIngredients: MAX_MISSING_INGREDIENTS }, {
    headers: { "Cache-Control": "private, no-store" },
  });
}
