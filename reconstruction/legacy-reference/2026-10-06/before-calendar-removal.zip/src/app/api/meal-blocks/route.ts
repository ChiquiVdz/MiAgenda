import { createHash } from "node:crypto";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { cookingCalendar, CalendarManagementError } from "@/lib/calendar-management";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { combinedCookingMinutes } from "@/lib/calendar-adjustment";
import type { calendar_v3 } from "googleapis";
import { preparationSteps, snapshotRecipeSteps } from "@/lib/recipe-steps";
import { syncMealStepChildren, linkedMealSteps } from "@/lib/meal-step-links";
import { deleteScheduledChildren } from "@/lib/scheduled-subtask-lifecycle";
import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
class BlockError extends Error { constructor(message: string, readonly status = 409) { super(message); } }
const statusOf = (error: unknown) => (error as { response?: { status?: number }; code?: number })?.response?.status ?? (error as { code?: number })?.code;
function failure(error: unknown) {
  if (error instanceof CalendarManagementError) return NextResponse.json({ error: error.message }, { status: error.status });
  if (error instanceof BlockError || error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status });
  if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
  if (statusOf(error) === 412) return NextResponse.json({ error: "La comida cambió en Google. Cierra y vuelve a abrir el bloque." }, { status: 409 });
  return NextResponse.json({ error: "No pudimos guardar o cargar el bloque. Puedes volver a intentarlo." }, { status: 502 });
}

export async function GET(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  try {
    const query = new URL(request.url).searchParams;
    const defaults = await prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { mealEatingMinutes: true, mealWashingMinutes: true } });
    if (!query.get("overlayId") && !query.get("eventId")) return NextResponse.json({ defaults, cookingCalendar: await cookingCalendar(userId) }, { headers });
    const block = await prisma.eventOverlay.findFirst({ where: { userId, kind: "meal",
      ...(query.get("overlayId") ? { id: query.get("overlayId")! } : { googleEventId: query.get("eventId")!, googleCalendarId: query.get("calendarId") ?? "" }) },
      include: { mealPlans: { orderBy: [{ createdAt: "asc" }, { id: "asc" }], include: { recipe: { select: { name: true } } } } } });
    if (!block) throw new BlockError("No encontramos esta comida.", 404);
    const calendar = await getGoogleCalendarClient(userId);
    const { data: event } = await calendar.events.get({ calendarId: block.googleCalendarId, eventId: block.googleEventId });
    if (event.status === "cancelled") throw new BlockError("La comida fue eliminada de Google.", 404);
    const remoteDuration = event.start?.dateTime && event.end?.dateTime ? Math.round((Date.parse(event.end.dateTime) - Date.parse(event.start.dateTime)) / 60000) : null;
    return NextResponse.json({ defaults, block: { ...block, etag: event.etag, startDateTime: event.start?.dateTime,
      mealDurationOverride: remoteDuration && remoteDuration !== block.mealPlans[0]?.durationMinutes ? remoteDuration : block.mealDurationOverride,
      mealCookingEnabled: block.mealBlockConfigured ? block.mealCookingEnabled : block.mealPlans[0]?.cookingEnabled ?? true } }, { headers });
  } catch (error) { return failure(error); }
}

type RecipeInput = { id?: string; recipeId: string; servings: number; cookedServings: number; preparationMinutes: number };
type Input = { overlayId?: string; version?: string; etag?: string; calendarId: string; startDateTime: string; mealSlotId: string | null;
  cookingEnabled: boolean; eatingEnabled: boolean; washingEnabled: boolean; eatingMinutes: number; washingMinutes: number;
  durationOverride: number | null; saveDefaults: boolean; recipes: RecipeInput[]; idempotencyKey: string };
function parse(value: unknown): Input {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new BlockError("Revisa los datos del bloque.", 400);
  const b = value as Input;
  const integer = (n: unknown, min: number, max: number) => typeof n === "number" && Number.isInteger(n) && n >= min && n <= max;
  const text = (s: unknown, max: number) => typeof s === "string" && s.length > 0 && s.length <= max;
  if (!text(b.calendarId, 1024) || !text(b.idempotencyKey, 100) || b.idempotencyKey.length < 16
    || typeof b.startDateTime !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(b.startDateTime) || !Number.isFinite(Date.parse(b.startDateTime))
    || ![b.cookingEnabled, b.eatingEnabled, b.washingEnabled, b.saveDefaults].every((v) => typeof v === "boolean")
    || (!b.cookingEnabled && !b.eatingEnabled && !b.washingEnabled)
    || !integer(b.eatingMinutes, b.eatingEnabled ? 1 : 0, 480) || !integer(b.washingMinutes, b.washingEnabled ? 1 : 0, 480)
    || (b.durationOverride !== null && !integer(b.durationOverride, 5, 1440))
    || (b.mealSlotId !== null && !text(b.mealSlotId, 30))
    || !Array.isArray(b.recipes) || !b.recipes.length || b.recipes.length > 12
    || b.recipes.some((r) => !r || !text(r.recipeId, 30) || (r.id !== undefined && !text(r.id, 30)) || !integer(r.servings, 1, 100) || !integer(r.cookedServings, b.cookingEnabled ? 1 : 0, 100) || !integer(r.preparationMinutes, 5, 480))
    || new Set(b.recipes.map((r) => r.recipeId)).size !== b.recipes.length
    || (b.overlayId !== undefined && (!text(b.overlayId, 30) || !text(b.etag, 300) || !text(b.version, 50)))) throw new BlockError("Revisa las recetas, porciones, fases y tiempos del bloque.", 400);
  return b;
}

async function save(request: Request, editing: boolean) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.startsWith("application/json")) return NextResponse.json({ error: "Formato no válido." }, { status: 415 });
  try {
    const body = parse(await request.json());
    if (editing !== Boolean(body.overlayId)) throw new BlockError("Revisa el bloque que deseas editar.", 400);
    const duration = body.durationOverride ?? ((body.cookingEnabled ? combinedCookingMinutes(body.recipes.map((r) => r.preparationMinutes)) : 0)
      + (body.eatingEnabled ? body.eatingMinutes : 0) + (body.washingEnabled ? body.washingMinutes : 0));
    if (duration < 5 || duration > 1440) throw new BlockError("El bloque debe durar entre 5 minutos y un día.", 400);
    const calendar = await getGoogleCalendarClient(userId);
    const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId: body.calendarId });
    if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) throw new BlockError("Necesitas permiso para escribir en este calendario.", 403);
    const googleEventId = `meal${createHash("sha256").update(`${userId}\0${body.calendarId}\0${body.idempotencyKey}`).digest("hex").slice(0, 40)}`;
    const fingerprint = createHash("sha256").update(JSON.stringify(body)).digest("hex");
    let compensation: { old: calendar_v3.Schema$Event; etag: string; eventId: string } | undefined;
    try {
      const result = await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        if (!editing) {
          const binding = await tx.calendarSubscription.findFirst({ where: { userId, isMeals: true } });
          if (binding?.googleCalendarId !== body.calendarId) throw new BlockError("Configura el calendario de Cocina y vuelve a abrir la comida.");
        }
        const existing = editing ? await tx.eventOverlay.findFirst({ where: { id: body.overlayId, userId }, include: { mealPlans: { include: { ingredients: true } } } }) : null;
        if (editing && (!existing || existing.kind !== "meal" || existing.googleCalendarId !== body.calendarId)) throw new BlockError("No encontramos este bloque en el calendario.", 404);
        if (existing && (existing.completedAt || existing.purgeStartedAt || existing.mealPlans.some((p) => p.completedAt))) throw new BlockError("Deshaz el completado antes de editar el bloque.");
        if (existing && existing.updatedAt.toISOString() !== body.version) throw new BlockError("El bloque cambió. Cierra y vuelve a abrirlo antes de editar.");
        if (!editing) {
          const repeated = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: body.calendarId, googleEventId } } });
          if (repeated) return { overlayId: repeated.id, googleEventId, repeated: true };
        }
        if (body.mealSlotId && !await tx.mealSlot.findFirst({ where: { id: body.mealSlotId, userId } })) throw new BlockError("La fila del planificador ya no existe.");
        const recipes = await tx.recipe.findMany({ where: { userId, id: { in: body.recipes.map((r) => r.recipeId) } }, include: { ingredients: { include: { ingredient: true } } } });
        if (recipes.length !== body.recipes.length || recipes.some((r) => !r.ingredients.length)) throw new BlockError("Una receta ya no está disponible o no tiene ingredientes.");
        const planIds = body.recipes.flatMap((r) => r.id ? [r.id] : []);
        if (new Set(planIds).size !== planIds.length || planIds.some((id) => !existing?.mealPlans.some((p) => p.id === id))) throw new BlockError("Las recetas del bloque cambiaron. Vuelve a abrirlo.");
        const rows = body.recipes.map((input) => {
          const recipe = recipes.find((r) => r.id === input.recipeId)!;
          const previous = existing?.mealPlans.find((plan) => plan.id === input.id && plan.recipeId === input.recipeId);
          const cookedServings = body.cookingEnabled ? input.cookedServings : 0;
          const source = previous ? previous.ingredients.map((line) => ({ ...line, ingredient: { name: line.nameSnapshot, unit: line.unit } })) : recipe.ingredients;
          const ingredients = source.map((line) => ({ ingredientId: line.ingredientId, nameSnapshot: line.ingredient.name, unit: line.ingredient.unit,
            isOptional: line.isOptional, quantityPerServing: line.quantityPerServing,
            requiredQuantity: Math.round(Number(line.quantityPerServing) * cookedServings * 1000) / 1000 }));
          if (ingredients.some((line) => !Number.isFinite(line.requiredQuantity) || line.requiredQuantity > 999999999.999)) throw new BlockError("Las cantidades superan el límite de inventario.", 400);
          const steps = previous && Array.isArray(previous.preparationSteps) ? preparationSteps(previous.preparationSteps) : snapshotRecipeSteps(recipe, source);
          return { input, recipe, cookedServings, ingredients, steps };
        });
        const eventId = existing?.googleEventId ?? googleEventId;
        const eventBody: calendar_v3.Schema$Event = { summary: rows.map((r) => r.recipe.name).join(" + ").slice(0, 250),
          start: { dateTime: body.startDateTime, timeZone: "America/Mexico_City" },
          end: { dateTime: new Date(Date.parse(body.startDateTime) + duration * 60000).toISOString(), timeZone: "America/Mexico_City" } };
        let event: calendar_v3.Schema$Event;
        if (existing) {
          const { data: current } = await calendar.events.get({ calendarId: body.calendarId, eventId });
          if (current.status === "cancelled" || current.etag !== body.etag) throw new BlockError("El evento cambió en Google. Cierra y vuelve a abrirlo.");
          event = (await calendar.events.patch({ calendarId: body.calendarId, eventId, requestBody: eventBody }, { headers: { "If-Match": body.etag! } })).data;
          if (event.etag) compensation = { old: current, etag: event.etag, eventId };
        } else {
          try { event = (await calendar.events.insert({ calendarId: body.calendarId, requestBody: { ...eventBody, id: eventId, extendedProperties: { private: { miagendaMealPlan: "1", blockRequest: fingerprint } } } })).data; }
          catch (error) {
            if (statusOf(error) !== 409) throw error;
            event = (await calendar.events.get({ calendarId: body.calendarId, eventId })).data;
            if (event.status === "cancelled" || event.extendedProperties?.private?.blockRequest !== fingerprint) throw new BlockError("Este intento ya cambió. Cierra el formulario y vuelve a crear el bloque.");
          }
        }
        const data = { etag: event.etag ?? null, mealBlockConfigured: true, mealCookingEnabled: body.cookingEnabled,
          mealEatingEnabled: body.eatingEnabled, mealWashingEnabled: body.washingEnabled, mealEatingMinutes: body.eatingMinutes,
          mealWashingMinutes: body.washingMinutes, mealDurationOverride: body.durationOverride };
        const overlay = existing ? await tx.eventOverlay.update({ where: { id: existing.id }, data })
          : await tx.eventOverlay.create({ data: { ...data, userId, googleCalendarId: body.calendarId, googleEventId: eventId, kind: "meal" } });
        if (existing) {
          const replaced = existing.mealPlans.filter((plan) => body.recipes.some((row) => row.id === plan.id && row.recipeId !== plan.recipeId));
          await deleteScheduledChildren(tx, userId, { calendarId: body.calendarId, eventId }, linkedMealSteps(replaced).map((step) => step.id));
        }
        if (existing) await tx.mealPlan.deleteMany({ where: { userId, overlayId: overlay.id, id: { notIn: planIds } } });
        for (const row of rows) {
          const planData = { recipeId: row.recipe.id, mealSlotId: body.mealSlotId, servings: row.input.servings, cookedServings: row.cookedServings,
            preparationSteps: row.steps,
            cookingEnabled: body.cookingEnabled, preparationMinutes: row.input.preparationMinutes, durationMinutes: duration,
            scheduledAt: new Date(body.startDateTime), eventMissing: false };
          if (row.input.id) {
            await tx.mealPlan.update({ where: { id: row.input.id }, data: planData });
            await tx.mealPlanIngredient.deleteMany({ where: { mealPlanId: row.input.id } });
            await tx.mealPlanIngredient.createMany({ data: row.ingredients.map((line) => ({ ...line, mealPlanId: row.input.id! })) });
          } else await tx.mealPlan.create({ data: { ...planData, userId, overlayId: overlay.id, googleCalendarId: body.calendarId, googleEventId: eventId,
            idempotencyKey: createHash("sha256").update(`${body.idempotencyKey}:${row.recipe.id}`).digest("hex"), ingredients: { create: row.ingredients } } });
        }
        if (body.saveDefaults) await tx.user.update({ where: { id: userId }, data: { mealEatingMinutes: body.eatingMinutes, mealWashingMinutes: body.washingMinutes } });
        if (existing) await syncMealStepChildren(tx, userId, overlay.id);
        return { overlayId: overlay.id, googleEventId: eventId };
      }, { timeout: 30000 });
      return NextResponse.json(result, { headers, status: editing ? 200 : 201 });
    } catch (error) {
      if (compensation) {
        const c = compensation;
        try { await calendar.events.patch({ calendarId: body.calendarId, eventId: c.eventId, requestBody: { summary: c.old.summary, start: c.old.start, end: c.old.end } }, { headers: { "If-Match": c.etag } }); } catch { /* A newer remote edit must win. */ }
      }
      throw error;
    }
  } catch (error) { return failure(error); }
}
export async function POST(request: Request) { return save(request, false); }
export async function PATCH(request: Request) { return save(request, true); }


