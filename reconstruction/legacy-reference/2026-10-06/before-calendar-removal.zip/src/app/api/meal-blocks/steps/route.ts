import { readMealPreparation as readBlock, mealPreparationState as state, markMealPreparation, MealStepError as StepError } from "@/lib/meal-preparation";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { MealActionError } from "@/lib/meal-portions";
import { preparationSteps } from "@/lib/recipe-steps";
import { syncMealSchedules } from "@/lib/meal-state";
import { reconcileScheduledSubtasks } from "@/lib/scheduled-subtask-lifecycle";
import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";



export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
async function handle(request: Request, changing: boolean) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (changing && request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  if (changing && !request.headers.get("content-type")?.startsWith("application/json")) return NextResponse.json({ error: "Envía JSON." }, { status: 415 });
  const query = new URL(request.url).searchParams;
  const body = changing ? await request.json().catch(() => null) : { calendarId: query.get("calendarId"), eventId: query.get("eventId") };
  if (!body || typeof body.calendarId !== "string" || !body.calendarId || body.calendarId.length > 1024 || typeof body.eventId !== "string" || !body.eventId || body.eventId.length > 1024
    || changing && (typeof body.planId !== "string" || body.planId.length > 30 || typeof body.stepId !== "string" || body.stepId.length > 100 || typeof body.completed !== "boolean" || typeof body.version !== "string" || body.version.length !== 64 || typeof body.etag !== "string")) {
    return NextResponse.json({ error: "Revisa la comida y el paso." }, { status: 400 });
  }
  try {
    const calendar = await getGoogleCalendarClient(userId);
    let completionPrepared = false;
    if (changing) {
      const remote = (await calendar.calendarList.get({ calendarId: body.calendarId })).data;
      if (!["owner", "writer"].includes(remote.accessRole ?? "")) throw new StepError("Necesitas permiso para modificar esta comida.", 403);
      // Only finishing the block needs the full chronological stock/schedule refresh.
      if (body.completed) {
        const plans = await prisma.mealPlan.findMany({ where: { userId, googleCalendarId: body.calendarId, googleEventId: body.eventId, cookingEnabled: true }, select: { id: true, preparationSteps: true } });
        const required = plans.flatMap((plan) => preparationSteps(plan.preparationSteps).filter((step) => !step.isOptional).map((step) => step.completed || plan.id === body.planId && step.id === body.stepId));
        completionPrepared = required.length > 0 && required.every(Boolean);
        if (completionPrepared) await syncMealSchedules(userId, calendar);
      }
    }
    const event = (await calendar.events.get({ calendarId: body.calendarId, eventId: body.eventId })).data;
    if (event.status === "cancelled") throw new StepError("La comida ya no existe en Google.", 404);
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      if (!changing) await reconcileScheduledSubtasks(tx, userId, { parentCalendarId: body.calendarId, parentEventId: body.eventId });
      const block = await readBlock(tx, userId, body.calendarId, body.eventId);
      if (!changing) return { ...state(block), etag: event.etag, startDateTime: event.start?.dateTime };
      if (event.etag !== body.etag) throw new StepError("El horario cambió. Actualiza la comida antes de marcar pasos.");
      const plan = block.mealPlans.find((row) => row.id === body.planId && row.cookingEnabled);
      const steps = preparationSteps(plan?.preparationSteps);
      const step = steps.find((row) => row.id === body.stepId);
      if (!plan || !step) throw new StepError("El paso ya no está en esta preparación. Actualiza.");
      if (step.completed === body.completed) return { ...state(block), etag: event.etag, startDateTime: event.start?.dateTime };
      if (block.completedAt || block.mealPlans.some((row) => row.completedAt)) throw new StepError("Deshaz el completado del bloque antes de corregir sus pasos.");
      if (state(block).version !== body.version) throw new StepError("Los pasos cambiaron en otra ventana. Actualiza antes de continuar.");
      await markMealPreparation(tx, userId, block, plan.id, step.id, body.completed, event, completionPrepared);
      return { ...state(await readBlock(tx, userId, body.calendarId, body.eventId)), etag: event.etag, startDateTime: event.start?.dateTime };
    }, { timeout: 30000 });
    return NextResponse.json(result, { headers });
  } catch (error) {
    if (error instanceof StepError || error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
    if (error instanceof MealActionError) return NextResponse.json({ error: `${error.message}${error.details?.length ? " " + error.details.map((line) => `${line.name}: faltan ${line.missingQuantity} ${line.unit}`).join("; ") : ""} No se descontó ningún ingrediente.` }, { status: 409, headers });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409, headers });
    return NextResponse.json({ error: "No pudimos guardar o cargar los pasos. Actualiza y reintenta." }, { status: 502, headers });
  }
}
export async function GET(request: Request) { return handle(request, false); }
export async function POST(request: Request) { return handle(request, true); }
