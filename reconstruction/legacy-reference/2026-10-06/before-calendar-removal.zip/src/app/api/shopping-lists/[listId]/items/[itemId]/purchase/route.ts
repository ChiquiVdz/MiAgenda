import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { purchaseItem, undoPurchase, ShoppingPurchaseError } from "@/lib/shopping-purchase";

export const runtime = "nodejs";
type Context = { params: Promise<{ listId: string; itemId: string }> };

async function changePurchase(request: Request, context: Context, undo: boolean) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para gestionar tus compras." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  const body = undo ? null : await request.json().catch(() => null);
  const quantity: unknown = body?.quantity;
  if (!undo && (typeof quantity !== "number" || !Number.isFinite(quantity) || quantity <= 0 || quantity > 999_999_999.999 || Number(quantity.toFixed(3)) !== quantity)) {
    return NextResponse.json({ error: "Indica una cantidad positiva con hasta tres decimales." }, { status: 400 });
  }
  const { listId, itemId } = await context.params;
  try {
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      return undo ? undoPurchase(tx, userId, listId, itemId) : purchaseItem(tx, userId, listId, itemId, quantity as number);
    });
    return NextResponse.json(result, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof ShoppingPurchaseError) return NextResponse.json({ error: error.message }, { status: error.status });
    return NextResponse.json({ error: "No pudimos actualizar esa compra." }, { status: 500 });
  }
}

export async function POST(request: Request, context: Context) { return changePurchase(request, context, false); }
export async function DELETE(request: Request, context: Context) { return changePurchase(request, context, true); }
