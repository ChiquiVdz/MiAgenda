import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { syncPlannedShopping } from "@/lib/planned-shopping";
import { syncMealSchedules } from "@/lib/meal-state";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";

export const runtime = "nodejs";
export async function POST(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para actualizar la lista." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) return NextResponse.json({ error: "El formato no es válido." }, { status: 415 });
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 400 });
  try {
    await syncMealSchedules(userId, await getGoogleCalendarClient(userId));
    const list = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      return syncPlannedShopping(tx, userId);
    }, { timeout: 30000 });
    return NextResponse.json({ list: { ...list, items: list.items.map((item) => ({ ...item, quantity: item.quantity.toString(),
      requiredQuantity: item.requiredQuantity?.toString() ?? null, optionalQuantity: item.optionalQuantity?.toString() ?? null,
      purchasedQuantity: item.purchasedQuantity?.toString() ?? null })) } }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    if (error instanceof Error && error.message === "AMOUNT_OUT_OF_RANGE") return NextResponse.json({ error: "La cantidad total supera el límite permitido." }, { status: 400 });
    console.error("[planned-shopping] Failed", { name: error instanceof Error ? error.name : "UnknownError" });
    return NextResponse.json({ error: "No pudimos actualizar la lista de todas las comidas pendientes." }, { status: 502 });
  }
}
