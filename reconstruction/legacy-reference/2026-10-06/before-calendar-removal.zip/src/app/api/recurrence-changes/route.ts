import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { prepareChange, resumeChange, discardChange, type ChangeInput } from "@/lib/recurrence-change";
import { ChecklistError } from "@/lib/activity-checklist";
import { GoogleCalendarConnectionError } from "@/lib/google/calendar";
export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
export async function GET() {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  try {
    // Finished requests only retain an idempotency receipt for five days.
    await prisma.recurrenceChange.deleteMany({ where: { userId, finishedAt: { lt: new Date(Date.now() - 5 * 86400000) } } });
    return NextResponse.json({ pending: await prisma.recurrenceChange.findMany({ where: { userId, finishedAt: null }, select: { id: true }, orderBy: { createdAt: "asc" } }) }, { headers });
  } catch { return NextResponse.json({ error: "No pudimos consultar los cambios pendientes." }, { status: 502 }); }
}
export async function POST(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.includes("application/json")) return NextResponse.json({ error: "Envía JSON." }, { status: 415 });
  const body = await request.json().catch(() => null);
  try {
    if (typeof body?.discardId === "string") return NextResponse.json(await discardChange(userId, body.discardId), { headers });
    const id = typeof body?.resumeId === "string" ? body.resumeId : (await prepareChange(userId, body as ChangeInput)).id;
    return NextResponse.json(await resumeChange(userId, id), { headers });
  } catch (error) {
    if (error instanceof ChecklistError || error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    const status = Number((error as { code?: number; response?: { status?: number } }).response?.status ?? (error as { code?: number }).code);
    return NextResponse.json({ error: status === 412 ? "Google recibió otro cambio. Actualiza la tarea antes de reintentar." : "No pudimos terminar el cambio. Puedes reanudarlo desde Agenda sin duplicar la serie." }, { status: 409 });
  }
}
