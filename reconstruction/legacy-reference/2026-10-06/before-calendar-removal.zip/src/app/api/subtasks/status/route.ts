import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
export async function GET(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401, headers });
  const query = new URL(request.url).searchParams;
  const inboxId = query.get("inboxId"), calendarId = query.get("parentCalendarId"), eventId = query.get("parentEventId");
  if (inboxId ? !/^[\w-]{1,30}$/.test(inboxId) : !calendarId || calendarId.length > 1024 || !eventId || eventId.length > 1024)
    return NextResponse.json({ error: "Revisa la principal." }, { status: 400, headers });
  try {
    const links = await prisma.scheduledSubtask.findMany({ where: { userId, ...(inboxId ? { parentInboxId: inboxId } : { parentCalendarId: calendarId!, parentEventId: eventId! }) } });
    if (!links.length) return NextResponse.json({ schedules: {} }, { headers });
    const google = await getGoogleCalendarClient(userId);
    const schedules: Record<string, { pending: boolean; missing: boolean; startDateTime?: string | null; endDateTime?: string | null; startDate?: string | null; htmlLink?: string | null }> = {};
    // One request per expanded principal, with bounded Google concurrency.
    for (let index = 0; index < links.length; index += 5) {
      await Promise.all(links.slice(index, index + 5).map(async (link) => {
        if (!link.active) { schedules[link.stepId] = { pending: true, missing: false }; return; }
        try {
          const event = (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId, fields: "id,status,start,end,htmlLink" })).data;
          schedules[link.stepId] = { pending: Boolean(link.pendingPayload), missing: event.status === "cancelled", startDateTime: event.start?.dateTime,
            endDateTime: event.end?.dateTime, startDate: event.start?.date, htmlLink: event.htmlLink };
        } catch (error) {
          const code = Number((error as { response?: { status?: number }; code?: number }).response?.status ?? (error as { code?: number }).code);
          if (![404, 410].includes(code)) throw error;
          schedules[link.stepId] = { pending: false, missing: true };
        }
      }));
    }
    return NextResponse.json({ schedules }, { headers });
  } catch (error) {
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409, headers });
    return NextResponse.json({ error: "No pudimos actualizar los horarios." }, { status: 502, headers });
  }
}
