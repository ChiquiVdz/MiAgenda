import { createHash, randomUUID } from "node:crypto";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";
import { authOptions } from "@/lib/auth";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { readChecklist, ChecklistError, type ActivityStep } from "@/lib/activity-checklist";
import { parentWhere, ScheduledSubtaskError, type SubtaskParent } from "@/lib/scheduled-subtask-state";
import { eventPurgeAfter } from "@/lib/google/event-retention";
import { deleteScheduledChildren, unlinkScheduledEvent } from "@/lib/scheduled-subtask-lifecycle";
import { readMealPreparation, mealPreparationState, MealStepError } from "@/lib/meal-preparation";
import { linkedMealSteps } from "@/lib/meal-step-links";
import { assertTaskAvailable, TaskActivityError } from "@/lib/task-activity";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
const status = (error: unknown) => Number((error as { response?: { status?: number } })?.response?.status);
const validText = (value: unknown, length: number): value is string => typeof value === "string" && value.length > 0 && value.length <= length;
function parseParent(body: Record<string, unknown>): SubtaskParent {
  if (validText(body.inboxId, 30)) return { inboxId: body.inboxId };
  if (validText(body.parentCalendarId, 1024) && validText(body.parentEventId, 1024)) return { calendarId: body.parentCalendarId, eventId: body.parentEventId };
  throw new ChecklistError("Revisa la tarea principal.", 400);
}
async function handle(request: Request, saving: boolean) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (saving && request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  if (saving && !request.headers.get("content-type")?.startsWith("application/json")) return NextResponse.json({ error: "Envía JSON." }, { status: 415 });
  try {
    const body = saving ? await request.json() : Object.fromEntries(new URL(request.url).searchParams);
    if (!body || typeof body !== "object") throw new ChecklistError("Revisa la subtarea.", 400);
    const parent = parseParent(body);
    if (!validText(body.stepId, 100)) throw new ChecklistError("Elige una subtarea guardada.", 400);
    const google = await getGoogleCalendarClient(userId);
    const parentEvent = "calendarId" in parent ? (await google.events.get({ calendarId: parent.calendarId, eventId: parent.eventId })).data : null;
    if (parentEvent?.status === "cancelled") throw new ChecklistError("La principal ya no existe.", 404);
    if (saving && parentEvent?.recurrence?.length && !parentEvent.recurringEventId) throw new ChecklistError("Abre una instancia concreta.");
    let completed = false;
    const prepared = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      if (saving && "calendarId" in parent) await assertTaskAvailable(tx, userId, parent.calendarId, parent.eventId);
      if (await tx.recurrenceChange.count({ where: { userId, finishedAt: null } })) throw new ChecklistError("Termina el cambio pendiente de la serie antes de programar subtareas.");
      let steps: ActivityStep[], version: string, title: string;
      let mealParent = false;
      if ("inboxId" in parent) {
        const item = await tx.inboxItem.findFirst({ where: { userId, id: parent.inboxId, transferredAt: null } });
        if (!item || item.transferPayload) throw new ChecklistError("Actualiza Inbox o termina su traslado.");
        steps = Array.isArray(item.checklist) ? item.checklist as unknown as ActivityStep[] : [];
        version = item.updatedAt.toISOString(); title = item.text;
      } else {
        const overlay = await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: parent.calendarId, googleEventId: parent.eventId } } });
        mealParent = overlay?.kind === "meal";
        if (mealParent) {
          const block = await readMealPreparation(tx, userId, parent.calendarId, parent.eventId);
          steps = linkedMealSteps(block.mealPlans); version = mealPreparationState(block).version;
        } else {
          const state = await readChecklist(tx, userId, parent.calendarId, parentEvent!);
          if (state.overlay?.purgeStartedAt) throw new ChecklistError("La retención está procesando la principal.");
          steps = state.steps; version = state.version;
        }
        title = parentEvent?.summary ?? "Tarea";
        if (saving) {
          const role = (await google.calendarList.get({ calendarId: parent.calendarId })).data.accessRole;
          if (!["owner", "writer"].includes(role ?? "")) throw new ChecklistError("Necesitas permiso para modificar la principal.", 403);
        }
      }
      const step = steps.find((item) => item.id === body.stepId);
      if (!step) throw new ChecklistError("Guarda la subtarea antes de programarla.");
      completed = step.completed;
      const existing = await tx.scheduledSubtask.findFirst({ where: { userId, ...parentWhere(parent), stepId: step.id } });
      if (!saving) return existing;
      if (existing?.pendingPayload) return existing;
      if (body.version !== version) throw new ChecklistError("La tarea cambió. Actualiza antes de programar.");
      if (!validText(body.calendarId, 1024) || !validText(body.startDateTime, 64) || !validText(body.endDateTime, 64)
        || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/.test(body.startDateTime)
        || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/.test(body.endDateTime)
        || !Number.isFinite(Date.parse(body.startDateTime)) || !Number.isFinite(Date.parse(body.endDateTime)) || Date.parse(body.endDateTime) <= Date.parse(body.startDateTime)) throw new ChecklistError("Elige fecha y hora final posterior al inicio.", 400);
      const calendarId = existing?.googleCalendarId ?? ("calendarId" in parent ? parent.calendarId : body.calendarId);
      if (existing && body.calendarId !== calendarId) throw new ChecklistError("Edita el horario en su calendario actual.");
      const role = (await google.calendarList.get({ calendarId })).data.accessRole;
      if (!["owner", "writer"].includes(role ?? "")) throw new ChecklistError("Elige un calendario editable.", 403);
      const parentKey = createHash("sha256").update(JSON.stringify(parent)).digest("hex");
      const eventId = existing?.googleEventId ?? `sub${randomUUID().replaceAll("-", "")}`;
      const payload = { startDateTime: body.startDateTime, endDateTime: body.endDateTime, text: step.text, title, etag: body.etag ?? null };
      if (existing) return tx.scheduledSubtask.update({ where: { id: existing.id }, data: { pendingPayload: payload } });
      if (parentEvent && !mealParent) {
        const key = { userId, googleCalendarId: (parent as { calendarId: string }).calendarId, googleEventId: parentEvent.id! };
        await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key }, create: { ...key, kind: "app_task", checklist: steps }, update: { checklist: steps } });
      }
      return tx.scheduledSubtask.create({ data: { userId, parentKey, stepId: step.id,
        parentInboxId: "inboxId" in parent ? parent.inboxId : null, parentCalendarId: "calendarId" in parent ? parent.calendarId : null,
        parentEventId: "eventId" in parent ? parent.eventId : null,
        googleCalendarId: calendarId, googleEventId: eventId, endSnapshot: new Date(body.endDateTime),
        parentEndSnapshot: parentEvent?.end?.dateTime ? new Date(parentEvent.end.dateTime) : parentEvent?.end?.date ? new Date(`${parentEvent.end.date}T00:00:00-06:00`) : null,
        pendingPayload: payload } });
    }, { timeout: 30000 });
    if (!prepared) return NextResponse.json({ scheduled: null }, { headers });
    if (!saving && !prepared.active) return NextResponse.json({ scheduled: { pending: true, calendarId: prepared.googleCalendarId } }, { headers });
    let event = null;
    if (saving) {
      event = await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        const link = await tx.scheduledSubtask.findFirstOrThrow({ where: { id: prepared.id, userId } });
        const payload = link.pendingPayload as { startDateTime: string; endDateTime: string; text: string; title: string; etag: string | null } | null;
        if (!payload) return (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId })).data;
        const owner = link.parentInboxId ? await tx.inboxItem.findFirst({ where: { userId, id: link.parentInboxId, transferredAt: null } }) : link.parentCalendarId && link.parentEventId
          ? await tx.eventOverlay.findUnique({ where: { userId_googleCalendarId_googleEventId: { userId, googleCalendarId: link.parentCalendarId, googleEventId: link.parentEventId } } }) : null;
        if (!owner || "purgeStartedAt" in owner && owner.purgeStartedAt) throw new ChecklistError("La principal cambió o está siendo eliminada. Actualiza antes de continuar.");
        const currentSteps = "kind" in owner && owner.kind === "meal"
          ? linkedMealSteps(await tx.mealPlan.findMany({ where: { userId, overlayId: owner.id } }))
          : Array.isArray(owner.checklist) ? owner.checklist as unknown as ActivityStep[] : [];
        const currentStep = currentSteps.find((step) => step.id === link.stepId);
        if (!currentStep) throw new ChecklistError("Este paso fue eliminado o la comida cambió de receta. Actualiza.");
        if (link.parentCalendarId && link.parentEventId) {
          const liveParent = (await google.events.get({ calendarId: link.parentCalendarId, eventId: link.parentEventId })).data;
          if (liveParent.status === "cancelled") throw new ChecklistError("La principal ya no existe en Google. Actualiza.");
        }
        let remote;
        try { remote = (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId })).data; }
        catch (error) { if (status(error) !== 404) throw error; }
        if (remote?.status === "cancelled") throw new ChecklistError("El evento fue eliminado. Actualiza y quita su vínculo antes de volver a programar.");
        const requestBody = { summary: payload.text.slice(0, 250), description: `Subtarea de: ${payload.title}\n\n${payload.text}`,
          start: { dateTime: payload.startDateTime, timeZone: "America/Mexico_City" }, end: { dateTime: payload.endDateTime, timeZone: "America/Mexico_City" },
          extendedProperties: { private: { miagendaSubtask: link.id } } };
        if (remote && remote.extendedProperties?.private?.miagendaSubtask !== link.id) throw new ChecklistError("El evento cambió de identidad. Actualiza.");
        const matches = remote?.start?.dateTime && Date.parse(remote.start.dateTime) === Date.parse(payload.startDateTime) && remote?.end?.dateTime && Date.parse(remote.end.dateTime) === Date.parse(payload.endDateTime) && remote.summary === payload.text.slice(0, 250);
        if (remote && !link.active && !matches) throw new ChecklistError("El evento del guardado pendiente cambió en Google. Quita su horario y vuelve a programarlo.");
        if (remote && link.active && !matches && (!payload.etag || remote.etag !== payload.etag)) {
          await tx.scheduledSubtask.update({ where: { id: link.id }, data: { pendingPayload: Prisma.DbNull } });
          return { ...remote, scheduleConflict: true };
        }
        if (!remote) {
          try { remote = (await google.events.insert({ calendarId: link.googleCalendarId, requestBody: { id: link.googleEventId, ...requestBody } })).data; }
          catch (error) { if (status(error) !== 409) throw error; remote = (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId })).data; }
        } else if (!matches) remote = (await google.events.patch({ calendarId: link.googleCalendarId, eventId: link.googleEventId, requestBody }, { headers: { "If-Match": remote.etag! } })).data;
        const key = { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId };
        const done = currentStep.completed ? new Date() : null;
        const overlay = await tx.eventOverlay.upsert({ where: { userId_googleCalendarId_googleEventId: key },
          create: { ...key, kind: "app_task", completedAt: done, purgeAfter: done ? eventPurgeAfter(done, remote.end) : null, etag: remote.etag }, update: { etag: remote.etag } });
        await tx.eventOverlay.update({ where: { id: overlay.id }, data: { purgeAfter: overlay.completedAt ? eventPurgeAfter(overlay.completedAt, remote.end) : null } });
        await tx.scheduledSubtask.update({ where: { id: link.id }, data: { active: true, endSnapshot: new Date(remote.end!.dateTime!), pendingPayload: Prisma.DbNull } });
        return remote;
      }, { timeout: 30000 });
      if ("scheduleConflict" in event) throw new ChecklistError("El horario cambió en Google. Actualiza antes de modificarlo.");
    } else {
      try { event = (await google.events.get({ calendarId: prepared.googleCalendarId, eventId: prepared.googleEventId })).data; }
      catch (error) { if (![404, 410].includes(status(error))) throw error; }
    }
    return NextResponse.json({ scheduled: { calendarId: prepared.googleCalendarId, eventId: prepared.googleEventId, pending: Boolean(!saving && prepared.pendingPayload),
      missing: !event || event.status === "cancelled", startDateTime: event?.start?.dateTime ?? null, endDateTime: event?.end?.dateTime ?? null, etag: event?.etag ?? null } }, { headers });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
    if (error instanceof ChecklistError || error instanceof ScheduledSubtaskError || error instanceof MealStepError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409, headers });
    return NextResponse.json({ error: "No pudimos programar la subtarea. Actualiza y reintenta; se recuperará el mismo evento." }, { status: 502, headers });
  }
}
export async function GET(request: Request) { return handle(request, false); }
export async function POST(request: Request) { return handle(request, true); }
export async function DELETE(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin || !request.headers.get("content-type")?.startsWith("application/json")) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  try {
    const body = await request.json();
    const parent = parseParent(body);
    if (!validText(body.stepId, 100)) throw new ChecklistError("Elige una subtarea.", 400);
    const google = await getGoogleCalendarClient(userId);
    await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      if ("calendarId" in parent) await assertTaskAvailable(tx, userId, parent.calendarId, parent.eventId);
      const link = await tx.scheduledSubtask.findFirst({ where: { userId, ...parentWhere(parent), stepId: body.stepId } });
      if (!link) return;
      const role = (await google.calendarList.get({ calendarId: link.googleCalendarId })).data.accessRole;
      if (!["owner", "writer"].includes(role ?? "")) throw new ChecklistError("Necesitas permiso para quitar el evento.", 403);
      let event;
      try { event = (await google.events.get({ calendarId: link.googleCalendarId, eventId: link.googleEventId })).data; }
      catch (error) { if (![404, 410].includes(status(error))) throw error; }
      if (event && event.status !== "cancelled") {
        if (event.extendedProperties?.private?.miagendaSubtask !== link.id || link.active && event.etag !== body.etag) throw new ChecklistError("El evento cambió. Actualiza su horario antes de quitarlo.");
      }
      await deleteScheduledChildren(tx, userId, { calendarId: link.googleCalendarId, eventId: link.googleEventId });
      if (event && event.status !== "cancelled") {
        try { await google.events.delete({ calendarId: link.googleCalendarId, eventId: link.googleEventId, sendUpdates: "none" }, { headers: { "If-Match": event.etag! } }); }
        catch (error) { if (![404, 410].includes(status(error))) throw error; }
      }
      await tx.eventOverlay.deleteMany({ where: { userId, googleCalendarId: link.googleCalendarId, googleEventId: link.googleEventId } });
      await unlinkScheduledEvent(tx, userId, link.googleCalendarId, link.googleEventId);
    }, { timeout: 30000 });
    return NextResponse.json({ scheduled: null }, { headers });
  } catch (error) {
    if (error instanceof TaskActivityError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
    if (error instanceof ChecklistError || error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
    return NextResponse.json({ error: "No pudimos quitar el horario. Actualiza y reintenta." }, { status: 502, headers });
  }
}
