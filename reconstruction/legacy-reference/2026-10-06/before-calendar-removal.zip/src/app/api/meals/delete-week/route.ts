import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { syncMealSchedules } from "@/lib/meal-state";
import { addWeekDays, validMonday, mexicoCopyDateTime } from "@/lib/meal-week-copy";
import { copyGoogleStatus, WeekCopyError } from "@/lib/meal-week-copy-service";
import { cleanupMealRecords } from "@/lib/meal-record-cleanup";
import { syncPlannedShopping } from "@/lib/planned-shopping";
import { deleteScheduledChildren } from "@/lib/scheduled-subtask-lifecycle";
import { ScheduledSubtaskError } from "@/lib/scheduled-subtask-state";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
export async function POST(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para eliminar comidas." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) return NextResponse.json({ error: "El formato no es válido." }, { status: 415 });
  const body = await request.json().catch(() => null);
  if (!body || !validMonday(body.week) || !["preview", "delete", "finish"].includes(body.action)) return NextResponse.json({ error: "Revisa la semana elegida." }, { status: 400 });
  const week: string = body.week, end = addWeekDays(week, 7);
  try {
    if (body.action === "finish") {
      await syncMealSchedules(userId, await getGoogleCalendarClient(userId));
      await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        await cleanupMealRecords(tx, userId);
        await syncPlannedShopping(tx, userId);
      }, { timeout: 30000 });
      return NextResponse.json({ done: true }, { headers });
    }
    const calendar = await getGoogleCalendarClient(userId);
    if (body.action === "preview") {
      const events = await syncMealSchedules(userId, calendar);
      const overlays = await prisma.eventOverlay.findMany({ where: { userId, kind: "meal", mealPlans: { some: {
        scheduledAt: { gte: new Date(`${week}T00:00:00-06:00`), lt: new Date(`${end}T00:00:00-06:00`) },
      } } }, include: { mealPlans: { select: { id: true, completedAt: true } } }, orderBy: { id: "asc" } });
      const meals = overlays.map((overlay) => {
        const event = events.get(overlay.mealPlans[0]?.id);
        return { id: overlay.id, version: overlay.updatedAt.toISOString(), etag: event?.etag ?? null,
          summary: event?.summary ?? "Comida sin evento en Google", completed: Boolean(overlay.completedAt || overlay.mealPlans.some((plan) => plan.completedAt)) };
      });
      return NextResponse.json({ meals, pending: meals.filter((meal) => !meal.completed).length, completed: meals.filter((meal) => meal.completed).length }, { headers });
    }
    const target = body.target;
    if (!target || typeof target.id !== "string" || target.id.length > 30 || typeof target.version !== "string"
      || (target.etag !== null && (typeof target.etag !== "string" || target.etag.length > 1024))) throw new WeekCopyError("No pudimos verificar la comida confirmada.", 400);
    await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      const overlay = await tx.eventOverlay.findFirst({ where: { userId, id: target.id, kind: "meal" }, include: { mealPlans: true } });
      if (!overlay) return; // Retrying a successfully removed event is harmless.
      if (overlay.updatedAt.toISOString() !== target.version || overlay.purgeStartedAt) throw new WeekCopyError("Una comida cambió. Cierra y revisa de nuevo la semana antes de borrar.");
      if (!overlay.mealPlans.length || overlay.mealPlans.some((plan) => !plan.scheduledAt || mexicoCopyDateTime(plan.scheduledAt.toISOString()).date < week || mexicoCopyDateTime(plan.scheduledAt.toISOString()).date >= end)) throw new WeekCopyError("Una comida cambió de semana. Revisa de nuevo antes de borrar.");
      const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId: overlay.googleCalendarId });
      if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) throw new WeekCopyError("No tienes permiso para borrar en el calendario de una comida.");
      let event;
      try { event = (await calendar.events.get({ calendarId: overlay.googleCalendarId, eventId: overlay.googleEventId })).data; }
      catch (error) { if (![404, 410].includes(Number(copyGoogleStatus(error)))) throw error; }
      if (event && event.status !== "cancelled") {
        const start = event.start?.dateTime ?? (event.start?.date ? `${event.start.date}T00:00:00-06:00` : null);
        if (!start || mexicoCopyDateTime(start).date < week || mexicoCopyDateTime(start).date >= end || !event.etag || event.etag !== target.etag || event.recurrence?.length) throw new WeekCopyError("Una comida cambió en Google. Cierra y revisa de nuevo antes de borrar.");
        await deleteScheduledChildren(tx, userId, { calendarId: overlay.googleCalendarId, eventId: overlay.googleEventId });
        try { await calendar.events.delete({ calendarId: overlay.googleCalendarId, eventId: overlay.googleEventId, sendUpdates: "none" }, { headers: { "If-Match": event.etag } }); }
        catch (error) { if (![404, 410].includes(Number(copyGoogleStatus(error)))) throw error; }
      }
      await deleteScheduledChildren(tx, userId, { calendarId: overlay.googleCalendarId, eventId: overlay.googleEventId });
      // Cascade removes undo ledgers; SetNull keeps cooked batches and their real consumption.
      await tx.eventOverlay.delete({ where: { id: overlay.id } });
      await cleanupMealRecords(tx, userId);
    }, { timeout: 30000 });
    return NextResponse.json({ removed: target.id }, { headers });
  } catch (error) {
    if (error instanceof WeekCopyError || error instanceof ScheduledSubtaskError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409, headers });
    return NextResponse.json({ error: copyGoogleStatus(error) === 412 ? "Una comida cambió en Google. Revisa de nuevo la semana." : "No pudimos continuar el borrado. Lo ya eliminado conserva su avance; puedes reintentarlo." }, { status: 502, headers });
  }
}
