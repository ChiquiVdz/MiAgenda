import { createHash } from "node:crypto";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { prisma } from "@/lib/prisma";
import { mealProjection, syncMealSchedules } from "@/lib/meal-state";
import { snapshotRecipeSteps } from "@/lib/recipe-steps";

export const runtime = "nodejs";

const RFC3339 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/;
const MAX_AMOUNT = 999_999_999.999;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function googleStatus(error: unknown) {
  if (typeof error !== "object" || error === null) return undefined;
  if ("response" in error && typeof error.response === "object" && error.response !== null && "status" in error.response) {
    return Number(error.response.status);
  }
  return "code" in error ? Number(error.code) : undefined;
}

function isUniqueConflict(error: unknown) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "P2002";
}

function parseRangeValue(value: string | null) {
  if (!value || !RFC3339.test(value)) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

async function existingMeal(userId: string, idempotencyKey: string) {
  return prisma.mealPlan.findUnique({
    where: { userId_idempotencyKey: { userId, idempotencyKey } },
    select: { googleEventId: true, googleCalendarId: true },
  });
}

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para ver tu planificador." }, { status: 401 });

  const url = new URL(request.url);
  const from = parseRangeValue(url.searchParams.get("from"));
  const to = parseRangeValue(url.searchParams.get("to"));
  const rangeMs = from && to ? to.getTime() - from.getTime() : 0;
  if (!from || !to || rangeMs <= 0 || rangeMs > 14 * 24 * 60 * 60 * 1000) {
    return NextResponse.json({ error: "El rango del planificador debe ser de hasta dos semanas." }, { status: 400 });
  }

  try {
    const calendar = await getGoogleCalendarClient(userId);
    const events = await syncMealSchedules(userId, calendar);
    const subscriptions = await prisma.calendarSubscription.findMany({ where: { userId } });
    const recipes = await prisma.recipe.findMany({ where: { userId }, select: { id: true, name: true } });
    const projection = await prisma.$transaction((tx) => mealProjection(tx, userId), { isolationLevel: "RepeatableRead", timeout: 15000 });
    const withAvailability = projection.meals.flatMap((plan) => {
      const event = events.get(plan.id);
      if (!event || !plan.scheduledAt || Date.parse(plan.scheduledAt) >= to.getTime()
        || Date.parse(event.end?.dateTime ?? (event.end?.date ? event.end.date + "T00:00:00-06:00" : plan.scheduledAt)) <= from.getTime()) return [];
      return [{ ...plan, inventoryBefore: undefined, googleEventId: plan.googleEventId,
        calendarId: plan.googleCalendarId,
        calendarName: subscriptions.find((sub) => sub.googleCalendarId === plan.googleCalendarId)?.summarySnapshot ?? plan.googleCalendarId,
        summary: event.summary ?? "(Sin título)", etag: event.etag ?? null,
        durationMinutes: event.start?.dateTime && event.end?.dateTime ? Math.round((Date.parse(event.end.dateTime) - Date.parse(event.start.dateTime)) / 60000) : plan.durationMinutes,
        recipeName: recipes.find((recipe) => recipe.id === plan.recipeId)?.name ?? "Receta eliminada",
        completedAt: plan.completedAt?.toISOString() ?? null,
        startDate: event.start?.date ?? null, startDateTime: event.start?.dateTime ?? null,
        endDate: event.end?.date ?? null, endDateTime: event.end?.dateTime ?? null,
        pendingSourceServings: plan.portionAllocations.filter((use) => !use.actual && use.originMealPlanId !== plan.id)
          .reduce((sum, use) => sum + use.servings, 0),
      }];
    });
    const leftovers = projection.batches.filter((batch) => batch.remainingServings > 0).map((batch) => ({
      id: batch.id, recipeId: batch.recipeKey, name: batch.recipeName, cookedAt: batch.cookedAt,
      servings: batch.remainingServings,
      reservedServings: batch.remainingServings - (projection.portions.find((row) => row.id === batch.id)?.remainingServings ?? 0),
    }));
    return NextResponse.json({ plans: withAvailability, leftovers }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    const status = googleStatus(error);
    if (status === 401) return NextResponse.json({ error: "La conexión con Google venció o fue revocada. Vuelve a conectar tu cuenta." }, { status: 401 });
    if (status === 403) return NextResponse.json({ error: "Google no permitió consultar tus calendarios." }, { status: 403 });
    console.error("[GET /api/meals] Meal plan sync failed", { status });
    return NextResponse.json({ error: "No pudimos cargar las comidas planeadas desde Google Calendar." }, { status: 502 });
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para planificar una comida." }, { status: 401 });

  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  }
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    return NextResponse.json({ error: "El formato de la solicitud no es válido." }, { status: 415 });
  }

  const body: unknown = await request.json().catch(() => null);
  if (!isRecord(body)
    || typeof body.recipeId !== "string" || !body.recipeId || body.recipeId.length > 30
    || typeof body.calendarId !== "string" || !body.calendarId || body.calendarId.length > 1024
    || typeof body.idempotencyKey !== "string" || body.idempotencyKey.length < 16 || body.idempotencyKey.length > 100
    || (body.mealSlotId !== undefined && body.mealSlotId !== null && (typeof body.mealSlotId !== "string" || body.mealSlotId.length > 30))
    || typeof body.startDateTime !== "string" || !RFC3339.test(body.startDateTime)
    || !Number.isFinite(new Date(body.startDateTime).getTime())
    || typeof body.servings !== "number" || !Number.isInteger(body.servings) || body.servings < 1 || body.servings > 100
    || (body.cookingEnabled !== undefined && typeof body.cookingEnabled !== "boolean")
    || (body.cookedServings !== undefined && (typeof body.cookedServings !== "number" || !Number.isInteger(body.cookedServings) || body.cookedServings < 0 || body.cookedServings > 100))
    || typeof body.durationMinutes !== "number" || !Number.isInteger(body.durationMinutes) || body.durationMinutes < 5 || body.durationMinutes > 480) {
    return NextResponse.json({ error: "Revisa la receta, fecha, hora, porciones y duración." }, { status: 400 });
  }

  const { recipeId, calendarId, idempotencyKey, startDateTime, servings, durationMinutes } = body;
  const cookingEnabled = body.cookingEnabled !== false;
  const cookedServings = cookingEnabled ? (typeof body.cookedServings === "number" ? body.cookedServings : servings) : 0;
  if (cookingEnabled && cookedServings < 1) return NextResponse.json({ error: "Indica al menos una porción a cocinar." }, { status: 400 });
  const mealSlotId = typeof body.mealSlotId === "string" ? body.mealSlotId : null;
  const startTimestamp = new Date(startDateTime).getTime();
  const endDateTime = new Date(startTimestamp + durationMinutes * 60_000).toISOString();
  const recipe = await prisma.recipe.findFirst({
    where: { id: recipeId, userId },
    include: {
      ingredients: {
        orderBy: { ingredient: { name: "asc" } },
        include: { ingredient: { select: { id: true, name: true, unit: true } } },
      },
    },
  });
  if (!recipe) return NextResponse.json({ error: "No encontramos esa receta en tu cuenta." }, { status: 404 });
  if (recipe.ingredients.length === 0) return NextResponse.json({ error: "Agrega ingredientes a la receta antes de planificarla." }, { status: 400 });
  if (mealSlotId && !await prisma.mealSlot.findFirst({ where: { id: mealSlotId, userId }, select: { id: true } })) {
    return NextResponse.json({ error: "No encontramos esa fila en tu planificador." }, { status: 400 });
  }

  const ingredients = recipe.ingredients.map((line) => {
    const requiredQuantity = Math.round(Number(line.quantityPerServing.toString()) * cookedServings * 1000) / 1000;
    return { isOptional: line.isOptional, ingredientId: line.ingredient.id, name: line.ingredient.name, unit: line.ingredient.unit, requiredQuantity, quantityPerServing: Number(line.quantityPerServing) };
  });
  if (ingredients.some((line) => !Number.isFinite(line.requiredQuantity) || line.requiredQuantity < 0 || line.requiredQuantity > MAX_AMOUNT)) {
    return NextResponse.json({ error: "Las cantidades de esta receta superan el límite permitido." }, { status: 400 });
  }

  const alreadyPlanned = await existingMeal(userId, idempotencyKey);
  if (alreadyPlanned) return NextResponse.json({ ...alreadyPlanned, repeated: true }, { headers: { "Cache-Control": "private, no-store" } });

  const googleEventId = `meal${createHash("sha256").update(`${userId}\u0000${calendarId}\u0000${idempotencyKey}`).digest("hex").slice(0, 40)}`;
  try {
    const binding = await prisma.calendarSubscription.findFirst({ where: { userId, isMeals: true } });
    if (binding?.googleCalendarId !== calendarId) return NextResponse.json({ error: "Usa el calendario configurado de Cocina." }, { status: 409 });
    const calendar = await getGoogleCalendarClient(userId);
    const { data: remoteCalendar } = await calendar.calendarList.get({ calendarId });
    if (!["owner", "writer"].includes(remoteCalendar.accessRole ?? "")) {
      return NextResponse.json({ error: "Necesitas permiso para escribir en ese calendario." }, { status: 403 });
    }

    let event;
    try {
      const response = await calendar.events.insert({
        calendarId,
        requestBody: {
          id: googleEventId,
          summary: recipe.name,
          start: { dateTime: startDateTime, timeZone: "America/Mexico_City" },
          end: { dateTime: endDateTime, timeZone: "America/Mexico_City" },
          extendedProperties: { private: { miagendaMealPlan: "1" } },
        },
        fields: "id,etag",
      });
      event = response.data;
    } catch (error) {
      if (googleStatus(error) !== 409) throw error;
      const response = await calendar.events.get({ calendarId, eventId: googleEventId });
      event = response.data;
    }
    if (!event.id) return NextResponse.json({ error: "Google no devolvió el identificador de la comida." }, { status: 502 });

    try {
      const mealPlan = await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        const current = await tx.calendarSubscription.findFirst({ where: { userId, isMeals: true } });
        if (current?.googleCalendarId !== calendarId) throw new Error("El calendario de Cocina cambió durante la creación.");
        const overlay = await tx.eventOverlay.create({
          data: {
            userId,
            googleCalendarId: calendarId,
            googleEventId: event.id!,
            etag: event.etag ?? null,
            kind: "meal",
          },
          select: { id: true },
        });
        const plan = await tx.mealPlan.create({
          data: {
            userId,
            recipeId: recipe.id,
            preparationSteps: snapshotRecipeSteps(recipe, recipe.ingredients),
            overlayId: overlay.id,
            mealSlotId,
            googleCalendarId: calendarId,
            googleEventId: event.id!,
            idempotencyKey,
            servings, cookedServings, cookingEnabled, scheduledAt: new Date(startDateTime),
            durationMinutes, preparationMinutes: durationMinutes,
            ingredients: {
              create: ingredients.map((line) => ({
                isOptional: line.isOptional, nameSnapshot: line.name,
                unit: line.unit,
                requiredQuantity: line.requiredQuantity, quantityPerServing: line.quantityPerServing,
                ingredient: { connect: { id: line.ingredientId } },
              })),
            },
          },
          select: { id: true, googleEventId: true, googleCalendarId: true },
        });
        return plan;
      });
      return NextResponse.json(mealPlan, { status: 201, headers: { "Cache-Control": "private, no-store" } });
    } catch (error) {
      if (isUniqueConflict(error)) {
        const repeated = await existingMeal(userId, idempotencyKey);
        if (repeated) return NextResponse.json({ ...repeated, repeated: true }, { headers: { "Cache-Control": "private, no-store" } });
      }
      throw error;
    }
  } catch (error) {
    if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409 });
    const status = googleStatus(error);
    if (status === 404) return NextResponse.json({ error: "Ese calendario ya no está disponible." }, { status: 404 });
    if (status === 403) return NextResponse.json({ error: "Google no permitió planificar la comida en ese calendario." }, { status: 403 });
    console.error("[POST /api/meals] Meal planning failed", { status });
    return NextResponse.json({ error: "No pudimos guardar la comida planificada. Puedes volver a intentarlo sin crear un evento duplicado." }, { status: 502 });
  }
}



