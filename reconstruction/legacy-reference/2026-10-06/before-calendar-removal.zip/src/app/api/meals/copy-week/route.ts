import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getGoogleCalendarClient, GoogleCalendarConnectionError } from "@/lib/google/calendar";
import { syncMealSchedules } from "@/lib/meal-state";
import { validMonday } from "@/lib/meal-week-copy";
import { advanceWeekCopy, copyGoogleStatus, copyProgress, previewWeekCopy, startWeekCopy, WeekCopyError } from "@/lib/meal-week-copy-service";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };
const record = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);
const text = (v: unknown, max: number): v is string => typeof v === "string" && v.length > 0 && v.length <= max;
function failure(error: unknown) {
  if (error instanceof WeekCopyError) return NextResponse.json({ error: error.message }, { status: error.status, headers });
  if (error instanceof GoogleCalendarConnectionError) return NextResponse.json({ error: error.message }, { status: 409, headers });
  if (copyGoogleStatus(error) === 401) return NextResponse.json({ error: "Vuelve a conectar Google para continuar la copia." }, { status: 401, headers });
  if (copyGoogleStatus(error) === 403 || copyGoogleStatus(error) === 404) return NextResponse.json({ error: "Google no permitió acceder al calendario de una comida. Revisa la conexión para reanudar." }, { status: 409, headers });
  if (error instanceof Error && error.message === "AMOUNT_OUT_OF_RANGE") return NextResponse.json({ error: "Las cantidades de compras superan el límite. Ajusta las porciones copiadas y reanuda para actualizar Compras." }, { status: 409, headers });
  console.error("[copy-week] Failed", { name: error instanceof Error ? error.name : "UnknownError" });
  return NextResponse.json({ error: "La copia se interrumpió. Puedes reanudarla; las comidas ya copiadas conservarán su avance." }, { status: 502, headers });
}
export async function GET() {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para copiar semanas." }, { status: 401 });
  try {
    const jobs = await prisma.mealWeekCopy.findMany({ where: { userId, finishedAt: null }, orderBy: { createdAt: "desc" }, take: 10 });
    return NextResponse.json({ pending: jobs.map(copyProgress) }, { headers });
  } catch (error) { return failure(error); }
}

export async function POST(request: Request) {
  const userId = (await getServerSession(authOptions))?.user?.id;
  if (!userId) return NextResponse.json({ error: "Inicia sesión para copiar semanas." }, { status: 401 });
  if (request.headers.get("origin") !== new URL(request.url).origin) return NextResponse.json({ error: "La solicitud no es válida." }, { status: 403 });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) return NextResponse.json({ error: "El formato no es válido." }, { status: 415 });
  const body: unknown = await request.json().catch(() => null);
  if (!record(body) || !["preview", "start", "advance"].includes(String(body.action))) return NextResponse.json({ error: "Revisa la solicitud de copia." }, { status: 400 });
  try {
    if (body.action === "advance") {
      if (!text(body.copyId, 30)) throw new WeekCopyError("No pudimos identificar esta copia.", 400);
      const job = await prisma.mealWeekCopy.findFirst({ where: { userId, id: body.copyId } });
      if (!job) throw new WeekCopyError("No encontramos esta copia en tu cuenta.", 404);
      if (job.finishedAt) return NextResponse.json(copyProgress(job), { headers });
      const calendar = await getGoogleCalendarClient(userId);
      await syncMealSchedules(userId, calendar);
      const copyId = body.copyId;
      const progress = await prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
        return advanceWeekCopy(tx, userId, copyId, calendar);
      }, { timeout: 30000 });
      return NextResponse.json(copyProgress(progress), { headers });
    }
    if (!validMonday(body.sourceWeek) || !validMonday(body.targetWeek) || body.sourceWeek === body.targetWeek) throw new WeekCopyError("Elige dos semanas distintas. Las semanas empiezan en lunes.", 400);
    const { sourceWeek, targetWeek } = body;
    if (body.action === "start") {
      if (!text(body.idempotencyKey, 100) || body.idempotencyKey.length < 16 || !text(body.fingerprint, 64) || !/^[a-f0-9]{64}$/.test(body.fingerprint)) throw new WeekCopyError("Revisa la vista previa antes de copiar.", 400);
      const existing = await prisma.mealWeekCopy.findUnique({ where: { userId_idempotencyKey: { userId, idempotencyKey: body.idempotencyKey } } });
      if (existing) {
        if (existing.sourceWeek !== sourceWeek || existing.targetWeek !== targetWeek || existing.fingerprint !== body.fingerprint) throw new WeekCopyError("Ese intento corresponde a otra copia.");
        return NextResponse.json(copyProgress(existing), { headers });
      }
    }
    const calendar = await getGoogleCalendarClient(userId);
    const events = await syncMealSchedules(userId, calendar);
    const result = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${userId}))`;
      const preview = await previewWeekCopy(tx, userId, sourceWeek, targetWeek, events);
      if (body.action === "start") return copyProgress(await startWeekCopy(tx, userId, body.idempotencyKey as string, body.fingerprint as string, preview));
      const names = await tx.recipe.findMany({ where: { userId }, select: { id: true, name: true } });
      const recipeCounts = new Map<string, { name: string; count: number; servings: number; cookedServings: number }>();
      for (const block of preview.selected) for (const recipe of block.recipes) {
        const count = recipeCounts.get(recipe.recipeId) ?? { name: names.find((r) => r.id === recipe.recipeId)?.name ?? "Receta", count: 0, servings: 0, cookedServings: 0 };
        count.count += 1; count.servings += recipe.servings; count.cookedServings += recipe.cookingEnabled ? recipe.cookedServings : 0;
        recipeCounts.set(recipe.recipeId, count);
      }
      return { sourceWeek, targetWeek, fingerprint: preview.fingerprint, sourceCount: preview.sourceCount, destinationCount: preview.destinationCount, recipeCounts: [...recipeCounts.values()],
        copyCount: preview.selected.length, omissions: preview.omissions,
        meals: preview.selected.map((block) => ({ summary: block.summary, date: block.startDateTime.slice(0, 10), slot: block.slotName, time: block.startDateTime.slice(11, 16), recipes: block.recipes.length })) };
    }, { timeout: 30000 });
    return NextResponse.json(result, { headers });
  } catch (error) { return failure(error); }
}
