import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { AgendaView } from "@/app/agenda-view";
import { authOptions } from "@/lib/auth";

export default async function Today() {
  if (!await getServerSession(authOptions)) redirect("/login");
  return <AgendaView initialView="day" />;
}
