import type { Metadata } from "next";
import "./globals.css";
import { QuickCapture } from "./components/quick-capture";
import { coreModeEnabled } from "@/lib/core-mode";

export const metadata: Metadata = {
  title: "MiAgenda | Tu semana, en orden",
  description: "Organiza tus actividades, horarios y cocina en MiAgenda.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="es-MX">
      <body>{children}{!coreModeEnabled() && <QuickCapture />}</body>
    </html>
  );
}
