import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { AgendaView } from "@/app/agenda-view";
import { authOptions } from "@/lib/auth";
import { coreModeEnabled } from "@/lib/core-mode";

export default async function Home() {
  if (coreModeEnabled()) redirect("/inbox");
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  return <AgendaView />;
}
