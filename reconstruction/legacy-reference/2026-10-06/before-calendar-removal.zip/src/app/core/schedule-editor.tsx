"use client";

import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import type { ActivityView } from "../../../reconstruction/core/src/views";
import type { ScheduleInput } from "../../../reconstruction/core/src/contracts";
import { dateParts, atTime, plusDays, ZONE } from "./dates";
import type { Mutate } from "./use-core-feed";
import { TimePicker } from "../components/time-picker";
import { RecurrenceFields } from "./recurrence-fields";
import { parseRecurrence, type RecurrenceRule } from "../../../reconstruction/core/src/recurrence";

export type CalendarView = { id: string; name: string; color: string; revision: number; visible: boolean; moduleKey: string | null; position: number };
export type ScheduledItem = ActivityView | ActivityView["children"][number];
export const CoreFeedback = createContext<{ error: string | null; retry: boolean; busy: boolean; reattempt: () => void }>({ error: null, retry: false, busy: false, reattempt() {} });
export function CoreDialog({ title, close, children }: { title: string; close: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const dialog = ref.current; dialog?.showModal(); return () => dialog?.close(); }, []);
  return <dialog className="event-dialog core-dialog" ref={ref} onCancel={event => { event.preventDefault(); close(); }} aria-label={title}>
    <div className="core-dialog-heading"><h2>{title}</h2><button type="button" className="core-text-button" aria-label="Cerrar" onClick={close}>×</button></div>{children}</dialog>;
}
export function ScheduleFields({ initial, calendars, defaultDate, defaultTime, duration = 60, onSave, disabled, allowRecurrence = false, allowAllDay = true }: {
  initial?: ScheduledItem["schedule"]; calendars: CalendarView[]; defaultDate?: string; defaultTime?: string; duration?: number;
  onSave: (schedule: ScheduleInput, recurrence?: RecurrenceRule) => void; disabled: boolean; allowRecurrence?: boolean; allowAllDay?: boolean;
}) {
  const zone = initial?.timeZone ?? ZONE;
  const now = new Date(Math.ceil(Date.now() / 900000) * 900000);
  const start = initial?.startsAt ? dateParts(initial.startsAt, zone) : { ...dateParts(now), ...(defaultDate ? { date: defaultDate } : {}), ...(defaultTime ? { time: defaultTime } : {}) };
  const end = initial?.endsAt ? dateParts(initial.endsAt, zone) : dateParts(new Date(new Date(atTime(start.date, start.time, zone)).getTime() + duration * 60000), zone);
  const [calendar, setCalendar] = useState(initial?.calendarId ?? calendars[0]?.id ?? "");
  const [allDay, setAllDay] = useState(initial?.mode === "allDay");
  const [startDate, setStartDate] = useState(initial?.startDate ?? start.date), [startTime, setStartTime] = useState(start.time);
  const [endDate, setEndDate] = useState(initial?.endDate ? plusDays(initial.endDate, -1) : end.date), [endTime, setEndTime] = useState(end.time);
  const [error, setError] = useState<string | null>(null);
  const [recurrence, setRecurrence] = useState<RecurrenceRule | null>(null);
  function changeStart(date: string, time: string) {
    try {
      const previous = new Date(atTime(startDate, startTime, zone)).getTime();
      const finish = new Date(atTime(endDate, endTime, zone)).getTime();
      const next = dateParts(new Date(new Date(atTime(date, time, zone)).getTime() + Math.max(900000, finish - previous)), zone);
      setStartDate(date); setStartTime(time); setEndDate(allDay ? date : next.date); setEndTime(next.time); setError(null);
    } catch { setError("Revisa la fecha y hora de inicio."); }
  }
  return <form className="core-edit-form" onSubmit={event => {
    event.preventDefault(); setError(null);
    try {
      const rule = allowRecurrence && recurrence ? parseRecurrence(recurrence, startDate) : undefined;
      if (allDay) {
        if (endDate < startDate) throw new Error("El último día no puede ser anterior al inicio.");
        onSave({ calendarId: calendar, timeZone: zone, mode: "allDay", startDate, endDate: plusDays(endDate, 1) }, rule);
      } else {
        if (+startTime.slice(3) % 15 || +endTime.slice(3) % 15) throw new Error("Usa horarios en intervalos de 15 minutos.");
        const startsAt = atTime(startDate, startTime, zone), endsAt = atTime(endDate, endTime, zone);
        if (startsAt >= endsAt) throw new Error("El fin debe ser posterior al inicio.");
        onSave({ calendarId: calendar, timeZone: zone, mode: "timed", startsAt, endsAt }, rule);
      }
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Revisa el horario."); }
  }}>
    <label className="form-field">Calendario<select required disabled={disabled} value={calendar} onChange={event => setCalendar(event.target.value)}>{calendars.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
    {allowAllDay && <label className="core-check"><input type="checkbox" disabled={disabled} checked={allDay} onChange={event => setAllDay(event.target.checked)} />Todo el día</label>}
    <div className="core-date-fields"><label className="form-field">Inicio<input required type="date" disabled={disabled} value={startDate} onChange={event => changeStart(event.target.value, startTime)} /></label>
      {!allDay && <TimePicker label="Hora de inicio" disabled={disabled} value={startTime} onChange={time => changeStart(startDate, time)} />}
      <label className="form-field">{allDay ? "Último día" : "Fin"}<input required type="date" disabled={disabled} min={startDate} value={endDate} onChange={event => setEndDate(event.target.value)} /></label>
      {!allDay && <TimePicker label="Hora de fin" disabled={disabled} value={endTime} onChange={setEndTime} />}</div>
    <small className="core-muted">Zona horaria: {zone}</small>{error && <p role="alert" className="pantry-error">{error}</p>}
    {allowRecurrence && <RecurrenceFields value={recurrence} change={setRecurrence} startDate={startDate} disabled={disabled} />}
    <button type="submit" className="pantry-add-button" disabled={disabled || !calendar}>Guardar horario</button>
  </form>;
}
export function ScheduleButton({ item, calendars, disabled, mutate, parentCalendarId }: {
  item: ScheduledItem; calendars: CalendarView[]; disabled: boolean; mutate: Mutate; parentCalendarId?: string;
}) {
  const [open, setOpen] = useState(false), [editRevision, setEditRevision] = useState(item.revision);
  const feedback = useContext(CoreFeedback);
  const choices = [...calendars].sort((a, b) => Number(b.id === parentCalendarId) - Number(a.id === parentCalendarId));
  return <><button className="core-text-button" type="button" disabled={disabled} onClick={() => { setEditRevision(item.revision); setOpen(true); }}>{item.schedule ? "Cambiar horario" : "Agendar"}</button>
    {open && <CoreDialog title={`Horario · ${item.title}`} close={() => { if (!feedback.busy) setOpen(false); }}>
      {feedback.error && <p className="pantry-error" role="alert">{feedback.error} {feedback.retry && <button className="core-text-button" disabled={feedback.busy} onClick={feedback.reattempt}>Reintentar cambio</button>}</p>}
      <ScheduleFields initial={item.schedule} calendars={choices} duration={item.parentId ? 15 : 60} allowAllDay={item.mealRole !== "priorReminder"} disabled={disabled} onSave={schedule => {
        void mutate({ action: "scheduleTask", id: item.id, expectedRevision: editRevision, schedule }, () => setOpen(false));
      }} />
      {item.schedule && <button className="core-text-button core-unschedule" type="button" disabled={disabled} onClick={() => {
        if ((!item.keep && !item.highlighted) || window.confirm("Quitar el horario también desactiva Conservar y Destacar. Se mantienen la tarea y su progreso. ¿Continuar?"))
          void mutate({ action: "unscheduleTask", id: item.id, expectedRevision: item.revision }, () => setOpen(false));
      }}>Quitar horario</button>}
    </CoreDialog>}
  </>;
}
export function scheduleLabel(item: ScheduledItem) {
  const schedule = item.schedule;
  if (!schedule) return "";
  if (schedule.mode === "allDay") return `${schedule.startDate} · Todo el día`;
  const format = new Intl.DateTimeFormat("es-MX", { dateStyle: "short", timeStyle: "short", timeZone: schedule.timeZone });
  return `${format.format(new Date(schedule.startsAt!))} – ${new Intl.DateTimeFormat("es-MX", { timeStyle: "short", timeZone: schedule.timeZone }).format(new Date(schedule.endsAt!))}`;
}
