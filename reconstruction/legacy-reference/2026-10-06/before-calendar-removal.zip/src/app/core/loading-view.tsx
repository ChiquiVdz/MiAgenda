import Link from "next/link";

export function LoadingView({ title }: { title: string }) {
  return <main className="app-shell"><aside className="sidebar">
    <Link prefetch={false} className="brand" href="/inbox"><span className="brand-mark">m</span><span>miagenda</span></Link>
    <nav className="primary-nav" aria-label="Navegación principal">
      <Link prefetch={false} className="nav-item" href="/inbox">▱ Inbox</Link>
      <Link prefetch={false} className="nav-item" href="/agenda">▦ Agenda</Link>
      <Link prefetch={false} className="nav-item" href="/cocina">♨ Alacena</Link>
      <Link prefetch={false} className="nav-item" href="/cocina/recetas">▤ Recetario</Link>
      <Link prefetch={false} className="nav-item" href="/cocina/planificar">▦ Planificar</Link>
      <Link prefetch={false} className="nav-item" href="/cocina/compras">▱ Compras</Link>
    </nav>
  </aside><section className="workspace" aria-busy="true"><div className="page-content">
    <h1>{title}</h1><p className="core-muted" role="status">Cargando…</p>
  </div></section></main>;
}
