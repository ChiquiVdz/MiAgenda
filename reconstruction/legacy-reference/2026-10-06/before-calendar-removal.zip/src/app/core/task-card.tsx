"use client";
import Link from "next/link";
import { useState } from "react";
import type { ActivityView } from "../../../reconstruction/core/src/views";
import type { Mutate } from "./use-core-feed";
import { useSeriesAction } from "./series-action";
import { ScheduleButton, scheduleLabel, type CalendarView } from "./schedule-editor";
import { MealCompletionButton } from "./meal-completion-button";
import { FrequencyButton } from "./frequency-editor";

export function TaskCard({ item, disabled, mutate, calendars, scopeControls = false }: { scopeControls?: boolean; item: ActivityView; disabled: boolean; mutate: Mutate; calendars: CalendarView[] }) {
  const [editing, setEditing] = useState(false), [text, setText] = useState(item.title), [description, setDescription] = useState(item.description ?? "");
  const [editRevision, setEditRevision] = useState(item.revision), [childDraft, setChildDraft] = useState("");
  const actions = useSeriesAction(item, scopeControls, disabled, mutate);
  const done = item.children.filter(child => child.completedAt).length;
  if (item.kind === "meal") return <li className={`today-item inbox-item core-task${item.completedAt?" today-item-completed":""}`}><MealCompletionButton item={item} disabled={disabled} mutate={mutate}/><div className="today-event-content"><strong>{item.title}</strong><small className="core-schedule-label">{scheduleLabel(item)}</small><p className="core-muted">Comida planificada · Los ingredientes se descuentan al completar</p><div className="core-row-actions core-flags"><label><input type="checkbox" disabled={disabled} checked={item.keep} onChange={event => void mutate({ action: "setFlags", id: item.id, expectedRevision: item.revision, keep: event.target.checked })} />Conservar</label><label><input type="checkbox" disabled={disabled} checked={item.highlighted} onChange={event => void mutate({ action: "setFlags", id: item.id, expectedRevision: item.revision, highlighted: event.target.checked })} />Destacar</label></div><details className="core-subtasks"><summary>Pasos y preparaciones ({item.children.length})</summary><ul>{item.children.map(child => <SubtaskRow key={child.id} child={child} calendars={calendars} disabled={disabled} mutate={mutate} quickMutate={mutate} scopeControls={false} parentCalendarId={item.schedule?.calendarId} />)}</ul></details></div><div className="inbox-actions"><Link prefetch={false} className="core-text-button" href={`/cocina/planificar?meal=${item.id}`}>{item.completedAt?"Ver en Planificar":"Editar en Planificar"}</Link><button disabled={disabled} onClick={() => { if (window.confirm(`¿Eliminar «${item.title}» y sus preparaciones?${item.completedAt?" Esto quita la tarjeta sin devolver ingredientes; sus tandas y consumos se conservan.":""}`)) void mutate({ action: "deleteTask", id: item.id, expectedRevision: item.revision }); }}>×</button></div></li>;
  return <li className={`today-item inbox-item core-task${item.completedAt ? " today-item-completed" : ""}`}>
    <button type="button" className="today-completion" disabled={disabled} aria-pressed={Boolean(item.completedAt)} aria-label={`${item.completedAt ? "Deshacer completado de" : "Completar"} ${item.title}`}
      onClick={() => void mutate({ action: "setCompleted", id: item.id, expectedRevision: item.revision, completed: !item.completedAt })}>{item.completedAt ? "✓" : ""}</button>
    <div className="today-event-content">
      {editing ? <form className="core-edit-form" onSubmit={event => { event.preventDefault(); void actions.request({ action: "editTask", id: item.id, expectedRevision: editRevision, ...(text.trim() !== item.title ? { title: text.trim() } : {}), ...(description.trim() !== (item.description ?? "") ? { description: description.trim() || null } : {}) }, () => setEditing(false)); }}>
        <label className="form-field">Nombre<input required maxLength={250} value={text} disabled={disabled} onChange={event => setText(event.target.value)} /></label>
        <label className="form-field">Descripción<textarea maxLength={10000} rows={2} value={description} disabled={disabled} onChange={event => setDescription(event.target.value)} /></label>
        <div className="core-row-actions"><button className="core-text-button" type="submit" disabled={disabled || !text.trim() || (text.trim() === item.title && description.trim() === (item.description ?? ""))}>Guardar</button>
          <button className="core-text-button" type="button" disabled={disabled} onClick={() => setEditing(false)}>Cancelar</button></div>
      </form> : <div className="inbox-text"><strong>{item.title}</strong>{item.recurrence && <small className="core-muted">↻ Recurrente · Casillas rápidas: solo esta instancia</small>}{item.schedule && <small className="core-schedule-label">{scheduleLabel(item)}</small>}{item.description && <p className="core-description">{item.description}</p>}</div>}
      {item.schedule && <div className="core-row-actions core-flags"><label><input type="checkbox" disabled={disabled} checked={item.keep} onChange={event => void mutate({ action: "setFlags", id: item.id, expectedRevision: item.revision, keep: event.target.checked })} />Conservar</label><label><input type="checkbox" disabled={disabled} checked={item.highlighted} onChange={event => void mutate({ action: "setFlags", id: item.id, expectedRevision: item.revision, highlighted: event.target.checked })} />Destacar</label></div>}
      {!item.parentId && <details className="core-subtasks"><summary>Subtareas {done}/{item.children.length}</summary>
        <ul>{item.children.map(child => <SubtaskRow key={child.id} child={child} calendars={calendars} parentCalendarId={item.schedule?.calendarId} disabled={disabled} mutate={actions.request} quickMutate={mutate} scopeControls={scopeControls} />)}</ul>
        <form className="core-subtask-add" onSubmit={event => { event.preventDefault(); void actions.request({ action: "createTask", id: crypto.randomUUID(), title: childDraft.trim(), description: null,
          parentId: item.id, expectedParentRevision: item.revision, position: item.children.length ? Math.max(...item.children.map(child => child.position)) + 1 : 0 }, () => setChildDraft("")); }}>
          <input aria-label={`Nueva subtarea de ${item.title}`} maxLength={250} required placeholder="Agregar subtarea" value={childDraft} disabled={disabled} onChange={event => setChildDraft(event.target.value)} />
          <button className="core-text-button" type="submit" disabled={disabled || !childDraft.trim()}>＋ Agregar</button>
        </form>
      </details>}
    </div><div className="inbox-actions">
      <button type="button" disabled={disabled || editing} onClick={() => { setText(item.title); setDescription(item.description ?? ""); setEditRevision(item.revision); setEditing(true); }}>Editar</button>
      <ScheduleButton item={item} calendars={calendars} disabled={disabled} mutate={actions.request} />
      {scopeControls && item.recurrence && !item.parentId && <FrequencyButton item={item} disabled={disabled} mutate={mutate} />}
      <button type="button" disabled={disabled} aria-label={`Eliminar ${item.title}`} onClick={() => {
        if ((scopeControls && item.recurrence) || window.confirm(`¿Eliminar “${item.title}” y sus ${item.children.length} subtareas? También se quitarán sus horarios si tienen alguno.`)) {
          void actions.request({ action: "deleteTask", id: item.id, expectedRevision: item.revision });
        }
      }}>×</button>
      {scopeControls && item.recurrence && <button type="button" disabled={disabled} onClick={() => void actions.request({ action: "setCompleted", id: item.id, expectedRevision: item.revision, completed: !!item.completedAt })}>Aplicar completado…</button>}
    </div>{actions.dialog}
  </li>;
}

function SubtaskRow({ child, disabled, mutate, calendars, parentCalendarId, quickMutate, scopeControls }: { quickMutate: Mutate; scopeControls: boolean; child: ActivityView["children"][number]; disabled: boolean; mutate: Mutate; calendars: CalendarView[]; parentCalendarId?: string }) {
  const [editing, setEditing] = useState(false), [text, setText] = useState(child.title), [editRevision, setEditRevision] = useState(child.revision);
  return <li className={`core-subtask${child.completedAt ? " core-subtask-completed" : ""}`}>
    <button type="button" className="today-completion" disabled={disabled} title={child.mealRole === "preparation" ? "Al terminar los pasos obligatorios se completará la comida" : undefined} aria-pressed={Boolean(child.completedAt)} aria-label={`${child.completedAt ? "Deshacer completado de" : "Completar"} ${child.title}`}
      onClick={() => void quickMutate({ action: "setCompleted", id: child.id, expectedRevision: child.revision, completed: !child.completedAt })}>{child.completedAt ? "✓" : ""}</button>
    {editing ? <form className="core-subtask-edit" onSubmit={event => { event.preventDefault(); void mutate({ action: "editTask", id: child.id, expectedRevision: editRevision, title: text.trim() }, () => setEditing(false)); }}>
      <input aria-label="Nombre de subtarea" maxLength={250} required value={text} disabled={disabled} onChange={event => setText(event.target.value)} />
      <button type="submit" className="core-text-button" disabled={disabled || !text.trim() || text.trim() === child.title}>Guardar</button>
      <button type="button" className="core-text-button" disabled={disabled} onClick={() => setEditing(false)}>Cancelar</button>
    </form> : <span className="core-subtask-name">{child.title}{child.mealOptional&&<small>Opcional</small>}{child.schedule && <small>Agendada · {scheduleLabel(child)}</small>}</span>}
    {child.mealRole !== "preparation" && <ScheduleButton item={child} calendars={calendars} parentCalendarId={parentCalendarId} disabled={disabled} mutate={quickMutate} />}
    {!editing && child.mealRole !== "preparation" && <button type="button" className="core-text-button" disabled={disabled} onClick={() => { setText(child.title); setEditRevision(child.revision); setEditing(true); }}>Editar</button>}
    <button type="button" className="core-text-button" disabled={disabled || child.mealRole === "preparation"} aria-label={`Eliminar subtarea ${child.title}`} onClick={() => {
      if ((scopeControls && child.recurrence) || window.confirm(`¿Eliminar la subtarea “${child.title}”${child.schedule ? " y su horario" : ""}?`)) void mutate({ action: "deleteTask", id: child.id, expectedRevision: child.revision });
    }}>×</button>
    {scopeControls && child.recurrence && <button type="button" className="core-text-button" disabled={disabled} onClick={() => void mutate({ action: "setCompleted", id: child.id, expectedRevision: child.revision, completed: !!child.completedAt })}>Aplicar marca…</button>}
  </li>;
}
