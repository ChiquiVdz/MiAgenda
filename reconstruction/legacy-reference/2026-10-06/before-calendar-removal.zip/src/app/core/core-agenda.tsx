"use client";
import Link from "next/link";
import dynamic from "next/dynamic";

import { useEffect, useRef, useState } from "react";
import { signOut } from "next-auth/react";
import type { ActivityView } from "../../../reconstruction/core/src/views";
import { TaskCard } from "./task-card";
import { CoreDialog, CoreFeedback, ScheduleFields, type CalendarView, scheduleLabel } from "./schedule-editor";
import { useCoreFeed, type Feed } from "./use-core-feed";
import { atTime, dateParts, labelDate, plusDays, rangeQuery, agendaPeriod, movePeriod, type AgendaViewMode } from "./dates";
import { monthDays } from "@/lib/calendar-month";
import { MonthAgenda } from "../components/month-agenda";
import { YearAgenda } from "../components/year-agenda";
import { useWeekDrag } from "./use-week-drag";
import { CalendarEditor } from "./calendar-editor";
const AgendaMealCreator = dynamic(() => import("./agenda-meal-creator").then(module => module.AgendaMealCreator), { loading: () => <p role="status">Cargando formulario de comida…</p> });

function intersects(item: ActivityView, start: string, end: string) {
  const schedule = item.schedule;
  return !!schedule && (schedule.mode === "allDay"
    ? schedule.startDate! < end && schedule.endDate! > start
    : schedule.startsAt! < atTime(end) && schedule.endsAt! > atTime(start));
}
function minuteAt(value: string) { const time = dateParts(value).time; return +time.slice(0, 2) * 60 + +time.slice(3); }
function placements(items: ActivityView[], day: string) {
  const midnight = atTime(day), next = atTime(plusDays(day, 1));
  const rows = items.filter(item => item.schedule?.mode === "timed" && intersects(item, day, plusDays(day, 1))).map(item => ({ item,
    start: item.schedule!.startsAt! <= midnight ? 0 : minuteAt(item.schedule!.startsAt!),
    end: item.schedule!.endsAt! >= next ? 1440 : minuteAt(item.schedule!.endsAt!), lane: 0, lanes: 1 }));
  rows.sort((a, b) => a.start - b.start || b.end - a.end || a.item.id.localeCompare(b.item.id));
  let cluster: typeof rows = [], ends: number[] = [], until = -1;
  const finish = () => { for (const row of cluster) row.lanes = ends.length; cluster = []; ends = []; };
  for (const row of rows) {
    // Visual minimum height also participates in overlap placement.
    const visualEnd = Math.max(row.end, row.start + 30);
    if (row.start >= until) { finish(); until = -1; }
    let lane = ends.findIndex(end => end <= row.start);
    if (lane === -1) lane = ends.length;
    ends[lane] = visualEnd; row.lane = lane; cluster.push(row); until = Math.max(until, visualEnd);
  }
  finish(); return rows;
}

export function CoreAgenda({ initialData, initialCalendars, initialToday }: { initialData: Feed; initialCalendars: CalendarView[]; initialToday: string }) {
  const [view, setView] = useState<AgendaViewMode>("week"), [anchor, setAnchor] = useState(initialToday);
  const [now, setNow] = useState<Date | null>(null), [calendars, setCalendars] = useState(initialCalendars);
  const [calendarError, setCalendarError] = useState<string | null>(null);
  const [editingCalendar, setEditingCalendar] = useState<CalendarView | null>(null);
  const [addingCalendar, setAddingCalendar] = useState(false), [name, setName] = useState(""), [color, setColor] = useState("#527860");
  const [createDate, setCreateDate] = useState<string | null>(null), [newTitle, setNewTitle] = useState("");
  const [createTime, setCreateTime] = useState<string | undefined>();
  const [createType, setCreateType] = useState<"task" | "meal">("task"), [mealLocked, setMealLocked] = useState(false), [mealNotice, setMealNotice] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [extraDetail, setExtraDetail] = useState<ActivityView | null>(null);
  const detailGeneration = useRef(0), calendarGeneration = useRef(0);
  const today = now ? dateParts(now).date : initialToday;
  const { start, days, end, visibleStart, visibleEnd } = agendaPeriod(view, anchor);
  const visibleIds = new Set(calendars.filter(calendar => calendar.visible).map(calendar => calendar.id));
  async function reloadCalendars(action?: string) {
    if (action && !["createCalendar", "setCalendarVisible", "editCalendar", "deleteCalendar"].includes(action)) return;
    const generation = ++calendarGeneration.current;
    try {
      const response = await fetch("/api/core?view=calendars", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message ?? "No pudimos consultar los calendarios.");
      if (generation === calendarGeneration.current) { setCalendars(result.items); setCalendarError(null); }
    } catch (cause) { setCalendarError(cause instanceof Error ? cause.message : "No pudimos consultar los calendarios."); }
  }
  const feed = useCoreFeed(initialData, rangeQuery(start, days, view === "year"), item => intersects(item, start, end) && (view !== "year" || item.highlighted), (action, result) => {
    if (action === "changeRecurrence") { ++detailGeneration.current; setSelectedId(null); setExtraDetail(null); }
    void reloadCalendars(action);
    if (result) setExtraDetail(current => current ? result.activities.find(item => item.id === current.id) ?? (result.removedIds.includes(current.id) ? null : current) : null);
    else if (selectedId && extraDetail && !extraDetail.recurrence?.virtual) void openParent(selectedId);
  });
  const items = feed.data.items.filter(item => intersects(item, start, end) && item.schedule && visibleIds.has(item.schedule.calendarId) && (view !== "year" || item.highlighted)).sort((a, b) => (a.schedule!.startsAt ?? a.schedule!.startDate!).localeCompare(b.schedule!.startsAt ?? b.schedule!.startDate!) || a.title.localeCompare(b.title));
  // A presentation projection only: all mutations still use the original Activity.
  const calendarEvents = items.map(item => {
    const calendar = calendars.find(calendar => calendar.id === item.schedule!.calendarId);
    return { id: item.id, calendarId: item.schedule!.calendarId, calendarName: calendar?.name ?? "Calendario", color: calendar?.color ?? null,
      summary: item.title, startDate: item.schedule!.startDate, endDate: item.schedule!.endDate, startDateTime: item.schedule!.startsAt, endDateTime: item.schedule!.endsAt,
      overlay: { completedAt: item.completedAt, highlighted: item.highlighted }, progress: item.children.length ? { done: item.children.filter(child => child.completedAt).length, total: item.children.length } : null };
  });
  const periodLabel = view === "year" ? anchor.slice(0, 4) : view === "month" ? labelDate(visibleStart, { month: "long", year: "numeric" }) : `${labelDate(start)}${view === "week" ? ` – ${labelDate(plusDays(end, -1))}` : ""}`;
  function keyOfLocalDay(day: Date) { return `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}`; }
  function openActivity(id: string) { ++detailGeneration.current; setExtraDetail(feed.data.items.find(item => item.id === id) ?? null); setSelectedId(id); }
  const selected = feed.data.items.find(item => item.id === selectedId) ?? (extraDetail?.id === selectedId ? extraDetail : null);
  const weekScroll = useRef<HTMLDivElement>(null);
  const lastScroll = useRef<string | null>(null);
  useEffect(() => {
    setNow(new Date()); const timer = setInterval(() => setNow(new Date()), 60000); return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (view !== "week") lastScroll.current = null;
    if (view === "week" && now && lastScroll.current !== start && weekScroll.current) {
      weekScroll.current.scrollTop = Math.max(0, minuteAt(now.toISOString()) - 100); lastScroll.current = start;
    }
  }, [view, now, start]);
  // Merge separately loaded parents with responses from the same common service.
  const mutate: typeof feed.mutate = async (command, success) => {
    ++detailGeneration.current;
    await feed.mutate(command, success);
  };
  const drag = useWeekDrag(weekScroll, start, feed.locked || feed.reading, mutate);
  const previewSource = feed.data.items.find(item => item.id === drag.preview?.id);
  const previewItem = drag.preview && previewSource ? { ...previewSource, schedule: { ...drag.preview.schedule, startDate: null, endDate: null } } : null;
  async function openParent(id: string) {
    const generation = ++detailGeneration.current;
    try {
      const response = await fetch(`/api/core?view=detail&id=${id}`, { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message ?? "No pudimos abrir la principal.");
      if (generation === detailGeneration.current) { setExtraDetail(result.item); setSelectedId(id); }
    } catch (cause) { setCalendarError(cause instanceof Error ? cause.message : "No pudimos abrir la principal."); }
  }
  function closeDetail() { ++detailGeneration.current; setSelectedId(null); setExtraDetail(null); }
  function status() { return <>{feed.error && <p className="pantry-message pantry-error" role="alert">{feed.error} {feed.retry && <button className="core-text-button" type="button" disabled={feed.busy} onClick={feed.reattempt}>Reintentar cambio</button>}</p>}{feed.notice && <p className="pantry-message" role="status">{feed.notice}</p>}{mealNotice && <p className="pantry-message" role="status">{mealNotice}</p>}</>; }
  function openCreate(date: string, time?: string) { setNewTitle(""); setMealNotice(null); setCreateType("task"); setCreateTime(time ?? dateParts(new Date(Math.ceil(Date.now()/900000)*900000)).time); setCreateDate(date); }
  function mealSaved(date: string) {
    setCreateDate(null); setMealLocked(false);
    if (date >= start && date < end) void feed.load(); else setAnchor(date);
    const kitchen = calendars.find(calendar => calendar.moduleKey === "kitchen");
    if (!kitchen) void reloadCalendars();
    setMealNotice(`Cambios de comida guardados en Agenda y Planificar.${kitchen && !kitchen.visible ? " Activa el calendario Cocina para verla aquí." : view === "year" ? " En Año solo se muestran los eventos destacados." : ""}`);
  }
  function eventButton(item: ActivityView, compact = false) {
    const calendar = calendars.find(calendar => calendar.id === item.schedule!.calendarId);
    return <button type="button" className={`core-week-event${item.completedAt ? " core-event-done" : ""}`} style={{ borderLeftColor: calendar?.color }} onClick={() => { if (!drag.suppressClick()) openActivity(item.id); }}>
      <strong>{item.highlighted ? "★ " : ""}{item.title}</strong>{!compact && <small>{scheduleLabel(item)}</small>}{item.parentId && <small>Subtarea</small>}</button>;
  }
  return <CoreFeedback.Provider value={feed}><main className="app-shell"><aside className="sidebar">
    <Link prefetch={false} className="brand" href="/inbox"><span className="brand-mark">m</span><span>miagenda</span></Link>
    <nav className="primary-nav"><Link prefetch={false} className="nav-item" href="/inbox">▱ Inbox</Link><Link prefetch={false} className="nav-item nav-item-active" href="/agenda" aria-current="page">▦ Agenda</Link><Link prefetch={false} className="nav-item" href="/cocina">♨ Alacena</Link><Link prefetch={false} className="nav-item" href="/cocina/planificar">▦ Planificar</Link></nav>
    <div className="sidebar-divider" /><div className="section-heading"><h2>Mis calendarios</h2><button className="calendar-add" aria-label="Crear calendario" disabled={feed.locked} onClick={() => setAddingCalendar(true)}>＋</button></div>
    <ul className="calendar-items">{calendars.map(calendar => <li className="core-calendar-row" key={calendar.id}><label className="core-check"><input type="checkbox" checked={calendar.visible} disabled={feed.locked} onChange={event => void mutate({ action: "setCalendarVisible", id: calendar.id, expectedRevision: calendar.revision, visible: event.target.checked })} /><span className="core-calendar-dot" style={{ background: calendar.color }} />{calendar.name}</label><button type="button" className="core-text-button" disabled={feed.locked} aria-label={`Editar calendario ${calendar.name}`} onClick={() => setEditingCalendar(calendar)}>⋯</button></li>)}</ul>
  </aside><section className="workspace"><header className="topbar"><div className="breadcrumb">Mi espacio / <strong>Agenda</strong></div><button className="core-text-button" disabled={feed.locked} onClick={() => void signOut({ callbackUrl: "/login" })}>Cerrar sesión</button></header>
    <div className="page-content"><div className="page-heading-row"><div><p className="eyebrow">TU TIEMPO</p><h1>Agenda</h1><p className="week-range">{periodLabel}</p></div>
      <div className="core-toolbar"><button className="core-text-button" disabled={feed.locked} onClick={() => openCreate(anchor)}>＋ Crear</button>
        {!(today >= visibleStart && today < visibleEnd) && <button className="core-text-button" disabled={feed.locked} onClick={() => setAnchor(today)}>Hoy</button>}
        <button className="core-text-button" disabled={feed.locked} aria-label="Período anterior" onClick={() => setAnchor(movePeriod(view, anchor, -1))}>‹</button>
        <button className="core-text-button" disabled={feed.locked} aria-label="Período siguiente" onClick={() => setAnchor(movePeriod(view, anchor, 1))}>›</button>
        <select aria-label="Vista de agenda" disabled={feed.locked} value={view} onChange={event => { setView(event.target.value as AgendaViewMode); setAnchor(today); }}><option value="day">Día</option><option value="week">Semana</option><option value="month">Mes</option><option value="year">Año</option></select>
        <button className="core-text-button" disabled={feed.busy || feed.reading} onClick={() => { void feed.load(); void reloadCalendars(); }}>{feed.reading ? "Actualizando…" : "Actualizar"}</button>
      </div></div>{status()}{calendarError && <p className="pantry-message pantry-error" role="alert">{calendarError}</p>}
      {view === "week" && <p className="core-muted">Arrastra una actividad para moverla; usa sus bordes para ajustar inicio o fin. Escape cancela. También puedes abrirla y elegir Cambiar horario.</p>}
      {drag.preview && previewItem && <p className="core-drag-status" role="status">{drag.preview.title} · {scheduleLabel(previewItem)} · Suelta para guardar</p>}
      {feed.data.nextAfterId && <p className="core-muted" role="status">Hay más {view === "year" ? "destacados" : "actividades"} en este período. Usa «Cargar más» para mostrarlos.</p>}
      {view === "year" ? <YearAgenda year={+anchor.slice(0, 4)} today={today} events={calendarEvents} loading={feed.reading} error={null} suppressEmpty={Boolean(feed.error)} onRetry={() => void feed.load()}
        onMonth={date => { setView("month"); setAnchor(keyOfLocalDay(date)); }} onOpen={event => openActivity(event.id)} />
      : view === "month" ? <MonthAgenda key={visibleStart} days={monthDays(new Date(+anchor.slice(0, 4), +anchor.slice(5, 7) - 1, 1, 12))} month={+anchor.slice(5, 7) - 1} today={today}
        events={calendarEvents} canCreate={!feed.locked} loading={feed.reading} error={null} createLabel="Crear tarea o comida" onRetry={() => void feed.load()} onCreate={date => openCreate(date)}
        onOpen={event => openActivity(event.id)} onWeek={date => { setView("week"); setAnchor(keyOfLocalDay(date)); }} />
      : view === "day" ? <div className="today-agenda"><h2>{labelDate(anchor, { weekday: "long", day: "numeric", month: "long" })}</h2>
        {items.length ? <ul className="core-inbox-list">{items.map(item => <TaskCard key={item.id} item={item} calendars={calendars} disabled={feed.locked} mutate={mutate} />)}</ul> : <p className="today-empty">No hay actividades en los calendarios visibles para este día.</p>}
      </div> : <div className="core-week-scroll" ref={weekScroll}><div className="core-week-grid">
        <div className="core-week-header"><div className="core-muted">GMT−6</div>{Array.from({ length: 7 }, (_, index) => { const day = plusDays(start, index); return <button className={`core-day-heading${day === today ? " core-is-today" : ""}`} key={day} onClick={() => { setView("day"); setAnchor(day); }}><span>{labelDate(day, { weekday: "short" })}</span><strong>{+day.slice(8)}</strong>{day === today && <small>Hoy</small>}</button>; })}</div>
        <div className="core-week-all-day"><span className="core-muted">Todo el día</span>{Array.from({ length: 7 }, (_, index) => { const day = plusDays(start, index); return <div key={day}>{items.filter(item => item.schedule!.mode === "allDay" && intersects(item, day, plusDays(day, 1))).map(item => <div key={item.id}>{eventButton(item, true)}</div>)}</div>; })}</div>
        <div className="core-week-timeline"><div className="core-hours">{Array.from({ length: 24 }, (_, hour) => <span key={hour} style={{ top: hour * 60 }}>{String(hour).padStart(2, "0")}:00</span>)}</div>
          {Array.from({ length: 7 }, (_, index) => { const day = plusDays(start, index); return <div className="core-day-column" key={day} onClick={event => {
            if (event.target !== event.currentTarget || feed.locked) return;
            const minute = Math.min(1425, Math.max(0, Math.floor((event.clientY - event.currentTarget.getBoundingClientRect().top) / 15) * 15));
            openCreate(day, `${String(Math.floor(minute / 60)).padStart(2, "0")}:${String(minute % 60).padStart(2, "0")}`);
          }}>
            {placements(items, day).map(row => <div className={`core-event-position core-draggable${drag.preview?.id === row.item.id ? " core-drag-origin" : ""}`} key={row.item.id}
              onPointerDown={event => drag.begin(event, row.item, index)} onPointerMove={drag.move} onPointerUp={drag.up} onPointerCancel={drag.cancel} onLostPointerCapture={drag.cancel}
              onClick={event => { if (event.target === event.currentTarget && !drag.suppressClick()) openActivity(row.item.id); }}
              style={{ top: row.start, height: Math.min(1440 - row.start, Math.max(30, row.end - row.start)), left: `${row.lane * 100 / row.lanes}%`, width: `${100 / row.lanes}%` }}>
              {eventButton(row.item)}
              {row.item.schedule!.startsAt! >= atTime(day) && <span className="core-resize-handle core-resize-start" data-resize="start" title="Arrastra para cambiar el inicio" aria-hidden="true" />}
              {row.item.schedule!.endsAt! <= atTime(plusDays(day, 1)) && <span className="core-resize-handle core-resize-end" data-resize="end" title="Arrastra para cambiar el fin" aria-hidden="true" />}
            </div>)}
            {previewItem && placements([previewItem], day).map(row => <div className="core-event-position core-drag-preview" key={row.item.id} style={{ top: row.start, height: Math.min(1440 - row.start, Math.max(30, row.end - row.start)), left: 0, width: "100%" }}><strong>{drag.preview!.title}</strong><small>{scheduleLabel(previewItem)}</small></div>)}
            {day === today && now && <div className="core-now-line" style={{ top: minuteAt(now.toISOString()) }}><span /></div>}
          </div>; })}</div>
      </div></div>}
      {feed.data.nextAfterId && <button className="core-text-button" disabled={feed.locked || feed.reading} onClick={() => void feed.load(feed.data.nextAfterId!)}>Cargar más actividades del período</button>}
    </div></section>
    {addingCalendar && <CoreDialog title="Nuevo calendario" close={() => { if (!feed.locked) setAddingCalendar(false); }}>{status()}<form className="core-edit-form" onSubmit={event => { event.preventDefault(); void mutate({ action: "createCalendar", id: crypto.randomUUID(), name: name.trim(), color }, () => { setAddingCalendar(false); setName(""); }); }}><label className="form-field">Nombre<input required maxLength={120} value={name} disabled={feed.locked} onChange={event => setName(event.target.value)} /></label><label className="form-field">Color<input type="color" value={color} disabled={feed.locked} onChange={event => setColor(event.target.value)} /></label><button className="pantry-add-button" disabled={feed.locked || !name.trim()}>Crear calendario</button></form></CoreDialog>}
    {createDate && <CoreDialog title="Crear actividad" close={() => { if (!feed.locked && !mealLocked) setCreateDate(null); }}>
      <label className="form-field core-new-title">Tipo de elemento<select value={createType} disabled={feed.locked || mealLocked} onChange={event => setCreateType(event.target.value as "task" | "meal")}><option value="task">Tarea</option><option value="meal">Comida</option></select></label>
      {createType === "meal" ? <AgendaMealCreator date={createDate} time={createTime!} onLockedChange={setMealLocked} close={() => setCreateDate(null)} saved={mealSaved} /> : <>{status()}<label className="form-field core-new-title">Nombre<input required maxLength={250} value={newTitle} disabled={feed.locked} onChange={event => setNewTitle(event.target.value)} /></label><ScheduleFields calendars={calendars} defaultDate={createDate} defaultTime={createTime} disabled={feed.locked || !newTitle.trim()} allowRecurrence onSave={(schedule, rule) => void mutate(rule ? { action: "createRecurringTask", id: crypto.randomUUID(), title: newTitle.trim(), description: null, schedule, rule } : { action: "createTask", id: crypto.randomUUID(), title: newTitle.trim(), description: null, parentId: null, expectedParentRevision: null, position: 0, schedule }, () => setCreateDate(null))} /></>}
    </CoreDialog>}
    {selectedId && <CoreDialog title="Detalle de actividad" close={() => { if (!feed.busy) closeDetail(); }}>{status()}{selected ? <>
      {selected.parentId && <button className="core-text-button" disabled={feed.locked} onClick={() => void openParent(selected.parentId!)}>Ver tarea principal</button>}
      <ul className="core-inbox-list core-detail-list"><TaskCard item={selected} scopeControls={view === "week" || view === "month"} calendars={calendars} disabled={feed.locked} mutate={mutate} /></ul>
    </> : <p>La actividad ya no está en este período. Su horario puede haberse quitado o cambiado; consulta Inbox u otro período.</p>}</CoreDialog>}
    {editingCalendar && <CalendarEditor calendar={editingCalendar} calendars={calendars} disabled={feed.locked} mutate={mutate} close={() => setEditingCalendar(null)} />}
  </main></CoreFeedback.Provider>;
}
