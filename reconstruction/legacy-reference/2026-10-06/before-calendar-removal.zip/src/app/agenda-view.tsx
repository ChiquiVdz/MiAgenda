"use client";
import { ExpandableMealPreparationSteps, MealPreparationSteps } from "./components/meal-preparation-steps";

import { useEffect, useMemo, useRef, useState, type CSSProperties, type FormEvent, type PointerEvent as ReactPointerEvent } from "react";
import { adjustCalendarTiming, type TimingMode } from "@/lib/calendar-adjustment";
import { CalendarManagerDialog } from "@/app/components/calendar-manager-dialog";
import { CalendarMealForm } from "@/app/components/calendar-meal-form";
import { calendarSlotTime, nextCalendarStart } from "@/lib/calendar-creation";
import { ActivityChecklistEditor, type ChecklistEditorHandle } from "@/app/components/activity-checklist-editor";
import { TaskRecurrenceEditor } from "@/app/components/task-recurrence-editor";
import { MonthAgenda } from "@/app/components/month-agenda";
import { YearAgenda } from "@/app/components/year-agenda";
import { monthDays, moveMonth } from "@/lib/calendar-month";
import { TaskSubtasks, ExpandableTaskSubtasks, type SubtaskProgress } from "@/app/components/task-subtasks";
import { emptyRepeat, type RepeatConfig } from "@/lib/task-recurrence";

import { OptionalIngredientsDialog, type OptionalChoice } from "@/app/components/optional-ingredients-dialog";

const hours = Array.from({ length: 24 }, (_, index) => index);
const weekDays = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
const AGENDA_TIME_ZONE = "America/Mexico_City";
const HOUR_HEIGHT = 58;

type CalendarItem = {
  id: string;
  summary: string;
  color: string | null;
  primary: boolean;
  selected: boolean;
  canWrite: boolean;
  isMeals: boolean;
};

type AgendaEvent = {
  activityId?: string | null;
  isSubtask?: boolean;
  progress?: { done: number; total: number } | null;
  id: string;
  calendarId: string;
  calendarName: string;
  color: string | null;
  summary: string;
  description?: string | null;
  startDate: string | null;
  endDate: string | null;
  startDateTime: string | null;
  endDateTime: string | null;
  recurringEventId: string | null;
  etag: string | null;
  overlay: { completedAt: string | null; keep: boolean; highlighted?: boolean; kind: "plain" | "app_task" | "meal" } | null;
};

type CreateEventDraft = {
  calendarId: string;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
  allDay: boolean;
};

function dateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function agendaRange(days: Date[]) {
  if (days.length !== 7) return null;
  const endDate = new Date(days[0]);
  endDate.setDate(endDate.getDate() + 7);
  // La agenda ya muestra GMT−6 / America/Mexico_City.
  return {
    from: `${dateKey(days[0])}T00:00:00-06:00`,
    to: `${dateKey(endDate)}T00:00:00-06:00`,
  };
}

function zonedMinutes(date: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: AGENDA_TIME_ZONE,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const hour = Number(parts.find((part) => part.type === "hour")?.value ?? 0);
  const minute = Number(parts.find((part) => part.type === "minute")?.value ?? 0);
  return hour * 60 + minute;
}

function eventTimeLabel(event: AgendaEvent) {
  if (!event.startDateTime || !event.endDateTime) return "";
  const time = (value: string) => new Intl.DateTimeFormat("es-MX", {
    timeZone: AGENDA_TIME_ZONE,
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
  return `${time(event.startDateTime)} – ${time(event.endDateTime)}`;
}

function dateTimeInputs(value: string) {
  const values = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
    timeZone: AGENDA_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(value)).map((part) => [part.type, part.value]));
  return {
    date: `${values.year}-${values.month}-${values.day}`,
    time: `${values.hour}:${values.minute}`,
  };
}

function dayWindow(date: Date) {
  const key = dateKey(date);
  const start = new Date(`${key}T00:00:00-06:00`);
  return { key, start: start.getTime(), end: start.getTime() + 24 * 60 * 60 * 1000 };
}

function addDaysToKey(value: string, amount: number) {
  const date = new Date(`${value}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + amount);
  return date.toISOString().slice(0, 10);
}

function minutesAfter(date: string, time: string, minutes: number) {
  const timestamp = new Date(`${date}T${time}:00-06:00`).getTime();
  return Number.isFinite(timestamp)
    ? dateTimeInputs(new Date(timestamp + minutes * 60_000).toISOString())
    : { date, time };
}

function draftDuration(draft: CreateEventDraft) {
  const start = new Date(`${draft.startDate}T${draft.startTime}:00-06:00`).getTime();
  const end = new Date(`${draft.endDate}T${draft.endTime}:00-06:00`).getTime();
  return Number.isFinite(start) && Number.isFinite(end) && end > start
    ? Math.max(1, Math.round((end - start) / 60_000))
    : 60;
}

function shiftDraftStart(draft: CreateEventDraft, startDate: string, startTime: string): CreateEventDraft {
  const duration = draftDuration(draft);
  const end = minutesAfter(startDate, startTime, duration);
  return { ...draft, startDate, startTime, endDate: end.date, endTime: end.time };
}

function setDraftEnd(draft: CreateEventDraft, endDate: string, endTime: string): CreateEventDraft {
  const start = new Date(`${draft.startDate}T${draft.startTime}:00-06:00`).getTime();
  const attemptedEnd = new Date(`${endDate}T${endTime}:00-06:00`).getTime();
  if (!Number.isFinite(attemptedEnd) || attemptedEnd > start) return { ...draft, endDate, endTime };
  const correctedEnd = minutesAfter(draft.startDate, draft.startTime, draftDuration(draft));
  return { ...draft, endDate: correctedEnd.date, endTime: correctedEnd.time };
}

function getWeek(date: Date) {
  const sunday = new Date(date);
  sunday.setDate(sunday.getDate() - sunday.getDay());
  sunday.setHours(12, 0, 0, 0);
  return weekDays.map((_, index) => {
    const current = new Date(sunday);
    current.setDate(sunday.getDate() + index);
    return current;
  });
}

function formatDate(date: Date, options: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat("es-MX", {
    ...options,
    timeZone: "America/Mexico_City",
  }).format(date);
}

export function AgendaView({ initialView = "week" }: { initialView?: "week" | "day" | "month" | "year" }) {
  const [view, setView] = useState(initialView);
  const [now, setNow] = useState<string | null>(null);
  useEffect(() => { setNow(new Date().toISOString()); const timer = window.setInterval(() => setNow(new Date().toISOString()), 60000); return () => clearInterval(timer); }, []);
  const todayKey = now ? dateTimeInputs(now).date : "";

  const [optionalSelection, setOptionalSelection] = useState<{ event: AgendaEvent; ingredients: OptionalChoice[] } | null>(null);
  const [focusDate, setFocusDate] = useState<Date | null>(null);
  const [calendarManager, setCalendarManager] = useState<"normal" | "cooking" | null>(null);
  const [calendars, setCalendars] = useState<CalendarItem[]>([]);
  const [calendarLoadState, setCalendarLoadState] = useState<"loading" | "ready" | "error">("loading");
  const [calendarMessage, setCalendarMessage] = useState<string | null>(null);
  const [savingCalendarId, setSavingCalendarId] = useState<string | null>(null);
  const [calendarReload, setCalendarReload] = useState(0);
  const [events, setEvents] = useState<AgendaEvent[]>([]);
  const [eventLoadState, setEventLoadState] = useState<"idle" | "loading" | "ready" | "error">("idle");
  const [eventLoadError, setEventLoadError] = useState<string | null>(null);
  const [eventReload, setEventReload] = useState(0);
  const [createEventOpen, setCreateEventOpen] = useState(false);
  const creationDialog = useRef<HTMLDialogElement>(null);
  const [creationType, setCreationType] = useState<"task" | "meal">("task");
  const [taskTitle, setTaskTitle] = useState("");
  const [activityDraft, setActivityDraft] = useState<{ steps: Array<{ id: string; text: string; completed: boolean }>; templateId: string | null; version?: string }>({ steps: [], templateId: null });
  const [activityBusy, setActivityBusy] = useState(false);
  const [repeat, setRepeat] = useState<RepeatConfig>(emptyRepeat);
  const [repeatDirty, setRepeatDirty] = useState(false);
  const [repeatSupported, setRepeatSupported] = useState(true);
  const [seriesEtag, setSeriesEtag] = useState("");
  const [changeScope, setChangeScope] = useState<"this" | "following" | "all">("this");
  const [scopePrompt, setScopePrompt] = useState(false);
  const [pendingChanges, setPendingChanges] = useState<string[]>([]);
  const [resumingChange, setResumingChange] = useState(false);
  const activityRequest = useRef<{ payload: string; key: string } | null>(null);
  const activityEditor = useRef<ChecklistEditorHandle>(null);
  const gridScroll = useRef<HTMLDivElement>(null);
  const dayColumns = useRef<Array<HTMLDivElement | null>>([]);
  const suppressClickUntil = useRef(0);
  const timingBusy = useRef(false);
  const [timingSaving, setTimingSaving] = useState(false);
  const [timingPreview, setTimingPreview] = useState<AgendaEvent | null>(null);
  const pointerDrag = useRef<{ event: AgendaEvent; mode: TimingMode; x: number; y: number; scroll: number; day: number; moved: boolean; pointerId: number; preview: AgendaEvent } | null>(null);
  const allDayDrag = useRef<{ event: AgendaEvent; day: string } | null>(null);
  const [editingEvent, setEditingEvent] = useState<AgendaEvent | null>(null);
  const [detailEvent, setDetailEvent] = useState<AgendaEvent | null>(null);
  const detailDialog = useRef<HTMLDialogElement>(null);
  const [detailDeleting, setDetailDeleting] = useState(false);
  const [detailBusy, setDetailBusy] = useState(false);
  const [highlightSaving, setHighlightSaving] = useState(false);
  const [detailChecklistReload, setDetailChecklistReload] = useState(0);
  const [expandedDayGroups, setExpandedDayGroups] = useState<Record<string, boolean>>({});
  const [dayChecklistBusy, setDayChecklistBusy] = useState<Record<string, boolean>>({});
  const [dayChecklistReload, setDayChecklistReload] = useState<Record<string, number>>({});
  const [detailConfirm, setDetailConfirm] = useState(false);
  const [detailScope, setDetailScope] = useState<"this" | "following" | "all">("this");
  const [detailError, setDetailError] = useState<string | null>(null);
  const detailRequest = useRef<{ payload: string; key: string } | null>(null);
  const [deleteEventConfirm, setDeleteEventConfirm] = useState(false);
  const [createEventSaving, setCreateEventSaving] = useState(false);
  const [createEventError, setCreateEventError] = useState<string | null>(null);
  const [eventActionMessage, setEventActionMessage] = useState<string | null>(null);
  const [eventActionError, setEventActionError] = useState(false);
  const [savingEventActionKey, setSavingEventActionKey] = useState<string | null>(null);
  const [createEventDraft, setCreateEventDraft] = useState<CreateEventDraft>({
    calendarId: "", startDate: "", startTime: "09:00", endDate: "", endTime: "10:00", allDay: false,
  });

  useEffect(() => setFocusDate(new Date(`${dateTimeInputs(new Date().toISOString()).date}T12:00:00`)), []);
  useEffect(() => { const dialog = detailDialog.current; if (detailEvent) dialog?.showModal(); return () => dialog?.close(); }, [Boolean(detailEvent)]);
  function openEventDetails(event: AgendaEvent) {
    if (Date.now() < suppressClickUntil.current || timingBusy.current) return;
    setDetailEvent(event); setDetailBusy(false); setDetailConfirm(false); setDetailScope("this"); setDetailError(null); detailRequest.current = null;
  }
  function updateSubtaskProgress(event: AgendaEvent, result: SubtaskProgress) {
    const update = (item: AgendaEvent) => item.id === event.id && item.calendarId === event.calendarId ? { ...item,
      progress: result.steps.length ? { done: result.steps.filter((step) => step.completed).length, total: result.steps.length } : null,
      overlay: { ...item.overlay, completedAt: result.completedAt, keep: result.keep, kind: item.overlay?.kind ?? "app_task" as const } } : item;
    setEvents((current) => current.map(update)); setDetailEvent((current) => current ? update(current) : null);
  }
  function updateMealProgress(event: AgendaEvent, result: { completedAt: string | null; keep: boolean }) {
    const update = (item: AgendaEvent): AgendaEvent => item.id === event.id && item.calendarId === event.calendarId ? { ...item,
      overlay: { ...item.overlay, completedAt: result.completedAt, keep: result.keep, kind: "meal" } } : item;
    setEvents((items) => items.map(update));
    setDetailEvent((item) => item ? update(item) : null);
  }
  async function deleteDetail() {
    if (!detailEvent || detailDeleting) return;
    setDetailDeleting(true); setDetailError(null);
    const meal = detailEvent.overlay?.kind === "meal";
    const change = { calendarId: detailEvent.calendarId, eventId: detailEvent.id, etag: detailEvent.etag, scope: detailScope, action: "delete" };
    const payload = JSON.stringify(change);
    if (detailRequest.current?.payload !== payload) detailRequest.current = { payload, key: crypto.randomUUID() };
    try {
      const response = await fetch(meal ? `/api/events/${encodeURIComponent(detailEvent.id)}` : "/api/recurrence-changes", { method: meal ? "DELETE" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(meal ? { calendarId: detailEvent.calendarId, etag: detailEvent.etag } : { ...change, key: detailRequest.current.key }) });
      const result = await response.json().catch(() => null); if (!response.ok) throw new Error(result?.error ?? "No pudimos eliminar la actividad.");
      setDetailEvent(null); setEventActionMessage("Actividad eliminada de Google Calendar.");
    } catch (cause) { setDetailError(cause instanceof Error ? cause.message : "No pudimos eliminar la actividad."); }
    finally { setDetailDeleting(false); setEventReload((current) => current + 1); }
  }

  async function unscheduleDetail() {
    if (!detailEvent || detailDeleting || detailBusy || !detailEvent.etag) return;
    const expired = detailEvent.overlay?.completedAt && Date.now() - Date.parse(detailEvent.overlay.completedAt) >= 5 * 86400000;
    const warning = `¿Quitar el horario y pasar esta tarea a Inbox? Se quitará su evento de Google y se desactivarán Conservar y Destacar. Se mantienen el progreso y los horarios propios de sus subtareas.${detailEvent.recurringEventId ? " Solo afecta esta instancia de la serie." : ""}${expired ? " Esta tarea ya cumplió cinco días desde completarse y podrá eliminarse al limpiar Inbox." : ""}`;
    if (!window.confirm(warning)) return;
    setDetailDeleting(true); setDetailError(null);
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(detailEvent.id)}/unschedule`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ calendarId: detailEvent.calendarId, etag: detailEvent.etag }) });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos quitar el horario.");
      setDetailEvent(null); setEventActionError(false); setEventActionMessage("La tarea está en Inbox con su progreso. Sus subtareas programadas conservan sus eventos.");
      setEventReload((value) => value + 1);
    } catch (error) { setDetailError(error instanceof Error ? error.message : "No pudimos quitar el horario."); }
    finally { setDetailDeleting(false); }
  }

  async function toggleHighlight(event: AgendaEvent) {
    if (highlightSaving || !event.etag) return;
    setHighlightSaving(true); setDetailError(null);
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(event.id)}/highlight`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ calendarId: event.calendarId, etag: event.etag, highlighted: !event.overlay?.highlighted }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No pudimos guardar el destacado.");
      const update = (item: AgendaEvent): AgendaEvent => item.id === event.id && item.calendarId === event.calendarId ? { ...item, overlay: { completedAt: item.overlay?.completedAt ?? null, keep: result.keep, kind: item.overlay?.kind ?? "plain", highlighted: result.highlighted } } : item;
      setEvents((current) => {
        const updated = current.map(update);
        if (view === "year" && result.highlighted && !updated.some((item) => item.id === event.id && item.calendarId === event.calendarId)) updated.push(update(event));
        return updated.filter((item) => view !== "year" || item.overlay?.highlighted);
      });
      setDetailEvent((current) => current ? update(current) : null);
      setDetailChecklistReload((current) => current + 1);
      const eventKey = `${event.calendarId}\u0000${event.id}`;
      setDayChecklistReload((current) => ({ ...current, [eventKey]: (current[eventKey] ?? 0) + 1 }));
    } catch (cause) { setDetailError(cause instanceof Error ? cause.message : "No pudimos guardar el destacado."); }
    finally { setHighlightSaving(false); }
  }

  useEffect(() => {
    const dialog = creationDialog.current;
    if (createEventOpen) dialog?.showModal();
    return () => dialog?.close();
  }, [createEventOpen]);

  useEffect(() => {
    let cancelled = false;

    async function loadCalendars() {
      setCalendarLoadState("loading");
      setCalendarMessage(null);
      try {
        const response = await fetch("/api/calendars", { cache: "no-store" });
        const result = await response.json().catch(() => null);
        if (!response.ok || !Array.isArray(result?.calendars)) {
          throw new Error("No pudimos cargar tus calendarios de Google.");
        }
        if (!cancelled) {
          setCalendars(result.calendars as CalendarItem[]);
          setCalendarLoadState("ready");
        }
      } catch {
        if (!cancelled) setCalendarLoadState("error");
      }
    }

    void loadCalendars();
    return () => { cancelled = true; };
  }, [calendarReload]);

  const days = useMemo(() => (focusDate ? getWeek(focusDate) : []), [focusDate]);
  const monthDates = useMemo(() => focusDate ? monthDays(focusDate) : [], [focusDate]);
  const selectedDayKey = focusDate ? dateKey(focusDate) : "";
  const containsToday = Boolean(todayKey && (view === "day" ? selectedDayKey === todayKey : view === "year" ? selectedDayKey.slice(0, 4) === todayKey.slice(0, 4) : view === "month" ? selectedDayKey.slice(0, 7) === todayKey.slice(0, 7) : days.some((day) => dateKey(day) === todayKey)));
  const range = useMemo(() => view === "day" ? selectedDayKey ? { from: `${selectedDayKey}T00:00:00-06:00`, to: `${addDaysToKey(selectedDayKey, 1)}T00:00:00-06:00` } : null : view === "month" ? monthDates.length ? { from: `${dateKey(monthDates[0])}T00:00:00-06:00`, to: `${addDaysToKey(dateKey(monthDates.at(-1)!), 1)}T00:00:00-06:00` } : null : agendaRange(days), [days, monthDates, view, selectedDayKey]);
  useEffect(() => {
    if (view !== "week" || !containsToday) return;
    const frame = requestAnimationFrame(() => {
      const scroll = gridScroll.current;
      if (scroll) scroll.scrollTop = Math.max(0, 14 + zonedMinutes(new Date()) / 60 * HOUR_HEIGHT - scroll.clientHeight / 3);
    });
    return () => cancelAnimationFrame(frame);
  }, [view, range?.from, containsToday]);
  const selectedCalendarKey = calendars.filter((calendar) => calendar.selected).map((calendar) => calendar.id).sort().join("|");
  useEffect(() => {
    const controller = new AbortController();
    void fetch("/api/recurrence-changes", { cache: "no-store", signal: controller.signal }).then(async (response) => {
      const result = await response.json(); if (response.ok) setPendingChanges(result.pending.map((item: { id: string }) => item.id));
    }).catch(() => undefined);
    return () => controller.abort();
  }, [eventReload]);
  async function resumePendingChange(discard = false) {
    if (resumingChange || !pendingChanges.length) return;
    setResumingChange(true);
    try {
      const response = await fetch("/api/recurrence-changes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(discard ? { discardId: pendingChanges[0] } : { resumeId: pendingChanges[0] }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No pudimos reanudar el cambio.");
      setEventActionError(false); setEventActionMessage(discard ? "Intento descartado; puedes volver a editar la tarea." : "Cambio pendiente terminado.");
    } catch (cause) { setEventActionError(true); setEventActionMessage(cause instanceof Error ? cause.message : "No pudimos reanudar el cambio."); }
    finally { setResumingChange(false); setEventReload((value) => value + 1); }
  }
  const weekLabel = days.length
    ? `${formatDate(days[0], { day: "numeric", month: "short" })} – ${formatDate(days[6], { day: "numeric", month: "short", year: "numeric" })}`
    : "Cargando semana…";

  async function saveTiming(event: AgendaEvent, start: number, end: number) {
    if (timingBusy.current || !event.etag) return;
    if (event.recurringEventId && event.overlay?.kind !== "meal") {
      suppressClickUntil.current = 0; openEditEvent(event);
      const from = dateTimeInputs(new Date(start).toISOString()); const to = dateTimeInputs(new Date(end).toISOString());
      setCreateEventDraft((draft) => ({ ...draft, startDate: event.startDate ? new Date(start).toISOString().slice(0, 10) : from.date,
        startTime: from.time, endDate: event.startDate ? new Date(end).toISOString().slice(0, 10) : to.date, endTime: to.time }));
      setTimingPreview(null); return;
    }
    timingBusy.current = true; setTimingSaving(true); setEventActionError(false); setEventActionMessage(null);
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(event.id)}`, { method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ calendarId: event.calendarId, etag: event.etag, summary: event.summary, allDay: Boolean(event.startDate),
          ...(event.startDate ? { startDate: new Date(start).toISOString().slice(0, 10), endDate: new Date(end).toISOString().slice(0, 10) }
            : { startDateTime: new Date(start).toISOString(), endDateTime: new Date(end).toISOString() }) }) });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos guardar el horario.");
      setEvents((current) => current.map((item) => item.id === event.id && item.calendarId === event.calendarId ? {
        ...item, startDateTime: result?.start?.dateTime ?? new Date(start).toISOString(), endDateTime: result?.end?.dateTime ?? new Date(end).toISOString(),
        ...(event.startDate ? { startDate: result?.start?.date ?? new Date(start).toISOString().slice(0, 10), endDate: result?.end?.date ?? new Date(end).toISOString().slice(0, 10), startDateTime: null, endDateTime: null } : {}),
        etag: result?.etag ?? null,
      } : item));
      setEventActionMessage("Horario actualizado en Google Calendar.");
    } catch (cause) {
      setEventActionError(true); setEventActionMessage(cause instanceof Error ? cause.message : "No pudimos guardar el horario.");
    } finally {
      setTimingPreview(null); timingBusy.current = false; setTimingSaving(false);
      setEventReload((current) => current + 1);
    }
  }

  function startTimingDrag(pointer: ReactPointerEvent<HTMLButtonElement>, event: AgendaEvent, mode: TimingMode, day: number) {
    if (pointer.button !== 0 || timingBusy.current || savingEventActionKey || !event.etag
      || (event.overlay?.kind === "meal" && event.overlay.completedAt)) return;
    pointer.stopPropagation();
    pointer.currentTarget.setPointerCapture(pointer.pointerId);
    pointerDrag.current = { event, mode, x: pointer.clientX, y: pointer.clientY, scroll: gridScroll.current?.scrollTop ?? 0, day,
      moved: false, pointerId: pointer.pointerId, preview: event };
  }

  useEffect(() => {
    const cancel = () => { if (pointerDrag.current) suppressClickUntil.current = Date.now() + 500; pointerDrag.current = null; setTimingPreview(null); };
    const move = (pointer: PointerEvent) => {
      const drag = pointerDrag.current;
      if (!drag || pointer.pointerId !== drag.pointerId) return;
      if (!drag.moved && Math.hypot(pointer.clientX - drag.x, pointer.clientY - drag.y) < 6) return;
      drag.moved = true; pointer.preventDefault();
      const scroll = gridScroll.current;
      if (scroll) {
        const rect = scroll.getBoundingClientRect();
        if (pointer.clientY < rect.top + 28) scroll.scrollTop -= 12;
        if (pointer.clientY > rect.bottom - 28) scroll.scrollTop += 12;
      }
      let targetDay = drag.day;
      if (drag.mode === "move") dayColumns.current.forEach((column, index) => {
        const rect = column?.getBoundingClientRect();
        if (rect && pointer.clientX >= rect.left && pointer.clientX < rect.right) targetDay = index;
      });
      const delta = (pointer.clientY - drag.y + (scroll?.scrollTop ?? drag.scroll) - drag.scroll) / HOUR_HEIGHT * 60;
      const timing = adjustCalendarTiming(Date.parse(drag.event.startDateTime!), Date.parse(drag.event.endDateTime!), drag.mode, delta, targetDay - drag.day,
        drag.event.overlay?.kind === "meal" ? 1440 : Infinity);
      drag.preview = { ...drag.event, startDateTime: new Date(timing.start).toISOString(), endDateTime: new Date(timing.end).toISOString() };
      setTimingPreview(drag.preview);
    };
    const finish = (pointer: PointerEvent) => {
      const drag = pointerDrag.current;
      if (!drag || pointer.pointerId !== drag.pointerId) return;
      pointerDrag.current = null;
      if (!drag.moved) return;
      suppressClickUntil.current = Date.now() + 500;
      if (drag.preview.startDateTime === drag.event.startDateTime && drag.preview.endDateTime === drag.event.endDateTime) { setTimingPreview(null); return; }
      void saveTiming(drag.event, Date.parse(drag.preview.startDateTime!), Date.parse(drag.preview.endDateTime!));
    };
    const key = (event: KeyboardEvent) => { if (event.key === "Escape") cancel(); };
    window.addEventListener("pointermove", move, { passive: false }); window.addEventListener("pointerup", finish);
    window.addEventListener("pointercancel", cancel); window.addEventListener("keydown", key); window.addEventListener("blur", cancel);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", finish); window.removeEventListener("pointercancel", cancel); window.removeEventListener("keydown", key); window.removeEventListener("blur", cancel); };
  });

  useEffect(() => {
    if (!range || calendarLoadState !== "ready" || view === "year") return;
    let cancelled = false;

    async function loadEvents() {
      setEventLoadState("loading");
      setEventLoadError(null);
      try {
        const params = new URLSearchParams({ from: range!.from, to: range!.to });
        const response = await fetch(`/api/events?${params}`, { cache: "no-store" });
        const result = await response.json().catch(() => null);
        if (!response.ok || !Array.isArray(result?.events)) {
          throw new Error(typeof result?.error === "string" ? result.error : "No pudimos cargar los eventos.");
        }
        if (!cancelled) {
          setEvents(result.events as AgendaEvent[]);
          setEventLoadState("ready");
        }
      } catch (error) {
        if (!cancelled) {
          setEvents([]);
          setEventLoadError(error instanceof Error ? error.message : "No pudimos cargar los eventos de Google Calendar.");
          setEventLoadState("error");
        }
      }
    }

    void loadEvents();
    return () => { cancelled = true; };
  }, [range?.from, range?.to, view, calendarLoadState, selectedCalendarKey, eventReload]);

  useEffect(() => {
    if (view !== "year" || !focusDate || calendarLoadState !== "ready") return;
    const controller = new AbortController();
    setEventLoadState("loading"); setEventLoadError(null); setEvents([]);
    (async () => {
      try {
        const resultEvents: AgendaEvent[] = []; let cursor: string | null = null;
        do {
          const params: URLSearchParams = new URLSearchParams({ year: String(focusDate.getFullYear()), ...(cursor ? { cursor } : {}) });
          const response: Response = await fetch(`/api/events/highlights?${params}`, { cache: "no-store", signal: controller.signal });
          const result: { events?: AgendaEvent[]; nextCursor?: string | null; error?: string } = await response.json();
          if (!response.ok || !Array.isArray(result.events)) throw new Error(result.error ?? "No pudimos cargar los destacados.");
          resultEvents.push(...result.events); cursor = result.nextCursor ?? null;
        } while (cursor && !controller.signal.aborted);
        if (!controller.signal.aborted) { setEvents(resultEvents); setEventLoadState("ready"); }
      } catch (cause) {
        if (!controller.signal.aborted) { setEventLoadError(cause instanceof Error ? cause.message : "No pudimos cargar los destacados."); setEventLoadState("error"); }
      }
    })();
    return () => controller.abort();
  }, [view, focusDate?.getFullYear(), calendarLoadState, selectedCalendarKey, eventReload]);

  useEffect(() => {
    if (calendarLoadState !== "ready") return;
    let lastRefreshAt = 0;
    const refreshIfVisible = () => {
      if (pointerDrag.current || timingBusy.current) return;
      const now = Date.now();
      if (document.visibilityState === "visible" && now - lastRefreshAt > 2_000) {
        lastRefreshAt = now;
        setEventReload((current) => current + 1);
      }
    };
    const intervalId = window.setInterval(refreshIfVisible, 60_000);
    window.addEventListener("focus", refreshIfVisible);
    window.addEventListener("miagenda:subtask-scheduled", refreshIfVisible);
    document.addEventListener("visibilitychange", refreshIfVisible);
    return () => {
      window.clearInterval(intervalId);
      window.removeEventListener("focus", refreshIfVisible);
      window.removeEventListener("miagenda:subtask-scheduled", refreshIfVisible);
      document.removeEventListener("visibilitychange", refreshIfVisible);
    };
  }, [calendarLoadState]);

  function movePeriod(amount: number) {
    if (timingBusy.current) return;
    pointerDrag.current = null; setTimingPreview(null);
    setFocusDate((current) => {
      const next = new Date(current ?? new Date());
      if (view === "year") return new Date(next.getFullYear() + amount, 0, 1, 12);
      if (view === "month") return moveMonth(next, amount);
      next.setDate(next.getDate() + amount * (view === "day" ? 1 : 7));
      return next;
    });
  }

  function goToToday(nextView = view) {
    if (timingBusy.current) return;
    pointerDrag.current = null; setTimingPreview(null);
    const current = new Date().toISOString();
    setNow(current);
    setFocusDate(new Date(`${dateTimeInputs(current).date}T12:00:00`));
    setView(nextView);
  }

  function openDay(date: Date) {
    if (timingBusy.current) return;
    pointerDrag.current = null; setTimingPreview(null);
    setFocusDate(new Date(date));
    setView("day");
  }

  function openWeek(date: Date) {
    if (timingBusy.current) return;
    pointerDrag.current = null; setTimingPreview(null);
    setFocusDate(new Date(date)); setView("week");
  }

  function openMonth(date: Date) {
    if (timingBusy.current) return;
    pointerDrag.current = null; setTimingPreview(null);
    setFocusDate(new Date(date)); setView("month");
  }

  function openCreateEvent(selectedDate?: string, selectedTime?: string) {
    setActivityDraft({ steps: [], templateId: null }); setActivityBusy(false); setRepeat(emptyRepeat()); setRepeatDirty(false); setRepeatSupported(true); setScopePrompt(false); setChangeScope("this"); activityRequest.current = null;
    setEditingEvent(null);
    setCreationType("task");
    setTaskTitle("");
    setDeleteEventConfirm(false);
    const next = nextCalendarStart(new Date());
    const startDate = selectedDate ?? (view === "day" ? selectedDayKey || next.date : view === "month" ? containsToday ? next.date : `${selectedDayKey.slice(0, 7)}-01` : view === "year" ? containsToday ? next.date : `${selectedDayKey.slice(0, 4)}-01-01` : days.some((day) => dateKey(day) === next.date) ? next.date : dateKey(days[0] ?? new Date()));
    const startTime = selectedTime ?? next.time;
    const end = minutesAfter(startDate, startTime, 60);
    setCreateEventDraft({
      calendarId: calendars.find((calendar) => calendar.canWrite && calendar.primary)?.id ?? calendars.find((calendar) => calendar.canWrite)?.id ?? "",
      startDate,
      startTime,
      endDate: end.date,
      endTime: end.time,
      allDay: false,
    });
    setCreateEventError(null);
    setCreateEventOpen(true);
  }

  function openEditEvent(event: AgendaEvent) {
    if (Date.now() < suppressClickUntil.current || timingBusy.current) return;
    setActivityDraft({ steps: [], templateId: null }); setActivityBusy(event.overlay?.kind !== "meal"); setRepeat(emptyRepeat()); setRepeatDirty(false); setRepeatSupported(true); setScopePrompt(false); setChangeScope("this"); activityRequest.current = null;
    const start = event.startDateTime ? dateTimeInputs(event.startDateTime) : null;
    const end = event.endDateTime ? dateTimeInputs(event.endDateTime) : null;
    setEditingEvent(event);
    setTaskTitle(event.summary);
    setCreationType(event.overlay?.kind === "meal" ? "meal" : "task");
    setDeleteEventConfirm(false);
    setCreateEventDraft({
      calendarId: event.calendarId,
      startDate: event.startDate ?? start?.date ?? "",
      startTime: start?.time ?? "09:00",
      endDate: event.endDate ?? end?.date ?? event.startDate ?? start?.date ?? "",
      endTime: end?.time ?? "10:00",
      allDay: Boolean(event.startDate && event.endDate),
    });
    setCreateEventError(null);
    setCreateEventOpen(true);
  }

  async function submitCreateEvent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (createEventSaving || activityBusy || (editingEvent && !activityDraft.version)) return;
    if (editingEvent?.recurringEventId && !scopePrompt) { setScopePrompt(true); return; }
    setCreateEventSaving(true);
    setCreateEventError(null);
    const form = new FormData(event.currentTarget);
    const allDay = form.get("allDay") === "on";
    const eventFields = allDay
      ? {
          summary: String(form.get("summary") ?? ""),
          allDay: true,
          startDate: String(form.get("startDate") ?? ""),
          endDate: String(form.get("endDate") ?? ""),
        }
      : {
          summary: String(form.get("summary") ?? ""),
          allDay: false,
          startDateTime: `${String(form.get("startDate") ?? "")}T${String(form.get("startTime") ?? "")}:00-06:00`,
          endDateTime: `${String(form.get("endDate") ?? "")}T${String(form.get("endTime") ?? "")}:00-06:00`,
        };
    const calendarId = editingEvent?.calendarId ?? String(form.get("calendarId") ?? "");
    const draft = { ...eventFields, calendarId, ...activityDraft, repeat };
    const change = editingEvent ? { calendarId, eventId: editingEvent.id, etag: editingEvent.etag, seriesEtag, scope: changeScope,
      action: "edit", summary: taskTitle, steps: activityDraft.steps, version: activityDraft.version,
      start: allDay ? { date: createEventDraft.startDate } : { dateTime: `${createEventDraft.startDate}T${createEventDraft.startTime}:00-06:00`, timeZone: AGENDA_TIME_ZONE },
      end: allDay ? { date: createEventDraft.endDate } : { dateTime: `${createEventDraft.endDate}T${createEventDraft.endTime}:00-06:00`, timeZone: AGENDA_TIME_ZONE },
      ...(repeatDirty ? { repeat } : {}),
    } : null;
    const payload = JSON.stringify(change ?? draft);
    if (activityRequest.current?.payload !== payload) activityRequest.current = { payload, key: crypto.randomUUID() };
    const body = editingEvent ? { ...change, key: activityRequest.current.key } : { ...draft, createKey: activityRequest.current.key };

    try {
      const response = await fetch(editingEvent ? "/api/recurrence-changes" : "/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos crear la actividad.");
      setCreateEventOpen(false);
      setEventActionMessage(editingEvent ? "Actividad actualizada en Google Calendar." : "Actividad creada en Google Calendar.");
      setEventReload((current) => current + 1);
      window.setTimeout(() => setEventActionMessage(null), 4500);
    } catch (error) {
      setCreateEventError(error instanceof Error ? error.message : "No pudimos crear la actividad.");
      setEventReload((value) => value + 1);
    } finally {
      setCreateEventSaving(false);
    }
  }

  async function deleteEvent() {
    if (!editingEvent) return;
    setCreateEventSaving(true);
    setCreateEventError(null);
    try {
      const meal = editingEvent.overlay?.kind === "meal";
      const change = { calendarId: editingEvent.calendarId, eventId: editingEvent.id, etag: editingEvent.etag, seriesEtag, scope: changeScope, action: "delete" };
      const payload = JSON.stringify(change);
      if (activityRequest.current?.payload !== payload) activityRequest.current = { payload, key: crypto.randomUUID() };
      const response = await fetch(meal ? `/api/events/${encodeURIComponent(editingEvent.id)}` : "/api/recurrence-changes", {
        method: meal ? "DELETE" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(meal ? { calendarId: editingEvent.calendarId, etag: editingEvent.etag } : { ...change, key: activityRequest.current.key }),
      });
      if (!response.ok) {
        const result = await response.json().catch(() => null);
        throw new Error(result?.error ?? "No pudimos eliminar la actividad.");
      }
      setCreateEventOpen(false);
      setEditingEvent(null);
      setDeleteEventConfirm(false);
      setEventActionMessage("Actividad eliminada de Google Calendar.");
      setEventReload((current) => current + 1);
      window.setTimeout(() => setEventActionMessage(null), 4500);
    } catch (error) {
      setCreateEventError(error instanceof Error ? error.message : "No pudimos eliminar la actividad.");
      setDeleteEventConfirm(false);
      setEventReload((current) => current + 1);
    } finally {
      setCreateEventSaving(false);
    }
  }

  async function updateEventState(
    eventToUpdate: AgendaEvent,
    action: "complete" | "uncomplete" | "keep" | "unkeep",
    closeEditor = false,
    optionalIngredientIds?: string[],
  ) {
    const eventKey = `${eventToUpdate.calendarId}\u0000${eventToUpdate.id}`;
    if (closeEditor) {
      setCreateEventSaving(true);
      setCreateEventError(null);
    }
    setSavingEventActionKey(eventKey);
    setDetailError(null);
    setEventActionError(false); setEventActionMessage(null);
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(eventToUpdate.id)}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ calendarId: eventToUpdate.calendarId, optionalIngredientIds }),
      });
      const result = await response.json().catch(() => null);
      if (result?.requiresOptionalSelection) { setOptionalSelection({ event: eventToUpdate, ingredients: result.optionalIngredients }); return; }
      if (!response.ok) throw new Error(result?.error ?? "No pudimos actualizar el estado de la actividad.");
      setOptionalSelection(null);
      setDayChecklistReload((current) => ({ ...current, [eventKey]: (current[eventKey] ?? 0) + 1 }));
      setDetailChecklistReload((current) => current + 1);
      const update = (item: AgendaEvent): AgendaEvent => {
        if (item.id !== eventToUpdate.id || item.calendarId !== eventToUpdate.calendarId) return item;
        return {
          ...item,
          progress: result?.progress ?? item.progress,
          overlay: {
            highlighted: item.overlay?.highlighted ?? false,
            completedAt: typeof result?.completedAt === "string" ? result.completedAt : null,
            keep: typeof result?.keep === "boolean" ? result.keep : item.overlay?.keep ?? false,
            kind: item.overlay?.kind ?? "plain",
          },
        };
      };
      setEvents((current) => current.map(update));
      setDetailEvent((current) => current ? update(current) : null);
      setEventReload((current) => current + 1);
      if (closeEditor) {
        setCreateEventOpen(false);
        setEditingEvent(null);
      }
      const messages = {
        complete: "Actividad marcada como completada.",
        uncomplete: "Actividad pendiente de nuevo.",
        keep: "Actividad guardada en Conservar.",
        unkeep: "La actividad volverá a la retención automática.",
      };
      setEventActionError(false);
      setEventActionMessage(messages[action]);
      window.setTimeout(() => setEventActionMessage(null), 4500);
    } catch (error) {
      const message = error instanceof Error ? error.message : "No pudimos actualizar el estado de la actividad.";
      if (closeEditor) setCreateEventError(message);
      else {
        setDetailError(message);
        setEventActionError(true);
        setEventActionMessage(message);
      }
    } finally {
      setSavingEventActionKey(null);
      if (closeEditor) setCreateEventSaving(false);
    }
  }

  async function toggleCalendar(calendar: CalendarItem) {
    const selected = !calendar.selected;
    setCalendarMessage(null);
    setCalendars((current) => current.map((item) => item.id === calendar.id ? { ...item, selected } : item));
    setSavingCalendarId(calendar.id);

    try {
      const response = await fetch(`/api/calendars/${encodeURIComponent(calendar.id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ selected }),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok) throw new Error(result?.error ?? "No pudimos guardar el cambio.");
    } catch {
      setCalendars((current) => current.map((item) => item.id === calendar.id ? { ...item, selected: calendar.selected } : item));
      setCalendarMessage("No pudimos guardar la selección. Inténtalo de nuevo.");
    } finally {
      setSavingCalendarId(null);
    }
  }

  const dayEvents = events.filter((event) => {
    if (!selectedDayKey) return false;
    if (!calendars.some((calendar) => calendar.id === event.calendarId && calendar.selected)) return false;
    if (event.startDate && event.endDate) return event.startDate <= selectedDayKey && event.endDate > selectedDayKey;
    const start = Date.parse(selectedDayKey + "T00:00:00-06:00");
    return event.startDateTime && event.endDateTime && Date.parse(event.startDateTime) < start + 86400000 && Date.parse(event.endDateTime) > start;
  }).sort((a, b) => (a.startDate ? -Infinity : Date.parse(a.startDateTime!)) - (b.startDate ? -Infinity : Date.parse(b.startDateTime!)) || a.summary.localeCompare(b.summary));

  const scopeSelector = <fieldset className="recurrence-scope" disabled={createEventSaving || activityBusy}>
    <legend>{deleteEventConfirm ? "¿Qué tareas quieres eliminar?" : "¿A qué tareas aplicamos los cambios?"}</legend>
    {([{ id: "this", label: "Solo esta tarea" }, { id: "following", label: "Esta y las siguientes" }, { id: "all", label: "Todas las tareas de la serie" }] as const).map((option) =>
      <label key={option.id}><input type="radio" name="recurrence-scope" value={option.id} checked={changeScope === option.id} disabled={!deleteEventConfirm && repeatDirty && option.id === "this"}
        onChange={() => setChangeScope(option.id)} />{option.label}</label>)}
    {!deleteEventConfirm && repeatDirty && <p className="form-hint">Cambiar la repetición requiere modificar las siguientes tareas o toda la serie.</p>}
    {changeScope === "following" && <p className="form-hint">Se conservan las tareas anteriores. Los cambios puntuales en repeticiones siguientes se reinician.</p>}
    <p className="form-hint">Completar una tarea o subtarea siempre afecta solo su día.</p>
  </fieldset>;
  return (
    <main className="app-shell">
      {optionalSelection && <OptionalIngredientsDialog ingredients={optionalSelection.ingredients} busy={savingEventActionKey !== null} error={eventActionError ? eventActionMessage : null} onCancel={() => setOptionalSelection(null)} onConfirm={(ids) => void updateEventState(optionalSelection.event, "complete", false, ids)} />}
      <aside className="sidebar">
        <a className="brand" href="#agenda" aria-label="MiAgenda, inicio">
          <span className="brand-mark">m</span>
          <span>miagenda</span>
        </a>

        <button className="new-item" type="button" disabled={calendarLoadState !== "ready"} onClick={() => openCreateEvent()}>
          <span className="new-item-plus">＋</span>
          <span>Crear actividad</span>
        </button>

        <nav className="primary-nav" aria-label="Navegación principal">
          <a className="nav-item" href="/inbox"><span className="nav-icon" aria-hidden="true">▱</span>Inbox</a>
          <a className="nav-item nav-item-active" href="/" aria-current="page">
            <span className="nav-icon" aria-hidden="true">▦</span>
            Agenda
          </a>
          <a className="nav-item nav-item-muted" href="/cocina">
            <span className="nav-icon" aria-hidden="true">♨</span>
            Cocina
          </a>
        </nav>

        <div className="sidebar-divider" />
        {calendarManager && <CalendarManagerDialog cooking={calendarManager === "cooking"} calendars={calendars} onClose={() => setCalendarManager(null)} onSaved={() => { setCalendarManager(null); setCalendarReload((n) => n + 1); setEventReload((n) => n + 1); }} />}
        <button className="calendar-config" type="button" onClick={() => setCalendarManager("cooking")}>Configurar Cocina</button>
        <section className="calendar-list" aria-labelledby="calendars-heading">
          <div className="section-heading">
            <h2 id="calendars-heading">Mis calendarios</h2>
            <button className="calendar-add" type="button" aria-label="Crear calendario" title="Crear calendario" onClick={() => setCalendarManager("normal")}>＋</button>
          </div>
          {calendarLoadState === "loading" && (
            <div className="connect-note"><span className="connect-note-icon" aria-hidden="true">◷</span><p>Cargando tus calendarios…</p></div>
          )}
          {calendarLoadState === "error" && (
            <div className="connect-note calendar-load-error" role="alert">
              <p>No pudimos cargar Google Calendar.</p>
              <button type="button" onClick={() => setCalendarReload((current) => current + 1)}>Reintentar</button>
            </div>
          )}
          {calendarLoadState === "ready" && calendars.length === 0 && (
            <div className="connect-note"><span className="connect-note-icon" aria-hidden="true">◷</span><p>No hay calendarios disponibles en esta cuenta.</p></div>
          )}
          {calendarLoadState === "ready" && calendars.length > 0 && (
            <ul className="calendar-items">
              {calendars.map((calendar) => (
                <li className="calendar-option" key={calendar.id}>
                  <label className="calendar-option-label" title={calendar.summary}>
                    <input
                      type="checkbox"
                      checked={calendar.selected}
                      disabled={savingCalendarId === calendar.id}
                      onChange={() => void toggleCalendar(calendar)}
                    />
                    <span className="calendar-swatch" style={{ backgroundColor: calendar.color ?? "#90a393" }} />
                    <span className="calendar-option-name">{calendar.summary}</span>
                  </label>
                  {calendar.isMeals && <span className="calendar-primary-label">Cocina</span>}{calendar.primary && <span className="calendar-primary-label">Principal</span>}
                </li>
              ))}
            </ul>
          )}
          {calendarMessage && <p className="calendar-feedback" role="alert">{calendarMessage}</p>}
        </section>

        <div className="sidebar-bottom">
          <div className="privacy-line"><span className="privacy-dot" />Tus datos, bajo tu control</div>
          <div className="profile-row">
            <div className="avatar">E</div>
            <div className="profile-copy"><strong>Tu espacio</strong><span>Cuenta personal</span></div>
            <span className="profile-menu" aria-hidden="true">···</span>
          </div>
        </div>
      </aside>

      <section className="workspace" id="agenda">
        <header className="topbar">
          <div className="breadcrumb"><span>Mi espacio</span><span className="breadcrumb-slash">/</span><strong>Agenda</strong></div>
          <div className="topbar-actions">
            <span className={`sync-status${calendarLoadState === "ready" ? " sync-status-connected" : ""}`}>
              <span />{calendarLoadState === "ready" ? "Google conectado" : calendarLoadState === "loading" ? "Cargando Google" : "Sin conexión"}
            </span>
            <button className="sync-refresh" type="button" onClick={() => setEventReload((current) => current + 1)} disabled={eventLoadState === "loading" || calendarLoadState !== "ready"} aria-label={eventLoadState === "loading" ? "Actualizando eventos" : "Actualizar eventos"} title="Actualizar eventos de Google Calendar">
              {eventLoadState === "loading" ? "…" : "↻"}
            </button>
            <button className="avatar avatar-small" type="button" aria-label="Perfil">E</button>
          </div>
        </header>

        <div className="page-content">
          <div className="page-heading-row">
            <div>
              <p className="eyebrow">TU TIEMPO, CON INTENCIÓN</p>
              <h1>{view === "day" ? "Agenda del día" : view === "month" ? "Agenda mensual" : view === "year" ? "Agenda anual" : "Agenda semanal"}</h1>
              <p className="week-range">{view === "day" ? focusDate ? formatDate(focusDate, { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "Cargando fecha…" : view === "month" ? focusDate ? formatDate(focusDate, { month: "long", year: "numeric" }) : "Cargando mes…" : view === "year" ? focusDate?.getFullYear() ?? "Cargando año…" : weekLabel}</p>
            </div>
            <div className="week-controls" aria-label="Controles de agenda">
              {pendingChanges.length > 0 && <><button type="button" disabled={resumingChange} onClick={() => void resumePendingChange()}>{resumingChange ? "Reanudando…" : "Reanudar cambio pendiente"}</button><button type="button" disabled={resumingChange} onClick={() => void resumePendingChange(true)}>Descartar intento sin aplicar</button></>}
              <button className="week-mobile-create" type="button" onClick={() => openCreateEvent()} disabled={calendarLoadState !== "ready"}>＋ Crear</button>
              <details className="agenda-view-select" onKeyDown={(event) => { if (event.key === "Escape") { event.currentTarget.open = false; event.currentTarget.querySelector("summary")?.focus(); } }} onBlur={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) event.currentTarget.open = false; }}>
                <summary aria-label={`Vista de agenda: ${view === "day" ? "Día" : view === "month" ? "Mes" : view === "year" ? "Año" : "Semana"}`}>{view === "day" ? "Día" : view === "month" ? "Mes" : view === "year" ? "Año" : "Semana"} <span aria-hidden="true">⌄</span></summary>
                <div className="agenda-view-options" aria-label="Vistas de agenda">
                  {([{ id: "day", label: "Día" }, { id: "week", label: "Semana" }, { id: "month", label: "Mes" }, { id: "year", label: "Año" }] as const).map((option) => <button key={option.id} type="button" disabled={!focusDate || timingSaving} aria-pressed={view === option.id} onClick={(event) => { goToToday(option.id); const menu = event.currentTarget.closest("details"); if (menu) { menu.open = false; menu.querySelector("summary")?.focus(); } }}>{option.label}</button>)}
                  
                </div>
              </details>
              {focusDate && todayKey && !containsToday && <button className="today-button" type="button" aria-label={view === "day" ? "Volver al día de hoy" : view === "month" ? "Volver al mes actual" : view === "year" ? "Volver al año actual" : "Volver a la semana actual"} onClick={() => goToToday()}>Hoy</button>}
              <div className="week-arrows">
                <button type="button" aria-label={view === "day" ? "Día anterior" : view === "month" ? "Mes anterior" : view === "year" ? "Año anterior" : "Semana anterior"} onClick={() => movePeriod(-1)}>‹</button>
                <button type="button" aria-label={view === "day" ? "Día siguiente" : view === "month" ? "Mes siguiente" : view === "year" ? "Año siguiente" : "Semana siguiente"} onClick={() => movePeriod(1)}>›</button>
              </div>
            </div>
          </div>

          {view === "year" ? <YearAgenda year={focusDate?.getFullYear() ?? new Date().getFullYear()} today={todayKey} events={events.filter((event) => event.overlay?.highlighted && calendars.some((calendar) => calendar.id === event.calendarId && calendar.selected))} loading={eventLoadState === "loading" || eventLoadState === "idle"} error={eventLoadState === "error" ? eventLoadError : null} onRetry={() => setEventReload((current) => current + 1)} onMonth={openMonth} onOpen={openEventDetails} /> : view === "day" ? <section className="today-agenda" aria-label="Actividades del día seleccionado">
            {eventLoadState === "loading" && <p role="status">Actualizando el día…</p>}
            {eventLoadState === "error" && <p className="form-error" role="alert">{eventLoadError} <button type="button" onClick={() => setEventReload((n) => n + 1)}>Reintentar</button></p>}
            {eventLoadState === "ready" && dayEvents.length === 0 && <div className="today-empty"><h2>Este día está libre</h2><p>No hay actividades en tus calendarios visibles para esta fecha.</p><button className="dialog-submit" type="button" onClick={() => openCreateEvent()}>Crear actividad</button></div>}
            {[{ title: "Pendientes", completed: false }, { title: "Completados", completed: true }].map((group) => {
              const items = dayEvents.filter((event) => (expandedDayGroups[`${event.calendarId}\u0000${event.id}`] ?? Boolean(event.overlay?.completedAt)) === group.completed);
              return items.length > 0 && <section key={group.title} className="today-group"><h2>{group.title} <span>{items.length}</span></h2><ul>{items.map((event) => {
                const key = `${event.calendarId}\u0000${event.id}`;
                const ongoing = event.startDateTime && event.endDateTime && now && Date.parse(event.startDateTime) <= Date.parse(now) && Date.parse(event.endDateTime) > Date.parse(now);
                const overdue = !group.completed && event.endDateTime && now && Date.parse(event.endDateTime) <= Date.parse(now);
                return <li key={key} className={group.completed ? "today-item today-item-completed" : "today-item"} style={{ borderLeftColor: event.color ?? "#809984" }}>
                  <button type="button" className="today-completion" aria-pressed={Boolean(event.overlay?.completedAt)} aria-label={`${group.completed ? "Deshacer completado de" : "Completar"} ${event.summary}`} disabled={Boolean(savingEventActionKey) || dayChecklistBusy[key]} onClick={() => void updateEventState(event, event.overlay?.completedAt ? "uncomplete" : "complete")}>{event.overlay?.completedAt ? "✓" : ""}</button>
                  <div className="today-event-content"><button type="button" className="today-event-detail" disabled={dayChecklistBusy[key]} onClick={() => openEventDetails(event)}><span className="today-event-time">{event.startDate ? "Todo el día" : eventTimeLabel(event)}{!group.completed && ongoing ? " · En curso" : overdue ? " · Pendiente de completar" : ""}</span><strong>{event.overlay?.highlighted ? "★ " : ""}{event.summary}</strong>{event.progress && <span>{event.progress.done}/{event.progress.total} pasos</span>}<span>{event.overlay?.kind === "meal" ? "♨ Comida · " : ""}{event.calendarName}{event.overlay?.keep ? " · Conservado" : ""}</span></button>{event.overlay?.kind !== "meal" && <ExpandableTaskSubtasks event={event} total={event.progress?.total ?? 0} done={event.progress?.done ?? 0} reloadKey={dayChecklistReload[key]} onBusy={(busy) => setDayChecklistBusy((current) => ({ ...current, [key]: busy }))} onOpen={(open) => setExpandedDayGroups((current) => { const next = { ...current }; if (open) next[key] = group.completed; else delete next[key]; return next; })} disabled={!calendars.find((calendar) => calendar.id === event.calendarId)?.canWrite || Boolean(savingEventActionKey)} onProgress={(result) => updateSubtaskProgress(event, result)} onApplied={() => setEventReload((current) => current + 1)} />}{event.overlay?.kind === "meal" && <ExpandableMealPreparationSteps event={event} reloadKey={dayChecklistReload[key]} disabled={Boolean(savingEventActionKey) || !calendars.find((calendar) => calendar.id === event.calendarId)?.canWrite} onBusy={(busy) => setDayChecklistBusy((current) => ({ ...current, [key]: busy }))} onProgress={(result) => updateMealProgress(event, result)} onApplied={() => setEventReload((n) => n + 1)} />}</div>
                </li>;
              })}</ul></section>;
            })}
          </section> : view === "month" ? <MonthAgenda key={selectedDayKey.slice(0, 7)} days={monthDates} month={focusDate?.getMonth() ?? 0} today={todayKey} events={events.filter((event) => calendars.some((calendar) => calendar.id === event.calendarId && calendar.selected))} canCreate={calendarLoadState === "ready" && calendars.some((calendar) => calendar.canWrite)} loading={eventLoadState === "loading" || eventLoadState === "idle"} error={eventLoadState === "error" ? eventLoadError : null} onRetry={() => setEventReload((current) => current + 1)} onCreate={(date) => openCreateEvent(date)} onOpen={openEventDetails} onWeek={openWeek} /> : <div className="calendar-card">
            <div className="day-header-row">
              <div className="timezone-cell">GMT−6</div>
              {weekDays.map((day, index) => {
                const date = days[index];
                const isToday = Boolean(date && dateKey(date) === todayKey);
                return (
                  <button type="button" className={`day-heading day-heading-link${isToday ? " day-heading-today" : ""}`} key={day} disabled={!date || timingSaving} aria-label={date ? `Ver día ${formatDate(date, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}` : "Cargando día"} onClick={() => date && openDay(date)}>
                    <span>{day}</span>
                    <strong>{date ? formatDate(date, { day: "numeric" }) : "–"}</strong>
                    {isToday && <i>HOY</i>}
                  </button>
                );
              })}
            </div>
            <div className="all-day-row" aria-label="Eventos de día completo">
              <div className="all-day-label">Día completo</div>
              {days.map((date) => {
                const day = dayWindow(date);
                const allDayEvents = events.filter((event) => event.startDate && event.endDate && event.startDate <= day.key && event.endDate > day.key);
                return (
                  <div className="all-day-cell" key={day.key} onDragOver={(drag) => { if (allDayDrag.current) { drag.preventDefault(); drag.dataTransfer.dropEffect = "move"; } }} onDrop={(drag) => {
                    const source = allDayDrag.current; allDayDrag.current = null;
                    if (!source) return;
                    drag.preventDefault();
                    const delta = Date.parse(day.key + "T00:00:00Z") - Date.parse(source.day + "T00:00:00Z");
                    if (delta) void saveTiming(source.event, Date.parse(source.event.startDate! + "T00:00:00Z") + delta, Date.parse(source.event.endDate! + "T00:00:00Z") + delta);
                  }}>
                    {allDayEvents.map((event) => (
                      <div className="all-day-event-container" key={`${event.calendarId}:${event.id}`} style={{ "--event-color": event.color ?? "#78947d" } as CSSProperties}>
                        <button className={`all-day-event${event.overlay?.completedAt ? " all-day-event-completed" : ""}`} type="button" draggable={Boolean(event.etag) && !timingSaving && !(event.overlay?.kind === "meal" && event.overlay.completedAt)}
                          onDragStart={(drag) => { allDayDrag.current = { event, day: day.key }; drag.dataTransfer.effectAllowed = "move"; drag.dataTransfer.setData("text/plain", event.id); }} onDragEnd={() => { allDayDrag.current = null; suppressClickUntil.current = Date.now() + 500; }}
                          title={`${event.summary} · ${event.calendarName}`} onClick={() => openEventDetails(event)}>
                          {event.overlay?.highlighted ? "★ " : ""}{event.summary}{event.progress ? ` · ${event.progress.done}/${event.progress.total}` : ""}
                        </button>
                        <button className={`event-completion${event.overlay?.completedAt ? " event-completion-checked" : ""}`} type="button" disabled={timingSaving || Boolean(timingPreview) || savingEventActionKey === `${event.calendarId}\u0000${event.id}`} aria-pressed={Boolean(event.overlay?.completedAt)} aria-label={`${event.overlay?.completedAt ? "Deshacer completado de" : "Completar"} ${event.summary}`} title={event.overlay?.completedAt ? "Deshacer completado" : "Completar"} onClick={() => void updateEventState(event, event.overlay?.completedAt ? "uncomplete" : "complete")}>
                          {event.overlay?.completedAt ? "✓" : ""}
                        </button>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
            <div className="time-grid-scroll" ref={gridScroll}>
              <div className="time-grid">
                <div className="hour-column">
                  {hours.map((hour) => <div className="hour-label" key={hour}>{`${String(hour).padStart(2, "0")}:00`}</div>)}
                </div>
                {days.map((date, dayIndex) => {
                  const window = dayWindow(date);
                  const dayEvents = events.flatMap((event) => {
                    if (!event.startDateTime || !event.endDateTime) return [];
                    const start = new Date(event.startDateTime).getTime();
                    const end = new Date(event.endDateTime).getTime();
                    const clippedStart = Math.max(start, window.start);
                    const clippedEnd = Math.min(end, window.end);
                    if (!Number.isFinite(start) || !Number.isFinite(end) || clippedEnd <= clippedStart) return [];
                    const top = start < window.start ? 0 : zonedMinutes(new Date(start)) / 60 * HOUR_HEIGHT;
                    const height = Math.max(20, (clippedEnd - clippedStart) / 60000 / 60 * HOUR_HEIGHT);
                    return [{ event, top, height }];
                  });
                  return (
                    <div className="day-column" key={window.key} ref={(element) => { dayColumns.current[dayIndex] = element; }}>
                      {now && window.key === todayKey && <div className="current-time-line" style={{ top: zonedMinutes(new Date(now)) / 60 * HOUR_HEIGHT }} role="img" aria-label={`Hora actual: ${dateTimeInputs(now).time}`}><span className="current-time-dot" /></div>}
                      {hours.map((hour) => <button className="hour-slot calendar-create-slot" key={hour} type="button" disabled={calendarLoadState !== "ready" || !calendars.some((calendar) => calendar.canWrite)}
                        aria-label={`Crear el ${window.key} a las ${String(hour).padStart(2, "0")}:00`} title="Pulsa para crear una tarea o comida"
                        onClick={(event) => { const rect = event.currentTarget.getBoundingClientRect(); openCreateEvent(window.key, calendarSlotTime(hour, event.detail === 0 ? 0 : event.clientY - rect.top, rect.height)); }} />)}
                      {dayEvents.map(({ event, top, height }) => (
                        <div className="agenda-event-container" key={`${event.calendarId}:${event.id}`} style={{ top, height, opacity: timingPreview?.id === event.id && timingPreview.calendarId === event.calendarId ? .35 : 1, "--event-color": event.color ?? "#78947d" } as CSSProperties}>
                          <button className={`agenda-event agenda-event-draggable${event.overlay?.completedAt ? " agenda-event-completed" : ""}`} title={`${event.summary}\n${event.calendarName}\n${eventTimeLabel(event)}\nArrastra para mover; pulsa para ver detalles`} aria-label={`Ver ${event.summary}${eventTimeLabel(event) ? `, ${eventTimeLabel(event)}` : ""}`} type="button" onPointerDown={(pointer) => startTimingDrag(pointer, event, "move", dayIndex)} onClick={() => openEventDetails(event)}>
                            <strong>{event.summary}</strong>
                            {event.progress && <span className="event-step-progress">{event.progress.done}/{event.progress.total} pasos</span>}
                            <span>{eventTimeLabel(event)}</span>
                          </button>
                          {event.etag && !(event.overlay?.kind === "meal" && event.overlay.completedAt) && <>
                            <button className="event-resize event-resize-start" type="button" disabled={timingSaving} aria-label={`Ajustar inicio de ${event.summary}`} title="Arrastra para ajustar el inicio; pulsa para editar" onPointerDown={(pointer) => startTimingDrag(pointer, event, "start", dayIndex)} onClick={() => openEventDetails(event)} />
                            <button className="event-resize event-resize-end" type="button" disabled={timingSaving} aria-label={`Ajustar fin de ${event.summary}`} title="Arrastra para ajustar el fin; pulsa para editar" onPointerDown={(pointer) => startTimingDrag(pointer, event, "end", dayIndex)} onClick={() => openEventDetails(event)} />
                          </>}
                          <button className={`event-completion${event.overlay?.completedAt ? " event-completion-checked" : ""}`} type="button" disabled={timingSaving || Boolean(timingPreview) || savingEventActionKey === `${event.calendarId}\u0000${event.id}`} aria-pressed={Boolean(event.overlay?.completedAt)} aria-label={`${event.overlay?.completedAt ? "Deshacer completado de" : "Completar"} ${event.summary}`} title={event.overlay?.completedAt ? "Deshacer completado" : "Completar"} onClick={() => void updateEventState(event, event.overlay?.completedAt ? "uncomplete" : "complete")}>
                            {event.overlay?.completedAt ? "✓" : ""}
                          </button>
                        </div>
                      ))}
                      {timingPreview && (() => {
                        const start = Math.max(Date.parse(timingPreview.startDateTime!), window.start);
                        const end = Math.min(Date.parse(timingPreview.endDateTime!), window.end);
                        if (end <= start) return null;
                        return <div className="event-timing-preview" style={{ top: (start - window.start) / 3600000 * HOUR_HEIGHT, height: Math.max(20, (end - start) / 3600000 * HOUR_HEIGHT) }}><strong>{timingPreview.summary}</strong><span>{eventTimeLabel(timingPreview)}</span></div>;
                      })()}
                    </div>
                  );
                })}
              </div>
              {eventLoadState === "ready" && events.length === 0 && <div className="empty-state">
                <div className="empty-illustration" aria-hidden="true">
                  <span className="empty-sun" />
                  <span className="empty-page"><i /><i /><i /></span>
                  <span className="empty-spark spark-one">✳</span>
                  <span className="empty-spark spark-two">✳</span>
                </div>
                <h2>{selectedCalendarKey ? "Tu semana está libre" : "Activa un calendario"}</h2>
                <p>{selectedCalendarKey ? "No hay eventos en los calendarios seleccionados para esta semana." : "Selecciona al menos un calendario en la barra lateral para ver sus eventos."}</p>
              </div>}
              {eventLoadState === "loading" && <div className="event-status" role="status">Cargando eventos de la semana…</div>}
              {eventLoadState === "error" && <div className="event-status event-status-error" role="alert">
                <span>{eventLoadError ?? "No pudimos cargar los eventos de Google Calendar."}</span>
                <button type="button" onClick={() => setEventReload((current) => current + 1)}>Reintentar</button>
              </div>}
            </div>
          </div>}
          {eventActionMessage && <p className={`action-feedback${eventActionError ? " action-feedback-error" : ""}`} role={eventActionError ? "alert" : "status"}>{eventActionMessage}</p>}
          {timingSaving && <p className="action-feedback" role="status">Guardando horario…</p>}
          <p className="footer-note">Google Calendar será la fuente de tus fechas y horarios. MiAgenda añade las herramientas para organizarte.</p>
        </div>
      </section>
      {detailEvent && <dialog ref={detailDialog} className="event-dialog calendar-creation-dialog" aria-labelledby="event-detail-title" onCancel={(event) => { event.preventDefault(); if (!detailDeleting && !detailBusy && !highlightSaving && !savingEventActionKey) setDetailEvent(null); }}>
        <div className="dialog-heading"><div><p className="eyebrow">{detailEvent.calendarName}</p><h2 id="event-detail-title">{detailEvent.summary}</h2></div><button className="dialog-close" type="button" disabled={detailDeleting || detailBusy || highlightSaving || Boolean(savingEventActionKey)} aria-label="Cerrar" onClick={() => setDetailEvent(null)}>×</button></div>
        <p>{detailEvent.startDate ?? (detailEvent.startDateTime ? dateTimeInputs(detailEvent.startDateTime).date : "")} · {detailEvent.startDate ? "Todo el día" : eventTimeLabel(detailEvent)}</p>
        <p>{detailEvent.overlay?.completedAt ? "✓ Completada" : "Pendiente"}{detailEvent.overlay?.keep ? " · Conservada" : ""}{detailEvent.recurringEventId ? " · Recurrente" : ""}</p>
        {detailEvent.description && <p className="event-description">{detailEvent.description}</p>}
        <div className="event-highlight-actions"><button className="highlight-toggle" type="button" aria-pressed={Boolean(detailEvent.overlay?.highlighted)} disabled={detailBusy || detailDeleting || highlightSaving || Boolean(savingEventActionKey) || !detailEvent.etag} onClick={() => void toggleHighlight(detailEvent)}>{highlightSaving ? "Guardando…" : detailEvent.overlay?.highlighted ? "★ Quitar destacado" : "☆ Destacar en Año"}</button>
          <button className="highlight-toggle" type="button" aria-pressed={Boolean(detailEvent.overlay?.keep)} disabled={detailBusy || detailDeleting || highlightSaving || Boolean(savingEventActionKey)} onClick={() => void updateEventState(detailEvent, detailEvent.overlay?.keep ? "unkeep" : "keep")}>{savingEventActionKey ? "Guardando…" : detailEvent.overlay?.keep ? "Quitar Conservar" : "Conservar"}</button>
          {detailEvent.recurringEventId && <span className="form-hint">Solo esta instancia.</span>}</div>
        <p className="form-hint">Al activar Destacado también se activa Conservar. Después puedes cambiar ambos por separado.</p>
        {detailEvent.overlay?.kind !== "meal" && <TaskSubtasks key={`${detailEvent.calendarId}:${detailEvent.id}:${detailChecklistReload}`} event={detailEvent} allowSeriesMarks={view === "week"} onBusy={setDetailBusy} disabled={detailDeleting || highlightSaving || Boolean(savingEventActionKey)} onProgress={(result) => updateSubtaskProgress(detailEvent, result)} onApplied={() => setEventReload((current) => current + 1)} />}
        {detailEvent.overlay?.kind === "meal" && <><MealPreparationSteps key={`${detailEvent.calendarId}:${detailEvent.id}:${detailChecklistReload}`} event={detailEvent} disabled={detailDeleting || highlightSaving || Boolean(savingEventActionKey) || !calendars.find((calendar) => calendar.id === detailEvent.calendarId)?.canWrite} onBusy={setDetailBusy} onProgress={(result) => updateMealProgress(detailEvent, result)} onApplied={() => setEventReload((n) => n + 1)} /><p className="form-hint">Abre Editar para cambiar recetas, porciones y fases.</p></>}
        {detailError && <p className="form-error" role="alert">{detailError}</p>}
        {detailConfirm ? <div className="delete-confirm"><p>¿Eliminar de Google Calendar y MiAgenda? También se eliminarán los eventos de sus subtareas programadas.</p>{detailEvent.recurringEventId && detailEvent.overlay?.kind !== "meal" && <label>Alcance <select value={detailScope} disabled={detailDeleting} onChange={(event) => setDetailScope(event.target.value as "this" | "following" | "all")}><option value="this">Solo esta tarea</option><option value="following">Esta y las siguientes</option><option value="all">Toda la serie</option></select></label>}<div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={detailDeleting} onClick={() => setDetailConfirm(false)}>Cancelar</button><button className="dialog-delete-confirm" type="button" disabled={detailDeleting} onClick={() => void deleteDetail()}>{detailDeleting ? "Eliminando…" : "Sí, eliminar"}</button></div></div>
          : <div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={detailDeleting || detailBusy || highlightSaving || Boolean(savingEventActionKey)} onClick={() => setDetailEvent(null)}>Cerrar</button>{calendars.find((calendar) => calendar.id === detailEvent.calendarId)?.canWrite && <>{detailEvent.overlay?.kind !== "meal" && !detailEvent.isSubtask && <button className="dialog-cancel" type="button" disabled={detailDeleting || detailBusy || highlightSaving || Boolean(savingEventActionKey) || !detailEvent.etag} onClick={() => void unscheduleDetail()}>{detailDeleting ? "Trasladando…" : "Quitar horario"}</button>}<button className="dialog-delete" type="button" disabled={detailDeleting || detailBusy || highlightSaving || Boolean(savingEventActionKey)} onClick={() => setDetailConfirm(true)}>Eliminar</button><button className="dialog-submit" type="button" disabled={detailDeleting || detailBusy || highlightSaving || Boolean(savingEventActionKey)} onClick={() => { const event = detailEvent; setDetailEvent(null); openEditEvent(event); }}>Editar</button></>}</div>}
      </dialog>}
      {createEventOpen && <dialog ref={creationDialog} className="event-dialog calendar-creation-dialog" aria-labelledby="create-event-title" onCancel={(event) => { event.preventDefault(); if (!createEventSaving && !activityBusy) setCreateEventOpen(false); }}>
          <div className="dialog-heading">
            <div><p className="eyebrow">GOOGLE CALENDAR</p><h2 id="create-event-title">{editingEvent ? "Editar actividad" : creationType === "meal" ? "Crear comida" : "Crear tarea"}</h2></div>
            <button className="dialog-close" type="button" disabled={createEventSaving || activityBusy} onClick={() => setCreateEventOpen(false)} aria-label="Cerrar">×</button>
          </div>
          {!editingEvent && <div className="creation-type-picker" role="group" aria-label="Tipo de elemento">
            <button type="button" aria-pressed={creationType === "task"} disabled={createEventSaving} onClick={() => setCreationType("task")}>✓ Tarea</button>
            <button type="button" aria-pressed={creationType === "meal"} disabled={createEventSaving} onClick={() => setCreationType("meal")}>♨ Comida</button>
          </div>}
          {(!editingEvent || creationType === "meal") && <CalendarMealForm eventId={editingEvent?.id} active={creationType === "meal"} schedule={createEventDraft} calendars={calendars.filter((calendar) => calendar.canWrite)}
            onPersisted={() => setEventReload((current) => current + 1)}
            onScheduleChange={(value) => setCreateEventDraft((draft) => shiftDraftStart({ ...draft, ...value }, value.startDate ?? draft.startDate, value.startTime ?? draft.startTime))}
            onBusyChange={setCreateEventSaving} onCancel={() => setCreateEventOpen(false)} onCreated={() => {
              setCreateEventOpen(false); setEventActionError(false); setEventActionMessage("Bloque guardado en Agenda y Planificar.");
              setEventReload((current) => current + 1);
            }} />}
          {editingEvent && creationType === "meal" && <>
            {createEventError && <p className="form-error" role="alert">{createEventError}</p>}
            <div className="dialog-actions"><button type="button" className="dialog-cancel" disabled={createEventSaving} onClick={() => void updateEventState(editingEvent, editingEvent.overlay?.keep ? "unkeep" : "keep", true)}>{editingEvent.overlay?.keep ? "Quitar de Conservar" : "Conservar"}</button>
            <button type="button" className="dialog-delete" disabled={createEventSaving || Boolean(editingEvent.overlay?.completedAt)} onClick={() => setDeleteEventConfirm(true)}>Eliminar bloque</button></div>
            {deleteEventConfirm && <div className="delete-confirm" role="alert"><p>Se eliminará el bloque completo de MiAgenda y Google Calendar.</p><button type="button" disabled={createEventSaving} onClick={() => setDeleteEventConfirm(false)}>Cancelar</button><button type="button" className="dialog-delete-confirm" disabled={createEventSaving} onClick={() => void deleteEvent()}>Sí, eliminar</button></div>}
          </>}
          {creationType === "task" && (calendars.filter((calendar) => calendar.canWrite).length === 0
            ? <p className="dialog-empty">Necesitas un calendario con permiso de escritura para crear una actividad.</p>
            : <form className="event-form" onSubmit={(event) => void submitCreateEvent(event)}>
                <label className="form-field">Título
                  <input name="summary" type="text" value={taskTitle} onChange={(event) => setTaskTitle(event.target.value)} maxLength={250} placeholder="Ej. Clase de Arquitectura" autoFocus required />
                </label>
                <label className="form-field">Calendario
                  <select name="calendarId" value={createEventDraft.calendarId} disabled={Boolean(editingEvent)} onChange={(event) => setCreateEventDraft((draft) => ({ ...draft, calendarId: event.target.value }))} required>
                    {calendars.filter((calendar) => calendar.canWrite).map((calendar) => <option key={calendar.id} value={calendar.id}>{calendar.summary}</option>)}
                  </select>
                </label>
                {editingEvent && <input type="hidden" name="calendarId" value={editingEvent.calendarId} />}
                <label className="all-day-toggle"><input name="allDay" type="checkbox" checked={createEventDraft.allDay} onChange={(event) => setCreateEventDraft((draft) => {
                  if (!event.target.checked) {
                    const end = minutesAfter(draft.startDate, draft.startTime, 60);
                    return { ...draft, allDay: false, endDate: end.date, endTime: end.time };
                  }
                  return { ...draft, allDay: true, endDate: draft.endDate <= draft.startDate ? addDaysToKey(draft.startDate, 1) : draft.endDate };
                })} /> Todo el día</label>
                <div className="form-date-grid">
                <label className="form-field">Inicia
                    <input name="startDate" type="date" value={createEventDraft.startDate} onChange={(event) => setCreateEventDraft((draft) => draft.allDay
                      ? { ...draft, startDate: event.target.value, endDate: draft.endDate <= event.target.value ? addDaysToKey(event.target.value, 1) : draft.endDate }
                      : shiftDraftStart(draft, event.target.value, draft.startTime))} required />
                  </label>
                  {!createEventDraft.allDay && <label className="form-field">Hora de inicio
                    <input name="startTime" type="time" value={createEventDraft.startTime} onChange={(event) => setCreateEventDraft((draft) => shiftDraftStart(draft, draft.startDate, event.target.value))} required />
                  </label>}
                  <label className="form-field">Termina
                    <input name="endDate" type="date" min={createEventDraft.allDay ? addDaysToKey(createEventDraft.startDate, 1) : createEventDraft.startDate} value={createEventDraft.endDate} onChange={(event) => setCreateEventDraft((draft) => draft.allDay
                      ? { ...draft, endDate: event.target.value }
                      : setDraftEnd(draft, event.target.value, draft.endTime))} required />
                  </label>
                  {!createEventDraft.allDay && <label className="form-field">Hora de fin
                    <input name="endTime" type="time" min={createEventDraft.endDate === createEventDraft.startDate ? createEventDraft.startTime : undefined} value={createEventDraft.endTime} onChange={(event) => setCreateEventDraft((draft) => setDraftEnd(draft, draft.endDate, event.target.value))} required />
                  </label>}
                </div>
                {createEventDraft.allDay && <p className="form-hint">La fecha final no se incluye en el evento de día completo.</p>}
                <p className="form-hint">Las horas usan la zona America/Mexico_City (GMT−6).</p>
                {repeatSupported || repeatDirty ? <TaskRecurrenceEditor value={repeat} startDate={createEventDraft.startDate} disabled={createEventSaving || activityBusy} onChange={(value) => { setRepeat(value); setRepeatDirty(true); if (editingEvent?.recurringEventId) setChangeScope("following"); }} />
                  : <p className="form-hint">Esta tarea tiene una repetición personalizada de Google. Se conservará. <button type="button" onClick={() => { setRepeatDirty(true); setChangeScope("following"); }}>Cambiar repetición</button></p>}
                <ActivityChecklistEditor saveRef={activityEditor} key={editingEvent ? `${editingEvent.calendarId}:${editingEvent.id}` : "new"} event={editingEvent ?? undefined} allowSeriesMarks={view === "week"} disabled={createEventSaving} onApplied={() => setEventReload((current) => current + 1)}
                  onDraft={setActivityDraft} onBusy={setActivityBusy} onRecurrence={(value, etag) => { setRepeat(value ?? emptyRepeat()); setRepeatSupported(Boolean(value)); setRepeatDirty(false); setSeriesEtag(etag); }} onProgress={(value) => {
                    const progress = value.steps.length ? { done: value.steps.filter((step) => step.completed).length, total: value.steps.length } : null;
                    const change = (item: AgendaEvent) => ({ ...item, progress, overlay: { ...item.overlay, completedAt: value.completedAt, keep: value.keep, kind: item.overlay?.kind ?? "app_task" } });
                    setEditingEvent((item) => item ? change(item) : null);
                    setEvents((items) => items.map((item) => item.id === editingEvent?.id && item.calendarId === editingEvent.calendarId ? change(item) : item));
                  }} />
                {scopePrompt && !deleteEventConfirm && editingEvent?.recurringEventId && scopeSelector}
                {createEventError && <p className="form-error" role="alert">{createEventError}</p>}
                {deleteEventConfirm
                  ? <div className="delete-confirm" role="alert">
                      <p>Se eliminarán las tareas del alcance elegido y los eventos de sus subtareas programadas de Google Calendar y de MiAgenda.</p>
                      {editingEvent?.recurringEventId && scopeSelector}
                      <div className="dialog-actions">
                        <button className="dialog-cancel" type="button" disabled={createEventSaving} onClick={() => setDeleteEventConfirm(false)}>Cancelar</button>
                        <button className="dialog-delete-confirm" type="button" disabled={createEventSaving} onClick={() => void deleteEvent()}>{createEventSaving ? "Eliminando…" : "Sí, eliminar"}</button>
                      </div>
                    </div>
                  : <div className="dialog-actions">
                      {editingEvent && <button className="dialog-cancel" type="button" disabled={createEventSaving} onClick={() => void updateEventState(editingEvent, editingEvent.overlay?.keep ? "unkeep" : "keep", true)}>{createEventSaving ? "Guardando…" : editingEvent.overlay?.keep ? "Quitar de Conservar" : "Conservar"}</button>}
                      {editingEvent && <button className="dialog-delete" type="button" disabled={createEventSaving} onClick={() => setDeleteEventConfirm(true)}>Eliminar</button>}
                      <button className="dialog-cancel" type="button" disabled={createEventSaving || activityBusy} onClick={() => setCreateEventOpen(false)}>Cancelar</button>
                      <button className="dialog-submit" type="submit" disabled={createEventSaving || activityBusy || Boolean(editingEvent && !activityDraft.version) || activityDraft.steps.some((step) => !step.text.trim())}>{createEventSaving ? "Guardando…" : editingEvent ? scopePrompt ? "Aplicar cambios" : "Guardar cambios" : "Crear actividad"}</button>
                    </div>}
              </form>)}
      </dialog>}
    </main>
  );
}






