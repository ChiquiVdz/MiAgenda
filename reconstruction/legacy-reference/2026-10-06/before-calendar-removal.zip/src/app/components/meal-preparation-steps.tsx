"use client";
import { useEffect, useRef, useState } from "react";
import type { PreparationStep } from "@/lib/recipe-steps";
import { SubtaskSchedule } from "./subtask-schedule";

type Step = PreparationStep & { scheduleStepId: string; ingredients: Array<{ name: string; quantity: number; unit: string; used: boolean | null }> };
type State = { version: string; etag: string | null; startDateTime?: string; completedAt: string | null; keep: boolean; recipes: Array<{ id: string; name: string; cookingEnabled: boolean; steps: Step[] }> };
type Props = { event: { id: string; calendarId: string; etag: string | null }; disabled?: boolean; onApplied: () => void; onBusy?: (busy: boolean) => void; onProgress?: (state: { completedAt: string | null; keep: boolean }) => void };
export function MealPreparationSteps({ event, disabled, onApplied, onBusy, onProgress }: Props) {
  const [state, setState] = useState<State | null>(null);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const busyRef = useRef(false), callbacks = useRef({ onApplied, onBusy, onProgress });
  callbacks.current = { onApplied, onBusy, onProgress };
  async function load(signal?: AbortSignal) {
    const response = await fetch(`/api/meal-blocks/steps?${new URLSearchParams({ calendarId: event.calendarId, eventId: event.id })}`, { cache: "no-store", signal });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error ?? "No pudimos cargar los pasos.");
    setState(result); callbacks.current.onProgress?.(result); return result as State;
  }
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch((cause) => { if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "No pudimos cargar los pasos."); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
    // This instance owns its progress until the parent explicitly reloads it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [event.id, event.calendarId]);
  useEffect(() => {
    const refresh = () => { if (!busyRef.current && document.visibilityState === "visible") void load().catch(() => {}); };
    window.addEventListener("focus", refresh);
    const timer = window.setInterval(refresh, 60000);
    return () => { window.removeEventListener("focus", refresh); clearInterval(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [event.id, event.calendarId]);
  async function toggle(planId: string, step: Step) {
    if (!state || busyRef.current || disabled) return;
    busyRef.current = true; setBusy(true); setError(null); callbacks.current.onBusy?.(true);
    try {
      const response = await fetch("/api/meal-blocks/steps", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ calendarId: event.calendarId, eventId: event.id, etag: state.etag, planId, stepId: step.id, completed: !step.completed, version: state.version }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No pudimos guardar el paso.");
      setState(result);
      callbacks.current.onProgress?.(result);
      if (result.completedAt !== state.completedAt) callbacks.current.onApplied();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos guardar el paso.");
      const fresh = await load().catch(() => null);
      if (fresh && fresh.completedAt !== state.completedAt) callbacks.current.onApplied();
    } finally { busyRef.current = false; setBusy(false); callbacks.current.onBusy?.(false); }
  }
  return <section className="meal-preparation-steps" aria-label="Pasos de preparación">
    {loading && <p className="form-hint">Cargando pasos…</p>}
    {error && <p className="form-error" role="alert">{error} <button type="button" disabled={busy} onClick={() => void load().then(() => { setError(null); callbacks.current.onApplied(); }).catch((cause) => setError(cause.message))}>Actualizar</button></p>}
    {state?.recipes.map((recipe) => <section key={recipe.id}><h4>{recipe.name}</h4>{!recipe.cookingEnabled ? <p className="form-hint">Sin cocinar: utiliza porciones ya preparadas.</p> : <ul>{recipe.steps.map((step) => <li key={step.id}>
      <label><input type="checkbox" checked={step.completed} disabled={busy || disabled || Boolean(state.completedAt) || !state.etag} onChange={() => void toggle(recipe.id, step)} /><span>{step.text}{step.isOptional && <small className="optional-badge">{state.completedAt && !step.completed ? step.ingredients.some((line) => line.used) ? "Parcial" : "Omitido" : "Opcional"}</small>}{step.ingredients.length > 0 && <small className="meal-step-quantity">{step.ingredients.map((line) => `${line.name}: ${line.quantity} ${line.unit === "piece" ? "piezas" : line.unit}${state.completedAt && step.isOptional ? line.used ? " · usado" : " · omitido" : ""}`).join(" · ")}</small>}</span></label>
      {step.priorTiming && <SubtaskSchedule parent={{ calendarId: event.calendarId, eventId: event.id }} stepId={step.scheduleStepId} version={state.version} disabled={busy || disabled}
        suggestedStart={state.startDateTime ? new Date(Date.parse(state.startDateTime) - step.priorTiming.minutesBefore * 60000).toISOString() : undefined}
        suggestedDuration={step.priorTiming.durationMinutes} onBusy={(value) => { busyRef.current = value; setBusy(value); callbacks.current.onBusy?.(value); }} onSaved={async () => { await load(); }} />}
    </li>)}</ul>}</section>)}
    {state && !state.completedAt && state.recipes.some((recipe) => recipe.cookingEnabled) && <p className="form-hint">Marca los opcionales que usaste antes del último paso obligatorio. Al terminar los obligatorios se completa todo el bloque y se descuentan los ingredientes.</p>}
    {state?.completedAt && <p className="form-hint">Comida completada. Deshaz desde el círculo del bloque para corregir sus pasos.</p>}
  </section>;
}

export function ExpandableMealPreparationSteps(props: Props & { reloadKey?: number }) {
  const [open, setOpen] = useState(false);
  return <details className="day-subtasks" onToggle={(event) => setOpen(event.currentTarget.open)}><summary>Pasos de preparación</summary>{open && <MealPreparationSteps key={props.reloadKey} {...props} />}</details>;
}
