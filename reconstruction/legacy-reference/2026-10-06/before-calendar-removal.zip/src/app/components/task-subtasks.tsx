"use client";
import { useRef, useState } from "react";
import { ActivityChecklistEditor, type ChecklistEditorHandle } from "./activity-checklist-editor";
import { DayTaskSubtasks } from "./day-task-subtasks";
export type SubtaskProgress = { steps: Array<{ id: string; text: string; completed: boolean }>; completedAt: string | null; keep: boolean };
type Props = { event: { id: string; calendarId: string }; disabled: boolean; onProgress: (value: SubtaskProgress) => void; onApplied: () => void; onBusy?: (busy: boolean) => void; allowSeriesMarks?: boolean };
export function TaskSubtasks(props: Props) {
  const ref = useRef<ChecklistEditorHandle>(null);
  return <ActivityChecklistEditor {...props} readOnly saveRef={ref} onDraft={() => undefined} onBusy={props.onBusy ?? (() => undefined)} onRecurrence={() => undefined} />;
}
export function ExpandableTaskSubtasks(props: Props & { total: number; done: number; reloadKey?: number; onOpen: (open: boolean) => void }) {
  const [open, setOpen] = useState(false);
  return <details className="day-subtasks" onToggle={(event) => { const value = event.currentTarget.open; setOpen(value); props.onOpen(value); }}><summary>{props.total ? `Subtareas · ${props.done}/${props.total}` : "＋ Subtareas"}</summary>{open && <DayTaskSubtasks {...props} />}</details>;
}
