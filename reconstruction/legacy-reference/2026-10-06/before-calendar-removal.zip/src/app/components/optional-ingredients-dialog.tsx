"use client";

import { useEffect, useRef, useState } from "react";
export type OptionalChoice = { ingredientId: string; name: string; unit: string; requiredQuantity: number; availableQuantity: number };

export function OptionalIngredientsDialog({ ingredients, busy, error, onConfirm, onCancel }: {
  ingredients: OptionalChoice[]; busy: boolean; error: string | null;
  onConfirm: (ids: string[]) => void; onCancel: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [selected, setSelected] = useState(() => ingredients.map((line) => line.ingredientId));
  useEffect(() => { const element = dialog.current; element?.showModal(); return () => element?.close(); }, []);
  return <dialog ref={dialog} className="optional-ingredients-dialog" aria-labelledby="optional-title" onCancel={(event) => { event.preventDefault(); if (!busy) onCancel(); }}>
    <h2 id="optional-title">¿Qué opcionales usaste?</h2>
    <p>Marca los ingredientes que utilizaste al cocinar. Solo esos se descontarán de tu alacena.</p>
    <div className="optional-ingredients-choices">{ingredients.map((line) => <label key={line.ingredientId} className="optional-ingredient-choice">
      <input type="checkbox" checked={selected.includes(line.ingredientId)} disabled={busy} onChange={(event) => setSelected((current) => event.target.checked ? [...current, line.ingredientId] : current.filter((id) => id !== line.ingredientId))} />
      <span><strong>{line.name}</strong><small>{line.requiredQuantity} {line.unit === "piece" ? "piezas" : line.unit} para esta cocinada</small></span>
    </label>)}</div>
    {error && <p className="pantry-message pantry-error" role="alert">{error}</p>}
    <div className="optional-dialog-actions"><button className="dialog-cancel" type="button" disabled={busy} onClick={onCancel}>Cancelar</button><button className="pantry-save-button" type="button" disabled={busy} onClick={() => onConfirm(selected)}>{busy ? "Guardando…" : "Confirmar y completar"}</button></div>
  </dialog>;
}
