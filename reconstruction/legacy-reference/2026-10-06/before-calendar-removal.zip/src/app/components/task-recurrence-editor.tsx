"use client";
import { repeatDays, type RepeatConfig } from "@/lib/task-recurrence";
export function TaskRecurrenceEditor({ value, onChange, disabled, startDate }: { value: RepeatConfig; onChange: (value: RepeatConfig) => void; disabled: boolean; startDate: string }) {
  const labels = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
  return <fieldset className="task-recurrence-editor" disabled={disabled}>
    <label className="form-field">Repetir<select value={value.frequency} onChange={(event) => {
      const frequency = event.target.value as RepeatConfig["frequency"];
      const day = repeatDays[(new Date(`${startDate}T12:00:00Z`).getUTCDay() + 6) % 7] ?? "MO";
      onChange({ ...value, frequency, days: value.days.length ? value.days : [day] });
    }}><option value="none">No se repite</option><option value="daily">Cada día</option><option value="weekly">Cada semana / elegir días</option><option value="monthly">Cada mes</option><option value="yearly">Cada año</option></select></label>
    {value.frequency !== "none" && <>
      <label className="form-field">Cada cuántos {value.frequency === "daily" ? "días" : value.frequency === "weekly" ? "semanas" : value.frequency === "monthly" ? "meses" : "años"}<input type="number" min={1} max={99} required value={value.interval} onChange={(event) => onChange({ ...value, interval: Number(event.target.value) })} /></label>
      {value.frequency === "weekly" && <div className="repeat-weekdays" role="group" aria-label="Días de repetición">{repeatDays.map((day, index) => <label key={day}><input type="checkbox" checked={value.days.includes(day)} onChange={() => onChange({ ...value, days: value.days.includes(day) ? value.days.filter((item) => item !== day) : [...value.days, day] })} />{labels[index]}</label>)}</div>}
      <label className="form-field">Termina<select value={value.ending} onChange={(event) => onChange({ ...value, ending: event.target.value as RepeatConfig["ending"] })}><option value="never">Nunca</option><option value="date">En una fecha</option><option value="count">Después de cierto número de veces</option></select></label>
      {value.ending === "date" && <label className="form-field">Última fecha<input type="date" min={startDate} required value={value.until} onChange={(event) => onChange({ ...value, until: event.target.value })} /></label>}
      {value.ending === "count" && <label className="form-field">Veces<input type="number" min={1} max={1000} required value={value.count} onChange={(event) => onChange({ ...value, count: Number(event.target.value) })} /></label>}
    </>}
  </fieldset>;
}
