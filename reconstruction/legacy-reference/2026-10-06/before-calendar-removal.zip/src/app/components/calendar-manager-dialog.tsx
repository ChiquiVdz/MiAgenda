"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";

export function CalendarManagerDialog({ cooking = false, calendars, onSaved, onClose }: {
  cooking?: boolean; calendars: Array<{ id: string; summary: string; canWrite: boolean; isMeals?: boolean }>;
  onSaved: () => void; onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [name, setName] = useState(cooking ? "Cocina" : "");
  const [color, setColor] = useState(cooking ? "#e67c33" : "#4285f4");
  const [existing, setExisting] = useState(cooking ? calendars.find((calendar) => calendar.isMeals)?.id ?? "" : "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const request = useRef<{ payload: string; key: string } | null>(null);
  const saving = useRef(false);
  useEffect(() => { dialog.current?.showModal(); }, []);
  async function submit(event: FormEvent) {
    event.preventDefault(); if (saving.current) return;
    const payload = JSON.stringify(cooking && existing ? { action: "bindCooking", calendarId: existing } : { name, color, cooking });
    if (request.current?.payload !== payload) request.current = { payload, key: crypto.randomUUID() };
    saving.current = true; setBusy(true); setError(null);
    try {
      const response = await fetch("/api/calendars", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...JSON.parse(payload), key: request.current.key }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No pudimos guardar el calendario.");
      onSaved();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos guardar el calendario."); }
    finally { saving.current = false; setBusy(false); }
  }
  return <dialog ref={dialog} className="event-dialog" onCancel={(event) => { if (saving.current) event.preventDefault(); else onClose(); }}>
    <div className="dialog-heading"><h2>{cooking ? "Calendario de Cocina" : "Crear calendario"}</h2></div>
    <form className="event-form" onSubmit={(event) => void submit(event)}>
      <fieldset disabled={busy}>
        {cooking && <><p className="form-hint">Las comidas se guardan en este calendario de Google. Ocultarlo en Agenda mantiene activo el planificador y las compras.</p>
          <label className="form-field">Usar calendario<select value={existing} onChange={(event) => setExisting(event.target.value)}>
            <option value="">{calendars.some((calendar) => calendar.isMeals) ? "Usar el calendario propio de Cocina" : "Crear un calendario propio de Cocina"}</option>{calendars.filter((c) => c.canWrite).map((c) => <option key={c.id} value={c.id}>{c.summary}{c.isMeals ? " · actual" : ""}</option>)}
          </select></label></>}
        {!existing && (!cooking || !calendars.some((calendar) => calendar.isMeals)) && <><label className="form-field">Nombre<input value={name} maxLength={150} required onChange={(event) => setName(event.target.value)} /></label>
          <label className="form-field">Color<input type="color" value={color} onChange={(event) => setColor(event.target.value)} /></label></>}
        {!cooking && <p className="form-hint">Este calendario aparecerá también en Google Calendar. Podrás elegirlo al crear actividades.</p>}
      </fieldset>
      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="dialog-actions"><button type="button" className="dialog-cancel" disabled={busy} onClick={onClose}>Cerrar</button><button className="dialog-submit" disabled={busy}>{busy ? "Guardando…" : cooking ? "Configurar Cocina" : "Crear calendario"}</button></div>
    </form>
  </dialog>;
}
