"use client";
import { useEffect, useRef, useState } from "react";
import type { PreparationStep } from "@/lib/recipe-steps";
import { SubtaskSchedule, notifySubtaskSchedules } from "./subtask-schedule";

type Step = PreparationStep & { scheduleStepId: string };
type State = { version: string; startDateTime: string; recipes: Array<{ id: string; name: string; cookingEnabled: boolean; steps: Step[] }> };
type Draft = { selected: boolean; start: string; duration: string };
type Status = { pending: boolean; missing: boolean };
function localTime(value: number) {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "America/Mexico_City", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(value)).replace(" ", "T");
}
export function MealPriorOffers({ calendarId, eventId, onDone, onBusy }: {
  calendarId: string; eventId: string; onDone: () => void; onBusy: (busy: boolean) => void;
}) {
  const [state, setState] = useState<State | null>(null), [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [schedules, setSchedules] = useState<Record<string, Status>>({});
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState<string | null>(null);
  const [savedCount, setSavedCount] = useState(0);
  const busyRef = useRef(false);
  async function load(signal?: AbortSignal) {
    const parent = { parentCalendarId: calendarId, parentEventId: eventId };
    const options = { cache: "no-store" as const, signal };
    const responses = await Promise.all([
      fetch(`/api/meal-blocks/steps?${new URLSearchParams({ calendarId, eventId })}`, options),
      fetch(`/api/subtasks/status?${new URLSearchParams(parent)}`, options),
    ]);
    const [result, status] = await Promise.all(responses.map((response) => response.json()));
    if (!responses[0].ok || !responses[1].ok) throw new Error(result.error ?? status.error ?? "No pudimos cargar las preparaciones.");
    if (signal?.aborted) return;
    setState(result); setSchedules(status.schedules);
    setDrafts((current) => Object.fromEntries((result as State).recipes.flatMap((recipe) => recipe.cookingEnabled ? recipe.steps.filter((step) => step.priorTiming).map((step) => [step.scheduleStepId,
      current[step.scheduleStepId] ?? { selected: false, start: localTime(Date.parse(result.startDateTime) - step.priorTiming!.minutesBefore * 60000), duration: String(step.priorTiming!.durationMinutes) },
    ]) : [])));
  }
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch((cause) => { if (!controller.signal.aborted) setError(cause.message); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
    // This dialog belongs to one saved meal.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calendarId, eventId]);
  function change(id: string, changes: Partial<Draft>) { setDrafts((current) => ({ ...current, [id]: { ...current[id], ...changes } })); }
  const steps = state?.recipes.flatMap((recipe) => recipe.cookingEnabled ? recipe.steps.filter((step) => step.priorTiming).map((step) => ({ ...step, recipeName: recipe.name })) : []) ?? [];
  const selected = steps.filter((step) => drafts[step.scheduleStepId]?.selected && (!schedules[step.scheduleStepId] || schedules[step.scheduleStepId].pending));
  async function save() {
    if (!state || busyRef.current || !selected.length) return;
    for (const step of selected) {
      const draft = drafts[step.scheduleStepId], duration = Number(draft.duration), start = Date.parse(`${draft.start}:00-06:00`);
      if (!Number.isFinite(start) || !Number.isInteger(duration) || duration < 1 || duration > 1440) { setError("Revisa fecha, hora y duración (de 1 a 1440 minutos) de las preparaciones seleccionadas."); return; }
    }
    busyRef.current = true; setBusy(true); onBusy(true); setError(null);
    try {
      for (const step of selected) {
        const draft = drafts[step.scheduleStepId];
        const response = await fetch("/api/subtasks/schedule", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
          parentCalendarId: calendarId, parentEventId: eventId, stepId: step.scheduleStepId, version: state.version, calendarId,
          startDateTime: `${draft.start}:00-06:00`, endDateTime: new Date(Date.parse(`${draft.start}:00-06:00`) + Number(draft.duration) * 60000).toISOString().replace(".000Z", "Z"),
        }) });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error ?? "No pudimos agendar esta preparación.");
        setSchedules((current) => ({ ...current, [step.scheduleStepId]: { pending: false, missing: false } }));
        change(step.scheduleStepId, { selected: false }); setSavedCount((count) => count + 1);
      }
      notifySubtaskSchedules({ calendarId, eventId });
      await load();
    } catch (cause) {
      notifySubtaskSchedules({ calendarId, eventId });
      setError(cause instanceof Error ? cause.message : "No pudimos agendar las preparaciones.");
      await load().catch(() => {});
    } finally { busyRef.current = false; setBusy(false); onBusy(false); }
  }
  return <section className="meal-prior-offers">
    <h3>¿Quieres agendar sus preparaciones previas?</h3>
    <p className="form-hint">La comida ya está guardada. Elige las preparaciones que quieras añadir a su calendario; puedes cambiar cada horario. No se agrega ninguna automáticamente.</p>
    {loading && <p role="status">Cargando preparaciones…</p>}
    {steps.map((step) => {
      const draft = drafts[step.scheduleStepId]; if (!draft) return null;
      const existing = schedules[step.scheduleStepId];
      return <section className="meal-prior-notice" key={step.scheduleStepId}>
        <strong>{step.recipeName}</strong>
        <label className="all-day-toggle"><input type="checkbox" checked={draft.selected} disabled={busy || Boolean(existing && !existing.pending)} onChange={(e) => change(step.scheduleStepId, { selected: e.target.checked })} />{step.text}{step.isOptional ? " (opcional)" : ""}</label>
        {!existing && <div className="form-date-grid">
          <label className="form-field">Inicio<input type="datetime-local" value={draft.start} disabled={busy} onChange={(e) => change(step.scheduleStepId, { start: e.target.value })} /></label>
          <label className="form-field">Duración (min)<input type="number" min="1" max="1440" value={draft.duration} disabled={busy} onChange={(e) => change(step.scheduleStepId, { duration: e.target.value })} /></label>
        </div>}
        {!existing && Date.parse(`${draft.start}:00-06:00`) < Date.now() && <p className="form-hint">La hora sugerida ya pasó. Puedes cambiarla antes de agendar.</p>}
        {existing && <SubtaskSchedule parent={{ calendarId, eventId }} stepId={step.scheduleStepId} version={state!.version} disabled={busy} onBusy={(value) => { busyRef.current = value; setBusy(value); onBusy(value); }} onSaved={() => load()} />}
        {existing?.pending && <p className="form-hint">Guardado pendiente: selecciona esta preparación y reintenta para recuperar el mismo evento.</p>}
      </section>;
    })}
    {!loading && state && !steps.length && <p>No hay preparaciones previas para agendar.</p>}
    {savedCount > 0 && <p role="status">Preparaciones agendadas: {savedCount}.</p>}
    {error && <p className="form-error" role="alert">{error} <button type="button" disabled={busy} onClick={() => void load().then(() => setError(null)).catch((cause) => setError(cause.message))}>Actualizar</button></p>}
    <div className="dialog-actions"><button type="button" className="dialog-cancel" disabled={busy} onClick={onDone}>{savedCount ? "Terminar" : "Continuar sin agregar más"}</button><button type="button" className="dialog-submit" disabled={busy || loading || !state || !selected.length} onClick={() => void save()}>{busy ? "Agendando…" : `Agendar seleccionadas (${selected.length})`}</button></div>
  </section>;
}
