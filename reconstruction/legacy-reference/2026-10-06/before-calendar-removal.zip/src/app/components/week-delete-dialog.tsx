"use client";
import { useEffect, useRef, useState } from "react";
import { addWeekDays } from "@/lib/meal-week-copy";
type Target = { id: string; version: string; etag: string | null; summary: string; completed: boolean };
type Preview = { meals: Target[]; pending: number; completed: number };
async function post(body: unknown) {
  const response = await fetch("/api/meals/delete-week", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await response.json().catch(() => null);
  if (!response.ok || !data) throw new Error(data?.error ?? "No pudimos continuar el borrado.");
  return data;
}
export function WeekDeleteDialog({ week, onClose, onDeleted }: { week: string; onClose: () => void; onDeleted: (count: number) => void }) {
  const dialog = useRef<HTMLDialogElement>(null), busyRef = useRef(false), removedRef = useRef(0);
  const [preview, setPreview] = useState<Preview | null>(null), [removed, setRemoved] = useState(0);
  const [busy, setBusy] = useState(false), [loading, setLoading] = useState(true), [error, setError] = useState<string | null>(null);
  const [reload, setReload] = useState(0);
  useEffect(() => {
    dialog.current?.showModal(); let cancelled = false;
    setLoading(true); setError(null);
    void post({ action: "preview", week }).then((result) => { if (!cancelled) { setPreview(result); removedRef.current = 0; setRemoved(0); } })
      .catch((cause) => { if (!cancelled) setError(cause instanceof Error ? cause.message : "No pudimos revisar la semana."); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [week, reload]);
  async function run() {
    if (!preview || busyRef.current) return;
    busyRef.current = true; setBusy(true); setError(null);
    try {
      for (let index = removedRef.current; index < preview.meals.length; index++) {
        await post({ action: "delete", week, target: preview.meals[index] });
        removedRef.current = index + 1; setRemoved(index + 1);
      }
      await post({ action: "finish", week });
      onDeleted(preview.meals.length);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "El borrado se interrumpió."); }
    finally { busyRef.current = false; setBusy(false); }
  }
  return <dialog ref={dialog} className="event-dialog week-copy-dialog" aria-labelledby="week-delete-title" onCancel={(event) => { if (busy) event.preventDefault(); else onClose(); }}>
    <div className="dialog-heading"><h2 id="week-delete-title">Borrar comidas de la semana</h2><button className="dialog-close" type="button" disabled={busy} onClick={onClose} aria-label="Cerrar">×</button></div>
    <p>{week} al {addWeekDays(week, 6)}</p>
    {loading && <p role="status">Revisando las comidas…</p>}
    {preview && <><p>Se eliminarán {preview.meals.length} bloques: {preview.pending} pendientes y {preview.completed} completados, de MiAgenda y Google Calendar.</p><p><strong>Lo consumido seguirá descontado.</strong> Las sobras se conservan. Se liberan las reservas de las comidas pendientes. Este borrado es definitivo y ya no permitirá deshacer esos completados.</p><ul>{preview.meals.map((meal) => <li key={meal.id}>{meal.summary} · {meal.completed ? "completada" : "pendiente"}</li>)}</ul></>}
    {removed > 0 && <p role="status">{removed} de {preview?.meals.length} bloques eliminados.</p>}
    {error && <p className="pantry-message pantry-error" role="alert">{error}</p>}
    <div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={busy} onClick={onClose}>Cancelar</button>{error && <button className="dialog-cancel" type="button" disabled={busy || loading} onClick={() => setReload((n) => n + 1)}>Volver a revisar</button>}<button className="dialog-submit week-delete-confirm" type="button" disabled={busy || loading || !preview?.meals.length} onClick={() => void run()}>{busy ? "Borrando…" : removed ? "Continuar borrado" : "Borrar estas comidas"}</button></div>
  </dialog>;
}
