"use client";
import { useEffect, useImperativeHandle, useRef, useState, type Ref } from "react";
import { parseRecurrence, type RepeatConfig } from "@/lib/task-recurrence";
import { SubtaskSchedule } from "./subtask-schedule";
type Step = { id: string; text: string; completed: boolean };
type Progress = { steps: Step[]; completedAt: string | null; keep: boolean };
export type ChecklistEditorHandle = { savePending: () => Promise<boolean> };
const structure = (steps: Step[]) => JSON.stringify(steps.map(({ id, text }) => ({ id, text })));
export function ActivityChecklistEditor({ event, disabled, onDraft, onProgress, onBusy, onRecurrence, saveRef, readOnly = false, onApplied, allowSeriesMarks = true }: {
  event?: { id: string; calendarId: string; startDate?: string | null; startDateTime?: string | null }; disabled: boolean;
  onDraft: (value: { steps: Step[]; templateId: null; version?: string }) => void;
  onProgress: (value: Progress) => void; onBusy: (value: boolean) => void;
  onRecurrence: (value: RepeatConfig | null, etag: string) => void; saveRef: Ref<ChecklistEditorHandle>;
  readOnly?: boolean; onApplied?: () => void; allowSeriesMarks?: boolean;
}) {
  const [steps, setSteps] = useState<Step[]>([]);
  const [version, setVersion] = useState("");
  const [savedStructure, setSavedStructure] = useState("[]");
  const [busy, setBusy] = useState(Boolean(event));
  const [loaded, setLoaded] = useState(!event);
  const [error, setError] = useState<string | null>(null);
  const [reload, setReload] = useState(0);
  const [recurring, setRecurring] = useState(false);
  const [canWrite, setCanWrite] = useState(true);
  const [marks, setMarks] = useState<Record<string, boolean>>({});
  const [markScope, setMarkScope] = useState<"following" | "all" | null>(null);
  const markRequest = useRef<{ payload: string; key: string } | null>(null);
  const saving = useRef(false);
  const callbacks = useRef({ onDraft, onProgress, onBusy, onRecurrence }); callbacks.current = { onDraft, onProgress, onBusy, onRecurrence };
  useImperativeHandle(saveRef, () => ({ savePending: async () => true }));
  useEffect(() => {
    if (!event) { callbacks.current.onDraft({ steps: [], templateId: null }); return; }
    const controller = new AbortController(); setBusy(true); setLoaded(false); callbacks.current.onBusy(true);
    (async () => {
      try {
        const response = await fetch(`/api/events/${encodeURIComponent(event.id)}/checklist?${new URLSearchParams({ calendarId: event.calendarId })}`, { cache: "no-store", signal: controller.signal });
        const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No pudimos cargar las subtareas.");
        if (controller.signal.aborted) return;
        setSteps(result.steps); setSavedStructure(structure(result.steps)); setVersion(result.version);
        setRecurring(Boolean(result.recurrence?.length)); setCanWrite(result.canWrite); setMarks({}); setMarkScope(null);
        callbacks.current.onDraft({ steps: result.steps, templateId: null, version: result.version });
        const date = event.startDate ?? event.startDateTime?.slice(0, 10) ?? new Date().toISOString().slice(0, 10);
        callbacks.current.onRecurrence(parseRecurrence(result.recurrence, date), result.seriesEtag);
        setLoaded(true); setError(null);
      } catch (cause) { if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "No pudimos cargar las subtareas."); }
      finally { if (!controller.signal.aborted) { setBusy(false); callbacks.current.onBusy(false); } }
    })();
    return () => controller.abort();
  }, [event?.id, event?.calendarId, reload]);
  function change(list: Step[], nextVersion = version) { setSteps(list); callbacks.current.onDraft({ steps: list, templateId: null, version: nextVersion }); }
  async function toggle(id: string) {
    if (!event || saving.current || structure(steps) !== savedStructure) return;
    saving.current = true; setBusy(true); callbacks.current.onBusy(true); setError(null);
    try {
      const list = steps.map((step) => step.id === id ? { ...step, completed: !step.completed } : step);
      const response = await fetch(`/api/events/${encodeURIComponent(event.id)}/checklist`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ calendarId: event.calendarId, version, steps: list }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No pudimos completar la subtarea.");
      change(result.steps, result.version); setVersion(result.version); setSavedStructure(structure(result.steps)); callbacks.current.onProgress(result);
      setMarks((current) => ({ ...current, [id]: list.find((step) => step.id === id)!.completed }));
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos completar la subtarea."); }
    finally { saving.current = false; setBusy(false); callbacks.current.onBusy(false); }
  }
  async function applyMarks() {
    if (!event || !markScope || saving.current) return;
    saving.current = true; setBusy(true); callbacks.current.onBusy(true); setError(null);
    const changes = steps.filter((step) => Object.hasOwn(marks, step.id)).map((step) => ({ id: step.id, completed: marks[step.id] }));
    const payload = JSON.stringify({ calendarId: event.calendarId, scope: markScope, changes });
    if (markRequest.current?.payload !== payload) markRequest.current = { payload, key: crypto.randomUUID() };
    try {
      const response = await fetch(`/api/events/${encodeURIComponent(event.id)}/checklist`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...JSON.parse(payload), action: "apply-marks", key: markRequest.current.key, version }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No pudimos aplicar las marcas.");
      change(result.steps, result.version); setVersion(result.version); callbacks.current.onProgress(result); setMarks({}); setMarkScope(null); markRequest.current = null; onApplied?.();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos aplicar las marcas."); }
    finally { saving.current = false; setBusy(false); callbacks.current.onBusy(false); }
  }
  const dirty = structure(steps) !== savedStructure;
  return <section className="activity-checklist" aria-label="Subtareas">
    <div className="activity-checklist-heading"><strong>{readOnly ? "Subtareas" : "Subtareas · opcional"}</strong>{steps.length > 0 && <span>{steps.filter((step) => step.completed).length}/{steps.length}</span>}</div>
    <fieldset disabled={disabled || busy || !loaded || !canWrite}>
      <div className="activity-step-list">{steps.map((step, index) => <div className={`activity-step${step.completed ? " activity-step-completed" : ""}`} key={step.id}>
        {event ? <input type="checkbox" checked={step.completed} disabled={dirty} aria-label={`${step.completed ? "Deshacer" : "Completar"} ${step.text}`} onChange={() => void toggle(step.id)} /> : <span className="activity-step-number">○</span>}
        {readOnly ? <span className="subtask-text">{step.text}</span> : <><input type="text" value={step.text} maxLength={150} aria-label={`Subtarea ${index + 1}`} placeholder="Ej. Tomar agua" onChange={(changeEvent) => change(steps.map((item) => item.id === step.id ? { ...item, text: changeEvent.target.value } : item))} />
        <button type="button" aria-label={`Subir subtarea ${index + 1}`} disabled={index === 0} onClick={() => { const list = [...steps]; [list[index - 1], list[index]] = [list[index], list[index - 1]]; change(list); }}>↑</button>
        <button type="button" aria-label={`Eliminar subtarea ${index + 1}`} onClick={() => change(steps.filter((item) => item.id !== step.id))}>×</button></>}
        {event && <SubtaskSchedule parent={{ calendarId: event.calendarId, eventId: event.id }} stepId={step.id} version={version} disabled={disabled || busy || dirty || !loaded || !canWrite} onBusy={onBusy} onSaved={() => { setReload((value) => value + 1); onApplied?.(); }} />}
      </div>)}</div>
      {!readOnly && <div className="activity-checklist-actions"><button type="button" disabled={steps.length >= 50} onClick={() => change([...steps, { id: crypto.randomUUID(), text: "", completed: false }])}>＋ Añadir subtarea</button></div>}
      {allowSeriesMarks && recurring && Object.keys(marks).length > 0 && !dirty && <div className="checklist-mark-scope"><p>Aplicar estas marcas: {steps.filter((step) => Object.hasOwn(marks, step.id)).map((step) => `${marks[step.id] ? "✓" : "○"} ${step.text}`).join(" · ")}</p><label>Alcance <select value={markScope ?? ""} onChange={(changeEvent) => setMarkScope(changeEvent.target.value as "following" | "all" || null)}><option value="">Elegir…</option><option value="following">Esta y las siguientes</option><option value="all">Toda la serie</option></select></label><button type="button" disabled={!markScope} onClick={() => void applyMarks()}>Aplicar estas marcas</button></div>}
    </fieldset>
    {event && dirty && <p className="form-hint">Pulsa Guardar cambios para aplicar las subtareas. En una tarea recurrente podrás elegir el alcance.</p>}
    {steps.length > 0 && <p className="form-hint">Cada casilla se guarda para este día.{allowSeriesMarks && " En una serie, usa Aplicar estas marcas para extender los cambios. Las demás subtareas conservan su estado."}</p>}
    {readOnly && loaded && steps.length === 0 && <p className="form-hint">Sin subtareas.</p>}
    {busy && <p className="form-hint" role="status">{loaded ? "Guardando…" : "Cargando subtareas…"}</p>}
    {error && <p className="form-error" role="alert">{error} <button type="button" disabled={busy} onClick={() => setReload((value) => value + 1)}>Actualizar</button></p>}
  </section>;
}
