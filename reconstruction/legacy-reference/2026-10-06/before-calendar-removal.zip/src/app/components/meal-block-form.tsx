"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { combinedCookingMinutes } from "@/lib/calendar-adjustment";
import { preparationSteps, validPriorTiming, type PriorTiming } from "@/lib/recipe-steps";
import { MealPriorOffers } from "./meal-prior-offers";

type Schedule = { calendarId: string; startDate: string; startTime: string };
type PriorPreparation = { id: string; text: string; isOptional: boolean; priorTiming?: PriorTiming | null };
type Recipe = { id: string; name: string; servings: number; durationMinutes: number; preparedServings: number; actualPreparedServings: number;
  priorPreparations?: PriorPreparation[];
  ingredients: Array<{ ingredientId: string; name: string; unit: string; isOptional: boolean; requiredQuantity: number; availableQuantity: number }> };
type Row = { id?: string; recipeId: string; servings: number; cookedServings: number; preparationMinutes: number; priorPreparations?: PriorPreparation[] };
export function CalendarMealForm({ active, schedule, calendars, onScheduleChange, onBusyChange, onCreated, onCancel, onPersisted, overlayId, eventId, initialSlotId }: {
  active: boolean; schedule: Schedule; calendars: Array<{ id: string; summary: string }>;
  onScheduleChange: (value: Partial<Schedule>) => void; onBusyChange: (busy: boolean) => void; onCreated: () => void; onCancel: () => void;
  onPersisted?: () => void;
  overlayId?: string; eventId?: string; initialSlotId?: string;
}) {
  const [cookingName, setCookingName] = useState("Cocina");
  const [slots, setSlots] = useState<Array<{ id: string; name: string; defaultTime: string }>>([]);
  const [slotId, setSlotId] = useState<string | null>(initialSlotId ?? null);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [rows, setRows] = useState<Row[]>([]);
  const [cooking, setCooking] = useState(true);
  const [eating, setEating] = useState(true);
  const [washing, setWashing] = useState(true);
  const [eatingMinutes, setEatingMinutes] = useState(20);
  const [washingMinutes, setWashingMinutes] = useState(10);
  const [durationOverride, setDurationOverride] = useState<number | null>(null);
  const [saveDefaults, setSaveDefaults] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);
  const [saving, setSaving] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [reload, setReload] = useState(0);
  const [block, setBlock] = useState<{ overlayId: string; version: string; etag: string } | null>(null);
  const requestRef = useRef<{ payload: string; key: string } | null>(null);
  const savingRef = useRef(false);
  const [savedEvent, setSavedEvent] = useState<{ calendarId: string; eventId: string } | null>(null);
  const scheduleCallback = useRef(onScheduleChange); scheduleCallback.current = onScheduleChange;
  const initialCalendar = useRef(schedule.calendarId);
  const initialDate = useRef(schedule.startDate);
  const start = `${schedule.startDate}T${schedule.startTime}:00-06:00`;
  const [loadedStart, setLoadedStart] = useState("");
  useEffect(() => {
    if (!active || initialized) return;
    const controller = new AbortController();
    const options = { cache: "no-store" as const, signal: controller.signal };
    (async () => {
      try {
        const query = new URLSearchParams(overlayId ? { overlayId } : eventId ? { eventId, calendarId: initialCalendar.current } : {});
        const [blockResponse, slotResponse] = await Promise.all([fetch(`/api/meal-blocks?${query}`, options), fetch("/api/meal-slots", options)]);
        const [result, slotData] = await Promise.all([blockResponse.json(), slotResponse.json()]);
        if (!blockResponse.ok || !slotResponse.ok) throw new Error(result.error ?? slotData.error ?? "No pudimos abrir la comida.");
        if (controller.signal.aborted) return;
        setSlots(slotData.mealSlots);
        if (result.block) {
          const b = result.block;
          setBlock({ overlayId: b.id, version: b.updatedAt, etag: b.etag }); setCompleted(Boolean(b.completedAt));
          setCooking(b.mealCookingEnabled); setEating(b.mealEatingEnabled); setWashing(b.mealWashingEnabled);
          setEatingMinutes(b.mealEatingMinutes || result.defaults.mealEatingMinutes); setWashingMinutes(b.mealWashingMinutes || result.defaults.mealWashingMinutes);
          setDurationOverride(b.mealBlockConfigured ? b.mealDurationOverride : b.mealPlans[0]?.durationMinutes ?? null);
          setSlotId(b.mealPlans[0]?.mealSlotId ?? "");
          setRows(b.mealPlans.map((p: Row & { preparationSteps: unknown }) => ({ id: p.id, recipeId: p.recipeId ?? "", servings: p.servings, cookedServings: p.cookedServings || p.servings, preparationMinutes: p.preparationMinutes,
            priorPreparations: preparationSteps(p.preparationSteps).filter((step) => validPriorTiming(step.priorTiming)) })));
          if (b.startDateTime) {
            const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: "America/Mexico_City", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(b.startDateTime)).map((p) => [p.type, p.value]));
            scheduleCallback.current({ calendarId: b.googleCalendarId, startDate: `${parts.year}-${parts.month}-${parts.day}`, startTime: `${parts.hour}:${parts.minute}` });
          }
        } else {
          if (!result.cookingCalendar) throw new Error("Configura el calendario de Cocina desde Mis calendarios o el planificador, y vuelve a abrir esta comida.");
          scheduleCallback.current({ calendarId: result.cookingCalendar.googleCalendarId });
          setCookingName(result.cookingCalendar.summarySnapshot ?? "Cocina");
          setEatingMinutes(result.defaults.mealEatingMinutes); setWashingMinutes(result.defaults.mealWashingMinutes);
        }
        const from = `${initialDate.current}T00:00:00-06:00`;
        const sync = await fetch(`/api/meals?${new URLSearchParams({ from, to: new Date(Date.parse(from) + 86400000).toISOString() })}`, options);
        if (!sync.ok) throw new Error((await sync.json()).error ?? "No pudimos sincronizar tus comidas.");
        if (!controller.signal.aborted) { setInitialized(true); setLoadError(null); }
      } catch (cause) { if (!controller.signal.aborted) { setLoadError(cause instanceof Error ? cause.message : "No pudimos abrir la comida."); setLoading(false); } }
    })();
    return () => controller.abort();
  }, [active, initialized, overlayId, eventId, reload]);
  useEffect(() => {
    if (!active || !initialized) return;
    const controller = new AbortController(); setLoading(true); setLoadedStart("");
    const timer = window.setTimeout(async () => {
      try {
        if (!Number.isFinite(Date.parse(start))) throw new Error("Elige una fecha y hora válidas.");
        const query = new URLSearchParams({ at: start, includeAll: "true" });
        if (block) query.set("excludeOverlayId", block.overlayId);
        const response = await fetch(`/api/recipes/suggestions?${query}`, { cache: "no-store", signal: controller.signal });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error ?? "No pudimos consultar la disponibilidad.");
        if (!controller.signal.aborted) { setRecipes(result.suggestions); setLoadedStart(start); setLoadError(null); }
      } catch (cause) { if (!controller.signal.aborted) setLoadError(cause instanceof Error ? cause.message : "No pudimos cargar las recetas."); }
      finally { if (!controller.signal.aborted) setLoading(false); }
    }, 250);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [active, initialized, start, block, reload]);
  const minute = (time: string) => Number(time.slice(0, 2)) * 60 + Number(time.slice(3, 5));
  const nearestSlot = [...slots].sort((a, b) => Math.abs(minute(a.defaultTime) - minute(schedule.startTime)) - Math.abs(minute(b.defaultTime) - minute(schedule.startTime)))[0];
  const effectiveSlotId = slotId ?? nearestSlot?.id ?? "";
  const cookingMinutes = cooking ? combinedCookingMinutes(rows.map((r) => r.preparationMinutes)) : 0;
  const calculatedDuration = cookingMinutes + (eating ? eatingMinutes : 0) + (washing ? washingMinutes : 0);
  const duration = durationOverride ?? calculatedDuration;
  const ready = initialized && !loading && loadedStart === start && !loadError;
  const reserved = new Map<string, number>();
  const needs = new Map<string, { name: string; unit: string; need: number; available: number }>();
  const missingPortions: string[] = [];
  for (const row of rows) {
    const recipe = recipes.find((r) => r.id === row.recipeId); if (!recipe) continue;
    const lacking = eating ? Math.max(0, row.servings - (cooking ? row.cookedServings : 0) - recipe.preparedServings) : 0;
    if (lacking) missingPortions.push(`${recipe.name}: falta cocinar ${lacking} porción(es)`);
    for (const line of recipe.ingredients.filter((l) => !l.isOptional)) {
      const quantity = line.requiredQuantity / recipe.servings * ((cooking ? row.cookedServings : 0) + lacking);
      reserved.set(line.ingredientId, (reserved.get(line.ingredientId) ?? 0) + quantity);
      needs.set(line.ingredientId, { name: line.name, unit: line.unit, need: reserved.get(line.ingredientId)!, available: line.availableQuantity });
    }
  }
  const shortages = [...needs.values()].filter((n) => n.need > n.available + 0.0005).map((n) => `${n.name}: faltan ${Math.round((n.need - n.available) * 1000) / 1000} ${n.unit === "piece" ? "piezas" : n.unit}`);
  const suggested = recipes.filter((r) => !rows.some((row) => row.recipeId === r.id)).map((r) => ({ ...r,
    missing: r.ingredients.filter((line) => !line.isOptional
      && line.requiredQuantity / r.servings * (cooking ? r.servings : eating ? Math.max(0, r.servings - r.preparedServings) : 0)
        > Math.max(0, line.availableQuantity - (reserved.get(line.ingredientId) ?? 0))).length,
  })).sort((a, b) => a.missing - b.missing || a.name.localeCompare(b.name));
  function changeRow(index: number, change: Partial<Row>) { setRows((current) => current.map((r, i) => i === index ? { ...r, ...change } : r)); }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!ready || savingRef.current || completed || !rows.length) return;
    const payload = JSON.stringify({ ...block, calendarId: schedule.calendarId, startDateTime: start, mealSlotId: effectiveSlotId || null,
      cookingEnabled: cooking, eatingEnabled: eating, washingEnabled: washing, eatingMinutes, washingMinutes, durationOverride, saveDefaults,
      recipes: rows.map((r) => ({ id: r.id, recipeId: r.recipeId, servings: r.servings, preparationMinutes: r.preparationMinutes, cookedServings: cooking ? r.cookedServings : 0 })) });
    if (requestRef.current?.payload !== payload) requestRef.current = { payload, key: crypto.randomUUID() };
    savingRef.current = true; setSaving(true); onBusyChange(true); setError(null);
    try {
      const response = await fetch("/api/meal-blocks", { method: block ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...JSON.parse(payload), idempotencyKey: requestRef.current.key }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No pudimos guardar el bloque.");
      const hasPrior = cooking && rows.some((row) => (row.priorPreparations ?? recipes.find((recipe) => recipe.id === row.recipeId)?.priorPreparations ?? []).some((step) => validPriorTiming(step.priorTiming)));
      if (hasPrior) { setSavedEvent({ calendarId: schedule.calendarId, eventId: result.googleEventId }); onPersisted?.(); } else onCreated();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos guardar el bloque."); }
    finally { savingRef.current = false; setSaving(false); onBusyChange(false); }
  }
  if (savedEvent) return <div hidden={!active}><MealPriorOffers {...savedEvent} onDone={onCreated} onBusy={onBusyChange} /></div>;
  return <form className="event-form calendar-meal-form" hidden={!active} onSubmit={(event) => void submit(event)}>
    {completed && <p className="form-hint">Bloque completado. Para editarlo, deshaz el completado desde su círculo.</p>}
    <fieldset disabled={saving || completed || !initialized}>
      <label className="form-field">Calendario<input readOnly value={calendars.find((calendar) => calendar.id === schedule.calendarId)?.summary ?? cookingName} /></label>
      <div className="form-date-grid"><label className="form-field">Fecha<input type="date" value={schedule.startDate} onChange={(e) => onScheduleChange({ startDate: e.target.value })} required /></label><label className="form-field">Inicio<input type="time" value={schedule.startTime} onChange={(e) => onScheduleChange({ startTime: e.target.value })} required /></label></div>
      <label className="form-field">Fila del planificador<select value={effectiveSlotId} onChange={(e) => setSlotId(e.target.value)}><option value="">Sin fila</option>{slots.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
      <div className="meal-phase-options">{([{ name: "Cocinar", checked: cooking, set: setCooking }, { name: "Comer", checked: eating, set: setEating }, { name: "Lavar", checked: washing, set: setWashing }]).map((phase) => <label className={`meal-phase${phase.checked ? " meal-phase-selected" : ""}`} key={phase.name}><input type="checkbox" checked={phase.checked} onChange={(e) => { phase.set(e.target.checked); setDurationOverride(null); }} />{phase.name}</label>)}</div>
      <p className="form-hint">Al completar el bloque se registran juntas las fases elegidas.</p>
      <div className="form-date-grid">{eating && <label className="form-field">Comer (min)<input type="number" min="1" max="480" value={eatingMinutes} onChange={(e) => { setEatingMinutes(Number(e.target.value)); setDurationOverride(null); }} required /></label>}{washing && <label className="form-field">Lavar (min)<input type="number" min="1" max="480" value={washingMinutes} onChange={(e) => { setWashingMinutes(Number(e.target.value)); setDurationOverride(null); }} required /></label>}</div>
      <label className="all-day-toggle"><input type="checkbox" checked={saveDefaults} onChange={(e) => setSaveDefaults(e.target.checked)} />Usar estos tiempos de Comer y Lavar en nuevos bloques</label>
      {rows.map((row, index) => {
        const recipe = recipes.find((r) => r.id === row.recipeId);
        return <section className="meal-block-recipe" key={row.id ?? row.recipeId}>
          <div className="meal-block-recipe-heading"><strong>{recipe?.name ?? (loading ? "Cargando receta…" : "Receta eliminada: quítala y elige otra")}</strong><button type="button" onClick={() => { setRows((current) => current.filter((_, i) => i !== index)); setDurationOverride(null); }}>Quitar</button></div>
          <div className="form-date-grid">{eating && <label className="form-field">Porciones a comer<input type="number" min="1" max="100" value={row.servings} onChange={(e) => { const servings = Number(e.target.value); changeRow(index, { servings, ...(row.cookedServings === row.servings ? { cookedServings: servings } : {}) }); }} required /></label>}{cooking && <label className="form-field">Porciones a cocinar<input type="number" min="1" max="100" value={row.cookedServings} onChange={(e) => changeRow(index, { cookedServings: Number(e.target.value) })} required /></label>}</div>
          {cooking && <label className="form-field">Preparación en este bloque (min)<input type="number" min="5" max="480" value={row.preparationMinutes} onChange={(e) => { changeRow(index, { preparationMinutes: Number(e.target.value) }); setDurationOverride(null); }} required /></label>}
          {cooking && Number.isFinite(Date.parse(start)) && (row.priorPreparations ?? recipe?.priorPreparations ?? []).length > 0 && <aside className="meal-prior-notice">
            <strong>Esta receta requiere preparación previa</strong>
            <ul>{(row.priorPreparations ?? recipe?.priorPreparations ?? []).filter((step) => validPriorTiming(step.priorTiming)).map((step) => {
              const timing = step.priorTiming!;
              const suggestedAt = new Date(Date.parse(start) - timing.minutesBefore * 60000);
              return <li key={step.id}><span>{step.text}{step.isOptional ? " (opcional)" : ""}</span><small>{new Intl.DateTimeFormat("es-MX", { timeZone: "America/Mexico_City", weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(suggestedAt)} · {timing.durationMinutes} min{suggestedAt.getTime() < Date.now() ? " · La hora sugerida ya pasó" : ""}</small></li>;
            })}</ul>
            <p className="form-hint">Horarios sugeridos según el inicio de la comida. Al guardar podrás elegir cuáles agendar y ajustar sus horarios.</p>
          </aside>}
          {recipe && ready && <p className="form-hint">Disponibles a esta hora: {recipe.actualPreparedServings} porciones preparadas y {recipe.preparedServings - recipe.actualPreparedServings} previstas de cocinadas anteriores.{!eating && cooking ? " Todo lo cocinado quedará como sobras." : ""}</p>}
        </section>;
      })}
      {loading ? <p role="status">Consultando recetas y disponibilidad…</p> : <>
        <label className="all-day-toggle"><input type="checkbox" checked={showAll} onChange={(e) => setShowAll(e.target.checked)} />Mostrar todas las recetas</label>
        <label className="form-field">Agregar receta al bloque<select value="" disabled={rows.length >= 12 || !ready} onChange={(e) => {
          const r = recipes.find((recipe) => recipe.id === e.target.value);
          if (r) { setRows((current) => [...current, { recipeId: r.id, servings: r.servings, cookedServings: r.servings, preparationMinutes: r.durationMinutes }]); setDurationOverride(null); }
        }}><option value="">Elige una receta…</option>{suggested.filter((r) => showAll || r.missing <= 3).map((r) => <option key={r.id} value={r.id}>{r.name} · {r.missing ? `faltan ${r.missing} ingredientes` : "tienes lo necesario"}</option>)}</select></label>
        {!recipes.length && <p className="form-hint"><a href="/cocina/recetas">Crea una receta</a> para agregarla al bloque.</p>}
      </>}
      {ready && shortages.length > 0 && <p className="meal-suggestion-missing">{shortages.join(" · ")}. Puedes planificar; los faltantes aparecerán en Compras.</p>}
      {ready && missingPortions.length > 0 && <p className="meal-suggestion-missing">{missingPortions.join(" · ")}{shortages.length === 0 ? ". Hay ingredientes disponibles." : "."}</p>}
      <div className="meal-block-total"><strong>{duration} minutos en total</strong><span>Cocinar {cookingMinutes} + Comer {eating ? eatingMinutes : 0} + Lavar {washing ? washingMinutes : 0} min</span>{durationOverride !== null && <><p className="form-hint">Duración ajustada en la agenda: {durationOverride} min.</p><button type="button" onClick={() => setDurationOverride(null)}>Usar duración calculada ({calculatedDuration} min)</button></>}</div>
      <label className="form-field">Duración total, si necesitas ajustarla (min)<input type="number" min="5" max="1440" value={duration} onChange={(e) => setDurationOverride(Number(e.target.value))} required /></label>
      <p className="form-hint">Cocina: el tiempo más largo más la mitad de los demás, redondeado hacia arriba a 5 minutos. Los opcionales utilizados se confirman al completar.</p>
    </fieldset>
    {(error || loadError) && <p className="form-error" role="alert">{error ?? loadError} {loadError && <button type="button" disabled={saving} onClick={() => setReload((n) => n + 1)}>Reintentar</button>}</p>}
    <div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={saving} onClick={onCancel}>Cerrar</button>{!completed && <button className="dialog-submit" type="submit" disabled={saving || !ready || !rows.length || !schedule.calendarId || rows.some((r) => !recipes.some((recipe) => recipe.id === r.recipeId))}>{saving ? "Guardando…" : block ? "Guardar bloque" : "Crear bloque de comida"}</button>}</div>
  </form>;
}

