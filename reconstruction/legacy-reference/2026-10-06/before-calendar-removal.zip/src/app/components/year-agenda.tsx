"use client";

import { monthDays } from "@/lib/calendar-month";

type HighlightEvent = {
  id: string; calendarId: string; summary: string; calendarName: string; color: string | null;
  startDate: string | null; endDate: string | null; startDateTime: string | null; endDateTime: string | null;
};
const weekdays = ["D", "L", "M", "M", "J", "V", "S"];
function dateKey(date: Date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
function intersects(event: HighlightEvent, date: string) {
  if (event.startDate && event.endDate) return event.startDate <= date && event.endDate > date;
  const start = Date.parse(`${date}T00:00:00-06:00`);
  return Boolean(event.startDateTime && event.endDateTime && Date.parse(event.startDateTime) < start + 86400000 && Date.parse(event.endDateTime) > start);
}
export function YearAgenda<T extends HighlightEvent>({ year, today, events, loading, error, showTitles = true, suppressEmpty = false, onRetry, onMonth, onOpen }: {
  year: number; today: string; events: T[]; loading: boolean; error: string | null; showTitles?: boolean; suppressEmpty?: boolean;
  onRetry: () => void; onMonth: (date: Date) => void; onOpen: (event: T) => void;
}) {
  return <section className="year-agenda" aria-label={`Agenda del año ${year}`} aria-busy={loading}>
    {loading && <p className="form-hint" role="status">Cargando eventos destacados…</p>}
    {error && <p className="form-error" role="alert">{error} <button type="button" onClick={onRetry}>Reintentar</button></p>}
    <div className="year-months">{Array.from({ length: 12 }, (_, month) => {
      const first = new Date(year, month, 1, 12);
      const name = first.toLocaleDateString("es-MX", { month: "long" });
      const days = monthDays(first);
      const highlighted = events.filter((event) => days.some((day) => day.getMonth() === month && intersects(event, dateKey(day))))
        .sort((a, b) => (a.startDateTime ?? a.startDate ?? "").localeCompare(b.startDateTime ?? b.startDate ?? "") || a.summary.localeCompare(b.summary));
      return <section className="year-month" key={month} aria-label={`${name} de ${year}`}>
        <h2><button type="button" onClick={() => onMonth(first)}>{name}</button></h2>
        <div className="year-days">{weekdays.map((day, index) => <span className="year-weekday" key={index}>{day}</span>)}
          {days.map((day) => {
            if (day.getMonth() !== month) return <span aria-hidden="true" key={dateKey(day)} />;
            const key = dateKey(day); const items = highlighted.filter((event) => intersects(event, key));
            return <button className={`year-day${key === today ? " year-day-today" : ""}${items.length ? " year-day-highlighted" : ""}`} type="button" key={key}
              aria-label={`${key}${key === today ? ", hoy" : ""}${items.length ? `, ${items.length} destacados` : ""}. Abrir mes`} title={items.length ? items.map((event) => event.summary).join(" · ") : "Abrir mes"} onClick={() => onMonth(day)}>{day.getDate()}{items.length > 0 && <span className="year-highlight-dot" aria-hidden="true" />}</button>;
          })}
        </div>
        {showTitles && highlighted.length > 0 && <ul className="year-highlight-list">{highlighted.map((event) => <li key={`${event.calendarId}:${event.id}`}><button type="button" onClick={() => onOpen(event)} title={`${event.summary} · ${event.calendarName}`}><span className="year-highlight-color" style={{ background: event.color ?? "#78947d" }} />
          <span><strong>{event.summary}</strong><small>{event.startDate ?? (event.startDateTime ? new Intl.DateTimeFormat("es-MX", { timeZone: "America/Mexico_City", day: "numeric", month: "short" }).format(new Date(event.startDateTime)) : "")} · {event.calendarName}</small></span></button></li>)}</ul>}
      </section>;
    })}</div>
    {!loading && !error && !suppressEmpty && events.length === 0 && <p className="form-hint">No hay eventos destacados en tus calendarios visibles para este año.</p>}
  </section>;
}
