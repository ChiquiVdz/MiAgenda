"use client";

import { useEffect, useRef, useState } from "react";
import type { SubtaskProgress } from "./task-subtasks";
import { SubtaskSchedule } from "./subtask-schedule";

type Step = SubtaskProgress["steps"][number];
type Props = {
  event: { id: string; calendarId: string };
  disabled: boolean;
  reloadKey?: number;
  onProgress: (value: SubtaskProgress) => void;
  onBusy?: (value: boolean) => void;
};

// These writes are snapshots of one occurrence, never changes to its series.
export function DayTaskSubtasks({ event, disabled, reloadKey, onProgress, onBusy }: Props) {
  const [steps, setSteps] = useState<Step[]>([]);
  const [version, setVersion] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [canWrite, setCanWrite] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reload, setReload] = useState(0);
  const [newText, setNewText] = useState("");
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const saving = useRef(false);
  const callbacks = useRef({ onProgress, onBusy }); callbacks.current = { onProgress, onBusy };
  const url = `/api/events/${encodeURIComponent(event.id)}/checklist`;

  useEffect(() => {
    const controller = new AbortController();
    setLoaded(false); setError(null); callbacks.current.onBusy?.(true);
    (async () => {
      try {
        const response = await fetch(`${url}?${new URLSearchParams({ calendarId: event.calendarId })}`, { cache: "no-store", signal: controller.signal });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error ?? "No pudimos cargar las subtareas.");
        if (controller.signal.aborted) return;
        setSteps(result.steps); setVersion(result.version); setCanWrite(result.canWrite); setLoaded(true);
        callbacks.current.onProgress(result);
      } catch (cause) {
        if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "No pudimos cargar las subtareas.");
      } finally { if (!controller.signal.aborted) callbacks.current.onBusy?.(false); }
    })();
    return () => { controller.abort(); callbacks.current.onBusy?.(false); };
  }, [url, event.calendarId, reload, reloadKey]);

  async function save(list: Step[]) {
    if (saving.current || disabled || !loaded || !canWrite) return false;
    saving.current = true; setBusy(true); setError(null); callbacks.current.onBusy?.(true);
    try {
      const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ calendarId: event.calendarId, version, steps: list }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No pudimos guardar la subtarea.");
      setSteps(result.steps); setVersion(result.version); callbacks.current.onProgress(result);
      return true;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos guardar la subtarea."); return false;
    } finally { saving.current = false; setBusy(false); callbacks.current.onBusy?.(false); }
  }
  async function add() {
    const text = newText.trim(); if (!text || steps.length >= 50) return;
    if (await save([...steps, { id: crypto.randomUUID(), text, completed: false }])) setNewText("");
  }
  async function rename() {
    if (!editing?.text.trim()) return;
    if (editing.text.trim() === steps.find((step) => step.id === editing.id)?.text) { setEditing(null); return; }
    if (await save(steps.map((step) => step.id === editing.id ? { ...step, text: editing.text.trim() } : step))) setEditing(null);
  }
  const locked = disabled || busy || !loaded || !canWrite;
  return <section className="day-checklist" aria-label="Editar subtareas de este día">
    <fieldset disabled={locked}>
      <div className="activity-step-list">{steps.map((step) => <div className={`activity-step${step.completed ? " activity-step-completed" : ""}`} key={step.id}>
        <input type="checkbox" checked={step.completed} disabled={Boolean(editing)} aria-label={`${step.completed ? "Deshacer" : "Completar"} ${step.text}`} onChange={() => void save(steps.map((item) => item.id === step.id ? { ...item, completed: !item.completed } : item))} />
        {editing?.id === step.id ? <>
          <input type="text" autoFocus maxLength={150} aria-label="Nombre de la subtarea" value={editing.text} onChange={(change) => setEditing({ ...editing, text: change.target.value })}
            onKeyDown={(key) => { if (key.key === "Enter") { key.preventDefault(); void rename(); } if (key.key === "Escape") { key.preventDefault(); setEditing(null); } }} />
          <button type="button" disabled={!editing.text.trim()} aria-label="Guardar nombre" title="Guardar nombre" onClick={() => void rename()}>✓</button>
          <button type="button" aria-label="Cancelar edición" title="Cancelar edición" onClick={() => setEditing(null)}>×</button>
        </> : <>
          <button className="day-subtask-name" type="button" disabled={Boolean(editing)} title="Editar nombre" onClick={() => setEditing({ id: step.id, text: step.text })}>{step.text}</button>
          <button type="button" disabled={Boolean(editing)} aria-label={`Editar ${step.text}`} title="Editar subtarea" onClick={() => setEditing({ id: step.id, text: step.text })}>✎</button>
          <button type="button" disabled={Boolean(editing)} aria-label={`Eliminar ${step.text}`} title="Eliminar subtarea de este día" onClick={() => void save(steps.filter((item) => item.id !== step.id))}>×</button>
        </>}
        <SubtaskSchedule parent={{ calendarId: event.calendarId, eventId: event.id }} stepId={step.id} version={version} disabled={locked || Boolean(editing)} onBusy={onBusy} onSaved={() => setReload((current) => current + 1)} />
      </div>)}</div>
      {canWrite && <div className="day-subtask-add"><input type="text" aria-label="Nueva subtarea" placeholder="Añadir subtarea…" maxLength={150} value={newText} disabled={Boolean(editing) || steps.length >= 50}
        onChange={(change) => setNewText(change.target.value)} onKeyDown={(key) => { if (key.key === "Enter") { key.preventDefault(); void add(); } }} /><button type="button" disabled={!newText.trim() || Boolean(editing) || steps.length >= 50} onClick={() => void add()}>＋ Añadir</button></div>}
    </fieldset>
    {!loaded && !error && <p className="form-hint" role="status">Cargando subtareas…</p>}
    {busy && <p className="form-hint" role="status">Guardando…</p>}
    {loaded && steps.length === 0 && <p className="form-hint">Sin subtareas.</p>}
    {canWrite && <p className="form-hint">Los cambios se guardan solo para este día. Eliminar una subtarea también elimina su evento si tiene horario.</p>}
    {error && <p className="form-error" role="alert">{error} <button type="button" disabled={busy} onClick={() => { setEditing(null); setReload((current) => current + 1); }}>Actualizar</button></p>}
  </section>;
}
