"use client";
import { useEffect, useState } from "react";
import { nextCalendarStart } from "@/lib/calendar-creation";

type Parent = { inboxId: string } | { calendarId: string; eventId: string };
type Scheduled = { calendarId: string; eventId?: string; startDateTime?: string | null; endDateTime?: string | null; etag?: string | null; pending?: boolean; missing?: boolean };
type Calendar = { id: string; summary: string; canWrite: boolean; primary: boolean };
type ScheduleStatus = { pending: boolean; missing: boolean; startDateTime?: string | null; endDateTime?: string | null; startDate?: string | null; htmlLink?: string | null };
const statusCache = new Map<string, { at: number; request: Promise<Record<string, ScheduleStatus>> }>();
function statuses(key: string) {
  const cached = statusCache.get(key);
  if (cached && Date.now() - cached.at < 30000) return cached.request;
  const request = fetch(`/api/subtasks/status?${key}`, { cache: "no-store" }).then(async (response) => {
    const result = await response.json();
    if (!response.ok) throw new Error(result.error ?? "No pudimos actualizar el horario.");
    return result.schedules as Record<string, ScheduleStatus>;
  }).catch((error) => { statusCache.delete(key); throw error; });
  // Cap the cache while navigating between many days.
  if (statusCache.size >= 100) statusCache.delete(statusCache.keys().next().value!);
  statusCache.set(key, { at: Date.now(), request }); return request;
}
function statusLabel(value: ScheduleStatus) {
  if (value.missing) return "Evento eliminado en Google";
  if (value.pending) return "Horario pendiente de guardar";
  if (value.startDate) return `Agendada · ${new Intl.DateTimeFormat("es-MX", { dateStyle: "medium", timeZone: "America/Mexico_City" }).format(new Date(`${value.startDate}T12:00:00-06:00`))} · todo el día`;
  if (!value.startDateTime) return "Agendada en Google";
  const day = new Intl.DateTimeFormat("es-MX", { day: "numeric", month: "short", year: "numeric", timeZone: "America/Mexico_City" });
  const time = new Intl.DateTimeFormat("es-MX", { hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: "America/Mexico_City" });
  const start = new Date(value.startDateTime), end = value.endDateTime ? new Date(value.endDateTime) : null;
  return `Agendada · ${day.format(start)} · ${time.format(start)}${end ? `–${day.format(end) !== day.format(start) ? `${day.format(end)} ` : ""}${time.format(end)}` : ""}`;
}
const parentBody = (parent: Parent): Record<string, string> => "inboxId" in parent ? { inboxId: parent.inboxId } : { parentCalendarId: parent.calendarId, parentEventId: parent.eventId };
export function notifySubtaskSchedules(parent: Parent) {
  const prefix = new URLSearchParams(parentBody(parent)).toString();
  for (const key of statusCache.keys()) if (key.startsWith(prefix)) statusCache.delete(key);
  window.dispatchEvent(new Event("miagenda:subtask-scheduled"));
}
const localTime = (value: string) => {
  const parts = new Intl.DateTimeFormat("sv-SE", { timeZone: "America/Mexico_City", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(value));
  return parts.replace(" ", "T");
};
function later(value: string, minutes = 15) { return value ? localTime(new Date(Date.parse(`${value}:00-06:00`) + minutes * 60000).toISOString()) : ""; }
export function SubtaskSchedule({ parent, stepId, version, disabled, onSaved, onBusy, suggestedStart, suggestedDuration = 15 }: {
  parent: Parent; stepId: string; version: string; disabled?: boolean; onSaved: () => void | Promise<void>; onBusy?: (busy: boolean) => void;
  suggestedStart?: string; suggestedDuration?: number;
}) {
  const [open, setOpen] = useState(false), [busy, setBusy] = useState(false), [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null), [scheduled, setScheduled] = useState<Scheduled | null>(null);
  const [calendars, setCalendars] = useState<Calendar[]>([]), [calendarId, setCalendarId] = useState("");
  const [start, setStart] = useState(""), [end, setEnd] = useState("");
  const [statusInfo, setStatusInfo] = useState<ScheduleStatus | null>(null), [statusError, setStatusError] = useState(false);
  const statusKey = new URLSearchParams({ ...parentBody(parent), revision: version }).toString();
  useEffect(() => {
    let active = true;
    setStatusInfo(null); setStatusError(false);
    const refresh = () => {
      if (document.visibilityState !== "visible") return;
      void statuses(statusKey).then((values) => { if (active) { setStatusInfo(values[stepId] ?? null); setStatusError(false); } })
        .catch(() => { if (active) setStatusError(true); });
    };
    refresh();
    const timer = window.setInterval(refresh, 60000);
    window.addEventListener("miagenda:subtask-scheduled", refresh); window.addEventListener("focus", refresh);
    return () => { active = false; clearInterval(timer); window.removeEventListener("miagenda:subtask-scheduled", refresh); window.removeEventListener("focus", refresh); };
  }, [statusKey, stepId, version]);
  async function load() {
    setBusy(true); setLoaded(false); setError(null); onBusy?.(true);
    try {
      const query = new URLSearchParams({ ...parentBody(parent), stepId });
      const responses = await Promise.all([fetch(`/api/subtasks/schedule?${query}`, { cache: "no-store" }), fetch("/api/calendars", { cache: "no-store" })]);
      const results = await Promise.all(responses.map((response) => response.json()));
      if (!responses[0].ok || !responses[1].ok) throw new Error(results[0].error ?? results[1].error ?? "No pudimos cargar el horario.");
      const current = results[0].scheduled as Scheduled | null;
      const choices = (results[1].calendars as Calendar[]).filter((calendar) => calendar.canWrite);
      const now = nextCalendarStart(new Date());
      const beginning = current?.startDateTime ? localTime(current.startDateTime) : suggestedStart ? localTime(suggestedStart) : `${now.date}T${now.time}`;
      setScheduled(current); setCalendars(choices); setStart(beginning); setEnd(current?.endDateTime ? localTime(current.endDateTime) : later(beginning, suggestedDuration));
      setCalendarId(current?.calendarId ?? ("calendarId" in parent ? parent.calendarId : choices.find((calendar) => calendar.primary)?.id ?? choices[0]?.id ?? ""));
      setLoaded(true);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos cargar el horario."); }
    finally { setBusy(false); onBusy?.(false); }
  }
  async function save(remove = false) {
    if (busy || disabled) return;
    setBusy(true); setError(null); onBusy?.(true);
    try {
      const response = await fetch("/api/subtasks/schedule", { method: remove ? "DELETE" : "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...parentBody(parent), stepId, version, calendarId, etag: scheduled?.etag,
          startDateTime: `${start}:00-06:00`, endDateTime: `${end}:00-06:00` }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No pudimos guardar el horario.");
      setScheduled(result.scheduled); setOpen(false); await onSaved();
      notifySubtaskSchedules(parent);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No pudimos guardar el horario."); }
    finally { setBusy(false); onBusy?.(false); }
  }
  return <div className="subtask-schedule">
    {statusInfo && <span className={`subtask-scheduled-badge${statusInfo.pending || statusInfo.missing ? " subtask-scheduled-warning" : ""}`} title="Horario de Ciudad de México">◷ {statusLabel(statusInfo)}</span>}
    {statusError && <span className="subtask-scheduled-warning" role="status">Horario sin actualizar</span>}
    <button type="button" disabled={disabled || busy} title="Programar o editar horario de la subtarea" onClick={() => { const next = !open; setOpen(next); if (next) void load(); }}>◷ Horario</button>
    {open && <div className="subtask-schedule-fields">
      {!loaded && !error && <span>Cargando…</span>}
      {scheduled?.pending && <p className="form-hint">Hay un guardado pendiente. Reintenta para recuperar el mismo evento.</p>}
      {scheduled?.missing && <p className="form-hint">Su evento ya no existe en Google. Quita el horario para volver a programarla.</p>}
      {loaded && <>
        <label className="form-field">Calendario<select value={calendarId} disabled={busy || Boolean(scheduled) || "calendarId" in parent} onChange={(event) => setCalendarId(event.target.value)}><option value="">Elegir…</option>{calendarId && !calendars.some((calendar) => calendar.id === calendarId) && <option value={calendarId}>Calendario actual</option>}{calendars.map((calendar) => <option value={calendar.id} key={calendar.id}>{calendar.summary}</option>)}</select></label>
        <label className="form-field">Inicio<input type="datetime-local" value={start} disabled={busy || scheduled?.pending} onChange={(event) => { const duration = (Date.parse(`${end}:00-06:00`) - Date.parse(`${start}:00-06:00`)) / 60000; setStart(event.target.value); setEnd(later(event.target.value, Number.isFinite(duration) && duration > 0 ? duration : suggestedDuration)); }} /></label>
        <label className="form-field">Fin<input type="datetime-local" value={end} min={start} disabled={busy || scheduled?.pending} onChange={(event) => setEnd(event.target.value)} /></label>
        <p className="form-hint">Horario de Ciudad de México. Se crea un evento ligado a su principal.{"calendarId" in parent && " En una serie afecta solo a este día."}</p>
        <div className="subtask-schedule-actions"><button type="button" disabled={busy || !calendarId || !start || !end || end <= start || scheduled?.missing} onClick={() => void save()}>{scheduled?.pending ? "Reintentar" : scheduled ? "Guardar horario" : "Programar"}</button>{scheduled && <button type="button" disabled={busy} onClick={() => { if (window.confirm("¿Quitar el evento de esta subtarea y los eventos de sus propias subtareas? Su casilla permanece en la principal.")) void save(true); }}>Quitar horario</button>}</div>
      </>}
      {error && <p className="form-error" role="alert">{error} <button type="button" disabled={busy} onClick={() => void load()}>Actualizar</button></p>}
    </div>}
  </div>;
}
