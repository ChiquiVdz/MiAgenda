"use client";
import { useEffect, useRef, useState } from "react";
import { addWeekDays, type CopyOmission } from "@/lib/meal-week-copy";
type Preview = { fingerprint: string; sourceCount: number; copyCount: number; omissions: CopyOmission[];
  recipeCounts: Array<{ name: string; count: number; servings: number; cookedServings: number }> };
type Progress = { copyId: string; sourceWeek: string; targetWeek: string; total: number; processed: number; copied: number; omissions: CopyOmission[]; done: boolean };
async function post(body: unknown) {
  const response = await fetch("/api/meals/copy-week", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const result = await response.json().catch(() => null);
  if (!response.ok || !result) throw new Error(result?.error ?? "No pudimos continuar la copia. Puedes reintentarlo.");
  return result;
}
export function WeekCopyDialog({ initialSource, initialTarget, onClose, onCopied }: {
  initialSource: string; initialTarget: string; onClose: () => void; onCopied: (target: string, copied: number, skipped: number) => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null), key = useRef<string | null>(null), busyRef = useRef(false);
  const close = useRef(onClose); close.current = onClose;
  const [preview, setPreview] = useState<Preview | null>(null), [progress, setProgress] = useState<Progress | null>(null);
  const [busy, setBusy] = useState(false), [loading, setLoading] = useState(true), [error, setError] = useState<string | null>(null);
  const [reload, setReload] = useState(0);
  useEffect(() => {
    dialog.current?.showModal();
    let cancelled = false;
    setLoading(true); setError(null);
    async function review() {
      try {
        const response = await fetch("/api/meals/copy-week", { cache: "no-store" });
        const jobs = await response.json();
        if (!response.ok) throw new Error(jobs.error ?? "No pudimos consultar copias pendientes.");
        const pending = (jobs.pending as Progress[]).find((job) => job.targetWeek === initialTarget);
        if (pending) { if (!cancelled) setProgress(pending); return; }
        const result = await post({ action: "preview", sourceWeek: initialSource, targetWeek: initialTarget }) as Preview;
        if (cancelled) return;
        if (!result.copyCount) { close.current(); return; }
        setPreview(result); key.current = crypto.randomUUID();
      } catch (cause) { if (!cancelled) setError(cause instanceof Error ? cause.message : "No pudimos revisar la semana."); }
      finally { if (!cancelled) setLoading(false); }
    }
    void review(); return () => { cancelled = true; };
  }, [initialSource, initialTarget, reload]);
  async function run() {
    if (busyRef.current) return;
    busyRef.current = true; setBusy(true); setError(null);
    try {
      let current = progress;
      if (!current) {
        if (!preview || !key.current) throw new Error("No pudimos preparar esta copia.");
        current = await post({ action: "start", sourceWeek: initialSource, targetWeek: initialTarget, fingerprint: preview.fingerprint, idempotencyKey: key.current }) as Progress;
      }
      setProgress(current);
      while (!current.done) { current = await post({ action: "advance", copyId: current.copyId }) as Progress; setProgress(current); }
      onCopied(current.targetWeek, current.copied, current.omissions.length);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "La copia se interrumpió. Puedes reanudarla."); }
    finally { busyRef.current = false; setBusy(false); }
  }
  return <dialog ref={dialog} className="event-dialog week-copy-dialog" aria-labelledby="week-copy-title" onCancel={(event) => { if (busy) event.preventDefault(); else onClose(); }}>
    <div className="dialog-heading"><h2 id="week-copy-title">Copiar semana anterior</h2><button className="dialog-close" type="button" disabled={busy} onClick={onClose} aria-label="Cerrar">×</button></div>
    <p>{initialSource} al {addWeekDays(initialSource, 6)} → {initialTarget} al {addWeekDays(initialTarget, 6)}</p>
    {loading && <p role="status">Revisando automáticamente la semana anterior…</p>}
    {error && <p className="pantry-message pantry-error" role="alert">{error}</p>}
    {!progress && preview && <section className="week-copy-review"><h3>{preview.copyCount} comidas por copiar, todas pendientes</h3><ul>{preview.recipeCounts.map((recipe, index) => <li key={index}><strong>{recipe.name}: {recipe.count} {recipe.count === 1 ? "vez" : "veces"}</strong><span>{recipe.servings} porciones a comer · {recipe.cookedServings} a cocinar</span></li>)}</ul>{preview.omissions.length > 0 && <p>Se omiten {preview.omissions.length} comidas: {preview.omissions.map((item) => `${item.summary} (${item.date}, ${item.reason})`).join("; ")}</p>}<p>Se conservan horarios y fases. Compras y disponibilidad se recalculan.</p></section>}
    {progress && <section className="week-copy-review" role="status"><h3>{progress.copied} comidas copiadas</h3><progress value={progress.processed} max={Math.max(1, progress.total)} /><p>{progress.processed === progress.total ? "Actualizando Compras…" : `${progress.processed} de ${progress.total} comidas revisadas.`}</p></section>}
    <div className="dialog-actions"><button className="dialog-cancel" type="button" disabled={busy} onClick={onClose}>Cerrar</button>{error && !progress && <button className="dialog-cancel" type="button" disabled={busy || loading} onClick={() => setReload((n) => n + 1)}>Reintentar</button>}<button className="dialog-submit" type="button" disabled={busy || loading || (!progress && !preview)} onClick={() => void run()}>{busy ? "Copiando…" : progress ? "Reanudar copia" : "Confirmar copia"}</button></div>
  </dialog>;
}
