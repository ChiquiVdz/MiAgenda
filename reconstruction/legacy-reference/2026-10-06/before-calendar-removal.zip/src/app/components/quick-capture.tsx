"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { usePathname } from "next/navigation";

export function QuickCapture() {
  const pathname = usePathname();
  const available = pathname === "/" || pathname === "/inbox" || pathname === "/hoy" || pathname === "/cocina" || pathname.startsWith("/cocina/");
  const dialog = useRef<HTMLDialogElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const busyRef = useRef(false);
  // Keep the same payload/key after an uncertain response to prevent duplicate notes.
  const attempt = useRef<{ text: string; createKey: string } | null>(null);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 4500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  async function save(event: FormEvent) {
    event.preventDefault();
    if (busyRef.current || !draft.trim()) return;
    busyRef.current = true; setBusy(true); setError(null);
    attempt.current ??= { text: draft.trim(), createKey: crypto.randomUUID() };
    try {
      const response = await fetch("/api/inbox", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "add", ...attempt.current }),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || !result?.item) throw new Error(result?.error ?? "No pudimos confirmar el guardado. Reintenta; no se duplicará el pendiente.");
      window.dispatchEvent(new CustomEvent("miagenda:inbox-added", { detail: { item: result.item } }));
      attempt.current = null; setDraft(""); dialog.current?.close();
      setNotice("Guardado en Inbox.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos guardar. Reintenta; conservamos tu texto.");
    } finally { busyRef.current = false; setBusy(false); }
  }

  if (!available) return null;
  return <>
    <button type="button" className="quick-capture-button" aria-haspopup="dialog" onClick={() => {
      setNotice(null); dialog.current?.showModal(); input.current?.focus();
    }}><span aria-hidden="true">＋</span> Anotar</button>
    {notice && <p className="quick-capture-notice" role="status">{notice}</p>}
    <dialog ref={dialog} className="event-dialog calendar-creation-dialog quick-capture-dialog" aria-labelledby="quick-capture-title" onCancel={(event) => { if (busyRef.current) event.preventDefault(); }}>
      <div className="dialog-heading"><div><p className="eyebrow">Captura rápida</p><h2 id="quick-capture-title">Anotar en Inbox</h2></div><button type="button" className="dialog-close" aria-label="Cerrar" disabled={busy} onClick={() => dialog.current?.close()}>×</button></div>
      <form className="event-form" onSubmit={(event) => void save(event)}>
        <label className="form-field" htmlFor="quick-capture-text">¿Qué tienes pendiente?
          <textarea ref={input} id="quick-capture-text" rows={3} maxLength={250} required value={draft} disabled={busy || Boolean(attempt.current)} placeholder="Examen a las 3 el jueves" onChange={(event) => setDraft(event.target.value)} />
        </label>
        <p className="form-hint">Se guarda como texto en Inbox. Después puedes pasarlo a la agenda.</p>
        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="dialog-actions"><button type="button" className="dialog-cancel" disabled={busy} onClick={() => dialog.current?.close()}>Cerrar</button><button type="submit" className="dialog-submit" disabled={busy || !draft.trim()}>{busy ? "Guardando…" : attempt.current ? "Reintentar guardado" : "Guardar en Inbox"}</button></div>
      </form>
    </dialog>
  </>;
}
