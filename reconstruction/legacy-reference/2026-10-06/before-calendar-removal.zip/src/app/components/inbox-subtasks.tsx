"use client";
import { useState } from "react";
import { SubtaskSchedule } from "./subtask-schedule";
type Step = { id: string; text: string; completed: boolean };
export function InboxSubtasks({ item, disabled, onSave, onScheduled, onBusy }: {
  item: { id: string; updatedAt: string; checklist: Step[] | null }; disabled: boolean;
  onSave: (steps: Step[]) => Promise<boolean>; onScheduled: () => Promise<void>; onBusy: (busy: boolean) => void;
}) {
  const steps = item.checklist ?? [];
  const [open, setOpen] = useState(false), [newText, setNewText] = useState("");
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  async function add() {
    const text = newText.trim();
    if (disabled || !text || steps.length >= 50) return;
    if (await onSave([...steps, { id: crypto.randomUUID(), text, completed: false }])) setNewText("");
  }
  async function rename() {
    if (!editing?.text.trim() || disabled) return;
    if (await onSave(steps.map((step) => step.id === editing.id ? { ...step, text: editing.text.trim() } : step))) setEditing(null);
  }
  return <details className="day-subtasks" onToggle={(event) => setOpen(event.currentTarget.open)}>
    <summary>{steps.length ? `Subtareas · ${steps.filter((step) => step.completed).length}/${steps.length}` : "＋ Subtareas"}</summary>
    {open && <section className="day-checklist" aria-label="Subtareas de Inbox"><fieldset disabled={disabled}>
      <div className="activity-step-list">{steps.map((step) => <div className={`activity-step${step.completed ? " activity-step-completed" : ""}`} key={step.id}>
        <input type="checkbox" checked={step.completed} disabled={Boolean(editing)} aria-label={`${step.completed ? "Deshacer" : "Completar"} ${step.text}`}
          onChange={() => void onSave(steps.map((other) => other.id === step.id ? { ...other, completed: !other.completed } : other))} />
        {editing?.id === step.id ? <>
          <input type="text" autoFocus maxLength={150} aria-label="Nombre de la subtarea" value={editing.text} onChange={(event) => setEditing({ ...editing, text: event.target.value })}
            onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void rename(); } if (event.key === "Escape") setEditing(null); }} />
          <button type="button" aria-label="Guardar nombre" disabled={!editing.text.trim()} onClick={() => void rename()}>✓</button>
          <button type="button" aria-label="Cancelar edición" onClick={() => setEditing(null)}>×</button>
        </> : <>
          <button className="day-subtask-name" type="button" disabled={Boolean(editing)} title="Editar nombre" onClick={() => setEditing({ id: step.id, text: step.text })}>{step.text}</button>
          <button type="button" aria-label={`Editar ${step.text}`} disabled={Boolean(editing)} onClick={() => setEditing({ id: step.id, text: step.text })}>✎</button>
          <button type="button" aria-label={`Eliminar ${step.text}`} disabled={Boolean(editing)} onClick={() => void onSave(steps.filter((other) => other.id !== step.id))}>×</button>
        </>}
        <SubtaskSchedule parent={{ inboxId: item.id }} stepId={step.id} version={item.updatedAt} disabled={disabled || Boolean(editing)} onBusy={onBusy} onSaved={onScheduled} />
      </div>)}</div>
      <div className="day-subtask-add"><input type="text" maxLength={150} aria-label="Nueva subtarea" placeholder="Añadir subtarea…" value={newText} disabled={Boolean(editing) || steps.length >= 50}
        onChange={(event) => setNewText(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void add(); } }} />
        <button type="button" disabled={!newText.trim() || Boolean(editing) || steps.length >= 50} onClick={() => void add()}>＋ Añadir</button></div>
    </fieldset><p className="form-hint">Los cambios se guardan al momento. Eliminar una subtarea también elimina su evento; Quitar horario conserva la subtarea.</p></section>}
  </details>;
}
