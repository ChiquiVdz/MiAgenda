const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const filename = path.resolve(__dirname, '../src/lib/meal-availability.ts');
const compiled = new Module(filename, module);
compiled._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText, filename);
const { projectMeals } = compiled.exports;
const plan = (id, day, eat, cook = eat, recipeId = 'pasta') => ({
  id, recipeId, servings: eat, cookingEnabled: cook > 0, cookedServings: cook,
  scheduledAt: `2026-10-${String(day).padStart(2, '0')}T12:00:00Z`, completedAt: null, eventMissing: false,
  ingredients: [{ ingredientId: 'egg', name: 'Huevo', unit: 'piece', requiredQuantity: cook, quantityPerServing: 1 }],
});
const batch = (id, portions, recipeKey = 'pasta', day = 1) => ({
  id, recipeKey, originMealPlanId: 'cooked', cookedAt: `2026-10-${String(day).padStart(2,'0')}T10:00:00Z`, remainingServings: portions,
});
const result = (stock, plans, batches=[]) => projectMeals(new Map([['egg',stock]]),plans,batches);
const meal = (projection, id) => projection.meals.find(row => row.id === id);

test('cocinar cuatro y comer dos reserva dos para el día posterior, sin descontar dos veces ingredientes', () => {
  const projection = result(4, [plan('tue', 2, 2, 0), plan('mon', 1, 2, 4)]);
  assert.equal(projection.inventory.get('egg'),0);
  assert.equal(meal(projection,'tue').missingCookServings,0);
  assert.equal(meal(projection,'tue').requiredIngredients[0].requiredQuantity,0);
  assert.equal(meal(projection,'tue').portionAllocations[0].originMealPlanId,'mon');
});
test('editar dos sobras a tres avisa falta cocinar, reserva ingredientes para la próxima comida y no cocina solo', () => {
  const projection = result(1,[plan('tue',2,3,0),plan('wed',3,1)], [batch('b',2)]);
  assert.equal(meal(projection,'tue').missingCookServings,1);
  assert.deepEqual(meal(projection,'tue').missingIngredients,[]);
  assert.equal(meal(projection,'wed').missingIngredients[0].missingQuantity,1);
  assert.equal(projection.portions.find(row=>row.id==='b').remainingServings,0);
});
test('reducir porciones y borrar un plan libera sobras para planes posteriores', () => {
  const reduced=result(0,[plan('tue',2,1,0),plan('wed',3,1,0)],[batch('b',2)]);
  assert.equal(meal(reduced,'wed').missingCookServings,0);
  const deleted=result(0,[plan('wed',3,2,0)],[batch('b',2)]);
  assert.equal(meal(deleted,'wed').missingCookServings,0);
});
test('las mismas sobras no se asignan a dos días y no se mezclan recetas', () => {
  const projection=result(0,[plan('tue',2,2,0),plan('wed',3,2,0),plan('chicken',4,2,0,'chicken')],[batch('b',2)]);
  assert.equal(meal(projection,'tue').missingCookServings,0);
  assert.equal(meal(projection,'wed').missingCookServings,2);
  assert.equal(meal(projection,'chicken').missingCookServings,2);
});
test('las alertas recaen en las fechas más lejanas aunque se cree antes la última', () => {
  const projection=result(4,[plan('late',14,2),plan('early',1,2),plan('middle',7,2)]);
  assert.deepEqual(meal(projection,'early').missingIngredients,[]);
  assert.deepEqual(meal(projection,'middle').missingIngredients,[]);
  assert.equal(meal(projection,'late').missingIngredients[0].missingQuantity,2);
});
test('no permite usar porciones cocinadas en el futuro para una comida anterior', () => {
  assert.equal(meal(result(0,[plan('early',1,2,0)],[batch('b',2,'pasta',2)]),'early').missingCookServings,2);
});
test('completadas y eventos borrados no reservan ingredientes otra vez', () => {
  const done={...plan('done',1,2),completedAt:'2026-10-01'};
  const removed={...plan('removed',2,2),eventMissing:true};
  assert.equal(result(2,[done,removed,plan('pending',3,2)]).inventory.get('egg'),0);
  assert.equal(meal(result(2,[done,removed,plan('pending',3,2)]),'pending').missingIngredients.length,0);
});
test('cocinar parte de las porciones y usar sobras conserva el consumo de ambas fuentes', () => {
  const projection=result(1,[plan('tue',2,3,1)],[batch('b',2)]);
  const uses=meal(projection,'tue').portionAllocations;
  assert.equal(uses.reduce((sum,use)=>sum+use.servings,0),3);
  assert.equal(uses.find(use=>use.actual).servings,2);
  assert.equal(meal(projection,'tue').missingCookServings,0);
});
