const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const filename = path.resolve(__dirname, '../src/lib/calendar-adjustment.ts');
const compiled = new Module(filename, module);
compiled._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText, filename);
const { adjustCalendarTiming, combinedCookingMinutes } = compiled.exports;
const start = Date.parse('2026-10-02T23:45:00-06:00');
const end = start + 45 * 60000;
test('mover conserva duración y cruza medianoche o día correctamente', () => {
  const moved = adjustCalendarTiming(start, end, 'move', 16, 1);
  assert.equal(moved.start, start + (1440 + 15) * 60000);
  assert.equal(moved.end - moved.start, end - start);
});
test('el movimiento ajusta un comienzo irregular sin cambiar su duración', () => {
  const moved = adjustCalendarTiming(start + 4 * 60000, end + 4 * 60000, 'move', 0);
  assert.equal(moved.start, start);
  assert.equal(moved.end - moved.start, 45 * 60000);
});
test('ajustar cualquiera de los bordes mantiene el otro fijo y evita inversión', () => {
  const shorter = adjustCalendarTiming(start, end, 'start', 120);
  assert.equal(shorter.end, end);
  assert.equal(shorter.end - shorter.start, 15 * 60000);
  const endShorter = adjustCalendarTiming(start, end, 'end', -120);
  assert.equal(endShorter.start, start);
  assert.equal(endShorter.end - endShorter.start, 15 * 60000);
});
test('las comidas respetan el límite de ocho horas al ampliar ambos bordes', () => {
  assert.equal(adjustCalendarTiming(start, end, 'start', -900, 0, 480).start, end - 480 * 60000);
  assert.equal(adjustCalendarTiming(start, end, 'end', 900, 0, 480).end, start + 480 * 60000);
});
test('cocina conjunta usa el máximo y la mitad del resto, con redondeo hacia arriba', () => {
  assert.equal(combinedCookingMinutes([5, 10]), 15);
  assert.equal(combinedCookingMinutes([30, 15]), 40);
  assert.equal(combinedCookingMinutes([10, 30, 20]), 45);
  assert.equal(combinedCookingMinutes([20]), 20);
  assert.equal(combinedCookingMinutes([]), 0);
});
