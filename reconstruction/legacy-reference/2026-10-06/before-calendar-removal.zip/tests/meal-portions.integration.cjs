// Explicit opt-in: exercises real PostgreSQL transactions and rolls back all fixtures.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
test('completar/deshacer porciones mantiene inventario, dependencias y retención', { skip: process.env.PORTIONS_DATABASE_TEST !== '1' }, async () => {
  require('dotenv').config({ path: ['.env.local','.env'], quiet: true });
  const originalResolve = Module._resolveFilename;
  const originalTs = require.extensions['.ts'];
  Module._resolveFilename = function(request,parent,...args) {
    if(request==='server-only') return path.resolve(__dirname,'../node_modules/server-only/empty.js');
    if(request.startsWith('@/')) request=path.resolve(__dirname,'../src',request.slice(2));
    return originalResolve.call(this,request,parent,...args);
  };
  require.extensions['.ts'] = (mod,filename) => {
    const source=fs.readFileSync(filename,'utf8').replaceAll('import.meta.url', 'require("node:url").pathToFileURL(__filename).href');
    mod._compile(ts.transpileModule(source,{ compilerOptions:{ module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true } }).outputText,filename);
  };
  const {prisma}=require('../src/lib/prisma.ts');
  const {completeMeal,uncompleteMeal}=require('../src/lib/meal-portions.ts');
  const {mealProjection}=require('../src/lib/meal-state.ts');
  const rollback = new Error('TEST_ROLLBACK');
  try {
    await prisma.$transaction(async tx => {
      const user=await tx.user.create({data:{name:'Prueba temporal de porciones'}});
      const uid=user.id;
      const ingredient=await tx.ingredient.create({data:{ownerUserId:uid,catalogScope:uid,name:'Ingrediente de prueba',normalizedName:'ingrediente prueba',unit:'piece'}});
      const recipe=await tx.recipe.create({data:{userId:uid,name:'Receta temporal',instructions:'Prueba',servings:2}});
      await tx.pantryItem.create({data:{userId:uid,ingredientId:ingredient.id,quantity:8}});
      const create=async (name,day,eat,cook)=>{
        const overlay=await tx.eventOverlay.create({data:{userId:uid,googleCalendarId:'test-calendar',googleEventId:name,kind:'meal'}});
        return tx.mealPlan.create({data:{userId:uid,recipeId:recipe.id,overlayId:overlay.id,googleCalendarId:'test-calendar',googleEventId:name,
          idempotencyKey:name,servings:eat,cookingEnabled:cook>0,cookedServings:cook,durationMinutes:45,scheduledAt:new Date(`2026-10-${String(day).padStart(2,'0')}T12:00:00Z`),
          ingredients:{create:{ingredientId:ingredient.id,nameSnapshot:ingredient.name,unit:'piece',requiredQuantity:cook,quantityPerServing:1}}}});
      };
      const mon=await create('test-mon',1,2,4), tue=await create('test-tue',2,2,0), wed=await create('test-wed',3,1,0);
      const stock=async()=>Number((await tx.pantryItem.findUniqueOrThrow({where:{userId_ingredientId:{userId:uid,ingredientId:ingredient.id}}})).quantity);
      const complete=async id=>{
        await completeMeal(tx,uid,id,new Date());
        await tx.eventOverlay.update({where:{id:(await tx.mealPlan.findUniqueOrThrow({where:{id}})).overlayId},data:{completedAt:new Date()}});
      };
      const undo=async id=>{
        await uncompleteMeal(tx,uid,id);
        await tx.eventOverlay.update({where:{id:(await tx.mealPlan.findUniqueOrThrow({where:{id}})).overlayId},data:{completedAt:null}});
      };
      await complete(mon.id);
      assert.equal(await stock(),4);
      await complete(mon.id); // idempotence: no second batch or deduction
      assert.equal(await stock(),4);
      assert.equal(await tx.cookedBatch.count({where:{userId:uid}}),1);
      await complete(tue.id);
      assert.equal(await stock(),4,'comer sobras no descuenta ingredientes');
      await assert.rejects(uncompleteMeal(tx,uid,mon.id), /comidas posteriores/);
      assert.equal(await stock(),4,'el bloqueo no repone cantidades');
      await undo(tue.id);
      await undo(tue.id);
      const projection=await mealProjection(tx,uid);
      assert.equal(projection.batches[0].remainingServings,2,'deshacer devuelve las porciones una sola vez');
      await tx.mealPlan.update({where:{id:tue.id},data:{servings:3}});
      let next=await mealProjection(tx,uid);
      assert.equal(next.meals.find(row=>row.id===tue.id).missingCookServings,1);
      assert.equal(next.meals.find(row=>row.id===tue.id).missingIngredients.length,0);
      await assert.rejects(completeMeal(tx,uid,tue.id,new Date()),/Falta cocinar/);
      assert.equal(await stock(),4);
      await tx.mealPlan.update({where:{id:tue.id},data:{servings:1}});
      next=await mealProjection(tx,uid);
      assert.equal(next.meals.find(row=>row.id===wed.id).missingCookServings,0,'la reducción libera sobras');
      await complete(tue.id);
      // Purging the consuming calendar event must not return its eaten portion.
      await tx.eventOverlay.delete({where:{id:tue.overlayId}});
      next=await mealProjection(tx,uid);
      assert.equal(next.batches[0].remainingServings,1);
      await assert.rejects(uncompleteMeal(tx,uid,mon.id),/comidas posteriores/);
      // Purging the cooking event preserves both the batch and its actual consumption.
      await tx.eventOverlay.delete({where:{id:mon.overlayId}});
      next=await mealProjection(tx,uid);
      assert.equal(next.batches[0].remainingServings,1);
      assert.equal(next.batches[0].originMealPlanId,null);
      await complete(wed.id);
      assert.equal(await stock(),4);
      await undo(wed.id);
      assert.equal((await mealProjection(tx,uid)).batches[0].remainingServings,1);
      assert.equal(await stock(),4);

      await tx.eventOverlay.delete({where:{id:wed.overlayId}});
      const cook=await create('test-cook-undo',4,1,2);
      await complete(cook.id);
      assert.equal(await stock(),2);
      await undo(cook.id);
      await undo(cook.id);
      assert.equal(await stock(),4,'deshacer cocinada repone exactamente el ledger una vez');
      throw rollback;
    },{timeout:60000});
  } catch(error) { if(error!==rollback) throw error; }
  finally {
    await prisma.$disconnect();
    Module._resolveFilename=originalResolve;
    if(originalTs) require.extensions['.ts']=originalTs; else delete require.extensions['.ts'];
  }
});
