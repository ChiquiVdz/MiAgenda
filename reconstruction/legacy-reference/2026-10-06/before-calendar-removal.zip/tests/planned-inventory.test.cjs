const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const Module = require("node:module");
const ts = require("typescript");

const filename = path.resolve(__dirname, "../src/lib/planned-inventory.ts");
const compiled = new Module(filename, module);
compiled._compile(ts.transpileModule(fs.readFileSync(filename, "utf8"), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText, filename);
const { inventoryAfterPlans, plansWithShortages } = compiled.exports;
const plan = (id, quantity, completedAt = null) => ({ id, completedAt, ingredients: [{ ingredientId: "egg", requiredQuantity: quantity }] });

test("la segunda receta usa solo las existencias no comprometidas por el menú", () => {
  const inventory = new Map([["egg", 4]]);
  assert.equal(inventoryAfterPlans(inventory, [plan("breakfast", 3)]).get("egg"), 1);
  assert.equal(inventory.get("egg"), 4, "planificar no descuenta inventario real");
});

test("varias recetas reservan cantidades acumuladas aunque compartan celda", () => {
  assert.equal(inventoryAfterPlans(new Map([["egg", 7]]), [plan("breakfast", 2), plan("smoothie", 3)]).get("egg"), 2);
});

test("las comidas completadas no vuelven a descontarse de la disponibilidad", () => {
  assert.equal(inventoryAfterPlans(new Map([["egg", 3]]), [plan("completed", 2, "2026-10-01"), plan("pending", 1)]).get("egg"), 2);
});

test("editar libera la reserva previa de la comida para evitar descontarla dos veces", () => {
  assert.equal(inventoryAfterPlans(new Map([["egg", 5]]), [plan("editing", 3), plan("another", 1)], "editing").get("egg"), 4);
});

test("faltantes o exceso de reservas dejan cero disponible sin inventario negativo", () => {
  assert.equal(inventoryAfterPlans(new Map(), [plan("no-stock", 2)]).get("egg"), 0);
  assert.equal(inventoryAfterPlans(new Map([["egg", 1]]), [plan("overbooked", 3)]).get("egg"), 0);
});

test("cantidades decimales no producen faltantes artificiales por redondeo", () => {
  assert.equal(inventoryAfterPlans(new Map([["egg", 0.3]]), [plan("first", 0.1), plan("second", 0.2)]).get("egg"), 0);
});

const scheduled = (id, day, quantity = 3) => ({
  ...plan(id, quantity), startDate: null, startDateTime: `${day}T12:00:00-06:00`,
  ingredients: [{ ingredientId: "egg", name: "Huevo", unit: "piece", requiredQuantity: quantity }],
});
const shortage = (plans, id) => plans.find((item) => item.id === id).missingIngredients;

test("borrar y volver a agregar una comida anterior reactiva el faltante de la última", () => {
  const stock = new Map([["egg", 6]]);
  const first = scheduled("first", "2026-10-01");
  const middle = scheduled("middle", "2026-10-02");
  const last = scheduled("last", "2026-10-03");
  assert.equal(shortage(plansWithShortages(stock, [first, middle, last]), "last")[0].missingQuantity, 3);
  assert.deepEqual(shortage(plansWithShortages(stock, [middle, last]), "last"), []);
  // The earlier meal is created again after the last one.
  const result = plansWithShortages(stock, [middle, last, scheduled("recreated", "2026-10-01")]);
  assert.equal(shortage(result, "last")[0].missingQuantity, 3);
  assert.deepEqual(shortage(result, "recreated"), []);
  assert.equal(stock.get("egg"), 6);
});

test("mover una comida de después a antes traslada la alerta a la comida posterior", () => {
  const original = scheduled("original", "2026-10-02");
  const added = scheduled("added", "2026-10-03");
  const stock = new Map([["egg", 3]]);
  assert.equal(shortage(plansWithShortages(stock, [original, added]), "added")[0].missingQuantity, 3);
  assert.equal(shortage(plansWithShortages(stock, [original, scheduled("added", "2026-10-01")]), "original")[0].missingQuantity, 3);
});

test("el orden considera horas y offsets reales, además de días completos", () => {
  const later = { ...scheduled("later", "2026-10-01"), startDateTime: "2026-10-01T19:00:00Z" };
  const earlier = scheduled("earlier", "2026-10-01");
  const allDay = { ...scheduled("all-day", "2026-10-01"), startDateTime: null, startDate: "2026-10-01" };
  const result = plansWithShortages(new Map([["egg", 6]]), [later, earlier, allDay]);
  assert.deepEqual(result.map((item) => item.id), ["all-day", "earlier", "later"]);
  assert.equal(shortage(result, "later")[0].missingQuantity, 3);
});
