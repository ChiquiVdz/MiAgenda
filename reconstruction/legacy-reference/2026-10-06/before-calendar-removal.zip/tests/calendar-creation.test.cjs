const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');
const filename = path.resolve(__dirname, '../src/lib/calendar-creation.ts');
const compiled = new Module(filename, module);
compiled._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText, filename);
const { nextCalendarStart, calendarSlotTime } = compiled.exports;

test('Crear propone el siguiente cuarto de hora en Ciudad de México', () => {
  assert.deepEqual(nextCalendarStart(new Date('2026-10-02T16:29:00-06:00')), { date: '2026-10-02', time: '16:30' });
  assert.deepEqual(nextCalendarStart(new Date('2026-10-02T16:30:00-06:00')), { date: '2026-10-02', time: '16:30' });
  assert.deepEqual(nextCalendarStart(new Date('2026-10-02T16:30:01-06:00')), { date: '2026-10-02', time: '16:45' });
});
test('redondear al cruzar medianoche cambia también fecha, mes y año', () => {
  assert.deepEqual(nextCalendarStart(new Date('2026-12-31T23:58:00-06:00')), { date: '2027-01-01', time: '00:00' });
});
test('la posición pulsada elige cuartos de hora y nunca sale del día', () => {
  assert.equal(calendarSlotTime(16, 0, 58), '16:00');
  assert.equal(calendarSlotTime(16, 16, 58), '16:15');
  assert.equal(calendarSlotTime(16, 30, 58), '16:30');
  assert.equal(calendarSlotTime(23, 58, 58), '23:45');
  assert.equal(calendarSlotTime(0, -1, 58), '00:00');
  assert.equal(calendarSlotTime(12, 0, 0), '12:00');
});
