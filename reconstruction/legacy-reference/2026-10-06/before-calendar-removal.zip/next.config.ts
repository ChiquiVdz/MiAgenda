import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  logging: { incomingRequests: { ignore: [/\/api\/auth\/callback\//] } },
  turbopack: {
    root: process.cwd(),
  },
};

export default nextConfig;
